# IMP-03 — Bootstrap Painel Admin

## Endereço

`/home/walbarellos/personal-site/personal-site(Graciliano)/Implementacao/IMP-03-bootstrap-painel-admin.md`

## Objetivo

Documentar o bootstrap operacional real de `apps/admin`, incluindo runtime Next.js, controle de sessão server-side, integração com API administrativa e páginas centrais do fluxo editorial.

## Fontes auditadas

- `apps/admin/package.json`
- `apps/admin/app/layout.tsx`
- `apps/admin/app/page.tsx`
- `apps/admin/app/painel/login/page.tsx`
- `apps/admin/app/painel/publicacoes/page.tsx`
- `apps/admin/app/painel/publicacoes/[id]/editar/page.tsx`
- `apps/admin/src/lib/routes.ts`
- `apps/admin/src/lib/session.ts`
- `apps/admin/src/lib/api/admin.ts`
- `APIs/API-07-openapi-admin.yaml`

## Runtime e execução

Stack atual:

- Next.js App Router
- React
- TypeScript

Scripts (`apps/admin/package.json`):

- `dev`: `next dev -p 3001`
- `build`: `next build --webpack`
- `start`: `next start -p 3001`
- `typecheck`: `tsc -p tsconfig.json --noEmit`
- `clean`: `rm -rf .next`

## Bootstrap de layout administrativo

Arquivo: `apps/admin/app/layout.tsx`.

Implementação atual:

- resolve `metadataBase` por `NEXT_PUBLIC_ADMIN_URL` com fallback local
- define metadata com `robots` não indexável
- estrutura shell visual de navegação interna (sidebar/topbar)

Resultado:

- painel nasce com contexto de área interna e metadata apropriada para não indexação.

## Bootstrap de rotas administrativas

Arquivo soberano: `apps/admin/src/lib/routes.ts`.

Capacidades principais:

- constantes de rota administrativa (`entry`, `login`, `dashboard`, `publicacoes`, `editar`)
- builders de href (`buildAdminLoginHref`, `buildAdminPublicationsHref`, `buildAdminPublicationEditHref`)
- sanitização de `next` para evitar redirecionamento inseguro

Resultado:

- redirecionamento pós-login e proteção de retorno ficam centralizados.

## Bootstrap de sessão server-side

Arquivo soberano: `apps/admin/src/lib/session.ts`.

Responsabilidades atuais:

- ler sessão atual da API (`readAdminSession*`)
- exigir sessão com papel permitido (`requireAdminSession*`)
- redirecionar para login quando necessário
- encaminhar cookies e `x-trace-id` em chamadas server-side

Papéis aceitos:

- `admin`
- `editor`

Resultado:

- proteção de acesso não depende só de estado client.

## Bootstrap de integração com API admin

Arquivo soberano: `apps/admin/src/lib/api/admin.ts`.

### 1) Resolução de base URL

Ordem de precedência:

1. `NEXT_PUBLIC_API_URL`
2. `ADMIN_API_URL`
3. `API_URL`
4. fallback `http://localhost:3002`

### 2) Superfícies consumidas

- auth: login, sessão atual, logout
- dashboard
- publicações: listagem, detalhe, criação de rascunho, edição, transição de status

### 3) Resiliência implementada

- validação de payload de sucesso/erro
- erro tipado `AdminApiError` com `status`, `code`, `traceId`, `details`
- suporte a runtime server/client
- tentativa de anexar CSRF em mutações quando aplicável

## Páginas bootstrapadas do painel

### 1) Entrada (`app/page.tsx`)

- tenta ler usuário atual
- autenticado: redireciona para rota protegida
- não autenticado: redireciona para login

### 2) Login (`app/painel/login/page.tsx`)

- valida input de credencial
- verifica sessão existente
- autentica via client admin
- aplica redirect seguro por `next`
- trata feedback de erro de autenticação/validação

### 3) Listagem editorial (`app/painel/publicacoes/page.tsx`)

- exige sessão server-side
- normaliza filtros/paginação
- consome listagem admin
- renderiza casca de listagem com estados operacionais

### 4) Edição editorial (`app/painel/publicacoes/[id]/editar/page.tsx`)

- exige sessão server-side
- busca publicação por id
- persiste edição de conteúdo e SEO
- executa transição de status editorial
- trata feedback e erros de sessão/validação

## Dependência contratual

A camada admin depende da coerência entre:

- OpenAPI admin (`APIs/API-07-openapi-admin.yaml`)
- contratos compartilhados (`packages/contracts`)
- rotas administrativas da API
- client/session do `apps/admin`

Regra do ciclo:

- alteração de contrato deve atravessar essas camadas em conjunto.

## Sequência mínima de bootstrap local

1. configurar `.env` (base em `.env.example`)
2. subir API (`pnpm --filter @william-albarello/api dev`)
3. subir admin (`pnpm --filter @william-albarello/admin dev`)
4. validar entrada, login, listagem e edição

## Checklist mínimo de homologação do painel

1. Entrada redireciona corretamente conforme estado de sessão.
2. Login aceita credenciais válidas e rejeita inválidas com feedback.
3. Leitura de sessão retorna usuário com papel permitido.
4. Listagem de publicações responde com filtros/paginação sem quebra.
5. Edição persiste conteúdo/SEO e retorna feedback consistente.
6. Transição de status respeita regra editorial da API.

## Critérios de aceite deste documento

1. Reflete fluxo real de entrada/sessão/login do `apps/admin`.
2. Mantém coerência com `routes.ts`, `session.ts` e `api/admin.ts`.
3. Não inventa funcionalidades fora do estado físico atual.
4. Permite bootstrap local sem ambiguidade operacional.
