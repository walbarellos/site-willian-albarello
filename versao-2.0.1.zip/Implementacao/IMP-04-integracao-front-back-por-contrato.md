# IMP-04 — Integração Front-Back por Contrato

## Endereço

`/home/walbarellos/personal-site/personal-site(Graciliano)/Implementacao/IMP-04-integracao-front-back-por-contrato.md`

## Objetivo

Documentar como a integração entre backend, web e admin é governada por contrato no estado atual do monorepo.

## Fontes auditadas

- `packages/contracts/src/index.ts`
- `packages/contracts/src/routes.ts`
- `packages/contracts/src/session.ts`
- `packages/contracts/src/publications.ts`
- `APIs/API-06-openapi-public.yaml`
- `APIs/API-07-openapi-admin.yaml`
- `apps/api/src/lib/http-contract.ts`
- `apps/api/src/routes/publications-public.ts`
- `apps/api/src/routes/publications-admin.ts`
- `apps/api/src/routes/auth.ts`
- `apps/web/src/lib/api/public.ts`
- `apps/admin/src/lib/api/admin.ts`

## Princípio soberano

A integração só é considerada válida quando estas camadas permanecem coerentes:

1. contracts compartilhados (`packages/contracts`)
2. OpenAPI público/admin (`APIs/API-06` e `APIs/API-07`)
3. implementação da API (`apps/api`)
4. client público (`apps/web/src/lib/api/public.ts`)
5. client admin (`apps/admin/src/lib/api/admin.ts`)

Mudança isolada em qualquer camada gera risco de quebra contratual.

## Camada de contracts

Arquivos centrais:

- `session.ts`
- `publications.ts`
- `routes.ts`
- barrel em `index.ts`

Responsabilidades atuais:

- tipos de sessão (`AdminSessionUser`, `SuccessSessionResponse`, `ApiErrorResponse`)
- tipos editoriais (`AdminPublication`, `PublicPublicationDetail`, filtros, transição de status)
- constantes e builders de rota (`WEB_PUBLIC_ROUTES`, `ADMIN_APP_ROUTES`, `API_PUBLIC_ROUTES`, `API_ADMIN_*`)

## Camada OpenAPI

Público (`API-06`):

- health/ready
- listagem pública
- detalhe público por slug

Admin (`API-07`):

- login/sessão/logout
- dashboard
- listagem, detalhe, criação, edição e transição de publicações

Função:

- manter contrato HTTP explícito e auditável além da tipagem interna.

## Camada API (producer)

Base de envelope: `apps/api/src/lib/http-contract.ts`.

Formato padrão:

- sucesso: `data + meta.traceId`
- sucesso paginado: `data[] + paginação + meta.traceId`
- erro: `error.code + error.message + error.details? + meta.traceId`

Implicação:

- web e admin tratam respostas por contrato estável, não por parsing ad hoc.

## Camada web (consumer público)

Arquivo: `apps/web/src/lib/api/public.ts`.

Pontos contratuais implementados:

- usa `API_PUBLIC_ROUTES` dos contracts
- valida shape de sucesso e erro em runtime
- transforma falhas em `PublicApiError`
- preserva `status`, `code`, `traceId` e `details`

## Camada admin (consumer administrativo)

Arquivo: `apps/admin/src/lib/api/admin.ts`.

Pontos contratuais implementados:

- usa `API_ADMIN_AUTH_ROUTES` e `API_ADMIN_ROUTES`
- valida payload de sessão/dashboard/publicações em runtime
- transforma falhas em `AdminApiError`
- preserva `status`, `code`, `traceId` e `details`

## Fluxos contratuais principais

### 1) Fluxo público de publicação

1. web monta URL por routes/contracts
2. web chama endpoint público
3. API responde envelope padrão
4. web valida payload e renderiza

### 2) Fluxo de autenticação admin

1. admin envia login por contrato
2. API valida e cria sessão
3. admin lê sessão atual
4. camada server-side decide redirecionamento e acesso

### 3) Fluxo editorial admin

1. admin lista/edita/transiciona publicação
2. API valida payload e regra de negócio
3. resposta retorna `traceId` e código contratual
4. admin aplica feedback consistente

## Ordem obrigatória para mudanças contratuais

1. atualizar `packages/contracts`
2. atualizar rotas e handlers em `apps/api`
3. atualizar OpenAPI correspondente
4. atualizar clients (`web`/`admin`)
5. executar validação técnica e homologação mínima

Não inverter essa ordem.

## Riscos de quebra mais comuns

- rota alterada sem atualizar helper em contracts
- payload alterado sem atualizar validator do client
- código de erro alterado sem atualizar tratamento de UI
- OpenAPI desatualizado frente ao código real

## Checklist mínimo de validação contratual

1. `pnpm run verify:hardening` verde.
2. endpoints públicos respondem no shape esperado.
3. endpoints admin respondem no shape esperado.
4. clients web/admin não geram `INVALID_RESPONSE_SHAPE` em fluxo nominal.
5. erros retornam `meta.traceId` e código contratual esperado.

## Critérios de aceite deste documento

1. Descreve integração real entre contracts/OpenAPI/API/clients.
2. Reflete arquivos físicos atuais do monorepo.
3. Define ordem de mudança contratual sem ambiguidade.
4. Evita regras genéricas não implementadas no projeto.
