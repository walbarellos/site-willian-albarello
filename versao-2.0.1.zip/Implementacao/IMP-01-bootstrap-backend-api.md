# IMP-01 — Bootstrap Backend API

## Endereço

`/home/walbarellos/personal-site/personal-site(Graciliano)/Implementacao/IMP-01-bootstrap-backend-api.md`

## Objetivo

Documentar o bootstrap operacional real de `apps/api` para execução local, validação técnica e integração com `apps/web` e `apps/admin`.

## Fontes auditadas

- `apps/api/src/index.ts`
- `apps/api/src/server.ts`
- `apps/api/src/lib/env.ts`
- `apps/api/src/lib/http-contract.ts`
- `apps/api/src/routes/auth.ts`
- `apps/api/src/routes/dashboard.ts`
- `apps/api/src/routes/health.ts`
- `apps/api/src/routes/publications-public.ts`
- `apps/api/src/routes/publications-admin.ts`
- `apps/api/package.json`
- `apps/api/tsconfig.json`
- `APIs/API-06-openapi-public.yaml`
- `APIs/API-07-openapi-admin.yaml`

## Entrypoint do processo

Arquivo: `apps/api/src/index.ts`.

Fluxo atual:

1. carrega `env`
2. cria app via `buildServer()`
3. registra shutdown handlers (`SIGINT`, `SIGTERM`, `unhandledRejection`, `uncaughtException`)
4. sobe servidor em `0.0.0.0:${env.PORT}`

Comportamento de shutdown:

- tenta `app.close()`
- loga sucesso/falha de encerramento
- encerra processo com código apropriado

## Construção do servidor

Arquivo: `apps/api/src/server.ts`.

### 1) Configuração base Fastify

- logger com `service=api` e redaction de headers sensíveis
- `trustProxy` em produção
- `requestIdHeader: x-trace-id`
- valida `x-trace-id` de entrada e gera UUID em fallback

### 2) Plugins core

- `@fastify/cors`
- `@fastify/cookie`
- `@fastify/csrf-protection`
- `@fastify/rate-limit`

### 3) Hooks globais

- `onRequest`: headers de segurança + `x-trace-id`
- `onSend`: `no-store/no-cache` para `/health`, `/ready` e `/v1/admin/*`
- `onResponse`: log estruturado (`traceId`, método, rota, status, latência)

### 4) Error handling global

- `setNotFoundHandler` com envelope `NOT_FOUND`
- `setErrorHandler` com mapeamento de códigos contratuais (`VALIDATION_ERROR`, `RATE_LIMITED`, `CSRF_INVALID_TOKEN`, etc.)
- separa log de erro esperado (`4xx`) e inesperado (`5xx`)

## Registro de rotas

Ordem atual de registro:

1. `healthRoutes`
2. `authRoutes`
3. `dashboardRoutes`
4. `publicPublicationsRoutes`
5. `adminPublicationsRoutes`

Superfícies principais:

- `/health`
- `/ready`
- `/v1/admin/auth/*`
- `/v1/admin/dashboard`
- `/v1/public/publications`
- `/v1/public/publications/:slug`
- `/v1/admin/publications*`

## Contrato HTTP da API

Arquivo: `apps/api/src/lib/http-contract.ts`.

Padrão atual:

- sucesso: `data` + `meta.traceId`
- sucesso paginado: `data[]` + metadados de paginação + `meta.traceId`
- erro: `error.code`, `error.message`, `error.details?` + `meta.traceId`

Implicação:

- clients (`apps/admin`, `apps/web`) e OpenAPI dependem deste envelope estável

## Ambiente e validação de configuração

Arquivo: `apps/api/src/lib/env.ts`.

Regras de bootstrap relevantes:

- validação com Zod e fail-fast
- `PORT` obrigatório/normalizado
- `SESSION_SECRET` com restrição de segurança
- URLs e `CORS_ORIGINS` validados
- regra mais estrita fora de development

## Build e execução

Scripts em `apps/api/package.json`:

- `dev`: `tsx watch src/index.ts`
- `build`: `tsc -p tsconfig.json`
- `start`: `node dist/index.js`
- `typecheck`: `tsc -p tsconfig.json --noEmit`
- `clean`: `rm -rf dist`

Tsconfig (`apps/api/tsconfig.json`):

- `module`/`moduleResolution`: `NodeNext`
- `rootDir: ./src`
- `outDir: ./dist`

## Sequência mínima de bootstrap local

1. configurar `.env` (base em `.env.example`)
2. `pnpm install` na raiz
3. `pnpm --filter @william-albarello/api dev`
4. validar `/health` e `/ready`

## Checklist de homologação mínima da API

1. `GET /health` retorna `200` com `meta.traceId`.
2. `GET /ready` retorna `200` (ou `503` com envelope padrão quando aplicável).
3. login admin responde com cookie de sessão e payload de sessão.
4. leitura de sessão admin responde `200` quando autenticado e `401 SESSION_EXPIRED` sem sessão.
5. listagem pública e detalhe por slug respondem envelope contratual válido.
6. listagem/admin edit/status respeitam autenticação e autorização.

## Relação com contratos externos

- OpenAPI público: `APIs/API-06-openapi-public.yaml`
- OpenAPI admin: `APIs/API-07-openapi-admin.yaml`

Regra do ciclo:

- mudança de rota/shape no backend exige atualização coordenada de contracts + OpenAPI + clients.

## Critérios de aceite deste documento

1. Reflete o bootstrap atual de `index.ts` e `server.ts`.
2. Lista plugins/hooks/handlers realmente registrados.
3. Mantém coerência com scripts e tsconfig da API.
4. Permite subida e verificação local sem ambiguidade.
