# IMP-02 — Bootstrap Frontend Público

## Endereço

`/home/walbarellos/personal-site/personal-site(Graciliano)/Implementacao/IMP-02-bootstrap-frontend-publico.md`

## Objetivo

Documentar o bootstrap operacional real de `apps/web`, incluindo runtime Next.js, rotas públicas, integração contratual com API pública e validação mínima de funcionamento.

## Fontes auditadas

- `apps/web/package.json`
- `apps/web/app/layout.tsx`
- `apps/web/app/page.tsx`
- `apps/web/app/publicacoes/page.tsx`
- `apps/web/app/publicacoes/[slug]/page.tsx`
- `apps/web/src/lib/routes.ts`
- `apps/web/src/lib/api/public.ts`
- `APIs/API-06-openapi-public.yaml`

## Runtime e execução

Stack atual:

- Next.js App Router
- React
- TypeScript

Scripts (`apps/web/package.json`):

- `dev`: `next dev -p 3000`
- `build`: `next build`
- `start`: `next start -p 3000`
- `typecheck`: `tsc -p tsconfig.json --noEmit`
- `clean`: `rm -rf .next`

## Bootstrap de layout público

Arquivo: `apps/web/app/layout.tsx`.

Implementação atual:

- define `metadataBase` usando `NEXT_PUBLIC_SITE_URL` com fallback local
- configura metadata global (`title`, `description`, Open Graph, Twitter, robots)
- mantém shell visual público com header/footer

Resultado:

- app público nasce com base de metadata e navegação consistentes.

## Bootstrap de rotas públicas

Arquivo soberano: `apps/web/src/lib/routes.ts`.

Rotas principais:

- `WEB_PUBLIC_ROUTES.home` → `/`
- `WEB_PUBLIC_ROUTES.publications` → `/publicacoes`
- `WEB_PUBLIC_ROUTES.publicationDetail(slug)` → `/publicacoes/:slug`

Helpers:

- `buildPublicationsHref(query)`
- `buildPublicationDetailHref(slug)`

Regras embutidas:

- normalização de slug
- normalização de paginação (`page`, `pageSize`)
- serialização segura de query string

## Bootstrap de integração com API pública

Arquivo soberano: `apps/web/src/lib/api/public.ts`.

### 1) Resolução de base URL

Ordem de precedência:

1. `NEXT_PUBLIC_API_URL`
2. `PUBLIC_API_URL`
3. `API_URL`
4. fallback `http://localhost:3002`

### 2) Operações principais

- `listPublications(query, init?)`
- `getPublicationBySlug(slug, init?)`

### 3) Resiliência implementada

- validação de payload de sucesso
- validação de envelope de erro
- erro tipado `PublicApiError` com `status`, `code`, `traceId`, `details`
- códigos técnicos explícitos (`NETWORK_ERROR`, `INVALID_CONTENT_TYPE`, `INVALID_RESPONSE_SHAPE`)

## Páginas públicas bootstrapadas

### 1) Home (`app/page.tsx`)

- canonical explícito da rota `/`
- busca destaques com `listPublications`
- `revalidate = 300`

### 2) Listagem (`app/publicacoes/page.tsx`)

- metadata com canonical de `/publicacoes`
- busca e paginação por query params
- tratamento de estados via leitura de API/erro
- `revalidate = 300`

### 3) Detalhe (`app/publicacoes/[slug]/page.tsx`)

- metadata dinâmica por publicação
- prioriza campos SEO vindos da API (`metaTitle`, `metaDescription`, `canonicalUrl`, `og*`)
- `notFound` para `404`/`422`
- fallback seguro em erro operacional
- `revalidate = 300`

## Dependência contratual

A camada pública depende da coerência entre:

- API pública (`apps/api/src/routes/publications-public.ts`)
- OpenAPI público (`APIs/API-06-openapi-public.yaml`)
- contratos compartilhados (`packages/contracts`)
- client público (`apps/web/src/lib/api/public.ts`)

Regra do ciclo:

- mudança de shape de dados exige atualização coordenada nessas camadas.

## Sequência mínima de bootstrap local

1. configurar `.env` (base em `.env.example`)
2. garantir API ativa (`pnpm --filter @william-albarello/api dev`)
3. subir web (`pnpm --filter @william-albarello/web dev`)
4. validar `/`, `/publicacoes` e `/publicacoes/[slug]`

## Checklist mínimo de homologação pública

1. Home carrega com metadata base e canonical corretos.
2. Listagem responde busca/paginação sem quebrar contrato.
3. Detalhe por slug válido renderiza conteúdo e metadata dinâmico.
4. Slug inválido retorna comportamento de não encontrado.
5. Falha de API produz erro tipado sem crash de runtime.

## Critérios de aceite deste documento

1. Reflete rotas/helpers/client realmente implementados.
2. Mantém coerência com runtime Next.js atual do `apps/web`.
3. Não inventa telas ou fluxos fora do estado físico.
4. Permite bootstrap local sem ambiguidade operacional.
