# UIUX-02 — Design System Base

## Endereço

`/home/walbarellos/personal-site/personal-site(Graciliano)/UI_UX/UIUX-02-design-system-base.md`

## Objetivo

Documentar a base de design system **já materializada** em `packages/ui` e em seu consumo por admin/web.

## Fontes auditadas

- `packages/ui/src/index.ts`
- `packages/ui/src/components/admin/admin-page-shell.tsx`
- `packages/ui/src/components/admin/admin-page-header.tsx`
- `packages/ui/src/components/admin/admin-section-card.tsx`
- `packages/ui/src/components/admin/admin-support-block.tsx`
- `packages/ui/src/components/feedback/alert-banner.tsx`
- `packages/ui/src/components/feedback/empty-state.tsx`
- `packages/ui/src/components/feedback/status-badge.tsx`

## Escopo

Incluído:

- componentes base disponíveis no pacote UI
- semântica visual e de feedback já implementada
- padrões de layout e composição reutilizáveis

Fora do escopo neste ciclo:

- token system centralizado em arquivo único
- tema multi-brand
- dark mode oficial
- design tokens automatizados por build

## Arquitetura atual do pacote UI

Barrel soberano: `packages/ui/src/index.ts`.

Exports administrativos:

- `AdminPageShell`
- `AdminPageHeader`
- `AdminSectionCard`
- `AdminSupportBlock`

Exports de feedback:

- `AlertBanner`
- `EmptyState`
- `StatusBadge`

Leitura operacional:

- o design system atual é pequeno, pragmático e orientado a reuso imediato.

## Padrões de composição administrativa

### 1) `AdminPageShell`

- contêiner de largura máxima (default `1280`)
- centraliza layout horizontal

### 2) `AdminPageHeader`

- título e descrição
- badge contextual opcional (`eyebrow`)
- metadados em cards (`meta`)
- área de ações (`actions`)

### 3) `AdminSectionCard`

- bloco de seção com `padding`, `radius`, `border` e `shadow` parametrizáveis
- padrão default aplicado em telas administrativas

### 4) `AdminSupportBlock`

- bloco auxiliar com título + conteúdo
- tons suportados: `neutral`, `info`, `success`, `warning`, `danger`

## Padrões de feedback reutilizável

### 1) `AlertBanner`

- mensagens contextuais com tom semântico
- tons: `info`, `success`, `warning`, `danger`, `neutral`
- acessibilidade:
  - `role="alert"` para `warning`/`danger`
  - `role="status"` para demais tons

### 2) `EmptyState`

- estado vazio com `title`, `description` e `action` opcional
- padrão de card neutro para ausência de dados

### 3) `StatusBadge`

- badge de estado curto
- tons: `neutral`, `info`, `success`, `warning`, `danger`

## Semântica visual observada

Paleta recorrente no pacote:

- informação: azul (`#175cd3`, `#1d4ed8`, `#eef4ff`, `#d5e3ff`)
- sucesso: verde (`#067647`, `#ecfdf3`, `#abefc6`)
- atenção: laranja (`#9a3412`, `#fff6ed`, `#fed7aa`)
- erro: vermelho (`#b42318`, `#fef3f2`, `#fecdca`)
- neutro: cinzas institucionais (`#101828`, `#475467`, `#e4e7ec`, `#f8fafc`)

Padrões de forma:

- blocos principais com raio entre `18` e `24`
- badges com raio `999`
- sombra institucional suave (`0 12px 32px rgba(16, 24, 40, 0.04~0.06)`)

## Diretriz de uso no projeto

Admin:

- usar `AdminPageShell` + `AdminPageHeader` como estrutura principal
- usar `AdminSectionCard` para separar áreas funcionais
- usar `AlertBanner` e `StatusBadge` para feedback e estado editorial

Web público:

- usar componentes de feedback sem inflar a UI
- preservar foco editorial e legibilidade da página pública

## Governança de evolução

Regra do ciclo:

- antes de criar novo componente, validar se os blocos atuais cobrem o caso
- novo componente só entra quando houver repetição real em mais de um contexto

## Critérios de aceite deste baseline

1. Documento reflete apenas componentes exportados em `packages/ui/src/index.ts`.
2. Tons semânticos documentados batem com implementações reais.
3. Regras de composição admin/feedback são compatíveis com o uso no projeto.
4. Não há padrão visual inventado fora do código atual.

## Riscos residuais aceitos

- ausência de tokens centralizados em camada única
- ausência de documentação automatizada de componentes

Esses pontos seguem para ciclo posterior de maturidade de design system.
