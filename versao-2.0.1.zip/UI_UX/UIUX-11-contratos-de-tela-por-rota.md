# UIUX-11 — Contratos de Tela por Rota

## Endereço

`/home/walbarellos/personal-site/personal-site(Graciliano)/UI_UX/UIUX-11-contratos-de-tela-por-rota.md`

## Status do arquivo no estado atual

**Existente e preenchido.**
Este documento materializa o contrato soberano entre **rota → tela → dados → estados → navegação → permissão** do projeto `personal-site`.

---

# 1. Finalidade do documento

Este documento define os **contratos de tela por rota** do projeto `personal-site`, com o objetivo de alinhar:

* `apps/web`
* `apps/admin`
* `apps/api`
* `packages/contracts`

Ele não descreve apenas layout.
Ele descreve o **comportamento esperado da tela** em função da rota que a origina, dos dados que ela depende, da permissão exigida, dos estados de erro, dos estados vazios e da ação principal esperada do usuário.

A função soberana deste documento é impedir que:

* a rota entregue um shape que a tela não espera;
* a tela espere um dado que a API não fornece;
* a navegação se torne implícita ou contraditória;
* o usuário fique sem feedback previsível;
* o admin continue acumulando ambiguidade estrutural.

---

# 2. Princípios soberanos dos contratos de tela

## 2.1 Cada rota deve ter uma finalidade inequívoca

Uma rota existe para cumprir uma função principal, e não para concentrar múltiplas intenções vagas.

## 2.2 Cada tela deve saber exatamente de quais dados depende

Toda tela deve declarar explicitamente:

* dados mínimos obrigatórios;
* dados enriquecedores opcionais;
* dependência de sessão;
* dependência de API;
* dependência de query params;
* dependência de path params.

## 2.3 Estados vazios e estados de erro fazem parte do contrato

Uma tela só está completa quando seus estados de ausência, falha e restrição também estão definidos.

## 2.4 Navegação é parte do contrato

Cada rota precisa declarar:

* como o usuário entra;
* o que pode fazer nela;
* para onde pode seguir;
* quando deve ser redirecionado.

## 2.5 Permissão não pode ficar implícita

Toda rota deve deixar claro se é:

* pública
* protegida por sessão
* protegida por papel
* protegida por contexto funcional

---

# 3. Matriz resumida das rotas cobertas

| Rota                              | Aplicação | Tipo                              | Permissão                                                      |
| --------------------------------- | --------- | --------------------------------- | -------------------------------------------------------------- |
| `/`                               | web       | pública institucional             | pública                                                        |
| `/publicacoes`                    | web       | pública editorial                 | pública                                                        |
| `/publicacoes/[slug]`             | web       | pública editorial detalhada       | pública                                                        |
| `/`                               | admin     | entrada inteligente do painel     | protegida por lógica de sessão/redirecionamento                |
| `/painel/login`                   | admin     | autenticação administrativa       | pública para não autenticado / redirecionável para autenticado |
| `/painel/publicacoes`             | admin     | listagem editorial administrativa | `admin` ou `editor`                                            |
| `/painel/publicacoes/[id]/editar` | admin     | edição editorial administrativa   | `admin` ou `editor`                                            |

---

# 4. Contrato de tela por rota

---

## 4.1 Rota pública inicial

### Rota

`/`

### Aplicação

`apps/web`

### Tipo de tela

Home pública institucional

### Objetivo da tela

Apresentar a presença institucional do projeto e orientar o usuário para:

* compreender quem é William Albarello no contexto do site;
* entender a proposta editorial/institucional;
* acessar a área pública de publicações;
* reconhecer consistência e credibilidade da presença digital.

### Papel da rota no sistema

Esta é a **porta pública principal** do projeto.
Ela não é apenas uma “landing page”; ela é o ponto de entrada da narrativa institucional e a camada inicial de descoberta do ecossistema editorial.

### Dados necessários

#### Obrigatórios

* metadados básicos da página
* blocos de conteúdo institucional estático
* links internos principais
* destaques editoriais, se a home exibir publicações em destaque

#### Opcionais

* cards de publicações recentes
* resumos editoriais
* métricas públicas ou sinais de prova social

### Loaders esperados

* skeleton ou placeholder discreto apenas se houver dependência de dados assíncronos
* evitar loading agressivo que quebre a sensação de estabilidade institucional

### Estado vazio

A home não deve “quebrar” se não houver publicações em destaque.
Nesse caso:

* a narrativa institucional continua aparecendo;
* o bloco editorial pode exibir mensagem discreta do tipo:

  * “As publicações serão disponibilizadas em breve.”

### Estados de erro

#### Erro leve

Falha ao carregar bloco complementar de publicações:

* a home permanece funcional;
* esconder o bloco dinâmico ou substituí-lo por fallback institucional.

#### Erro grave

Falha estrutural da página:

* exibir erro genérico institucional;
* preservar cabeçalho, rodapé e possibilidade de navegação.

### CTA principal

**Explorar publicações**
CTA secundário possível:

* conhecer o projeto
* navegar pelo conteúdo público

### Dependência de API

**Baixa a média**, dependendo de a home consumir ou não destaques editoriais.

Se consumir:

* depende de endpoint público de publicações.

Se não consumir:

* pode operar integralmente com conteúdo estático.

### Permissão

**Pública**

### Critério de navegação

O usuário deve conseguir:

* entrar sem autenticação;
* compreender o projeto em poucos blocos;
* seguir para `/publicacoes` de forma clara;
* nunca cair em beco sem saída.

### Estrutura visual obrigatória (estado atual consolidado)

Para manter legibilidade e evitar regressão visual, a Home pública deve respeitar:

* hero com fundo claro institucional (não usar bloco escuro dominante como padrão);
* contraste alto entre título/descrição e o fundo do hero;
* painel lateral “Direção de presença” com altura de conteúdo (`fit-content`), sem esticar artificialmente;
* grid do hero com alinhamento em `start`, evitando cards altos por estiramento;
* blocos de apoio do hero com densidade visual leve (cards brancos e bordas neutras).

### Critério de aceite funcional da rota

A rota está correta quando:

* abre sem exigir autenticação;
* apresenta narrativa institucional coerente;
* possui CTA claro para a camada editorial;
* não depende criticamente de dados frágeis para renderizar;
* mantém legibilidade em todo o hero sem texto “sumindo” por contraste inadequado;
* mantém o painel lateral compacto e proporcional ao conteúdo.

---

## 4.2 Listagem pública de publicações

### Rota

`/publicacoes`

### Aplicação

`apps/web`

### Tipo de tela

Listagem pública editorial

### Objetivo da tela

Permitir descoberta e navegação pública entre conteúdos publicados.

### Papel da rota no sistema

É a **porta editorial pública principal** do projeto.

### Dados necessários

#### Obrigatórios

* lista de publicações públicas
* paginação
* `title`
* `slug`
* `summary`
* `publishedAt`
* categoria, quando existir
* tags, quando existirem

#### Opcionais

* reading time
* total geral destacado na UI
* filtros complementares

### Query params previstos

* `page`
* `pageSize`
* `category`
* `tag`
* `q`

### Loaders esperados

* estado de carregamento inicial da listagem
* loader discreto ao trocar filtros/página
* preservar estrutura da página para evitar salto visual

### Estado vazio

Quando não houver publicações para o filtro aplicado:

* mostrar mensagem clara de ausência de resultados;
* manter campo de busca e controles de filtro visíveis;
* oferecer retorno ao estado sem filtro.

Exemplo de mensagem:

* “Nenhuma publicação encontrada para os filtros atuais.”

### Estados de erro

#### 422

Query inválida:

* exibir mensagem amigável;
* preferencialmente resetar para filtros válidos.

#### 500

Erro inesperado:

* mostrar fallback institucional:

  * “Não foi possível carregar as publicações no momento.”

#### 429

Rate limit:

* informar que houve excesso de requisições e orientar tentativa posterior.

### CTA principal

**Abrir publicação**
CTA secundário:

* limpar filtros
* voltar para a home

### Dependência de API

**Alta**

Endpoint dependente:

* `GET /v1/public/publications`

### Permissão

**Pública**

### Critério de navegação

O usuário deve conseguir:

* chegar pela home ou por URL direta;
* buscar, filtrar e paginar sem quebrar a navegação;
* abrir o detalhe por slug;
* retornar à listagem sem perder coerência funcional.

### Estrutura visual obrigatória (estado atual consolidado)

Para manter consistência e evitar layout “espalhado”, a listagem pública deve respeitar:

* container central com largura máxima (`max-width`) e `padding` horizontal consistente;
* barra de busca dentro de card próprio, alinhada com o mesmo grid da listagem;
* cabeçalho de resultados, grid de cards e paginação na mesma coluna estrutural;
* ausência de elementos full-width desalinhados em relação ao conteúdo principal.

### Critério de aceite funcional da rota

A rota está correta quando:

* lista somente conteúdos públicos;
* respeita filtros e paginação;
* trata vazio e erro de forma previsível;
* conduz o usuário naturalmente ao detalhe por slug;
* mantém proporção visual limpa, sem quebras de alinhamento entre busca, resultados e paginação.

---

## 4.3 Detalhe público de publicação

### Rota

`/publicacoes/[slug]`

### Aplicação

`apps/web`

### Tipo de tela

Detalhe editorial público

### Objetivo da tela

Exibir integralmente uma publicação pública específica.

### Papel da rota no sistema

É a **rota editorial pública mais importante** do projeto, pois nela a promessa institucional vira conteúdo efetivo.

### Dados necessários

#### Obrigatórios

* `title`
* `slug`
* `summary`
* `content`
* `publishedAt`
* SEO fields mínimos quando disponíveis
* categoria/tags quando existirem

#### Opcionais

* reading time
* related content
* breadcrumb
* CTA de retorno à listagem

### Path params previstos

* `slug`

### Loaders esperados

* loading inicial do detalhe
* fallback de carregamento apenas enquanto a publicação estiver sendo resolvida

### Estado vazio

Não há “vazio” clássico aqui.
O equivalente funcional é:

* slug não encontrado
* slug não publicado
* conteúdo indisponível

### Estados de erro

#### 404

Slug inexistente ou não publicado:

* renderizar not found claro;
* permitir retorno para `/publicacoes`.

#### 422

Slug inválido:

* tratar como rota inválida/not found amigável.

#### 500

Erro inesperado:

* exibir fallback editorial institucional.

### CTA principal

**Voltar para publicações**
CTAs secundários possíveis:

* navegar para outro conteúdo
* voltar para a home

### Dependência de API

**Alta**

Endpoint dependente:

* `GET /v1/public/publications/{slug}`

### Permissão

**Pública**

### Critério de navegação

O usuário deve conseguir:

* chegar pela listagem ou por link direto;
* ler o conteúdo com estabilidade visual;
* voltar para a listagem sem fricção;
* entender quando a publicação não existe.

### Critério de aceite funcional da rota

A rota está correta quando:

* resolve `slug` válido;
* exibe conteúdo publicado;
* trata 404 com dignidade;
* não mistura estado público com lógica administrativa.

---

## 4.4 Entrada do painel

### Rota

`/`

### Aplicação

`apps/admin`

### Tipo de tela

Entry point inteligente do painel

### Objetivo da tela

Tomar a decisão inicial de navegação administrativa:

* enviar autenticado para a área interna;
* enviar não autenticado para o login.

### Papel da rota no sistema

Funciona como **roteador de entrada**, não como tela rica em conteúdo.

### Dados necessários

#### Obrigatórios

* leitura da sessão atual
* definição da rota-alvo pós-checagem

#### Opcionais

* none

### Loaders esperados

* idealmente nenhum loader visual pesado
* essa rota deve resolver rapidamente por lógica de sessão e redirect

### Estado vazio

Não aplicável como estado de conteúdo.

### Estados de erro

#### Sessão inconsistente

* redirecionar para login
* evitar tela quebrada

#### Falha temporária ao ler sessão

* tratar como não autenticado com segurança
* enviar para `/painel/login`

### CTA principal

Não há CTA de conteúdo.
A função principal é **redirecionar**.

### Dependência de API

**Média**

* depende de leitura consistente da sessão
* pode depender de `/v1/admin/auth/session`, conforme implementação

### Permissão

Híbrida:

* acessível como entrada
* seu resultado depende da sessão

### Critério de navegação

A rota deve:

* nunca deixar o usuário preso;
* decidir com rapidez e clareza;
* evitar intermitência visual desnecessária;
* encaminhar corretamente para:

  * `/painel/publicacoes` ou área interna equivalente
  * `/painel/login`

### Critério de aceite funcional da rota

A rota está correta quando:

* não exibe erro de import/export quebrado;
* usa helpers reais de sessão/rota;
* redireciona com consistência.

---

## 4.5 Login admin

### Rota

`/painel/login`

### Aplicação

`apps/admin`

### Tipo de tela

Autenticação administrativa

### Objetivo da tela

Permitir o login administrativo bootstrap com clareza, previsibilidade e feedback correto.

### Papel da rota no sistema

É a **porta de entrada segura do painel**.

### Dados necessários

#### Obrigatórios

* formulário com `email`
* formulário com `password`
* destino de redirecionamento pós-login
* leitura de estado de autenticação atual

#### Opcionais

* mensagem contextual de sessão expirada
* mensagem de retorno de rota protegida

### Loaders esperados

* loading no submit
* bloqueio temporário do botão durante envio
* feedback visual claro de processamento

### Estado vazio

Não aplicável como conteúdo, mas a tela deve abrir limpa e pronta para preenchimento.

### Estados de erro

#### 401

Credenciais inválidas:

* mensagem clara e objetiva
* não apagar o email digitado

#### 422

Payload inválido:

* validar campos localmente e/ou refletir erro da API

#### 403

Possível erro de CSRF/permissão:

* mostrar mensagem administrativa segura
* orientar nova tentativa

#### 500

Erro inesperado:

* mensagem genérica institucional:

  * “Não foi possível concluir o login no momento.”

### CTA principal

**Entrar no painel**

### Dependência de API

**Alta**

Endpoints dependentes:

* `POST /v1/admin/auth/login`
* eventualmente `GET /v1/admin/auth/session` para checar sessão prévia

### Permissão

* acessível para não autenticado
* autenticado deve ser redirecionado para área interna

### Critério de navegação

O usuário deve conseguir:

* chegar por redirect protegido ou acesso direto;
* autenticar-se;
* ir para o destino correto após sucesso;
* ser impedido de permanecer no login se já estiver autenticado.

### Critério de aceite funcional da rota

A rota está correta quando:

* valida os campos principais;
* envia login para a API correta;
* mostra erro sem ambiguidade;
* redireciona corretamente após sucesso;
* não depende de helpers inexistentes.

---

## 4.6 Listagem admin de publicações

### Rota

`/painel/publicacoes`

### Aplicação

`apps/admin`

### Tipo de tela

Listagem editorial administrativa

### Objetivo da tela

Permitir que o usuário administrativo:

* visualize publicações existentes;
* busque;
* filtre por status;
* abra a edição de um item;
* entenda o estado editorial do acervo.

### Papel da rota no sistema

É a **tela operacional central do CMS administrativo**.

### Dados necessários

#### Obrigatórios

* lista paginada de publicações administrativas
* `id`
* `title`
* `slug`
* `status`
* `updatedAt`
* resumo mínimo editorial
* paginação
* filtros de busca e status

#### Opcionais

* categoria
* tags
* publishedAt
* reading time
* contadores visuais por status

### Query params previstos

* `page`
* `pageSize`
* `q`
* `status`

### Loaders esperados

* loading inicial da tabela/lista
* loading de atualização ao mudar filtro
* loading de paginação
* loaders parciais preferíveis a bloquear a tela inteira

### Estado vazio

#### Cenário 1 — sem publicações no sistema

* mensagem do tipo:

  * “Ainda não há publicações cadastradas.”
* CTA para criar rascunho, quando disponível

#### Cenário 2 — filtro sem resultado

* mensagem do tipo:

  * “Nenhuma publicação encontrada para os filtros atuais.”
* CTA para limpar filtros

### Estados de erro

#### 401

Sessão expirada:

* redirecionar para login
* preservar contexto quando possível

#### 403

Sem permissão:

* tela de acesso negado ou fallback adequado

#### 422

Filtros inválidos:

* corrigir query ou voltar ao estado válido

#### 500

Erro inesperado:

* mostrar fallback com opção de recarregar

### CTA principal

**Abrir/editar publicação**
CTAs secundários:

* limpar filtros
* criar rascunho
* voltar ao dashboard, se existir

### Dependência de API

**Alta**

Endpoint dependente:

* `GET /v1/admin/publications`

### Permissão

`admin` ou `editor`

### Critério de navegação

O usuário deve conseguir:

* entrar autenticado;
* visualizar a lista com estabilidade;
* buscar e filtrar;
* abrir `/painel/publicacoes/[id]/editar`;
* retornar depois sem perder coerência de fluxo.

### Critério de aceite funcional da rota

A rota está correta quando:

* exige sessão válida;
* lista dados administrativos reais;
* trata vazio e erro;
* permite navegação até a edição;
* não permanece como monólito frágil impossível de manter.

---

## 4.7 Edição admin de publicação

### Rota

`/painel/publicacoes/[id]/editar`

### Aplicação

`apps/admin`

### Tipo de tela

Edição editorial administrativa

### Objetivo da tela

Permitir edição completa de uma publicação administrativa, incluindo:

* título
* slug
* summary
* content
* categoria
* tags
* SEO
* transição de status editorial

### Papel da rota no sistema

É a **tela de governança editorial detalhada** do projeto.

### Dados necessários

#### Obrigatórios

* `id`
* publicação administrativa completa
* status atual
* campos do formulário
* dados mínimos para update
* estado atual da sessão

#### Opcionais

* listas de categorias/tags
* preview
* histórico
* metadados auxiliares

### Path params previstos

* `id`

### Loaders esperados

* loading inicial do detalhe
* loading no submit de update
* loading nas transições de status
* desativação contextual de ações durante mutação

### Estado vazio

Não há vazio clássico.
Os equivalentes funcionais são:

* publicação inexistente
* publicação inacessível
* formulário sem dados carregados por falha

### Estados de erro

#### 401

Sessão expirada:

* redirecionar para login

#### 403

Sem permissão:

* acesso negado

#### 404

Publicação não encontrada:

* exibir fallback claro
* permitir retorno à listagem

#### 409

Transição editorial inválida:

* feedback preciso sobre regra de negócio

#### 422

Payload inválido:

* destacar campos problemáticos
* manter o restante da tela preservado

#### 500

Erro inesperado:

* fallback robusto sem perder confiança do usuário

### CTA principal

**Salvar alterações**

### CTAs secundários

* alterar status
* voltar para listagem
* descartar alterações, quando existir essa função
* publicar/arquivar conforme contexto

### Dependência de API

**Muito alta**

Endpoints dependentes:

* `GET /v1/admin/publications/{id}`
* `PATCH /v1/admin/publications/{id}`
* `PATCH /v1/admin/publications/{id}/status`

### Permissão

`admin` ou `editor`

### Critério de navegação

O usuário deve conseguir:

* chegar pela listagem;
* carregar a publicação por `id`;
* editar sem ambiguidade;
* salvar alterações;
* transicionar status quando permitido;
* voltar à listagem com previsibilidade.

### Critério de aceite funcional da rota

A rota está correta quando:

* resolve o `id`;
* exibe os dados reais da publicação;
* separa edição de conteúdo e transição de status com clareza;
* trata 404/409/422 sem colapso;
* funciona como orchestrator limpo, e não como arquivo monolítico caótico.

---

# 5. Regras transversais obrigatórias

## 5.1 Toda tela deve declarar sua dependência de API

Não pode haver dependência implícita.

## 5.2 Toda tela protegida deve declarar sua regra de sessão

No admin, isso é obrigatório.

## 5.3 Toda rota deve ter CTA principal inequívoco

Mesmo a rota de entrada do painel, cuja ação principal é o redirect.

## 5.4 Toda tela deve tratar erro sem humilhar o usuário

Erro não pode se transformar em silêncio, stack visível ou navegação morta.

## 5.5 Toda tela deve permitir continuidade de fluxo

O usuário deve sempre saber qual é o próximo passo possível.

---

# 6. Matriz resumida de dependência por rota

| Rota                              | API dependente                                            | Sessão            | Papel exigido                     | Ação principal        |
| --------------------------------- | --------------------------------------------------------- | ----------------- | --------------------------------- | --------------------- |
| `/` (web)                         | opcional                                                  | não               | público                           | explorar o projeto    |
| `/publicacoes`                    | `GET /v1/public/publications`                             | não               | público                           | abrir publicação      |
| `/publicacoes/[slug]`             | `GET /v1/public/publications/{slug}`                      | não               | público                           | consumir conteúdo     |
| `/` (admin)                       | leitura de sessão                                         | sim, para decisão | `admin`/`editor` conforme destino | redirecionar          |
| `/painel/login`                   | `POST /v1/admin/auth/login`, `GET /v1/admin/auth/session` | depende do estado | não autenticado para uso direto   | entrar                |
| `/painel/publicacoes`             | `GET /v1/admin/publications`                              | sim               | `admin` ou `editor`               | listar e abrir edição |
| `/painel/publicacoes/[id]/editar` | `GET/PATCH /v1/admin/publications/{id}`, `PATCH /status`  | sim               | `admin` ou `editor`               | editar e salvar       |

---

# 7. Leitura soberana final

A leitura correta do projeto é:

* o **web público** já tem função institucional e editorial definida;
* o **admin** não é um painel genérico, mas um **CMS editorial interno**;
* o contrato entre rota e tela precisa agora servir como ponte de fechamento entre:

  * OpenAPI
  * contracts
  * API runtime
  * client admin
  * páginas do admin

Este documento existe para garantir que a camada de UI/UX não vire decoração abstrata, mas sim **instrumento de alinhamento operacional real**.

---

# 8. Próxima utilização correta deste documento

Este documento deve ser usado imediatamente para orientar a reforma dos arquivos:

* `apps/admin/app/page.tsx`
* `apps/admin/app/painel/login/page.tsx`
* `apps/admin/app/painel/publicacoes/page.tsx`
* `apps/admin/app/painel/publicacoes/[id]/editar/page.tsx`
* `apps/web/app/page.tsx`
* `apps/web/app/publicacoes/page.tsx`
* `apps/web/app/publicacoes/[slug]/page.tsx`

E também para validar coerência com:

* `API-06-openapi-public.yaml`
* `API-07-openapi-admin.yaml`
