# UIUX-04 — Guia de Componentes

## Endereço

`/home/walbarellos/personal-site/personal-site(Graciliano)/UI_UX/UIUX-04-guia-de-componentes.md`

## Objetivo

Catalogar os componentes disponíveis em `@william-albarello/ui` e definir quando usar cada um, com base no estado físico atual do monorepo.

## Fontes auditadas

- `packages/ui/src/index.ts`
- `packages/ui/src/components/admin/index.ts`
- `packages/ui/src/components/feedback/index.ts`
- `packages/ui/src/components/admin/admin-page-shell.tsx`
- `packages/ui/src/components/admin/admin-page-header.tsx`
- `packages/ui/src/components/admin/admin-section-card.tsx`
- `packages/ui/src/components/admin/admin-support-block.tsx`
- `packages/ui/src/components/feedback/alert-banner.tsx`
- `packages/ui/src/components/feedback/empty-state.tsx`
- `packages/ui/src/components/feedback/status-badge.tsx`

## Escopo

Incluído:

- catálogo dos componentes realmente existentes
- responsabilidades e props principais
- critérios de escolha por cenário

Fora do escopo neste ciclo:

- criação de novos componentes
- refatoração completa das páginas para adoção total do pacote UI

## Catálogo soberano — Admin

### 1) `AdminPageShell`

Arquivo: `packages/ui/src/components/admin/admin-page-shell.tsx`

Função:

- contêiner de página com largura máxima e centralização

Props principais:

- `children`
- `maxWidth?` (default `1280`)
- `padding?` (default `'0'`)

Usar quando:

- precisar definir o quadro externo de uma tela administrativa

### 2) `AdminPageHeader`

Arquivo: `packages/ui/src/components/admin/admin-page-header.tsx`

Função:

- cabeçalho de tela com título, descrição, ações e metadados

Props principais:

- `title`
- `description?`
- `eyebrow?`
- `meta?`
- `actions?`

Usar quando:

- precisar abrir a tela com contexto operacional explícito

### 3) `AdminSectionCard`

Arquivo: `packages/ui/src/components/admin/admin-section-card.tsx`

Função:

- cartão de seção para agrupar conteúdo funcional

Props principais:

- `children`
- `gap?`, `padding?`, `radius?`, `background?`, `border?`, `shadow?`

Usar quando:

- precisar separar visualmente filtros, formulário, listagem ou bloco de edição

### 4) `AdminSupportBlock`

Arquivo: `packages/ui/src/components/admin/admin-support-block.tsx`

Função:

- bloco contextual de orientação/aviso por tom semântico

Props principais:

- `title`
- `children`
- `tone?` (`neutral | info | success | warning | danger`)

Usar quando:

- precisar instrução curta ou aviso contextual dentro de seção administrativa

## Catálogo soberano — Feedback

### 1) `AlertBanner`

Arquivo: `packages/ui/src/components/feedback/alert-banner.tsx`

Função:

- feedback principal de operação (erro, aviso, sucesso, info)

Props principais:

- `title?`
- `children`
- `tone?`
- `action?`

Acessibilidade embutida:

- `warning` e `danger` usam `role="alert"`
- demais tons usam `role="status"`

### 2) `EmptyState`

Arquivo: `packages/ui/src/components/feedback/empty-state.tsx`

Função:

- representar ausência de dados com possível ação de continuidade

Props principais:

- `title`
- `description?`
- `action?`

### 3) `StatusBadge`

Arquivo: `packages/ui/src/components/feedback/status-badge.tsx`

Função:

- sinal curto de estado persistente

Props principais:

- `label`
- `tone?` (`neutral | info | success | warning | danger`)

## Regra de importação

Barrel oficial: `packages/ui/src/index.ts`.

Consumir por:

- `@william-albarello/ui`

Evitar:

- importar arquivos internos por caminho profundo do pacote

## Estado atual de adoção

- o pacote `@william-albarello/ui` está configurado nos workspaces `apps/admin` e `apps/web`
- parte das telas ainda mantém blocos locais inline
- a adoção deve seguir incrementalmente, sem reescrever tela inteira sem necessidade

## Guia rápido de decisão

1. Estrutura de página admin: `AdminPageShell` + `AdminPageHeader`.
2. Bloco funcional da tela: `AdminSectionCard`.
3. Aviso contextual interno: `AdminSupportBlock`.
4. Feedback operacional principal: `AlertBanner`.
5. Ausência de dados: `EmptyState`.
6. Indicador compacto de estado: `StatusBadge`.

## Diretriz de composição pública (web)

Mesmo quando a tela pública não usa `AdminPageShell`, a composição deve seguir o mesmo princípio de disciplina estrutural:

1. manter conteúdo principal em container central com largura máxima e `padding` horizontal consistente;
2. alinhar busca, cabeçalho de resultados, grid e paginação no mesmo eixo estrutural;
3. usar bloco lateral contextual com altura de conteúdo (`fit-content`) quando aplicável;
4. evitar cards laterais esticados artificialmente por `stretch` no grid;
5. priorizar contraste legível em hero e textos de apoio, sem depender de fundo escuro dominante.

Aplicação direta no estado atual:

- home pública (`/`): hero claro com painel lateral compacto de “Direção de presença”;
- listagem pública (`/publicacoes`): busca/resultados/paginação centralizados no mesmo container.

## Critérios de aceite deste guia

1. Só lista componentes realmente exportados pelo pacote UI.
2. Descreve props e responsabilidade conforme implementação atual.
3. Define importação oficial por barrel público.
4. Não afirma adoção total onde ela ainda não existe.
5. Registra diretrizes de composição pública coerentes com o estado físico da home e da listagem.

## Riscos residuais aceitos

- coexistência temporária entre componentes do pacote e blocos locais
- inconsistência visual pontual enquanto migração incremental não termina

Esses pontos seguem para o próximo ciclo de consolidação de UI.
