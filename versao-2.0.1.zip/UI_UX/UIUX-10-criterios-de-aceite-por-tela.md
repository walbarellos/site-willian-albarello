# UIUX-10 — Critérios de Aceite por Tela

## Endereço

`/home/walbarellos/personal-site/personal-site(Graciliano)/UI_UX/UIUX-10-criterios-de-aceite-por-tela.md`

## Status do arquivo no estado atual

**Existente e preenchido.**

---

# 1. Finalidade do documento

Este documento define os **critérios de aceite por tela** do projeto `personal-site`, cobrindo:

* home pública
* listagem pública de publicações
* detalhe público de publicação
* entrada do painel
* login admin
* listagem administrativa de publicações
* edição administrativa de publicação

A função soberana deste documento é transformar “parece pronto” em **condição objetiva de homologação**.

Ele existe para impedir que uma tela seja considerada concluída apenas porque:

* renderiza visualmente;
* “abre no navegador”;
* tem HTML/CSS aceitável;
* parece funcional em cenário ideal.

Uma tela só é considerada aprovada quando seu comportamento real estiver coerente com:

* a rota
* os dados mínimos
* os estados de erro
* a acessibilidade mínima
* o SEO, quando aplicável
* a navegação
* a ação principal da tela
* a homologação manual operacional

---

# 2. Regras soberanas de aceite

## 2.1 O critério de aceite é funcional, não decorativo

A aprovação da tela depende do que ela **faz**, não apenas de como ela parece.

## 2.2 Toda tela deve poder ser homologada manualmente

O documento deve permitir que alguém teste a tela com checklist claro, sem precisar adivinhar intenção.

## 2.3 Toda tela deve declarar seus dados mínimos

Sem os dados mínimos, a tela não pode ser considerada completa.

## 2.4 Toda tela deve declarar seus estados de erro

Se a tela não sabe como se comportar em erro, ela ainda não está pronta.

## 2.5 Toda tela com função pública relevante deve considerar SEO

Especialmente:

* home pública
* listagem pública
* detalhe público

## 2.6 Toda tela administrativa deve considerar sessão, permissão e fluxo operacional

Sem isso, não há aceite real no admin.

---

# 3. Convenção de leitura

Cada tela será documentada com:

1. finalidade
2. comportamento esperado
3. dados mínimos
4. estados de erro
5. acessibilidade
6. SEO, quando aplicável
7. critérios objetivos de aceite
8. checklist de homologação manual
9. condição de reprovação

---

# 4. Critérios de aceite por tela

---

## 4.1 Home pública

### Rota

`/`

### Aplicação

`apps/web`

### Finalidade da tela

Apresentar a presença institucional do projeto, orientar navegação e conduzir o usuário para a camada editorial pública.

### Comportamento esperado

A tela deve:

* abrir sem autenticação;
* apresentar identidade institucional coerente;
* manter estabilidade visual inicial;
* oferecer caminho claro para `publicações`;
* continuar funcional mesmo se blocos editoriais complementares falharem;
* preservar leitura agradável em desktop e mobile.

### Dados mínimos

#### Obrigatórios

* título principal institucional
* blocos base da narrativa pública
* CTA principal navegável
* estrutura semântica clara
* navegação principal funcional

#### Opcionais

* destaques editoriais
* cards de publicações recentes
* resumo institucional complementar

### Estados de erro esperados

* se o bloco de destaques falhar, a home não pode colapsar;
* a falha de bloco complementar não pode impedir a renderização da página;
* a interface deve manter navegação e CTA principal;
* mensagens de erro, se existirem, devem ser discretas e institucionais.

### Acessibilidade mínima obrigatória

* hierarquia semântica coerente de headings
* navegação por teclado funcional nos CTAs principais
* contraste legível
* links com texto compreensível
* não depender exclusivamente de cor para comunicar ação

### SEO aplicável

Sim.

### Critérios de SEO mínimos

* título de página coerente
* description coerente
* estrutura adequada para indexação pública
* ausência de conteúdo crítico invisível apenas em JS quebrável
* consistência com proposta institucional da home

### Critérios objetivos de aceite

A tela é aprovada quando:

* abre sem autenticação;
* carrega a estrutura principal sem depender de estado administrativo;
* apresenta narrativa institucional legível;
* possui CTA principal funcional;
* não quebra se conteúdo complementar falhar;
* mantém semântica e legibilidade em mobile e desktop;
* possui metadata básica coerente;
* mantém contraste legível no hero (sem texto claro sobre fundo claro);
* mantém o bloco “Direção de presença” compacto, sem estiramento vertical artificial.

### Checklist de homologação manual

* [ ] abrir `/`
* [ ] verificar se a tela renderiza sem login
* [ ] verificar presença de CTA principal
* [ ] clicar no CTA principal e confirmar navegação correta
* [ ] validar leitura inicial da proposta institucional
* [ ] validar se o layout não colapsa em viewport menor
* [ ] validar headings principais
* [ ] validar title e description da página
* [ ] validar que a falha de bloco secundário não mata a home
* [ ] validar contraste do hero (título e descrição sempre legíveis)
* [ ] validar que o bloco “Direção de presença” não ocupa altura excessiva sem conteúdo

### Condição de reprovação

Reprovar se:

* a home depende de dado opcional para existir;
* o CTA principal não estiver claro;
* a página estiver visualmente estável, mas sem narrativa coerente;
* faltar metadata mínima;
* houver colapso estrutural por falha secundária;
* houver texto do hero com contraste insuficiente;
* o card lateral da direção de presença ficar esticado e desproporcional ao conteúdo.

---

## 4.2 Listagem pública de publicações

### Rota

`/publicacoes`

### Aplicação

`apps/web`

### Finalidade da tela

Permitir descoberta pública de publicações por lista, paginação, busca e filtros.

### Comportamento esperado

A tela deve:

* abrir sem autenticação;
* carregar publicações públicas;
* respeitar paginação;
* respeitar filtros por categoria, tag e busca;
* permitir acesso ao detalhe por slug;
* tratar vazio e erro sem parecer quebrada;
* manter coerência entre query params e estado exibido.

### Dados mínimos

#### Obrigatórios

* lista de publicações públicas
* `title`
* `slug`
* `summary`
* `publishedAt`
* paginação mínima
* CTA para abrir detalhe

#### Opcionais

* categoria
* tags
* reading time
* contagem total destacada

### Estados de erro esperados

* 422 para query inválida deve ser tratável sem quebrar a tela;
* 500 deve virar fallback claro;
* 429 deve informar excesso de requisições;
* estado vazio deve ser tratado como ausência legítima, não erro técnico.

### Acessibilidade mínima obrigatória

* navegação por teclado entre filtros, cards e paginação
* botões/links com rótulos claros
* foco visível
* estrutura da lista compreensível por leitor de tela
* estados de erro e vazio com texto legível

### SEO aplicável

Sim.

### Critérios de SEO mínimos

* title coerente com listagem pública
* description coerente
* URL estável e legível
* paginação/filtros não podem destruir a inteligibilidade da rota
* conteúdo principal deve ser semanticamente reconhecível

### Critérios objetivos de aceite

A tela é aprovada quando:

* carrega conteúdos públicos via API correta;
* aplica busca/filtros/paginação de modo coerente;
* permite abrir detalhe por slug;
* trata vazio e erro de forma explícita;
* mantém a tela navegável mesmo quando não há resultados;
* possui metadata adequada;
* não exige autenticação;
* mantém estrutura visual alinhada (busca, resultados e paginação no mesmo container central);
* evita layout “espalhado” com blocos full-width desalinhados do conteúdo principal.

### Checklist de homologação manual

* [ ] abrir `/publicacoes`
* [ ] validar renderização inicial da lista
* [ ] abrir uma publicação e confirmar navegação para detalhe
* [ ] testar busca por `q`
* [ ] testar filtro por `category`
* [ ] testar filtro por `tag`
* [ ] testar paginação
* [ ] testar cenário de resultado vazio
* [ ] testar query inválida manualmente
* [ ] validar title e description
* [ ] validar navegação por teclado nos itens principais
* [ ] validar alinhamento visual entre barra de busca, cabeçalho de resultados e grid de cards
* [ ] validar paginação alinhada ao mesmo eixo estrutural da listagem

### Condição de reprovação

Reprovar se:

* a lista não refletir a query string;
* o detalhe não abrir corretamente;
* vazio for tratado como erro silencioso;
* a tela quebrar com filtro inválido;
* SEO mínimo não estiver coerente;
* a estrutura visual estiver desalinhada (busca/lista/paginação em eixos diferentes);
* houver sensação de layout “espalhado” por falta de container central consistente.

---

## 4.3 Detalhe público de publicação

### Rota

`/publicacoes/[slug]`

### Aplicação

`apps/web`

### Finalidade da tela

Exibir integralmente uma publicação pública específica.

### Comportamento esperado

A tela deve:

* resolver o slug corretamente;
* exibir título, resumo e conteúdo;
* exibir data de publicação quando houver;
* permitir retorno lógico à listagem;
* tratar `not found` com clareza;
* preservar legibilidade editorial;
* não expor lógica administrativa.

### Dados mínimos

#### Obrigatórios

* `title`
* `slug`
* `summary`
* `content`
* `publishedAt` quando existente
* metadata SEO mínima
* retorno navegável para listagem

#### Opcionais

* categoria
* tags
* reading time
* conteúdo relacionado

### Estados de erro esperados

* `404` para slug inexistente ou não publicado;
* `422` para slug inválido;
* `500` para falha inesperada;
* fallback com retorno à listagem.

### Acessibilidade mínima obrigatória

* hierarquia de headings coerente
* conteúdo legível por teclado e leitor de tela
* link de retorno claro
* contraste suficiente em texto longo
* não depender de elementos ambíguos para navegação

### SEO aplicável

Sim, fortemente.

### Critérios de SEO mínimos

* title coerente com o conteúdo
* meta description coerente
* rota canônica clara por slug
* conteúdo principal semanticamente reconhecível
* not found não deve indexar como conteúdo válido

### Critérios objetivos de aceite

A tela é aprovada quando:

* resolve slug válido;
* exibe conteúdo público legível;
* trata 404 com clareza;
* oferece retorno para a listagem;
* mantém SEO mínimo coerente;
* não mistura estado administrativo com visual público.

### Checklist de homologação manual

* [ ] abrir uma publicação válida por slug
* [ ] validar título, resumo e conteúdo
* [ ] validar presença de retorno para listagem
* [ ] abrir slug inexistente
* [ ] validar comportamento de not found
* [ ] validar title e description
* [ ] validar legibilidade em desktop e mobile
* [ ] validar headings e fluxo de leitura

### Condição de reprovação

Reprovar se:

* slug válido não carregar conteúdo;
* slug inválido gerar tela quebrada;
* a página não permitir retorno natural;
* metadata SEO estiver ausente ou incoerente;
* o conteúdo estiver tecnicamente “carregado”, mas editorialmente ilegível.

---

## 4.4 Entrada do painel

### Rota

`/`

### Aplicação

`apps/admin`

### Finalidade da tela

Resolver automaticamente o destino do usuário administrativo com base no estado de sessão.

### Comportamento esperado

A tela deve:

* verificar a sessão atual;
* redirecionar autenticado para a área interna;
* redirecionar não autenticado para `/painel/login`;
* não ficar parada em estado ambíguo;
* não depender de helpers inexistentes;
* não exibir erro bruto ao usuário.

### Dados mínimos

#### Obrigatórios

* leitura de sessão
* definição da rota de destino
* regra de redirect coerente

#### Opcionais

* indicação transitória de verificação de sessão

### Estados de erro esperados

* falha ao ler sessão deve cair em fluxo seguro;
* usuário sem sessão deve ser enviado ao login;
* inconsistência interna não pode explodir em runtime visível.

### Acessibilidade mínima obrigatória

* se houver tela transitória, ela deve ser legível;
* não criar loop de navegação impossível;
* não exigir interação desnecessária do usuário.

### SEO aplicável

Não.

### Critérios objetivos de aceite

A tela é aprovada quando:

* usuário autenticado é enviado corretamente ao painel;
* usuário não autenticado é enviado corretamente ao login;
* não há erro por import/export inexistente;
* não há loop de redirect;
* não há tela morta sem próximo passo.

### Checklist de homologação manual

* [ ] abrir a raiz do admin sem sessão
* [ ] validar redirect para `/painel/login`
* [ ] abrir a raiz do admin com sessão válida
* [ ] validar redirect para área autenticada
* [ ] confirmar ausência de runtime error
* [ ] confirmar ausência de loop de redirect

### Condição de reprovação

Reprovar se:

* a rota não souber decidir o destino;
* houver import quebrado;
* houver loop;
* o usuário ficar preso em tela intermediária sem conclusão.

---

## 4.5 Login admin

### Rota

`/painel/login`

### Aplicação

`apps/admin`

### Finalidade da tela

Autenticar o usuário administrativo bootstrap e iniciar sessão.

### Comportamento esperado

A tela deve:

* exibir formulário de email e senha;
* validar o mínimo dos campos;
* bloquear submit duplicado enquanto envia;
* mostrar erro claro em caso de credencial inválida;
* redirecionar corretamente após sucesso;
* redirecionar autenticado já logado para a área interna;
* lidar corretamente com retorno de rota protegida.

### Dados mínimos

#### Obrigatórios

* campo `email`
* campo `password`
* botão principal de submit
* integração com endpoint de login
* redirect pós-login
* estado de feedback de erro/sucesso

#### Opcionais

* mensagem de sessão expirada
* indicação de rota originalmente desejada

### Estados de erro esperados

* `401` credenciais inválidas
* `422` payload inválido
* `403` falha de segurança/CSRF quando aplicável
* `500` erro inesperado

### Acessibilidade mínima obrigatória

* labels claros
* foco navegável por teclado
* botão acionável por teclado
* mensagens de erro associadas ao formulário
* contraste e legibilidade adequados

### SEO aplicável

Não relevante como prioridade pública.

### Critérios objetivos de aceite

A tela é aprovada quando:

* permite preencher email e senha;
* impede submit múltiplo em loading;
* mostra erro claro se login falhar;
* mantém contexto minimamente útil após erro;
* redireciona corretamente após sucesso;
* não permanece acessível como tela útil para usuário já autenticado.

### Checklist de homologação manual

* [ ] abrir `/painel/login`
* [ ] validar renderização do formulário
* [ ] tentar submit vazio/insuficiente
* [ ] validar mensagens de erro
* [ ] tentar login inválido
* [ ] validar feedback de credencial incorreta
* [ ] tentar login válido
* [ ] validar redirect pós-login
* [ ] abrir login já autenticado
* [ ] validar redirect para área interna
* [ ] validar navegação por teclado no formulário

### Condição de reprovação

Reprovar se:

* o formulário não comunicar erro;
* o submit puder duplicar sem controle;
* o redirect pós-login falhar;
* a tela depender de helpers quebrados;
* o usuário autenticado ficar parado na tela de login.

---

## 4.6 Listagem administrativa de publicações

### Rota

`/painel/publicacoes`

### Aplicação

`apps/admin`

### Finalidade da tela

Permitir operação editorial sobre o conjunto de publicações administrativas.

### Comportamento esperado

A tela deve:

* exigir sessão válida;
* listar publicações administrativas;
* permitir busca;
* permitir filtro por status;
* permitir paginação;
* exibir status editorial claramente;
* permitir acesso à edição por id;
* tratar vazio, erro e sessão expirada de forma previsível.

### Dados mínimos

#### Obrigatórios

* lista administrativa
* `id`
* `title`
* `status`
* `updatedAt`
* ação para abrir edição
* filtros principais
* paginação mínima

#### Opcionais

* `summary`
* `slug`
* categoria
* tags
* publishedAt
* reading time
* contadores complementares

### Estados de erro esperados

* `401` sessão expirada
* `403` sem permissão
* `422` query inválida
* `500` falha inesperada
* estado vazio geral
* estado vazio por filtro

### Acessibilidade mínima obrigatória

* tabela/listagem navegável por teclado
* filtros acessíveis
* botões/links com rótulo claro
* foco visível
* status não comunicados apenas por cor

### SEO aplicável

Não.

### Critérios objetivos de aceite

A tela é aprovada quando:

* exige autenticação válida;
* carrega a lista administrativa;
* reflete busca/filtro/paginação corretamente;
* permite abrir a edição da publicação;
* trata estados vazios e erros;
* comunica status editoriais com clareza;
* não depende de improvisação visual para parecer funcional.

### Checklist de homologação manual

* [ ] abrir `/painel/publicacoes` com sessão válida
* [ ] validar carregamento da lista
* [ ] testar filtro por status
* [ ] testar busca por texto
* [ ] testar paginação
* [ ] abrir edição de um item
* [ ] testar cenário sem resultados
* [ ] testar sessão expirada
* [ ] validar navegação por teclado nos controles principais
* [ ] validar leitura clara dos status editoriais

### Condição de reprovação

Reprovar se:

* a lista não responder aos filtros;
* a edição não puder ser aberta;
* vazio e erro não forem distinguíveis;
* o status não estiver claro;
* a tela continuar sendo um monólito visualmente aceitável, mas funcionalmente frágil.

---

## 4.7 Edição administrativa de publicação

### Rota

`/painel/publicacoes/[id]/editar`

### Aplicação

`apps/admin`

### Finalidade da tela

Permitir edição e governança detalhada de uma publicação administrativa.

### Comportamento esperado

A tela deve:

* exigir sessão válida;
* resolver o `id` da publicação;
* carregar dados completos do item;
* permitir editar conteúdo principal;
* permitir editar campos auxiliares como SEO;
* permitir salvar alterações;
* permitir transicionar status editorial quando aplicável;
* tratar 404, 409, 422 e 500 com clareza;
* preservar contexto do usuário sempre que possível.

### Dados mínimos

#### Obrigatórios

* `id`
* `title`
* `slug`
* `summary`
* `content`
* `status`
* mecanismo de salvar
* mecanismo de tratar erro de atualização
* mecanismo de transição de status

#### Opcionais

* categoria
* tags
* blocos auxiliares
* preview futuro
* informações complementares

### Estados de erro esperados

* `401` sessão expirada
* `403` sem permissão
* `404` publicação inexistente
* `409` transição editorial inválida
* `422` payload inválido
* `500` erro inesperado

### Acessibilidade mínima obrigatória

* labels claros nos campos
* foco visível
* ordem de tab coerente
* erro de campo próximo ao campo
* botões principais com texto inequívoco
* status não comunicado apenas por cor

### SEO aplicável

Sim, no sentido funcional de edição do conteúdo público.

### Critérios de SEO mínimos na tela

* campos de SEO devem existir de forma inteligível, se previstos
* a edição SEO não pode ser impossível de entender
* erros de SEO devem ser tratáveis sem destruir a edição principal

### Critérios objetivos de aceite

A tela é aprovada quando:

* carrega a publicação por `id`;
* exibe os campos centrais de edição;
* permite salvar alterações;
* mostra erro claro quando o payload falha;
* trata 404 corretamente;
* trata transição inválida corretamente;
* preserva a experiência operacional do editor/admin;
* oferece caminho de retorno à listagem.

### Checklist de homologação manual

* [ ] abrir edição de uma publicação existente
* [ ] validar carregamento dos dados
* [ ] editar título/resumo/conteúdo
* [ ] salvar alterações
* [ ] validar feedback de sucesso
* [ ] induzir erro de validação e validar feedback
* [ ] testar mudança de status válida
* [ ] testar mudança de status inválida, se possível
* [ ] testar publicação inexistente
* [ ] validar retorno para listagem
* [ ] validar foco, labels e erros próximos aos campos

### Condição de reprovação

Reprovar se:

* o `id` não resolver corretamente;
* a tela salvar sem feedback;
* o erro de validação não indicar o que corrigir;
* 404/409 causarem colapso visual;
* a tela continuar concentrando tudo de forma opaca e impossível de homologar.

---

# 5. Critérios transversais obrigatórios

---

## 5.1 Critério transversal de navegação

Toda tela deve permitir ao usuário compreender:

* onde está
* o que pode fazer
* o que aconteceu
* qual é o próximo passo

---

## 5.2 Critério transversal de estado

Toda tela deve ter tratamento explícito, quando aplicável, para:

* loading
* success
* empty
* validation error
* unauthorized
* forbidden
* not found
* server error
* retry

---

## 5.3 Critério transversal de estabilidade

Nenhuma tela deve:

* depender de um dado opcional para existir;
* colapsar por falha parcial;
* ocultar totalmente a navegação sem fallback;
* exigir conhecimento técnico do usuário para continuar.

---

## 5.4 Critério transversal de consistência visual

Os estados devem seguir o padrão soberano definido em:

* `UIUX-09-estados-de-interface-e-feedback.md`

---

## 5.5 Critério transversal de coerência funcional

Os critérios deste documento devem estar alinhados a:

* `UIUX-11-contratos-de-tela-por-rota.md`
* `API-06-openapi-public.yaml`
* `API-07-openapi-admin.yaml`

---

# 6. Matriz resumida de homologação

| Tela              | Sessão             | API                | SEO           | Erros críticos a validar     |
| ----------------- | ------------------ | ------------------ | ------------- | ---------------------------- |
| Home pública      | não                | opcional / parcial | sim           | falha de bloco complementar  |
| Listagem pública  | não                | sim                | sim           | 422, 500, vazio              |
| Detalhe público   | não                | sim                | sim           | 404, 422, 500                |
| Entrada do painel | sim para decisão   | sim/indireta       | não           | sessão, redirect, loop       |
| Login admin       | contexto de sessão | sim                | não           | 401, 422, 403, 500           |
| Listagem admin    | sim                | sim                | não           | 401, 403, 422, 500, vazio    |
| Edição admin      | sim                | sim                | sim funcional | 401, 403, 404, 409, 422, 500 |

---

# 7. Condição soberana de aprovação

Uma tela do `personal-site` só pode ser considerada **aprovada** quando atender simultaneamente a estes quatro níveis:

## Nível 1 — Renderização

A tela abre e exibe a estrutura esperada.

## Nível 2 — Comportamento

A tela responde corretamente aos dados, à navegação e às ações do usuário.

## Nível 3 — Resiliência

A tela trata erro, ausência, sessão e fallback sem colapso.

## Nível 4 — Homologação manual

A tela passa no checklist sem depender de interpretação subjetiva.

Se um desses quatro níveis falhar, a tela ainda **não está aceita**.

---

# 8. Leitura soberana final

O projeto `personal-site` está em um momento em que “aparentemente funciona” já não basta.
A partir deste documento, cada tela passa a ter um padrão claro de aceite, para que:

* o web público tenha fechamento real;
* o admin deixe de ser validado por impressão subjetiva;
* o projeto avance com menos retrabalho;
* a homologação manual se torne objetiva, auditável e reproduzível.

---

# 9. Próxima utilização correta deste documento

Este documento deve ser usado imediatamente para validar e reformar:

* `apps/web/app/page.tsx`
* `apps/web/app/publicacoes/page.tsx`
* `apps/web/app/publicacoes/[slug]/page.tsx`
* `apps/admin/app/page.tsx`
* `apps/admin/app/painel/login/page.tsx`
* `apps/admin/app/painel/publicacoes/page.tsx`
* `apps/admin/app/painel/publicacoes/[id]/editar/page.tsx`

E deve ser lido em conjunto com:

* `UIUX-09-estados-de-interface-e-feedback.md`
* `UIUX-11-contratos-de-tela-por-rota.md`
