# UIUX-09 — Estados de Interface e Feedback

## Endereço

`/home/walbarellos/personal-site/personal-site(Graciliano)/UI_UX/UIUX-09-estados-de-interface-e-feedback.md`

## Status do arquivo no estado atual

**Existente e preenchido.**

---

# 1. Finalidade do documento

Este documento define o **padrão soberano de estados de interface e feedback** do projeto `personal-site`, cobrindo:

* loading
* success
* empty
* validation error
* unauthorized
* forbidden
* not found
* server error
* retry
* feedback pós-ação

O objetivo é alinhar:

* `apps/web`
* `apps/admin`
* `packages/ui`
* contratos de tela
* comportamento da API

Este documento existe para impedir que cada tela invente seu próprio padrão de feedback, gerando:

* inconsistência visual
* mensagens contraditórias
* estados silenciosos
* telas ambíguas
* UX improvisada
* fragilidade no painel administrativo

A função correta deste documento é transformar estados de interface em **comportamento previsível, institucional e auditável**.

---

# 2. Princípios soberanos

## 2.1 Todo estado comunica uma verdade operacional

O feedback da interface não existe para “decorar a tela”.
Ele existe para informar com precisão:

* o que está acontecendo
* o que já aconteceu
* o que falhou
* o que o usuário pode fazer em seguida

## 2.2 O usuário nunca deve ficar sem próximo passo

Todo estado relevante precisa indicar:

* continuação natural
* retorno seguro
* nova tentativa
* ajuste necessário

## 2.3 Erros devem ser claros sem expor fragilidade técnica

A interface não deve:

* despejar stack trace
* exibir texto cru de exceção
* culpar o usuário
* falar em jargão de backend sem necessidade

## 2.4 O contexto define a intensidade do feedback

O mesmo erro não precisa ter a mesma apresentação em todos os lugares.

Exemplo:

* erro leve na home pública → discreto
* erro de autenticação no admin → explícito e operacional

## 2.5 Estados não podem quebrar a dignidade institucional do projeto

O tom deve ser:

* claro
* sóbrio
* profissional
* objetivo
* institucional

Não usar:

* humor deslocado
* ironia
* mensagens agressivas
* excesso de exclamações
* culpa implícita

---

# 3. Contextos de aplicação

---

## 3.1 Contexto público

Abrange:

* home pública
* listagem pública de publicações
* detalhe público de publicação

Características:

* linguagem mais acolhedora
* menor densidade operacional
* maior peso de continuidade de navegação
* feedback mais discreto
* erro tratado sem dramatização

Objetivo do feedback público:

* manter confiança
* preservar leitura
* orientar navegação
* evitar sensação de quebra estrutural

---

## 3.2 Contexto administrativo

Abrange:

* entrada do painel
* login admin
* dashboard
* listagem admin de publicações
* edição admin de publicação

Características:

* linguagem mais direta
* maior precisão operacional
* maior visibilidade de erro funcional
* feedback mais explícito em formulários, ações e sessão
* maior obrigação de indicar o que fazer em seguida

Objetivo do feedback administrativo:

* sustentar operação
* evitar retrabalho
* proteger sessão e fluxo
* reduzir ambiguidade
* permitir correção rápida

---

# 4. Componentes de feedback e suas funções

---

## 4.1 Banner

### Função

Comunicar estados relevantes no topo de bloco ou página.

### Usar quando

* o estado afeta toda a tela
* há aviso geral
* é preciso orientar ação em nível macro

### Exemplos

* erro ao carregar lista
* sessão expirada
* publicação salva com sucesso
* acesso negado
* serviço temporariamente indisponível

### Regras

* um banner principal por contexto visual imediato
* não empilhar banners concorrentes sem hierarquia
* texto sempre curto e acionável

---

## 4.2 Badge

### Função

Sinalizar estado resumido e persistente de item.

### Usar quando

* o estado é atributo do objeto
* não é mensagem transitória
* precisa ser legível em lista, tabela ou detalhe

### Exemplos

* `draft`
* `review`
* `ready_to_publish`
* `published`
* `archived`

### Regras

* badge não substitui explicação quando a ação depende de contexto
* badge é estado, não feedback completo
* o texto do badge deve ser curto, estável e sem ambiguidade

---

## 4.3 Alert

### Função

Comunicar problema ou aviso localizado dentro de bloco/formulário.

### Usar quando

* o problema afeta parte da tela
* o feedback precisa aparecer perto da ação
* o contexto é mais localizado que um banner global

### Exemplos

* erro de validação geral no formulário
* falha ao salvar SEO
* problema de transição editorial

### Regras

* posicionar próximo da origem funcional
* nunca competir com erro de campo mais específico
* mensagem deve explicar impacto e próximo passo

---

## 4.4 Tabela

### Função

Apresentar coleções com estados de carregamento, vazio, erro e paginação.

### Regras soberanas

Toda tabela/listagem administrativa ou pública deve ter:

* loading state
* empty state
* error state
* estado nominal de conteúdo
* paginação previsível, quando aplicável

### Proibido

* tabela vazia sem mensagem
* spinner eterno
* cabeçalho desaparecendo sem motivo
* erro substituindo toda a navegação desnecessariamente

---

## 4.5 Formulário

### Função

Receber entrada do usuário com validação, envio e retorno.

### Regras soberanas

Todo formulário deve tratar:

* estado inicial
* loading de submit
* erro de validação por campo
* erro geral de envio
* sucesso pós-ação
* bloqueio temporário de múltiplos envios

### Proibido

* resetar tudo após erro
* ocultar qual campo falhou
* botão seguir clicável durante submit crítico
* sucesso silencioso sem confirmação visível

---

# 5. Padrão soberano de estados

---

## 5.1 Loading

### Definição

Estado em que a interface está aguardando dados ou conclusão de uma ação.

### Quando usar

* carregamento inicial de tela dependente de dados
* troca de página/filtro
* submit de formulário
* mutação administrativa
* leitura de sessão na entrada do painel

### Objetivo comunicacional

Informar que a interface está trabalhando, sem transmitir travamento.

### Padrão no contexto público

* loading discreto
* skeleton preferível a spinner grande
* preservar estrutura geral da página
* evitar apagar completamente a tela

### Padrão no contexto administrativo

* loading explícito quando a ação for operacional
* botão de submit deve indicar processamento
* em listagens, manter estrutura e cabeçalhos enquanto carrega

### Regras visuais

* usar skeleton em blocos de conteúdo e listas
* usar spinner apenas em ações pequenas e localizadas
* em formulários, bloquear o botão principal enquanto a ação estiver em curso
* texto opcional:

  * “Carregando publicações…”
  * “Salvando alterações…”
  * “Verificando sessão…”

### CTA principal

Nenhum CTA novo; o sistema está executando a ação iniciada.

### Anti-padrões

* spinner sem contexto
* tela completamente branca
* loading eterno sem fallback
* sumiço brusco da interface

---

## 5.2 Success

### Definição

Estado em que a ação foi concluída com êxito.

### Quando usar

* login concluído
* publicação salva
* status editorial atualizado
* logout bem-sucedido
* carregamento com sucesso quando feedback explícito for necessário

### Objetivo comunicacional

Confirmar conclusão sem exagero.

### Padrão no contexto público

* success explícito só quando houve ação do usuário
* evitar banner de sucesso para simples navegação de leitura

### Padrão no contexto administrativo

* success explícito em:

  * login
  * save
  * update
  * transition
  * create draft

### Regras visuais

* success de ação pontual → alert/banner curto
* success de estado persistente → badge ou confirmação localizada
* texto objetivo:

  * “Alterações salvas com sucesso.”
  * “Rascunho criado com sucesso.”
  * “Status atualizado com sucesso.”

### CTA principal

* seguir trabalhando
* abrir item
* voltar à listagem
* continuar edição

### Anti-padrões

* mensagens triunfalistas
* excesso de animação
* feedback duplicado em banner + toast + alert ao mesmo tempo

---

## 5.3 Empty

### Definição

Estado em que não há conteúdo para exibir, mas não existe erro técnico.

### Quando usar

* nenhuma publicação encontrada
* nenhum resultado para filtro
* nenhum item ainda criado
* nenhuma categoria aplicável

### Objetivo comunicacional

Mostrar ausência sem parecer falha.

### Padrão no contexto público

Mensagens exemplo:

* “Ainda não há publicações disponíveis.”
* “Nenhuma publicação encontrada para os filtros atuais.”

### Padrão no contexto administrativo

Mensagens exemplo:

* “Ainda não há publicações cadastradas.”
* “Nenhuma publicação corresponde aos filtros informados.”

### Regras visuais

* manter estrutura da tela
* indicar claramente que não é erro
* oferecer ação seguinte:

  * limpar filtros
  * criar rascunho
  * voltar para publicações
  * voltar para a home

### CTA principal

Depende do contexto:

* público: “Ver todas as publicações” ou “Voltar ao início”
* admin: “Criar rascunho” ou “Limpar filtros”

### Anti-padrões

* tela vazia sem texto
* tabela sem linhas e sem explicação
* empty state com tom de falha técnica

---

## 5.4 Validation Error

### Definição

Erro causado por entrada inválida do usuário ou payload inconsistente.

### Quando usar

* login com email inválido
* senha curta
* título insuficiente
* slug inválido
* transição sem payload válido
* formulário com campos obrigatórios ausentes

### Objetivo comunicacional

Ajudar o usuário a corrigir, não apenas informar que falhou.

### Padrão no contexto público

Uso mais raro.
Aplicável em:

* busca ou filtros inválidos
* algum formulário futuro público

### Padrão no contexto administrativo

Uso obrigatório em todos os formulários.

### Regras visuais

* erro por campo deve aparecer próximo do campo
* erro geral do formulário pode aparecer em alert acima da área de ação
* linguagem direta:

  * “Informe um email válido.”
  * “O título deve ter pelo menos 3 caracteres.”
  * “Selecione um status válido.”

### CTA principal

Corrigir e reenviar

### Anti-padrões

* mostrar apenas erro global sem indicar o campo
* limpar formulário inteiro após erro
* usar linguagem técnica crua do backend

---

## 5.5 Unauthorized

### Definição

Estado em que o usuário não está autenticado ou a sessão expirou.

### Quando usar

* leitura de sessão falhou
* acesso a rota admin sem sessão
* expiração do cookie
* login obrigatório para continuar

### Objetivo comunicacional

Proteger o sistema e recolocar o usuário no fluxo correto.

### Padrão no contexto público

Raro; normalmente não se aplica.

### Padrão no contexto administrativo

Central.

### Regras visuais

* preferir redirect controlado para `/painel/login`
* quando necessário exibir feedback antes do redirect:

  * “Sua sessão expirou. Faça login novamente.”
* preservar destino desejado quando aplicável

### CTA principal

**Fazer login novamente**

### Anti-padrões

* deixar o usuário em tela quebrada
* mostrar erro genérico “algo deu errado”
* tratar sessão expirada como falha de sistema

---

## 5.6 Forbidden

### Definição

Estado em que o usuário está autenticado, mas não tem permissão para a ação ou recurso.

### Quando usar

* papel insuficiente
* acesso a recurso restrito
* falha de autorização
* token CSRF inválido, quando modelado como proibição operacional

### Objetivo comunicacional

Informar claramente que o problema é de permissão, não de autenticação.

### Padrão no contexto público

Quase inexistente.

### Padrão no contexto administrativo

Usar quando:

* usuário autenticado não pode acessar recurso
* ação foi recusada por regra de segurança/autorização

### Regras visuais

Mensagem exemplo:

* “Você não tem permissão para acessar este recurso.”
* “Não foi possível concluir a ação com as permissões atuais.”

Se for CSRF:

* “Não foi possível validar a segurança da ação. Tente novamente.”

### CTA principal

* voltar à área permitida
* tentar novamente, quando aplicável
* refazer login, se o contexto indicar sessão degradada

### Anti-padrões

* confundir forbidden com unauthorized
* mandar o usuário “adivinhar” o que fazer

---

## 5.7 Not Found

### Definição

Estado em que o recurso solicitado não existe ou não está disponível no contexto esperado.

### Quando usar

* slug inexistente
* id de publicação inexistente
* rota administrativa para item ausente

### Objetivo comunicacional

Explicar ausência do recurso e oferecer continuidade.

### Padrão no contexto público

Mensagem exemplo:

* “A publicação solicitada não foi encontrada.”

CTA:

* “Voltar para publicações”

### Padrão no contexto administrativo

Mensagem exemplo:

* “A publicação solicitada não foi encontrada ou não está mais disponível.”

CTA:

* “Voltar para a listagem”

### Regras visuais

* not found deve ser claro, limpo e navegável
* não tratar como erro interno
* não deixar a tela sem contexto

### Anti-padrões

* transformar 404 em 500 visual
* esconder navegação de retorno

---

## 5.8 Server Error

### Definição

Erro inesperado do sistema, não resolvível diretamente pelo usuário.

### Quando usar

* falha inesperada de backend
* erro interno em leitura
* falha de persistência
* exceção não mapeada

### Objetivo comunicacional

Preservar confiança sem fingir normalidade.

### Padrão no contexto público

Mensagem exemplo:

* “Não foi possível carregar este conteúdo no momento.”

Tom:

* sóbrio
* breve
* sem alarmismo

### Padrão no contexto administrativo

Mensagem exemplo:

* “Não foi possível concluir a operação no momento.”
* “O sistema encontrou um erro inesperado ao processar sua solicitação.”

### Regras visuais

* usar banner ou alert conforme escopo
* sempre oferecer:

  * tentar novamente
  * voltar
  * continuar por outro caminho, se possível

### CTA principal

**Tentar novamente**

### Anti-padrões

* stack trace visível
* mensagem crua do backend
* erro silencioso sem alternativa

---

## 5.9 Retry

### Definição

Estado ou ação de nova tentativa após falha transitória.

### Quando usar

* falha de rede
* falha de carregamento pontual
* erro temporário do serviço
* ação administrativa que pode ser repetida sem dano

### Objetivo comunicacional

Dar ao usuário uma continuação digna e imediata.

### Padrão no contexto público

* botão discreto:

  * “Tentar novamente”
* manter restante da página quando possível

### Padrão no contexto administrativo

* retry explícito
* manter contexto preenchido do formulário, sempre que possível
* evitar perda de trabalho já digitado

### Regras visuais

* retry deve vir junto do erro que o motivou
* não exibir retry quando a ação não deve ser repetida sem revisão
* se houver risco operacional, orientar antes de repetir

### Anti-padrões

* recarregar tudo sem explicar
* perder o estado do usuário
* multiplicar envios da mesma ação

---

## 5.10 Feedback pós-ação

### Definição

Confirmação posterior a uma ação concluída, especialmente em fluxo administrativo.

### Quando usar

* salvar publicação
* criar rascunho
* alterar status
* efetuar login
* efetuar logout
* limpar filtros, quando relevante
* restaurar contexto após erro resolvido

### Objetivo comunicacional

Fechar o ciclo da ação.

### Padrão no contexto público

Mais raro.
Aplicar quando houver ação explícita do usuário.

### Padrão no contexto administrativo

Obrigatório nas ações centrais.

### Regras visuais

* feedback pós-ação deve ser breve
* deve aparecer perto da ação ou no topo do bloco
* deve desaparecer de forma controlada ou permanecer enquanto fizer sentido operacional

### Exemplos

* “Alterações salvas com sucesso.”
* “Status alterado para publicado.”
* “Rascunho criado com sucesso.”
* “Login realizado com sucesso.”

### CTA principal

* continuar
* revisar item
* voltar para listagem
* seguir para a próxima ação

### Anti-padrões

* feedback invisível
* redirect instantâneo que apaga a confirmação sem necessidade
* sucesso sem contexto do que foi concluído

---

# 6. Regras soberanas de consistência visual

---

## 6.1 Hierarquia visual

A ordem de força visual deve ser:

1. erro crítico que bloqueia a tela
2. aviso relevante da ação atual
3. sucesso pós-ação
4. estado vazio
5. estados persistentes por badge

---

## 6.2 Coerência entre público e admin

Os dois contextos devem parecer parte do mesmo sistema, mas não precisam ter a mesma intensidade.

### Público

* mais leve
* mais discreto
* mais narrativo

### Admin

* mais direto
* mais operacional
* mais explícito

---

## 6.3 Consistência textual

Todos os feedbacks devem obedecer a estas regras:

* uma verdade por mensagem
* frase curta
* verbo claro
* sem ambiguidade
* sem jargão desnecessário
* sem tom infantilizado

---

## 6.4 Consistência em tabelas

Toda tabela/listagem deve ter:

* loading coerente
* empty state coerente
* erro coerente
* paginação estável
* feedback de filtro claro

---

## 6.5 Consistência em formulários

Todo formulário deve ter:

* validação por campo
* erro geral quando necessário
* loading de submit
* botão bloqueado durante envio
* sucesso ou erro claro após submit

---

## 6.6 Persistência do contexto do usuário

Sempre que possível, a interface deve preservar:

* campos já digitados
* filtros selecionados
* página atual
* retorno desejado após login
* contexto da edição

---

# 7. Matriz resumida por contexto

| Estado            | Público                      | Admin                            |
| ----------------- | ---------------------------- | -------------------------------- |
| Loading           | discreto, preferir skeleton  | explícito e operacional          |
| Success           | raro e só quando houver ação | obrigatório nas ações principais |
| Empty             | orienta navegação            | orienta operação                 |
| Validation error  | pouco frequente              | obrigatório em formulários       |
| Unauthorized      | raro                         | central e com redirect           |
| Forbidden         | raro                         | explícito                        |
| Not found         | com retorno para conteúdo    | com retorno para listagem        |
| Server error      | sóbrio e breve               | objetivo e acionável             |
| Retry             | discreto                     | explícito e preservando contexto |
| Feedback pós-ação | pontual                      | obrigatório                      |

---

# 8. Padrões de texto recomendados

---

## Público

* “Não foi possível carregar este conteúdo no momento.”
* “Nenhuma publicação encontrada para os filtros atuais.”
* “A publicação solicitada não foi encontrada.”
* “Tentar novamente”
* “Voltar para publicações”

---

## Administrativo

* “Sua sessão expirou. Faça login novamente.”
* “Você não tem permissão para acessar este recurso.”
* “Não foi possível concluir a operação no momento.”
* “Alterações salvas com sucesso.”
* “Rascunho criado com sucesso.”
* “Status atualizado com sucesso.”
* “Corrija os campos destacados e tente novamente.”

---

# 9. Proibições explícitas

É proibido no `personal-site`:

* erro cru de backend exposto ao usuário
* tela vazia sem explicação
* spinner eterno sem fallback
* formulário que perde dados por erro validável
* sucesso silencioso após ação importante
* confundir sessão expirada com erro genérico
* usar badge como substituto de feedback operacional
* misturar multiple feedbacks concorrentes sem hierarquia
* feedback agressivo, irônico ou infantilizado

---

# 10. Leitura soberana final

O projeto `personal-site` precisa de um sistema de estados que seja:

* institucional no público
* operacional no admin
* previsível nas ações
* claro nos erros
* econômico no texto
* coerente entre rotas, telas e API

Este documento define o padrão para que feedback e estado deixem de ser improviso local e passem a ser **infraestrutura de UX real do sistema**.

---

# 11. Próxima utilização correta deste documento

Este documento deve orientar imediatamente a reforma de:

* `apps/admin/app/painel/login/page.tsx`
* `apps/admin/app/painel/publicacoes/page.tsx`
* `apps/admin/app/painel/publicacoes/[id]/editar/page.tsx`
* `apps/web/app/publicacoes/page.tsx`
* `apps/web/app/publicacoes/[slug]/page.tsx`
* componentes futuros em `packages/ui/src/components/feedback/`
