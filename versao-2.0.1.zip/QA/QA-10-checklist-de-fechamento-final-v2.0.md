# QA-10 — Checklist de Fechamento Final v2.0

## 1. Objetivo
Checklist operacional final para concluir a liberacao da versao `v2.0` sem falso positivo.

## 1.1 Estado atual conhecido desta rodada
- `API-03`: pendente
- `ADM-01`: PASS
- `PUB-01` e `PUB-02`: PASS
- `ADM-02..ADM-05`: pendentes
- `PUB-03..PUB-05`: pendentes
- `G-17`, `G-18`, `G-19`: AMARELO
- `G-20`: VERDE
- `smoke`: houve janela verde (`PASS=10 FAIL=0`) e regressao no `release-check` para `PASS=4 FAIL=3`

## 2. Pre-condicoes
- [ ] API, Web e Admin ativos localmente.
- [ ] Credencial bootstrap valida disponivel.
- [ ] Ultima versao dos documentos QA carregada (`QA-01` a `QA-09`).
- [ ] Rotas basicas sem erro `500` (`/`, `/publicacoes`, `/painel/login`).

## 3. Fechamento funcional (QA-01)
- [ ] `API-03` executado e evidenciado.
- [ ] `ADM-02..ADM-05` executados/evidenciados.
- [ ] `PUB-03..PUB-05` executados/evidenciados.
- [ ] Todos os itens criticos do QA-01 sem pendencia.

## 4. Fechamento de gates (QA-02)
- [ ] G-17 atualizado para `VERDE`.
- [ ] G-18 atualizado para `VERDE`.
- [ ] G-19 atualizado para `VERDE`.
- [ ] G-20 atualizado para `VERDE`.
- [ ] Matriz com G-01..G-20 em `VERDE`.

## 5. Checklist de release (`infra/ci/RELEASE-EVIDENCE-CHECKLIST.md`)
- [ ] A-03 concluido.
- [ ] B-03 concluido (`release-check`).
- [ ] B-04 concluido (`smoke`).
- [ ] C-01..C-05 com status coletado e registrado.
- [ ] D-01 e D-03 concluídos.
- [ ] Nenhum item bloqueante pendente.
- [ ] `smoke` validado com `PASS=10 FAIL=0`.
- [ ] `release-check` validado sem regressao imediata para erro `500` em web/admin.

## 6. Evidencias obrigatorias anexadas
- [ ] Logs de comandos locais (`test:ci`, `verify:hardening`, `release-check`, `smoke`).
- [ ] Evidencias funcionais de admin/web (screenshot ou registro equivalente).
- [ ] Evidencias de `traceId` nos cenarios API/contrato.
- [ ] Status dos workflows CI da rodada.

## 7. Ato final
- [ ] Reemitir `QA-04-ato-final-de-liberacao-v2.0.md`.
- [ ] Definir decisao final: `LIBERAR` ou `BLOQUEAR`.
- [ ] Registrar justificativa objetiva da decisao.

## 8. Congelamento de versao
- [ ] Atualizar relatorio final da rodada de liberacao.
- [ ] Gerar novo zip da versao homologada (sem `node_modules`, `.env`, `.codex`).
- [ ] Registrar handoff final de continuidade (se houver proximo ciclo).

## 9. Criterio de sucesso
Checklist concluido apenas quando todos os itens acima estiverem marcados e a decisao final estiver documentada com evidencia.

## 9.1 Regra de bloqueio explicita
Se qualquer item abaixo estiver aberto, a decisao obrigatoria e `BLOQUEAR`:
1. erro `500` em rotas basicas web/admin;
2. `API-03` sem evidencia;
3. qualquer item `ADM-*` ou `PUB-*` em FAIL;
4. `G-18` ou `G-19` fora de VERDE;
5. `smoke` sem `PASS=10 FAIL=0`;
6. `release-check` com regressao imediata para erro `500` em web/admin.

## 10. Registro da rodada final
Data:
Executor:
Versao alvo:
Decisao final:
Observacoes:
