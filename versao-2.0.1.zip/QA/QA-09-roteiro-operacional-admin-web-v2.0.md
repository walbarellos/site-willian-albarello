# QA-09 — Roteiro Operacional Admin/Web v2.0

## 1. Objetivo
Padronizar a execucao manual dos cenarios pendentes do `QA-01` para os blocos:
1. `ADM-02..ADM-05`
2. `PUB-03..PUB-05`

## 2. Pre-condicoes
1. API em `http://localhost:3002`;
2. Admin em `http://localhost:3001`;
3. Web em `http://localhost:3000`;
4. credencial bootstrap valida (`admin@local.test` / `ChangeMe123!`).
5. sanity check inicial das rotas basicas sem erro `500`:
- `GET http://localhost:3000/`
- `GET http://localhost:3000/publicacoes`
- `GET http://localhost:3001/painel/login`

## 3. Evidencia minima por cenario
Para cada item, registrar:
1. resultado (`PASS`/`FAIL`);
2. evidencia curta (screenshot ou log);
3. observacao tecnica se houver desvio;
4. `traceId` quando houver chamada API associada.

## 4. Roteiro ADM (ADM-01..ADM-05)

Estado atual conhecido:
1. `ADM-01` ja foi comprovado em PASS (redirect 307 + login 200 em runtime limpo);
2. `ADM-02..ADM-05` permanecem pendentes;
3. a rodada ainda exige estabilizacao operacional para evitar regressao apos `release-check`.

## ADM-01 — Redirect de entrada
1. abrir `http://localhost:3001/` sem sessao;
2. validar redirecionamento para `/painel/login`.

Passa quando:
- redirect ocorre sem erro de runtime.

Status atual:
- PASS (ja evidenciado na rodada).

## ADM-02 — Pos-login
1. autenticar na tela `/painel/login`;
2. validar navegação para `/painel/publicacoes`.

Passa quando:
- login conclui e painel abre sem erro fatal.

## ADM-03 — Listagem editorial
1. na listagem, validar carregamento da tabela;
2. testar filtro/busca;
3. testar paginação quando houver multiplos registros.

Passa quando:
- listagem responde sem quebra e estados de UI sao coerentes.

## ADM-04 — Edicao de publicacao
1. abrir `/painel/publicacoes/:id/editar`;
2. alterar campo simples (ex.: resumo);
3. salvar e validar feedback de sucesso.

Passa quando:
- persistencia conclui sem erro fatal e feedback aparece.

## ADM-05 — Transicao de status
1. no fluxo de edicao/listagem, executar transicao valida;
2. confirmar status atualizado.

Passa quando:
- API aceita a transicao e UI reflete o novo estado.

## 5. Roteiro PUB (PUB-01..PUB-05)

Estado atual conhecido:
1. `PUB-01` e `PUB-02` ja foram comprovados em PASS em runtime limpo;
2. `PUB-03..PUB-05` permanecem pendentes;
3. a rodada ainda exige estabilizacao operacional para evitar regressao apos `release-check`.

## PUB-01 — Home publica
1. abrir `http://localhost:3000/`;
2. validar renderizacao completa da home.

Passa quando:
- tela carrega sem erro e blocos principais aparecem.

Status atual:
- PASS (ja evidenciado na rodada).

## PUB-02 — Listagem publica
1. abrir `/publicacoes`;
2. validar lista de cards/publicacoes.

Passa quando:
- lista carrega com estados consistentes.

Status atual:
- PASS (ja evidenciado na rodada).

## PUB-03 — Busca/filtro/pagina
1. aplicar query (`q`, `page`, `pageSize`);
2. validar retorno e navegacao paginada.

Passa quando:
- resultado acompanha parametros sem quebrar contrato.

## PUB-04 — Detalhe por slug valido
1. abrir `/publicacoes/<slug-existente>`;
2. validar conteudo e metadados.

Passa quando:
- pagina abre corretamente com conteudo esperado.

## PUB-05 — Detalhe por slug invalido
1. abrir `/publicacoes/<slug-invalido>`;
2. validar comportamento de not found.

Passa quando:
- nao ocorre crash e o fallback e correto.

## 6. Pos-execucao obrigatoria
1. atualizar `QA-01` com PASS/FAIL e evidencias;
2. atualizar `QA-02` para refletir impacto nos gates G-17..G-20;
3. atualizar `infra/ci/RELEASE-EVIDENCE-CHECKLIST.md` (D-01 e D-03);
4. reexecutar `bash infra/scripts/smoke.sh` e anexar resultado;
5. reemitir `QA-04` com decisao revisada.

## 7. Criterio de saida deste roteiro
Roteiro concluido quando:
1. ADM-02..ADM-05 e PUB-03..PUB-05 estiverem classificados com evidencia;
2. pendencias do QA funcional forem reduzidas a zero ou registradas como FAIL com plano de correcao;
3. `smoke.sh` estiver verde (`PASS=10 FAIL=0`) no estado de liberacao;
4. `release-check.sh` concluir sem regressao imediata de runtime para `500` nas rotas basicas.
