# QA-08 — Registro de Evidencias de Execucao v2.0

## 1. Objetivo
Consolidar, em formato auditavel, os comandos efetivamente executados na rodada v2.0 para validacao tecnica e homologacao funcional.

## 2. Escopo
Inclui apenas evidencias reais coletadas nesta rodada.

Nao inclui:
1. evidencias inferidas;
2. comandos nao executados.

## 3. Evidencias tecnicas gerais

### 3.0 Saneamento operacional (protocolo v2.0)
Comando de referencia da rodada final:
```bash
bash infra/scripts/runtime-reset.sh
```
Status:
1. protocolo incorporado como precondicao obrigatoria antes de `smoke` e `release-check`;
2. evidencia final consolidada com restart limpo do stack.

### 3.1 Testes agregados
Comando executado:
```bash
pnpm test:ci
```
Resultado:
1. sucesso (exit 0);
2. contracts verdes;
3. API verde.

### 3.2 Hardening integrado
Comando executado:
```bash
pnpm verify:hardening
```
Resultado:
1. sucesso (exit 0);
2. build/typecheck de shared/api/web/admin concluido sem erro.

### 3.3 Gate local de release
Comandos executados:
```bash
bash infra/scripts/smoke.sh
bash infra/scripts/release-check.sh
```
Resultado final consolidado:
1. `smoke.sh` verde (`PASS=10 FAIL=0`);
2. `release-check.sh` verde (`test:ci` + `verify:hardening` + smoke final verde);
3. sem regressao imediata de `500` nas rotas basicas (`/`, `/publicacoes`, `/painel/login`).

## 4. Evidencias HTTP coletadas (API/Contrato/Auth)

### 4.1 Health e Ready
Comandos executados:
```bash
curl -sS -D - http://127.0.0.1:3002/health
curl -sS -D - http://127.0.0.1:3002/ready
```
Resultados:
1. `/health` -> HTTP 200, `data.status=ok`, `meta.traceId=6f4179e2-64ea-45d1-ba9f-884f45c9480a`;
2. `/ready` -> HTTP 200, `data.ready=true`, `meta.traceId=ed4ebeb9-a8e3-4bf1-9c5a-9cd6689fd170`.

### 4.2 Envelope de erro padrao
Comando executado:
```bash
curl -sS -D - http://127.0.0.1:3002/rota-inexistente
```
Resultado:
1. HTTP 404;
2. `error.code=NOT_FOUND`;
3. `meta.traceId=9b5b9689-00ec-4209-b360-fcd275672407`.

### 4.3 Auth — invalido/valido/sessao/logout
Resultados objetivos registrados:
1. payload invalido -> HTTP 422 (`VALIDATION_ERROR`, traceId presente);
2. credencial invalida -> HTTP 401 (`UNAUTHENTICATED`, traceId presente);
3. login valido -> HTTP 200 + usuario bootstrap + cookie de sessao;
4. sessao ativa -> HTTP 200;
5. sessao sem cookie -> HTTP 401 (`SESSION_EXPIRED`);
6. logout com/sem cookie -> HTTP 200 (`success=true`).

### 4.4 Contrato — query invalida em listagem publica
Comando executado:
```bash
curl -sS -D - 'http://127.0.0.1:3002/v1/public/publications?page=abc'
```
Resultado:
1. HTTP 422;
2. `error.code=VALIDATION_ERROR`;
3. `meta.traceId=30ee37a7-7960-4342-a15f-678174529823`.

## 5. Evidencia funcional complementar da rodada final
Resumo objetivo:
1. API-03 validado por teste dedicado de `health.test.ts` (`/ready` bloqueante => 503);
2. ADM-02 validado por navegador headless com submit real e URL final em `/painel/publicacoes`;
3. ADM-03/ADM-04/ADM-05 em PASS com evidencias HTTP objetivas;
4. PUB-03/PUB-04/PUB-05 em PASS com evidencias HTTP objetivas;
5. CT-01 e CT-02 em PASS com `meta.traceId`.

## 6. Evidencia remota de workflows CI (C-01..C-05)
Coleta consolidada em 2026-04-06:
```bash
gh run list -R walbarellos/site-willian-albarello --limit 30 --json databaseId,name,workflowName,headSha,status,conclusion,createdAt,updatedAt,url
```

Resultados:
1. C-01 Scaffold Bootstrap: `success` — run `24015983801` — sha `93427fa`;
2. C-02 API Contract: `success` — run `24015906452` — sha `a9a6e64`;
3. C-03 API Docs: `success` — run `24015983797` — sha `93427fa`;
4. C-04 API Breaking Change: `success` — run `24015983791` — sha `93427fa`;
5. C-05 Deploy Readiness: `success` — run `24015983822` — sha `93427fa`.

Conclusao de C-01..C-05:
- todos em PASS com evidencia remota coletada.

## 7. Conclusao objetiva
A rodada v2.0 possui evidencia tecnica, funcional e de CI suficiente para fechamento sem ressalvas. O bloqueio residual anterior (coleta de workflows C-01..C-05) foi encerrado nesta coleta remota.
