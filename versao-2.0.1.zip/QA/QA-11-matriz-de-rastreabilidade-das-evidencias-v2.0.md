# QA-11 — Matriz de Rastreabilidade das Evidencias v2.0

## 1. Objetivo
Mapear, de forma direta e auditavel, a relacao entre:
1. requisito de fechamento da versao;
2. evidencia existente;
3. gate relacionado;
4. documento soberano que registra a prova;
5. status atual.

## 2. Fontes soberanas
1. `QA/QA-01-checklist-de-homologacao-funcional.md`
2. `QA/QA-02-matriz-de-gates-ci-e-deploy-readiness.md`
3. `QA/QA-03-auditoria-consolidada-final.md`
4. `QA/QA-04-ato-final-de-liberacao-v2.0.md`
5. `QA/QA-08-registro-de-evidencias-de-execucao-v2.0.md`
6. `QA/QA-13-diagnostico-operacional-runtime-500-v2.0.md`
7. `infra/ci/RELEASE-EVIDENCE-CHECKLIST.md`
8. `RELATORIO-FINAL-V2.0.md`

## 3. Matriz de rastreabilidade

| Bloco | Item | Gate relacionado | Evidencia existente | Documento de prova | Status |
|---|---|---|---|---|---|
| Tecnico | `pnpm test:ci` | B-01 | executado com sucesso | `RELATORIO-FINAL-V2.0.md`, `QA-08` | CONCLUIDO |
| Tecnico | `pnpm verify:hardening` | B-02 | executado com sucesso | `RELATORIO-FINAL-V2.0.md`, `QA-08` | CONCLUIDO |
| Tecnico | `runtime-reset` pre-smoke | A-04 | execucao final consolidada antes de smoke/release-check | `RELEASE-EVIDENCE-CHECKLIST.md`, `QA-08` | CONCLUIDO |
| Funcional API | API-01..API-04 | G-17 / D-03 | todos em PASS com evidencias objetivas | `QA-01`, `QA-08` | CONCLUIDO |
| Funcional Auth/Admin | AUTH-01..AUTH-06 + ADM-01..ADM-05 | G-18 / D-03 | todos em PASS; ADM-02 com browser headless | `QA-01`, `QA-08`, `QA-09` | CONCLUIDO |
| Funcional Web | PUB-01..PUB-05 | G-19 / D-03 | todos em PASS com status HTTP objetivo | `QA-01`, `QA-08`, `QA-09` | CONCLUIDO |
| Contrato | CT-01 e CT-02 | G-20 / D-03 | evidenciados em PASS com traceId | `QA-01`, `QA-08` | CONCLUIDO |
| Workflows CI | C-01..C-05 | C-01..C-05 | todos com run remoto `success` coletado por `gh run list` | `RELEASE-EVIDENCE-CHECKLIST.md`, `QA-08` | CONCLUIDO |
| Checklist release | A..E | A..E | checklist sem bloqueio e decisao `LIBERAR` | `RELEASE-EVIDENCE-CHECKLIST.md`, `QA-04` | CONCLUIDO |

## 4. Leitura executiva da matriz
1. trilha tecnica principal esta fechada;
2. trilha funcional esta fechada (API/Auth/Admin/Web/CT em PASS);
3. trilha de workflows CI esta fechada (C-01..C-05 em PASS remoto);
4. rastreabilidade final esta consolidada para decisao binaria sem ambiguidades.

## 5. Criterio de fechamento desta matriz
1. zero item em `PENDENTE`;
2. referencia cruzada consistente entre QA-01, QA-02, QA-08, checklist e QA-04;
3. decisao final coerente entre checklist e ato final.

## 6. Conclusao
Esta matriz confirma fechamento integral da trilha de evidencia da v2.0 e sustenta a decisao final de `LIBERAR` sem ressalvas.
