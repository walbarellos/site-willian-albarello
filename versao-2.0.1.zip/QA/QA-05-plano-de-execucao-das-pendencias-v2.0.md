# QA-05 — Plano de Execucao das Pendencias v2.0

## 1. Objetivo
Registrar a execucao final das pendencias bloqueantes da v2.0 e congelar o estado de fechamento para auditoria.

## 2. Base de referencia
1. `QA/QA-01-checklist-de-homologacao-funcional.md`
2. `QA/QA-02-matriz-de-gates-ci-e-deploy-readiness.md`
3. `QA/QA-04-ato-final-de-liberacao-v2.0.md`
4. `infra/ci/RELEASE-EVIDENCE-CHECKLIST.md`
5. `QA/QA-08-registro-de-evidencias-de-execucao-v2.0.md`
6. `QA/QA-11-matriz-de-rastreabilidade-das-evidencias-v2.0.md`
7. `QA/QA-13-diagnostico-operacional-runtime-500-v2.0.md`

## 3. Estado de pendencias
Pendencias bloqueantes iniciais desta trilha:
1. `C-01..C-05` (coleta de status dos workflows CI).

Estado final:
1. `C-01..C-05` fechados com evidencia remota de runs `success`.
2. sem pendencias bloqueantes remanescentes.

## 4. Execucao consolidada por blocos

### Bloco A — Preparacao de ambiente
- executado (`runtime-reset` + disponibilidade de api/web/admin).

### Bloco B — Estabilizacao operacional web/admin
- executado e encerrado sem regressao imediata de `500`.

### Bloco C — API-03 (ready degradado)
- fechado via teste dedicado `health.test.ts` (`/ready` => 503 em degradacao bloqueante).

### Bloco D — Fluxo ADM (ADM-01..ADM-05)
- fechado com evidencias objetivas; ADM-02 confirmado por navegador headless.

### Bloco E — Fluxo PUB (PUB-01..PUB-05)
- fechado com evidencias objetivas.

### Bloco F — Checklist de release local
- `release-check` e `smoke` consolidados em verde.

### Bloco G — Evidencia de workflows CI
- coleta remota realizada por `gh run list`.
- C-01..C-05 fechados em PASS.

### Bloco H — Fechamento documental
- QA-01, QA-02, QA-08, QA-11, QA-13 e checklist atualizados.
- QA-04 reemitido com decisao final `LIBERAR`.

## 5. Criterio final de sucesso
Plano considerado concluido quando:
1. QA-01 sem pendencia em itens criticos;
2. QA-02 com G-01..G-20 em VERDE;
3. checklist de release sem item bloqueante pendente;
4. QA-04 com `DECISAO: LIBERAR`.

Resultado final:
- **CONCLUIDO**.

## 6. Backlog residual
1. nenhum item bloqueante residual desta versao.
2. evolucoes futuras devem abrir novo ciclo (nao reabrir o fechamento da v2.0).
