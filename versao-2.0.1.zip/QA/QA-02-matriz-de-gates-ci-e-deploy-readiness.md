# QA-02 — Matriz de Gates CI e Deploy Readiness

## 1. Objetivo
Consolidar os gates tecnicos e funcionais que precisam estar verdes para declarar o `personal-site` apto a avancar para deploy/readiness.

## 2. Fontes soberanas deste gate
1. `package.json` (scripts de build/typecheck/test)
2. `.github/workflows/scaffold-bootstrap.yml`
3. `.github/workflows/api-contract.yml`
4. `.github/workflows/api-docs.yml`
5. `.github/workflows/api-breaking-change.yml`
6. `.github/workflows/deploy-readiness.yml`
7. `Scaffold/SCF-04-bootstrap-de-qualidade-local-e-ci.md`
8. `QA/QA-01-checklist-de-homologacao-funcional.md`
9. `RELATORIO-FINAL-V2.0.md`
10. `infra/scripts/runtime-reset.sh`
11. `infra/scripts/smoke.sh`
12. `infra/scripts/release-check.sh`
13. `infra/ci/RELEASE-EVIDENCE-CHECKLIST.md`

## 3. Escala de status
- `VERDE`: gate implementado e com criterio objetivo de aprovacao + evidencia da rodada
- `AMARELO`: gate implementado parcialmente ou sem evidencia funcional completa na rodada
- `VERMELHO`: gate ausente ou sem condicao operacional minima

## 4. Matriz de gates

| Gate ID | Gate | Criterio de aprovacao | Evidencia esperada | Estado atual | Observacao |
|---|---|---|---|---|---|
| G-01 | Instalacao deterministica | `pnpm install --frozen-lockfile` conclui sem erro | log CI/local | VERDE | install executado no fluxo de validacao tecnica da rodada |
| G-02 | Build compartilhado | `pnpm build:shared` verde | log com exit code 0 | VERDE | coberto por `pnpm verify:hardening` |
| G-03 | Typecheck compartilhado | `pnpm typecheck:shared` verde | log com exit code 0 | VERDE | coberto por `pnpm verify:hardening` |
| G-04 | Build API | `pnpm build:api` verde | log com exit code 0 | VERDE | coberto por `pnpm verify:hardening` |
| G-05 | Typecheck API | `pnpm typecheck:api` verde | log com exit code 0 | VERDE | coberto por `pnpm verify:hardening` |
| G-06 | Build Web | `pnpm build:web` verde | log com exit code 0 | VERDE | coberto por `pnpm verify:hardening` |
| G-07 | Typecheck Web | `pnpm typecheck:web` verde | log com exit code 0 | VERDE | coberto por `pnpm verify:hardening` |
| G-08 | Build Admin | `pnpm build:admin` verde | log com exit code 0 | VERDE | coberto por `pnpm verify:hardening` |
| G-09 | Typecheck Admin | `pnpm typecheck:admin` verde | log com exit code 0 | VERDE | coberto por `pnpm verify:hardening` |
| G-10 | Verificacao agregada hardening | `pnpm verify:hardening` verde | log CI/local | VERDE | executado com sucesso |
| G-11 | Contrato OpenAPI basico | `api-contract.yml` passa validacoes de presenca/chaves | status do workflow | VERDE | run `24015906452` sucesso |
| G-12 | Documentacao OpenAPI basica | `api-docs.yml` valida core keys + refs + README | status do workflow | VERDE | run `24015983797` sucesso |
| G-13 | Guarda de breaking change contratual | `api-breaking-change.yml` bloqueia remocoes de superficie | status do workflow em PR | VERDE | run `24015983791` sucesso |
| G-14 | Testes unitarios contracts | `pnpm test:contracts` verde | relatorio de teste | VERDE | executado via `pnpm test:ci` |
| G-15 | Testes API por injecao | `pnpm test:api` verde | relatorio de teste | VERDE | executado via `pnpm test:ci` |
| G-16 | Testes agregados CI | `pnpm test:ci` verde | relatorio de teste | VERDE | executado com sucesso |
| G-17 | Homologacao funcional API | itens `API-*` em PASS no QA-01 | checklist preenchido + evidencias | VERDE | API-01..API-04 em PASS |
| G-18 | Homologacao funcional Auth/Admin | itens `AUTH-*` e `ADM-*` em PASS | checklist preenchido + evidencias | VERDE | AUTH/ADM em PASS; ADM-02 validado por browser headless |
| G-19 | Homologacao funcional Web publico | itens `PUB-*` em PASS | checklist preenchido + evidencias | VERDE | PUB-01..PUB-05 em PASS |
| G-20 | Coerencia de envelope/trace | itens `CT-*` em PASS | evidencia de `meta.traceId` e erros padronizados | VERDE | CT-01 e CT-02 em PASS |

## 5. Gates obrigatorios para readiness de deploy
Deploy readiness sem ressalva so pode ser declarado quando os gates abaixo estiverem `VERDE`:
1. G-01 a G-10
2. G-11, G-12, G-13
3. G-14, G-15, G-16
4. G-17, G-18, G-19, G-20

## 6. Criterio de aprovacao final da rodada QA
Para fechamento sem ressalva:
1. manter pipeline local minima verde (`verify:hardening` + `test:ci`);
2. garantir workflows CI criticos verdes;
3. preencher `QA-01` com evidencias reais de homologacao funcional;
4. manter esta matriz sincronizada com as evidencias da versao.

Condicao de aprovacao sem ressalva:
- 100% dos gates obrigatorios em `VERDE`.

Estado consolidado da rodada v2.0:
- todos os gates obrigatorios em VERDE.

## 7. Registro de estado atual desta versao
Data: 2026-04-06
Ambiente: local + remoto (Actions)
Executor: IA + operador do ciclo

Resumo:
1. Gates VERDE:
- G-01..G-20
2. Gates AMARELO:
- nenhum
3. Gates VERMELHO:
- nenhum
4. Bloqueios:
- nenhum
5. Proxima acao:
- manter monitoramento de regressao nas proximas mudancas de codigo.
