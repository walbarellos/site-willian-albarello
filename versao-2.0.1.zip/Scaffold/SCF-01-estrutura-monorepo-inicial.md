# SCF-01 — Estrutura Monorepo Inicial

## Endereço

`/home/walbarellos/personal-site/personal-site(Graciliano)/Scaffold/SCF-01-estrutura-monorepo-inicial.md`

## Objetivo

Registrar a estrutura física atual do monorepo `personal-site`, distinguindo claramente código-fonte, pacotes compartilhados, documentação e artefatos gerados.

## Fontes auditadas

- `pnpm-workspace.yaml`
- `package.json` (raiz)
- árvore real de diretórios `apps/*` e `packages/*`
- árvore documental (`APIs`, `UI_UX`, `Waterfall`, `Scaffold`, `Implementacao`, `Diagrama`)

## Workspace soberano

Definição oficial (`pnpm-workspace.yaml`):

- `apps/*`
- `packages/*`

Orquestração na raiz (`package.json`):

- scripts por app/pacote
- sequência `verify:hardening` para validação técnica integrada

## Estrutura física principal

### 1) Apps executáveis

`apps/api`

- backend Fastify
- código-fonte em `apps/api/src`
- build em `apps/api/dist`

`apps/web`

- frontend público (Next.js App Router)
- código-fonte em `apps/web/app` e `apps/web/src`

`apps/admin`

- painel administrativo (Next.js App Router)
- código-fonte em `apps/admin/app` e `apps/admin/src`

### 2) Pacotes compartilhados

`packages/contracts`

- contratos de tipos/rotas/sessão/publicações
- fonte em `packages/contracts/src`
- build em `packages/contracts/dist`

`packages/ui`

- componentes reutilizáveis de admin e feedback
- fonte em `packages/ui/src`
- build em `packages/ui/dist`

### 3) Camadas documentais e contratuais

`APIs/`

- contratos OpenAPI do ciclo

`Waterfall/`

- documentação técnica e de governança

`UI_UX/`

- contratos de tela, feedback e diretrizes de interface

`Scaffold/`

- bootstrap estrutural e qualidade do monorepo

`Implementacao/`

- documentos de implantação por camada

`Diagrama/`

- diagramas Mermaid do sistema

`/.github/workflows/`

- automações de validação e contratos

## Convenções de organização

1. Apps concentram execução e runtime.
2. Packages concentram compartilhamento transversal.
3. Contratos (`packages/contracts`, OpenAPI) antecedem mudanças de consumo.
4. Documentação deve acompanhar o estado físico do código.

## Código-fonte vs artefatos gerados

Presentes no estado atual:

- artefatos de build (`dist/`, `.next/`)
- diretórios de dependências (`node_modules/`)

Diretriz de auditoria/empacotamento:

- considerar soberano o conteúdo de fonte e documentação
- excluir artefatos gerados e dependências quando o objetivo for auditoria documental/técnica

## Mapa mínimo para navegação rápida

- backend: `apps/api/src`
- frontend público: `apps/web/app`, `apps/web/src`
- frontend admin: `apps/admin/app`, `apps/admin/src`
- contratos: `packages/contracts/src`
- UI compartilhada: `packages/ui/src`
- OpenAPI: `APIs/`
- documentação de processo: `Waterfall/`, `UI_UX/`, `Scaffold/`, `Implementacao/`, `Diagrama/`

## Critérios de aceite deste documento

1. A estrutura listada corresponde ao estado físico do repositório.
2. `apps/*` e `packages/*` batem com o workspace PNPM.
3. Há separação explícita entre fonte e artefatos gerados.
4. O mapa de navegação permite continuidade de ciclo sem ambiguidade.

## Riscos residuais aceitos

- presença de artefatos gerados no workspace local pode confundir leitura rápida da árvore

Mitigação do ciclo:

- usar este documento como referência soberana de estrutura ao abrir novos ciclos.
