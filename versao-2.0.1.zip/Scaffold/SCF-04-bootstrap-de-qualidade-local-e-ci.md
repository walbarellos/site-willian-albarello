# SCF-04 — Bootstrap de Qualidade Local e CI

## 1. Objetivo deste documento
Este documento define a ordem soberana de validação técnica do monorepo `personal-site` no ciclo de fechamento técnico (Hardening).

A intenção é evitar falso positivo de “projeto pronto” quando ainda existe falha em:
- toolchain TypeScript
- pacotes compartilhados (`contracts` e `ui`)
- integração `api` ↔ `admin` ↔ `web`
- build/typecheck por pacote
- fluxo mínimo de homologação funcional

Este arquivo é operacional. Não é texto conceitual.

## 2. Escopo atual do monorepo
Workspaces:
- `apps/api`
- `apps/web`
- `apps/admin`
- `packages/contracts`
- `packages/ui`

Scripts relevantes na raiz:
- `pnpm run clean`
- `pnpm run build:shared`
- `pnpm run typecheck:shared`
- `pnpm run build:api`
- `pnpm run typecheck:api`
- `pnpm run build:web`
- `pnpm run typecheck:web`
- `pnpm run build:admin`
- `pnpm run typecheck:admin`
- `pnpm run verify:hardening`

## 3. Pré-requisitos locais
Versões e dependências mínimas:
- Node `>=20.11.0`
- PNPM `10.x`
- Dependências instaladas na raiz (`pnpm install`)

Variáveis de ambiente mínimas para execução real da API:
- `PORT`
- `NODE_ENV`
- `SESSION_SECRET`
- `DATABASE_URL`
- `PUBLIC_SITE_URL`
- `ADMIN_SITE_URL`
- `CORS_ORIGINS`

Observação:
- Para typecheck/build, parte das variáveis pode não ser necessária.
- Para homologação funcional, configuração de ambiente deve estar íntegra.

## 4. Sequência soberana de validação técnica
A sequência abaixo deve ser seguida sem trocar ordem.

### Fase A — higiene de execução
1. `pnpm run clean`

### Fase B — pacotes compartilhados (base da tipagem)
2. `pnpm --filter @william-albarello/contracts build`
3. `pnpm --filter @william-albarello/contracts typecheck`
4. `pnpm --filter @william-albarello/ui build`
5. `pnpm --filter @william-albarello/ui typecheck`

### Fase C — backend API
6. `pnpm --filter @william-albarello/api build`
7. `pnpm --filter @william-albarello/api typecheck`

### Fase D — frontend público
8. `pnpm --filter @william-albarello/web build`
9. `pnpm --filter @william-albarello/web typecheck`

### Fase E — frontend administrativo
10. `pnpm --filter @william-albarello/admin build`
11. `pnpm --filter @william-albarello/admin typecheck`

### Fase F — comando agregado
12. `pnpm run verify:hardening`

Observação de disciplina:
- O comando agregado não substitui as fases anteriores em diagnóstico.
- Em caso de falha, corrigir no menor escopo e reexecutar da fase afetada para frente.

## 5. Critérios de aceite técnico deste ciclo
O ciclo só pode ser considerado tecnicamente fechado quando:
1. todos os comandos da sequência soberana acima finalizam com exit code 0
2. `packages/contracts` compila e gera artefatos em `dist`
3. `packages/ui` compila e gera artefatos em `dist`
4. `apps/api`, `apps/web` e `apps/admin` passam em build e typecheck
5. não existe erro de resolução de módulo (`moduleResolution classic`, etc.)
6. não existe quebra de contrato de tipos entre `contracts` e consumidores

## 6. Homologação funcional mínima (manual)
Após validação técnica, validar fluxo mínimo ponta a ponta:
1. Health da API: `GET /health` retorna 200 com `meta.traceId`
2. Ready da API: `GET /ready` retorna 200 (ou 503 com envelope padronizado)
3. Login admin: fluxo de autenticação conclui com sessão válida
4. Sessão admin: leitura de sessão atual retorna usuário autenticado
5. Listagem admin: painel lista publicações com paginação/filtros
6. Edição admin: salvar conteúdo e SEO funciona com feedback correto
7. Transição editorial: mudança de status respeita regras
8. Web público: home, listagem e detalhe por slug carregam sem quebra

## 7. Política de falha e reexecução
Quando qualquer passo falhar:
1. registrar o comando que falhou
2. registrar o erro objetivo (mensagem e arquivo, quando aplicável)
3. corrigir no menor conjunto de arquivos possível
4. reexecutar a partir da fase correspondente
5. só avançar para a próxima fase com resultado 100% verde

Não pular fases.

## 8. Observabilidade mínima durante validação
Durante validação local:
- monitorar logs da API com `traceId`
- confirmar envelopes de erro padronizados (código/mensagem/meta.traceId)
- confirmar ausência de resposta HTML inesperada em clients JSON

## 9. Saída esperada para CI
O workflow de CI deste ciclo deve reproduzir, no mínimo:
1. instalação de dependências
2. execução da sequência soberana de build/typecheck
3. falha imediata em qualquer etapa com exit code não-zero

Arquivo relacionado:
- `.github/workflows/scaffold-bootstrap.yml`

## 10. Encerramento do ciclo
Este ciclo é encerrado somente quando:
- validação técnica está íntegra
- homologação mínima foi executada
- fluxo de CI básico está ativo
- documentação de continuidade do próximo ciclo foi atualizada

Sem esses quatro pontos, o ciclo permanece aberto.
