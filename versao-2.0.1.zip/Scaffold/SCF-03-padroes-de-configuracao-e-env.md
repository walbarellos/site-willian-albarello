# SCF-03 — Padrões de Configuração e ENV

## Endereço

`/home/walbarellos/personal-site/personal-site(Graciliano)/Scaffold/SCF-03-padroes-de-configuracao-e-env.md`

## Objetivo

Definir o padrão de configuração e variáveis de ambiente do monorepo com base no comportamento real de API, web e admin.

## Fontes auditadas

- `.env.example`
- `apps/api/src/lib/env.ts`
- `apps/web/src/lib/api/public.ts`
- `apps/web/app/page.tsx`
- `apps/web/app/publicacoes/[slug]/page.tsx`
- `apps/admin/src/lib/api/admin.ts`
- `apps/admin/app/layout.tsx`

## Contrato base de ambiente

Fonte soberana: `.env.example`.

Diretriz:

- desenvolvimento: copiar para `.env` e ajustar
- produção: usar segredos reais, sem defaults de desenvolvimento

## Segmentação de variáveis por contexto

### 1) Global

- `NODE_ENV`

### 2) API / backend

- `PORT`
- `SESSION_SECRET`
- `DATABASE_URL`
- `PUBLIC_SITE_URL`
- `ADMIN_SITE_URL`
- `CORS_ORIGINS`
- `ADMIN_BOOTSTRAP_EMAIL`
- `ADMIN_BOOTSTRAP_PASSWORD`
- `ADMIN_BOOTSTRAP_DISPLAY_NAME`
- `ADMIN_BOOTSTRAP_ROLE`

### 3) Web público

- `NEXT_PUBLIC_SITE_URL`
- `NEXT_PUBLIC_API_URL`
- `PUBLIC_API_URL`
- `API_URL`

### 4) Admin

- `NEXT_PUBLIC_ADMIN_URL`
- `NEXT_PUBLIC_API_URL`
- `ADMIN_API_URL`
- `API_URL`

## Loader soberano da API

Arquivo: `apps/api/src/lib/env.ts`.

Comportamento atual:

- validação com Zod
- fail-fast em configuração inválida
- defaults de desenvolvimento controlados
- exigências mais rígidas fora de `development`

Regras relevantes implementadas:

- `PORT` válido entre `1..65535`
- `SESSION_SECRET` mínimo de 16 chars (dev) e 32 (prod)
- em produção, `SESSION_SECRET` não pode ser o default de dev
- `PUBLIC_SITE_URL` e `ADMIN_SITE_URL` devem ser URLs absolutas
- `CORS_ORIGINS` deve conter apenas URLs válidas
- fora de desenvolvimento, `CORS_ORIGINS` não pode ficar vazio

## Resolução de endpoint nos clients

### 1) Web (`apps/web/src/lib/api/public.ts`)

Ordem de precedência:

1. `NEXT_PUBLIC_API_URL`
2. `PUBLIC_API_URL`
3. `API_URL`
4. fallback `http://localhost:3002`

### 2) Admin (`apps/admin/src/lib/api/admin.ts`)

Ordem de precedência:

1. `NEXT_PUBLIC_API_URL`
2. `ADMIN_API_URL`
3. `API_URL`
4. fallback `http://localhost:3002`

## Resolução de metadata base por app

Web:

- `apps/web/app/page.tsx` e detalhe por slug usam `NEXT_PUBLIC_SITE_URL` com fallback local

Admin:

- `apps/admin/app/layout.tsx` usa `NEXT_PUBLIC_ADMIN_URL` com fallback `http://localhost:3001`

## Padrão de segurança operacional

1. Não versionar `.env` com segredo real.
2. Manter `SESSION_SECRET` de alta entropia.
3. Trocar `ADMIN_BOOTSTRAP_PASSWORD` em qualquer ambiente não local.
4. Restringir `CORS_ORIGINS` às origens realmente autorizadas.

## Fluxo mínimo de bootstrap local

1. `cp .env.example .env`
2. ajustar segredos e URLs
3. `pnpm install`
4. subir API, web e admin

## Diagnóstico rápido de falha de configuração

1. API não sobe: revisar mensagem de fail-fast em `env.ts`.
2. CORS bloqueando browser: validar `CORS_ORIGINS`.
3. frontend chamando API errada: validar ordem de precedência no client.
4. metadata base incorreta: revisar `NEXT_PUBLIC_SITE_URL` ou `NEXT_PUBLIC_ADMIN_URL`.

## Critérios de aceite deste documento

1. Variáveis documentadas batem com `.env.example`.
2. Regras de validação batem com `apps/api/src/lib/env.ts`.
3. Ordens de resolução de URL batem com clients web/admin.
4. Documento permite bootstrap local sem ambiguidade.
