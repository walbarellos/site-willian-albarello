# SCF-02 — Templates de Apps e Pacotes

## Endereço

`/home/walbarellos/personal-site/personal-site(Graciliano)/Scaffold/SCF-02-templates-de-apps-e-pacotes.md`

## Objetivo

Documentar os templates reais de workspace usados no monorepo (apps e packages), com base nos manifests e tsconfigs atuais.

## Fontes auditadas

- `package.json` (raiz)
- `apps/api/package.json`
- `apps/web/package.json`
- `apps/admin/package.json`
- `packages/contracts/package.json`
- `packages/ui/package.json`
- `apps/api/tsconfig.json`
- `apps/web/tsconfig.json`
- `apps/admin/tsconfig.json`
- `packages/contracts/tsconfig.json`
- `packages/ui/tsconfig.json`
- `tsconfig.base.json`

## Template base de workspace

Campos comuns observados:

- `name`
- `version`
- `private: true`
- `type: module`

Scripts mínimos recorrentes:

- `build`
- `typecheck`
- `clean`

Apps executáveis adicionam:

- `dev`
- `start`

## Template de apps

### 1) API (`@william-albarello/api`)

Manifest (`apps/api/package.json`):

- `dev`: `tsx watch src/index.ts`
- `build`: `tsc -p tsconfig.json`
- `start`: `node dist/index.js`
- `typecheck`: `tsc -p tsconfig.json --noEmit`
- `clean`: `rm -rf dist`

Tsconfig (`apps/api/tsconfig.json`):

- `module: NodeNext`
- `moduleResolution: NodeNext`
- `rootDir: ./src`
- `outDir: ./dist`
- `noEmit: false`

### 2) Web público (`@william-albarello/web`)

Manifest (`apps/web/package.json`):

- `dev`: `next dev -p 3000`
- `build`: `next build`
- `start`: `next start -p 3000`
- `typecheck`: `tsc -p tsconfig.json --noEmit`
- `clean`: `rm -rf .next`

Dependências-chave:

- `next`, `react`, `react-dom`
- `@william-albarello/contracts` (`workspace:*`)
- `@william-albarello/ui` (`workspace:*`)

Tsconfig (`apps/web/tsconfig.json`):

- `module: ESNext`
- `moduleResolution: Bundler`
- `jsx: preserve`
- `noEmit: true`
- plugin `next`
- `paths` para `contracts` e `ui`

### 3) Admin (`@william-albarello/admin`)

Manifest (`apps/admin/package.json`):

- `dev`: `next dev -p 3001`
- `build`: `next build --webpack`
- `start`: `next start -p 3001`
- `typecheck`: `tsc -p tsconfig.json --noEmit`
- `clean`: `rm -rf .next`

Dependências e tsconfig seguem o mesmo padrão estrutural do `apps/web`.

## Template de packages

### 1) Contracts (`@william-albarello/contracts`)

Manifest (`packages/contracts/package.json`):

- saída em `dist`
- `main/module/types` apontando para `dist/index.*`
- `exports["."]` explícito
- `sideEffects: false`
- scripts: `build`, `typecheck`, `clean`

Tsconfig (`packages/contracts/tsconfig.json`):

- `rootDir: ./src`
- `outDir: ./dist`
- `declaration: true`
- `declarationMap: true`
- `composite: true`
- `noEmit: false`

### 2) UI (`@william-albarello/ui`)

Manifest (`packages/ui/package.json`):

- mesmo padrão de distribuição do `contracts`
- `peerDependencies` de `react` e `react-dom`
- scripts: `build`, `typecheck`, `clean`

Tsconfig (`packages/ui/tsconfig.json`):

- `rootDir: ./src`
- `outDir: ./dist`
- `module: ESNext`
- `moduleResolution: Bundler`
- `jsx: react-jsx`
- `declaration: true`
- `composite: true`

## Base global TypeScript

Arquivo: `tsconfig.base.json`.

Baseline atual:

- `target: ES2022`
- `module: ESNext`
- `moduleResolution: Bundler`
- `strict: true`
- `resolveJsonModule: true`

Leitura operacional:

- apps/packages sobrescrevem quando necessário (`NodeNext` na API, por exemplo)

## Orquestração de validação na raiz

`package.json` raiz define:

- builds e typechecks por escopo (`shared`, `api`, `web`, `admin`)
- `verify:hardening` com sequência completa do ciclo

## Regras de consistência para novos módulos

1. Repetir padrão de scripts (`build`, `typecheck`, `clean`).
2. Definir tsconfig compatível com o runtime do workspace.
3. Em package compartilhado, publicar saída por `dist` com `types` e `exports` estáveis.
4. Integrar o novo módulo na validação da raiz quando aplicável.

## Anti-padrões a evitar

- workspace sem `typecheck`
- package compartilhado sem `exports`/`types` explícitos
- dependência de caminhos internos de outro app
- divergência de `moduleResolution` sem justificativa técnica

## Critérios de aceite deste documento

1. Template descrito bate com manifests e tsconfigs atuais.
2. Diferenças entre API e frontends ficam explícitas.
3. Padrões de packages compartilhados ficam claros para reprodução.
4. Documento permite criar novo workspace sem quebrar convenção do monorepo.
