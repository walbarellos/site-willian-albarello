# DOC-21 — Observabilidade, Logs e Incidentes

## Endereço

`/home/walbarellos/personal-site/personal-site(Graciliano)/Waterfall/DOC-21-observabilidade-logs-e-incidentes.md`

## Objetivo

Registrar o baseline de observabilidade **já implementado** no projeto para diagnóstico operacional de API, admin e web.

## Fontes auditadas

- `apps/api/src/server.ts`
- `apps/api/src/lib/http-contract.ts`
- `apps/admin/src/lib/api/admin.ts`
- `apps/web/src/lib/api/public.ts`
- `Scaffold/SCF-04-bootstrap-de-qualidade-local-e-ci.md`
- `.github/workflows/scaffold-bootstrap.yml`

## Escopo

Incluído:

- correlação de requisições com `traceId`
- logging estruturado da API
- envelope de sucesso/erro com metadados
- sinais mínimos para triagem de incidente
- relação entre observabilidade e validação técnica do ciclo

Fora do escopo neste ciclo:

- APM externo
- SIEM centralizado
- alerta automático com SLO/SLA formal

## Baseline implementado

### 1) Correlation ID (`traceId`)

Fonte: `apps/api/src/server.ts`.

- `requestIdHeader: 'x-trace-id'`
- validação de formato para `x-trace-id` recebido
- fallback para UUID quando o header não é válido/ausente
- resposta expõe `x-trace-id`

Resultado: cada requisição pode ser rastreada ponta a ponta.

### 2) Envelope HTTP padronizado

Fonte: `apps/api/src/lib/http-contract.ts`.

Sucesso:

- `data`
- `meta.traceId`

Erro:

- `error.code`
- `error.message`
- `error.details?`
- `meta.traceId`

Resultado: clients não precisam inferir erro por texto solto.

### 3) Logging estruturado da API

Fonte: `apps/api/src/server.ts`.

- log por resposta em `onResponse` com:
  - `traceId`
  - `method`
  - `route`
  - `statusCode`
  - `responseTimeMs`
- separação entre falha esperada (`4xx`) e inesperada (`5xx`) no `setErrorHandler`
- redaction de dados sensíveis no logger:
  - `authorization`
  - `cookie`
  - `set-cookie`

## Taxonomia de erro observável

A API normaliza erro para códigos contratuais, incluindo:

- `UNAUTHENTICATED`
- `SESSION_EXPIRED`
- `FORBIDDEN`
- `CSRF_INVALID_TOKEN`
- `VALIDATION_ERROR`
- `INVALID_STATE_TRANSITION`
- `RATE_LIMITED`
- `INTERNAL_SERVER_ERROR`

Esses códigos devem ser usados na triagem junto com `traceId`.

## Sinais em clients (admin e web)

### Admin client (`apps/admin/src/lib/api/admin.ts`)

- exceção tipada `AdminApiError`
- preserva `status`, `code`, `traceId` e `details`
- classifica falhas técnicas explícitas:
  - `INVALID_CONTENT_TYPE`
  - `INVALID_RESPONSE_SHAPE`
  - `NETWORK_ERROR`

### Web client (`apps/web/src/lib/api/public.ts`)

- exceção tipada `PublicApiError`
- preserva `status`, `code`, `traceId` e `details`
- mesma classe de falhas técnicas:
  - `INVALID_CONTENT_TYPE`
  - `INVALID_RESPONSE_SHAPE`
  - `NETWORK_ERROR`

## Protocolo operacional de incidente (ciclo atual)

1. Identificar rota/fluxo afetado e horário.
2. Capturar `traceId` da resposta ou do client.
3. Correlacionar com logs da API (`traceId`, rota, status, latência).
4. Classificar erro:
   - contrato/validação/autorização (`4xx`)
   - falha interna/integração (`5xx` ou erro técnico de client)
5. Corrigir no menor escopo possível.
6. Reexecutar validação técnica da fase correspondente.
7. Revalidar fluxo funcional impactado.

## Relação com validação do ciclo

- `Scaffold/SCF-04-bootstrap-de-qualidade-local-e-ci.md` define ordem de validação local.
- `.github/workflows/scaffold-bootstrap.yml` executa `pnpm run verify:hardening` no CI.

Leitura operacional:

- observabilidade local + validação automatizada reduzem falso positivo de ciclo fechado.

## Critérios de aceite deste baseline

1. Respostas da API trazem `meta.traceId` e header `x-trace-id`.
2. Logs da API permitem localizar requisição por `traceId`.
3. Erros contratuais são estáveis e classificados por código.
4. Clients admin/web preservam erro técnico com `status`, `code` e `traceId`.
5. Fluxo de incidente segue protocolo sequencial e verificável.

## Riscos residuais aceitos

- ausência de observabilidade centralizada externa
- triagem ainda dependente de disciplina operacional manual

Esses pontos entram no backlog de maturidade operacional dos próximos ciclos.
