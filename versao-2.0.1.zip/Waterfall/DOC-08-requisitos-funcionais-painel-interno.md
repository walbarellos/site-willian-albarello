# DOC-08 — Requisitos Funcionais do Painel Interno

## Endereço

`/home/walbarellos/personal-site/personal-site(Graciliano)/Waterfall/DOC-08-requisitos-funcionais-painel-interno.md`

## Status do arquivo no estado atual

**Existente e preenchido.**

---

# 1. Finalidade do documento

Este documento define os **requisitos funcionais soberanos do painel interno** do projeto `personal-site`.

Ele existe para alinhar, de forma auditável e objetiva:

* `apps/admin`
* `apps/api`
* `packages/contracts`
* contratos de rota/tela
* autenticação administrativa
* fluxo editorial interno

A leitura correta do painel interno, no estado atual do projeto, é:

> o painel não é um “admin genérico”; ele é um **CMS editorial interno**, com autenticação administrativa, leitura de sessão, dashboard resumido e governança do ciclo de vida de publicações.

Este documento cobre:

* entrada do painel
* login
* sessão
* dashboard resumido
* listagem de publicações
* busca
* filtro por status
* abertura de detalhe
* edição de conteúdo
* edição SEO
* transição editorial
* tratamento de sessão expirada

---

# 2. Objetivo funcional do painel interno

O painel interno deve permitir que um usuário autenticado com papel válido:

* entre no ambiente administrativo com segurança;
* tenha sua sessão validada;
* visualize um resumo operacional do acervo editorial;
* liste publicações administrativas;
* busque e filtre publicações;
* abra uma publicação específica para edição;
* edite conteúdo e campos editoriais;
* edite dados de SEO;
* transicione o status editorial;
* lide com expiração de sessão sem ambiguidade;
* continue o fluxo de trabalho sem depender de improviso da interface.

---

# 3. Escopo funcional soberano

## 3.1 Incluído neste documento

Está no escopo deste documento:

* autenticação bootstrap administrativa
* uso de cookie de sessão administrativa
* leitura da sessão atual
* controle por papéis `admin` e `editor`
* entrada inteligente do painel
* login administrativo
* dashboard resumido
* listagem administrativa de publicações
* busca textual
* filtro por status editorial
* detalhamento/abertura de publicação
* edição de publicação
* edição de campos SEO
* transição de status editorial
* tratamento de sessão expirada
* feedback funcional mínimo de erro/sucesso

## 3.2 Fora do escopo imediato

Não está no escopo funcional central deste documento, embora possa existir depois:

* gestão completa de usuários
* permissões finas por recurso além de `admin` e `editor`
* mídia manager
* analytics avançado
* preview editorial robusto
* workflow de aprovação multiusuário
* histórico/auditoria editorial persistente
* persistência real em banco já concluída

---

# 4. Premissas do estado atual do projeto

Este documento está alinhado ao **código atual do monorepo**, o que implica as seguintes premissas:

## 4.1 Papéis atualmente suportados

O painel interno opera hoje com os papéis:

* `admin`
* `editor`

## 4.2 Sessão administrativa

A autenticação usa sessão administrativa baseada em cookie:

* cookie administrativo assinado
* leitura da sessão atual via API
* expiração possível e tratável

## 4.3 Dashboard

O dashboard é atualmente um **dashboard resumido** com contagens editoriais.

## 4.4 Fluxo editorial

O fluxo editorial atual contempla os estados:

* `draft`
* `review`
* `ready_to_publish`
* `published`
* `archived`

## 4.5 Persistência funcional atual

O comportamento atual da API administrativa está funcionalmente estruturado, ainda que parte do backend opere com adapter em memória no estágio atual.

A consequência correta dessa premissa é:

> os requisitos funcionais já devem ser escritos como requisitos reais do produto, mesmo que a persistência definitiva ainda esteja em maturação.

---

# 5. Atores funcionais

---

## 5.1 Admin

### Definição

Usuário com papel administrativo pleno no painel interno.

### Capacidades funcionais esperadas

* autenticar-se
* visualizar sessão
* acessar dashboard
* listar publicações
* buscar e filtrar
* abrir detalhe/edição
* editar conteúdo
* editar SEO
* transicionar status editorial
* operar o fluxo interno completo previsto nesta fase

---

## 5.2 Editor

### Definição

Usuário com papel editorial autorizado.

### Capacidades funcionais esperadas

* autenticar-se
* visualizar sessão
* acessar dashboard
* listar publicações
* buscar e filtrar
* abrir detalhe/edição
* editar conteúdo
* editar SEO
* transicionar status editorial nas regras atualmente aceitas pelo sistema

---

## 5.3 Usuário não autenticado

### Definição

Qualquer visitante sem sessão administrativa válida.

### Capacidades funcionais esperadas

* acessar a rota de login
* ser redirecionado ao login quando tentar entrar em área protegida
* não acessar listagem ou edição administrativa

---

# 6. Requisitos funcionais soberanos

---

## RF-PI-001 — Entrada inteligente do painel

### Descrição

O sistema deve possuir uma rota de entrada do painel capaz de decidir automaticamente o destino do usuário com base na sessão administrativa atual.

### Regra funcional

* se houver sessão válida com papel permitido, o sistema deve encaminhar o usuário para a área interna principal;
* se não houver sessão válida, o sistema deve encaminhar o usuário para a tela de login;
* a entrada não deve depender de interação manual do usuário para decidir o fluxo principal.

### Dor que este requisito cura

Evita:

* entrada ambígua
* erro de navegação inicial
* tela intermediária sem função
* necessidade de o usuário “adivinhar” para onde deve ir

### Critério de aceite

* autenticado entra na área interna;
* não autenticado cai no login;
* não há loop de redirecionamento;
* não há dependência de helper inexistente.

---

## RF-PI-002 — Login administrativo bootstrap

### Descrição

O sistema deve permitir login administrativo com email e senha válidos do bootstrap administrativo atual.

### Regra funcional

* o formulário deve receber `email` e `password`;
* o backend deve validar a estrutura mínima do payload;
* credenciais válidas devem iniciar sessão;
* credenciais inválidas devem retornar erro claro;
* a tela deve tratar o retorno da API sem ambiguidade.

### Comportamentos esperados

* sucesso → redirecionamento para área interna
* 401 → credenciais inválidas
* 422 → payload inválido
* erro inesperado → mensagem operacional segura

### Dor que este requisito cura

Evita:

* autenticação silenciosa ou opaca
* entrada inconsistente no painel
* perda de clareza no fluxo inicial do admin

### Critério de aceite

* login válido cria sessão utilizável;
* login inválido informa erro;
* submit duplicado é bloqueado durante envio;
* o usuário autenticado segue para a área correta.

---

## RF-PI-003 — Leitura da sessão administrativa atual

### Descrição

O sistema deve permitir consultar a sessão administrativa atual para validar autenticidade e papel do usuário.

### Regra funcional

* a API deve expor a sessão atual;
* a resposta de sessão válida deve retornar o usuário autenticado;
* quando aplicável, a resposta deve incluir `csrfToken`;
* sessão ausente ou expirada deve ser tratada como estado não autenticado.

### Resultado esperado

A leitura de sessão deve permitir:

* redirecionamento correto na entrada
* bloqueio/abertura de rotas protegidas
* exibição segura do estado autenticado
* renovação lógica do contexto do usuário

### Dor que este requisito cura

Evita:

* painel “cego” ao estado da autenticação
* telas protegidas acessadas sem verificação
* comportamento quebrado ao recarregar páginas administrativas

### Critério de aceite

* sessão válida é reconhecida;
* sessão inexistente retorna estado coerente de não autenticado;
* o papel do usuário pode ser usado para controle de acesso.

---

## RF-PI-004 — Tratamento de sessão expirada

### Descrição

O sistema deve tratar sessão expirada de forma clara e operacionalmente segura.

### Regra funcional

Quando a sessão expirar ou não existir mais:

* o usuário deve ser redirecionado ao login ou receber orientação inequívoca para reautenticação;
* a interface não deve quebrar;
* o erro não deve ser tratado como falha genérica do sistema.

### Contextos de aplicação

* entrada do painel
* listagem administrativa
* edição administrativa
* chamada de logout
* validações de proteção de rota

### Dor que este requisito cura

Evita:

* “erro 500 visual” em caso de sessão expirada
* perda de confiança
* confusão entre autenticação e falha interna

### Critério de aceite

* 401 administrativo é tratado como sessão expirada/não autenticada;
* o usuário é conduzido de volta ao login;
* a mensagem e o fluxo deixam claro o próximo passo.

---

## RF-PI-005 — Controle de acesso por papel

### Descrição

O sistema deve restringir o acesso às áreas internas do painel com base nos papéis administrativos válidos.

### Regra funcional

* apenas usuários com papel `admin` ou `editor` podem acessar as rotas administrativas atualmente previstas;
* usuários fora desses papéis devem ser bloqueados;
* o bloqueio deve resultar em redirecionamento seguro ou resposta de autorização negada, conforme o contexto.

### Dor que este requisito cura

Evita:

* exposição indevida do painel
* fluxo administrativo acessível a usuários não autorizados
* fragilidade de segurança lógica

### Critério de aceite

* papel válido acessa;
* papel inválido não acessa;
* a UI não apresenta estados incoerentes para quem não tem permissão.

---

## RF-PI-006 — Dashboard resumido

### Descrição

O sistema deve apresentar um dashboard administrativo resumido com contagens editoriais relevantes.

### Conteúdo funcional esperado

O dashboard resumido deve expor, no mínimo:

* quantidade de `drafts`
* quantidade em `review`
* quantidade em `ready_to_publish`
* quantidade `published`
* quantidade `archived`
* quantidade com pendência SEO (`seoPending`)

### Regra funcional

* o dashboard não precisa, nesta fase, ser um painel analítico extenso;
* ele deve funcionar como sumário operacional rápido do estado editorial.

### Dor que este requisito cura

Evita:

* painel sem leitura situacional
* falta de visão resumida do acervo
* navegação cega para operação editorial

### Critério de aceite

* o dashboard carrega para sessão válida;
* os contadores principais aparecem;
* o usuário entende o estado geral do conteúdo em poucos segundos.

---

## RF-PI-007 — Listagem administrativa de publicações

### Descrição

O sistema deve listar publicações no contexto administrativo.

### Dados funcionais mínimos por item

Cada item listado deve conter, no mínimo:

* `id`
* `title`
* `slug`
* `summary`
* `status`
* `updatedAt`

Podendo ainda conter:

* `categoryId`
* `tagIds`
* categoria
* tags
* `publishedAt`
* `readingTimeMinutes`
* `seo`

### Regra funcional

A listagem deve:

* ser acessível apenas a usuários autorizados;
* refletir o acervo administrativo;
* permitir navegação até a edição do item.

### Dor que este requisito cura

Evita:

* edição sem visão global do acervo
* dificuldade de localizar conteúdo
* operação editorial fragmentada

### Critério de aceite

* lista carregada para sessão válida;
* itens navegáveis até o detalhe/edição;
* estados de vazio e erro tratados corretamente.

---

## RF-PI-008 — Busca textual em publicações administrativas

### Descrição

O sistema deve permitir busca textual sobre a listagem administrativa de publicações.

### Regra funcional

* o usuário deve poder informar um termo de busca;
* o sistema deve enviar o termo para a API administrativa;
* a listagem exibida deve refletir o resultado da busca;
* busca sem resultado deve gerar estado vazio, não erro técnico.

### Dor que este requisito cura

Evita:

* navegação manual excessiva por grandes listas
* baixa produtividade editorial
* dificuldade de localizar itens específicos

### Critério de aceite

* buscar altera o resultado exibido;
* resultado vazio é tratado corretamente;
* a busca não destrói a estrutura da tela.

---

## RF-PI-009 — Filtro por status editorial

### Descrição

O sistema deve permitir filtrar a listagem administrativa por status editorial.

### Status contemplados

* `draft`
* `review`
* `ready_to_publish`
* `published`
* `archived`

### Regra funcional

* o filtro deve ser aplicável à listagem administrativa;
* o resultado exibido deve refletir o status solicitado;
* o filtro deve poder conviver com busca e paginação.

### Dor que este requisito cura

Evita:

* dificuldade de gestão por estágio editorial
* baixa rastreabilidade operacional
* impossibilidade de operar o funil editorial com clareza

### Critério de aceite

* selecionar um status modifica a lista;
* combinações com busca/paginação permanecem coerentes;
* estado vazio por filtro é tratado adequadamente.

---

## RF-PI-010 — Paginação administrativa

### Descrição

O sistema deve paginar a listagem administrativa de publicações.

### Regra funcional

* a API deve aceitar `page` e `pageSize`;
* a interface deve refletir `page`, `pageSize`, `totalItems` e `totalPages`;
* a navegação paginada deve ser previsível.

### Dor que este requisito cura

Evita:

* listas excessivamente longas
* lentidão cognitiva
* ausência de controle do conjunto editorial

### Critério de aceite

* troca de página altera os resultados;
* metadados de paginação são respeitados;
* a navegação não perde coerência com filtros.

---

## RF-PI-011 — Abertura de detalhe/edição por id

### Descrição

O sistema deve permitir abrir uma publicação administrativa específica a partir do seu `id`.

### Regra funcional

* a listagem deve conter mecanismo de acesso à edição;
* a rota de edição deve resolver o `id`;
* se o item não existir, a tela deve tratar `404` de forma explícita.

### Dor que este requisito cura

Evita:

* operação editorial desconectada da listagem
* dificuldade de manutenção de conteúdo
* quebra de fluxo entre localizar e editar

### Critério de aceite

* o usuário consegue sair da lista e abrir a edição;
* item inexistente gera tratamento funcional de ausência;
* a navegação de retorno permanece possível.

---

## RF-PI-012 — Edição de conteúdo editorial

### Descrição

O sistema deve permitir editar os campos editoriais principais de uma publicação administrativa.

### Campos funcionais centrais

* `title`
* `slug`
* `summary`
* `content`
* `categoryId`
* `tagIds`

### Regra funcional

* a edição deve aceitar atualização parcial;
* o sistema deve impedir payload vazio;
* o sistema deve validar os campos conforme as regras atuais;
* erro de validação deve ser retornado com clareza.

### Dor que este requisito cura

Evita:

* impossibilidade de manutenção editorial
* atualização opaca do conteúdo
* falta de controle sobre o corpo da publicação

### Critério de aceite

* alteração de conteúdo pode ser salva;
* payload inválido retorna erro tratável;
* atualização válida reflete retorno consistente do item atualizado.

---

## RF-PI-013 — Edição de SEO

### Descrição

O sistema deve permitir editar os campos de SEO da publicação administrativa.

### Campos funcionais contemplados

* `metaTitle`
* `metaDescription`
* `canonicalUrl`
* `ogTitle`
* `ogDescription`
* `ogImageUrl`

### Regra funcional

* os campos SEO devem existir como parte da edição administrativa;
* URLs devem respeitar formato válido quando exigido;
* os limites de texto devem ser respeitados nos campos correspondentes;
* erro de SEO deve ser tratável sem inviabilizar toda a edição.

### Dor que este requisito cura

Evita:

* conteúdo público sem governança mínima de descoberta
* SEO tratado como improviso
* divergência entre operação editorial e camada pública

### Critério de aceite

* o usuário consegue editar campos SEO;
* valores válidos são aceitos;
* valores inválidos retornam erro de validação compreensível;
* a edição principal não colapsa por causa do bloco SEO.

---

## RF-PI-014 — Criação de rascunho

### Descrição

O sistema deve permitir criar uma nova publicação em estado inicial de rascunho.

### Regra funcional

* a criação deve exigir, no mínimo, um `title` válido;
* o item criado deve nascer como `draft`;
* o sistema pode aceitar dados adicionais no momento da criação;
* a resposta deve retornar o item criado.

### Dor que este requisito cura

Evita:

* fluxo editorial dependente de inserção manual fora do CMS
* ausência de ponto de partida para novas publicações

### Critério de aceite

* ao criar com dados mínimos válidos, o sistema retorna um novo item em `draft`;
* criação inválida é recusada com erro tratável.

---

## RF-PI-015 — Transição de status editorial

### Descrição

O sistema deve permitir alterar o status editorial de uma publicação administrativa.

### Estados contemplados

* `draft`
* `review`
* `ready_to_publish`
* `published`
* `archived`

### Regra funcional

* a transição deve ocorrer por endpoint específico;
* a UI deve comunicar claramente a mudança;
* transição inválida deve ser recusada;
* o retorno deve refletir o estado atualizado quando a transição for válida.

### Dor que este requisito cura

Evita:

* gestão editorial sem funil de estados
* publicação sem governança de estágio
* impossibilidade de operar revisão e publicação com clareza

### Critério de aceite

* transição válida é aplicada;
* transição inválida retorna erro tratável, inclusive `409` quando aplicável;
* a interface reflete o novo status após sucesso.

---

## RF-PI-016 — Feedback operacional após ações críticas

### Descrição

O sistema deve fornecer feedback operacional claro após ações principais do painel.

### Ações cobertas

* login
* logout
* salvar edição
* criar rascunho
* alterar status
* erro de validação
* sessão expirada

### Regra funcional

A interface deve comunicar:

* sucesso
* falha
* necessidade de correção
* necessidade de novo login
* possibilidade de tentar novamente

### Dor que este requisito cura

Evita:

* silêncio operacional
* insegurança do usuário após ações importantes
* duplicidade de envio
* perda de contexto

### Critério de aceite

* toda ação principal retorna feedback coerente;
* a interface não deixa o usuário sem próximo passo.

---

## RF-PI-017 — Tratamento de erro funcional por contexto

### Descrição

O sistema deve distinguir corretamente os principais contextos de erro do painel.

### Erros funcionais mínimos a tratar

* `401` sessão ausente ou expirada
* `403` acesso proibido
* `404` publicação não encontrada
* `409` transição inválida
* `422` payload ou query inválida
* `500` erro inesperado
* `429` excesso de requisições, quando aplicável

### Regra funcional

Cada erro deve gerar consequência funcional coerente:

* redirecionamento
* mensagem operacional
* correção de campo
* retry
* retorno à listagem
* nova autenticação

### Dor que este requisito cura

Evita:

* tratamento genérico de todo erro
* confusão entre autorização, autenticação e validação
* UX administrativa instável

### Critério de aceite

* cada erro relevante possui resposta funcional distinta;
* o usuário entende o que aconteceu e o que fazer em seguida.

---

## RF-PI-018 — Logout administrativo

### Descrição

O sistema deve permitir encerrar a sessão administrativa atual.

### Regra funcional

* o logout deve remover/invalidar a sessão atual quando houver;
* o cookie administrativo deve ser limpo;
* o sistema deve considerar o fluxo de logout como concluído com segurança.

### Dor que este requisito cura

Evita:

* sessão administrativa persistindo indevidamente
* término ambíguo do uso do painel
* risco funcional de permanência autenticada

### Critério de aceite

* após logout, o usuário não permanece autenticado;
* o acesso subsequente às áreas internas exige nova autenticação.

---

# 7. Requisitos de navegação funcional

---

## RNF-PI-001 — Continuidade de fluxo

O painel deve sempre oferecer um próximo passo claro ao usuário.

Exemplos:

* sem sessão → ir para login
* item não encontrado → voltar para listagem
* validação falhou → corrigir campos
* sucesso → continuar edição ou retornar à lista

---

## RNF-PI-002 — Ausência de becos sem saída

Nenhuma tela do painel deve deixar o usuário sem saída funcional.

---

## RNF-PI-003 — Coerência entre rota e função

Cada rota administrativa deve ter uma função operacional inequívoca:

* entrada
* login
* resumo
* listagem
* edição

---

# 8. Requisitos de dados funcionais mínimos

---

## RDF-PI-001 — Sessão

Uma sessão válida deve conter, no mínimo:

* `id` do usuário
* `email`
* `displayName`
* `role`

E, quando aplicável:

* `csrfToken`

---

## RDF-PI-002 — Dashboard

O dashboard resumido deve conter:

* `drafts`
* `review`
* `readyToPublish`
* `published`
* `archived`
* `seoPending`

---

## RDF-PI-003 — Publicação administrativa

Uma publicação administrativa deve conter, no mínimo:

* `id`
* `title`
* `slug`
* `summary`
* `content`
* `status`
* `tagIds`
* `tags`
* `updatedAt`

Podendo conter adicionalmente:

* `categoryId`
* `category`
* `seo`
* `publishedAt`
* `readingTimeMinutes`

---

# 9. Regras funcionais de validação

---

## RV-PI-001 — Login

* email deve ter formato válido
* senha deve ter tamanho mínimo aceitável

## RV-PI-002 — Criação de rascunho

* `title` deve ter tamanho mínimo válido

## RV-PI-003 — Atualização de publicação

* ao menos um campo deve ser enviado
* `slug` deve ser URL-safe quando informado
* `summary` deve respeitar limite definido
* campos SEO devem respeitar suas validações específicas
* arrays de tags devem respeitar limites aceitáveis

## RV-PI-004 — Transição editorial

* `status` deve pertencer ao conjunto permitido
* transições inválidas devem ser recusadas

---

# 10. Casos funcionais principais

---

## CF-PI-001 — Entrar no painel sem sessão

**Dado** que o usuário não possui sessão válida
**Quando** acessar a entrada ou uma rota protegida
**Então** o sistema deve direcioná-lo ao login.

---

## CF-PI-002 — Entrar no painel com sessão válida

**Dado** que o usuário possui sessão válida com papel permitido
**Quando** acessar a entrada do painel
**Então** o sistema deve encaminhá-lo à área interna principal.

---

## CF-PI-003 — Autenticar com sucesso

**Dado** que o usuário informa credenciais válidas
**Quando** submeter o login
**Então** o sistema deve criar sessão e redirecionar para a área autenticada.

---

## CF-PI-004 — Falhar no login

**Dado** que o usuário informa credenciais inválidas
**Quando** submeter o login
**Então** o sistema deve informar erro sem quebrar a tela.

---

## CF-PI-005 — Visualizar dashboard

**Dado** que o usuário está autenticado
**Quando** acessar o dashboard resumido
**Então** o sistema deve apresentar contagens editoriais.

---

## CF-PI-006 — Buscar e filtrar publicações

**Dado** que o usuário está autenticado
**Quando** aplicar busca e/ou filtro por status
**Então** a listagem deve refletir o critério aplicado.

---

## CF-PI-007 — Abrir edição de publicação

**Dado** que existe uma publicação válida
**Quando** o usuário a abrir para edição
**Então** o sistema deve carregar seus dados administrativos.

---

## CF-PI-008 — Salvar edição

**Dado** que a publicação está carregada
**Quando** o usuário enviar alterações válidas
**Então** o sistema deve persistir/aceitar a atualização e retornar o item atualizado.

---

## CF-PI-009 — Alterar status editorial

**Dado** que a publicação está carregada
**Quando** o usuário solicitar transição válida de status
**Então** o sistema deve aplicar o novo estado e refletir isso no retorno.

---

## CF-PI-010 — Sessão expirar durante uso

**Dado** que a sessão expira durante a operação
**Quando** uma tela protegida ou ação administrativa for executada
**Então** o sistema deve tratar o caso como necessidade de nova autenticação, e não como erro genérico.

---

# 11. Critérios soberanos de aceite do painel interno

O painel interno só pode ser considerado funcionalmente aprovado quando:

* a entrada decide corretamente o destino do usuário;
* o login funciona com feedback claro;
* a sessão atual pode ser lida e interpretada;
* a expiração de sessão é tratada corretamente;
* o dashboard resumido carrega para usuário autorizado;
* a listagem administrativa funciona com busca, filtro e paginação;
* a abertura de detalhe/edição funciona por `id`;
* a edição de conteúdo funciona com validação;
* a edição SEO funciona com validação;
* a transição de status editorial funciona com retorno coerente;
* erros 401/403/404/409/422/500 são tratados funcionalmente;
* o usuário nunca fica sem próximo passo.

---

# 12. Matriz resumida de requisitos por área

| Área                   | Requisitos principais                      |
| ---------------------- | ------------------------------------------ |
| Entrada                | RF-PI-001                                  |
| Login                  | RF-PI-002                                  |
| Sessão                 | RF-PI-003, RF-PI-004, RF-PI-005            |
| Dashboard              | RF-PI-006                                  |
| Listagem               | RF-PI-007, RF-PI-008, RF-PI-009, RF-PI-010 |
| Edição                 | RF-PI-011, RF-PI-012, RF-PI-013            |
| Workflow editorial     | RF-PI-014, RF-PI-015                       |
| Feedback/erros         | RF-PI-016, RF-PI-017                       |
| Encerramento de sessão | RF-PI-018                                  |

---

# 13. Leitura soberana final

O painel interno do `personal-site` deve ser compreendido como:

> um ambiente editorial administrativo enxuto, disciplinado e funcional, desenhado para autenticar usuários válidos, resumir o estado do acervo, localizar publicações e operar o ciclo de edição e publicação com clareza.

A direção correta não é inflar o painel com recursos arbitrários, mas **fechar com qualidade o seu núcleo editorial soberano**.

---

# 14. Próxima utilização correta deste documento

Este documento deve orientar imediatamente a reforma e validação de:

* `apps/admin/app/page.tsx`
* `apps/admin/app/painel/login/page.tsx`
* `apps/admin/app/painel/publicacoes/page.tsx`
* `apps/admin/app/painel/publicacoes/[id]/editar/page.tsx`
* `apps/admin/src/lib/session.ts`
* `apps/admin/src/lib/api/admin.ts`
* `apps/api/src/routes/auth.ts`
* `apps/api/src/routes/dashboard.ts`
* `apps/api/src/routes/publications-admin.ts`

Também deve ser lido em conjunto com:

* `API-07-openapi-admin.yaml`
* `UIUX-11-contratos-de-tela-por-rota.md`
* `UIUX-09-estados-de-interface-e-feedback.md`
* `UIUX-10-criterios-de-aceite-por-tela.md`
