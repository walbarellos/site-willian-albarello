# DOC-15 — SEO Técnico

## Endereço

`/home/walbarellos/personal-site/personal-site(Graciliano)/Waterfall/DOC-15-seo-tecnico.md`

## Objetivo

Registrar o baseline de SEO técnico **já implementado** no `apps/web`, sem suposições.

## Fontes auditadas

- `apps/web/app/page.tsx`
- `apps/web/app/publicacoes/page.tsx`
- `apps/web/app/publicacoes/[slug]/page.tsx`
- `apps/web/src/lib/routes.ts`
- `apps/web/src/lib/api/public.ts`
- `APIs/API-06-openapi-public.yaml`

## Escopo do documento

Incluído:

- metadata por rota pública
- canonicalização
- política de indexação para estados de erro/não encontrado
- dependência entre SEO e contrato da API pública

Fora do escopo neste ciclo:

- sitemap automatizado
- robots.txt avançado por ambiente
- JSON-LD completo por tipo de conteúdo
- monitoramento SEO em produção

## Rotas públicas canônicas

Fonte soberana: `apps/web/src/lib/routes.ts`.

- `WEB_PUBLIC_ROUTES.home` → `/`
- `WEB_PUBLIC_ROUTES.publications` → `/publicacoes`
- `WEB_PUBLIC_ROUTES.publicationDetail(slug)` → `/publicacoes/:slug`

A construção de URL é centralizada e normaliza slug/query antes de gerar href.

## Implementação por página

### 1) Home (`apps/web/app/page.tsx`)

- define `metadata` estático com `title`, `description` e canonical em `/`
- define `metadataBase` por `NEXT_PUBLIC_SITE_URL` com fallback local
- usa `revalidate = 300`

Resultado técnico:

- URL raiz tem canonical explícito
- metadado base não depende de valor implícito do runtime

### 2) Listagem (`apps/web/app/publicacoes/page.tsx`)

- usa `generateMetadata()` com canonical fixo em `/publicacoes`
- usa `revalidate = 300`
- normaliza `q` e `page` antes de consumir a API pública

Resultado técnico:

- listagem principal mantém URL canônica estável
- query params de busca/paginação não redefinem canonical

### 3) Detalhe (`apps/web/app/publicacoes/[slug]/page.tsx`)

- usa `generateMetadata()` dinâmico por slug
- prioriza campos editoriais de SEO vindos da API (`metaTitle`, `metaDescription`, `canonicalUrl`, `og*`)
- aplica fallback para título/resumo quando SEO editorial não está preenchido
- em não encontrado, responde metadata com `robots: { index: false, follow: false }`
- em erro transitório, mantém canonical da rota de detalhe por slug

Resultado técnico:

- detalhe público preserva canonical por conteúdo
- páginas inexistentes não entram em indexação

## Contrato de dados que impacta SEO

Origem: `apps/web/src/lib/api/public.ts` + OpenAPI público.

Campos críticos usados nas páginas:

- `slug`
- `title`
- `summary`
- `publishedAt`
- `updatedAt`
- `seo.metaTitle`
- `seo.metaDescription`
- `seo.canonicalUrl`
- `seo.ogTitle`
- `seo.ogDescription`
- `seo.ogImageUrl`

Implicação:

- alteração nesses campos exige atualização coordenada entre `apps/api`, `packages/contracts`, OpenAPI e `apps/web`

## Política de indexação no estado atual

- páginas públicas válidas: indexáveis
- detalhe não encontrado: `noindex, nofollow`
- canonical sempre explícito nas rotas principais

## Cache e atualização editorial

`revalidate = 300` em home, listagem e detalhe.

Leitura operacional:

- conteúdo público é atualizado periodicamente sem render a cada request
- mudanças críticas podem exigir política de invalidação específica em ciclo futuro

## Critérios de aceite deste baseline

1. `/` expõe canonical da home.
2. `/publicacoes` expõe canonical fixo da listagem.
3. `/publicacoes/[slug]` usa metadata dinâmico com prioridade para SEO editorial.
4. slug inexistente não é indexado.
5. URLs são geradas pelos helpers de rota, sem strings soltas na camada pública.

## Riscos residuais aceitos

- ausência de sitemap e robots avançado neste ciclo
- ausência de métricas SEO automatizadas no repositório

Esses pontos ficam para o próximo ciclo de maturidade operacional.
