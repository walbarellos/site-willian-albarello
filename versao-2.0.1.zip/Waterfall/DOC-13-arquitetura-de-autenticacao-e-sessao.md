# DOC-13 — Arquitetura de Autenticação e Sessão

## Endereço

`/home/walbarellos/personal-site/personal-site(Graciliano)/Waterfall/DOC-13-arquitetura-de-autenticacao-e-sessao.md`

## Status do arquivo no estado atual

**Existente e preenchido.**

---

# 1. Finalidade do documento

Este documento define a **arquitetura soberana de autenticação e sessão** do projeto `personal-site`, em nível:

* técnico
* funcional
* operacional
* corretivo

Ele existe para servir como referência central de correção para:

* `apps/api`
* `apps/admin`

e para alinhar os seguintes temas:

* bootstrap admin
* cookie de sessão
* leitura de sessão no admin
* redirecionamentos protegidos
* perfis `admin` e `editor`
* expiração
* logout
* CSRF
* pontos de falha atuais

A função correta deste documento não é apenas descrever “como deveria ser”, mas também registrar **como está hoje**, quais são os **acertos do desenho atual** e quais são os **gargalos reais que precisam ser corrigidos**.

---

# 2. Leitura soberana do estado atual

A arquitetura atual do projeto já possui uma base real de autenticação administrativa, porém ainda em estágio de **P0 executável avançado**, com algumas inconsistências importantes entre backend e admin.

A leitura correta do momento é:

> a arquitetura de autenticação já existe de verdade no backend, mas ainda não está completamente harmonizada na camada do painel administrativo.

Isso significa:

## 2.1 O que já está implementado de forma real

* autenticação bootstrap por email e senha
* sessão administrativa por cookie assinado
* leitura de sessão atual por endpoint dedicado
* logout por endpoint dedicado
* papéis `admin` e `editor`
* proteção server-side no backend para rotas administrativas
* emissão de `csrfToken` em respostas de sessão bem-sucedidas
* expiração de sessão em store in-memory
* limpeza de cookie quando sessão é inválida ou expirada

## 2.2 O que ainda não está plenamente harmonizado

* helpers de sessão do admin estão incompletos em relação ao que as páginas esperam
* fluxo server-side do admin ainda não está consolidado
* uso prático do `csrfToken` ainda não está fechado ponta a ponta
* client admin ainda não cobre todas as opções que as páginas tentam passar
* store de sessão ainda é in-memory, não persistente

---

# 3. Objetivo arquitetural soberano

A arquitetura de autenticação e sessão do `personal-site` deve garantir que:

* apenas usuários autorizados acessem o painel
* a autenticação administrativa seja simples, segura e auditável
* a sessão seja legível tanto pela API quanto pelo admin
* o redirecionamento protegido seja previsível
* a expiração da sessão seja tratada com clareza
* o logout encerre efetivamente a sessão
* o uso de CSRF seja coerente nas mutações
* a camada de autenticação não vire fonte de inconsistência entre backend e frontend

---

# 4. Componentes da arquitetura atual

---

## 4.1 Backend de autenticação administrativa

### Local principal

`apps/api/src/lib/admin-auth.ts`

### Responsabilidades atuais

* carregar credenciais bootstrap
* autenticar credenciais bootstrap
* criar sessão administrativa
* ler sessão atual
* exigir sessão em rotas protegidas
* emitir payload de sessão
* assinar e limpar cookie administrativo
* emitir `csrfToken` quando disponível

### Papel arquitetural

É a **fonte soberana atual da lógica de autenticação no backend**.

---

## 4.2 Store de sessão administrativa

### Local principal

`apps/api/src/lib/admin-session-store.ts`

### Responsabilidades atuais

* criar sessão
* recuperar sessão por id
* apagar sessão
* expurgar expiradas
* manter TTL
* tocar `lastAccessedAt` quando configurado

### Estado atual

A store é **in-memory**.

### Consequência arquitetural

Ela serve muito bem para:

* scaffold
* validação local
* P0 executável

Mas ainda não serve como solução final para:

* persistência real
* escalabilidade
* reinício de processo sem perda de sessão
* múltiplas instâncias

---

## 4.3 API administrativa de autenticação

### Local principal

`apps/api/src/routes/auth.ts`

### Endpoints atuais

* `POST /v1/admin/auth/login`
* `GET /v1/admin/auth/session`
* `POST /v1/admin/auth/logout`

### Papel arquitetural

São os **endpoints soberanos de autenticação e sessão** consumidos pelo painel.

---

## 4.4 Admin client de sessão/auth

### Local principal

`apps/admin/src/lib/api/admin.ts`

### Responsabilidades pretendidas

* consumir login
* consumir sessão atual
* consumir logout
* consumir demais endpoints administrativos

### Estado atual

Já existe, mas ainda tem desalinhamentos com o que as páginas administrativas tentam fazer.

---

## 4.5 Helpers de sessão do admin

### Local principal

`apps/admin/src/lib/session.ts`

### Responsabilidades atuais

* ler sessão via API
* extrair usuário da sessão
* exigir sessão e redirecionar para login

### Estado atual

Útil, mas **incompleto** para o que as páginas realmente precisam.

---

# 5. Arquitetura funcional atual

---

## 5.1 Bootstrap admin

### Definição

A autenticação atual do projeto parte de um modelo de **credenciais bootstrap** carregadas por ambiente.

### Fonte das credenciais

* `ADMIN_BOOTSTRAP_EMAIL`
* `ADMIN_BOOTSTRAP_PASSWORD`
* `ADMIN_BOOTSTRAP_DISPLAY_NAME`
* `ADMIN_BOOTSTRAP_ROLE`

### Regras atuais

* em produção, a ausência de email/senha bootstrap deve falhar de forma fechada
* em desenvolvimento, há fallback seguro de conveniência:

  * `admin@local.test`
  * `ChangeMe123!`
* o papel bootstrap aceito hoje é:

  * `admin`
  * `editor`

### Leitura correta

O bootstrap atual é uma **solução deliberada de P0/P1**, suficiente para iniciar o painel e validar seu fluxo, sem ainda introduzir gestão completa de usuários.

---

## 5.2 Modelo de usuário autenticado

### Estrutura atual

O usuário autenticado administrativo possui, no mínimo:

* `id`
* `email`
* `displayName`
* `role`

### Papéis atuais

* `admin`
* `editor`

### Leitura correta

O sistema hoje não opera com RBAC profundo; ele opera com um controle mais enxuto de papéis válidos para o painel interno.

---

## 5.3 Criação da sessão

### Fluxo atual

1. usuário envia email e senha para `POST /v1/admin/auth/login`
2. backend valida payload
3. backend compara as credenciais com o bootstrap
4. se válidas, cria uma sessão administrativa
5. backend grava cookie assinado `wa_admin_session`
6. backend responde com:

   * `user`
   * `csrfToken` quando disponível
   * `meta.traceId`

### Objetivo funcional

Iniciar uma sessão administrativa utilizável pelo painel.

---

## 5.4 Leitura da sessão atual

### Fluxo atual

1. admin chama `GET /v1/admin/auth/session`
2. backend lê o cookie `wa_admin_session`
3. backend dessina o cookie
4. backend busca a sessão na store
5. se houver sessão válida:

   * retorna usuário autenticado
   * retorna `csrfToken` quando disponível
6. se não houver:

   * limpa cookie
   * responde `401 SESSION_EXPIRED`

### Objetivo funcional

Permitir que o painel saiba se o usuário está autenticado e com qual papel.

---

## 5.5 Logout

### Fluxo atual

1. admin chama `POST /v1/admin/auth/logout`
2. backend lê a sessão atual via cookie
3. se houver id de sessão:

   * remove a sessão da store
4. limpa o cookie administrativo
5. responde:

   * `data.success = true`

### Leitura correta

O logout atual é funcionalmente correto para o estágio atual do projeto.

---

# 6. Cookie de sessão

---

## 6.1 Nome atual do cookie

`wa_admin_session`

## 6.2 Propriedades atuais

O cookie é configurado com:

* `path: /`
* `httpOnly: true`
* `signed: true`
* `sameSite: strict`
* `secure: env.IS_PROD`
* `maxAge` derivado do TTL

## 6.3 Leitura correta do desenho atual

O desenho atual do cookie é bom para o estágio do projeto porque:

* evita leitura direta por JavaScript
* usa assinatura
* restringe contexto via `sameSite: strict`
* exige `secure` em produção

## 6.4 Limite atual do desenho

O cookie transporta o **id da sessão**, não toda a sessão.
A sessão real está na store in-memory.

---

# 7. TTL, expiração e ciclo de vida da sessão

---

## 7.1 TTL atual

A sessão administrativa usa, por padrão:

**8 horas**

### Constante atual

`DEFAULT_ADMIN_SESSION_TTL_MS = 1000 * 60 * 60 * 8`

---

## 7.2 Estrutura temporal atual da sessão

Cada sessão registra:

* `createdAt`
* `expiresAt`
* `lastAccessedAt`

---

## 7.3 Comportamento atual de leitura

Ao ler a sessão, o backend pode atualizar:

* `lastAccessedAt`

### Ponto importante

Hoje, o `touch` atualiza `lastAccessedAt`, **mas não reescreve `expiresAt`**.

### Consequência

O comportamento atual é:

* há “toque operacional” da sessão
* mas não há renovação deslizante completa do TTL

---

## 7.4 Expiração atual

Quando a sessão expira:

* ela deixa de ser encontrada na store
* o backend limpa o cookie
* a API responde como sessão expirada/não existente

### Leitura correta

A expiração está razoavelmente bem tratada no backend.

---

# 8. Perfis e autorização

---

## 8.1 Perfis atuais

* `admin`
* `editor`

## 8.2 Validação no backend

O backend possui `requireAdminSession(...)`, que:

* lê a sessão atual
* devolve `401` se a sessão não existir
* devolve `403` se o papel não for permitido
* devolve a sessão quando o usuário é autorizado

## 8.3 Leitura correta

A API está em melhor estado que o admin no tema autorização.
O backend já sabe decidir melhor entre:

* não autenticado
* autenticado sem permissão
* autenticado com permissão

---

# 9. Redirecionamentos protegidos no admin

---

## 9.1 Objetivo funcional

O painel deve:

* enviar não autenticado ao login
* permitir acesso interno ao autenticado autorizado
* evitar loops e helpers quebrados

## 9.2 Estado atual do helper admin

Hoje `apps/admin/src/lib/session.ts` oferece:

* `readAdminSession()`
* `requireAdminSession()`
* `getAdminUserFromSession()`

### Limitação atual

As páginas do admin esperam helpers adicionais que **não existem** hoje, como:

* `buildAdminLoginHref`
* `buildProtectedRedirectHref`
* `readCurrentAdminUserServer`
* `requireAdminSessionServer`

### Consequência

O backend já está mais coerente do que a camada de entrada protegida do admin.

---

## 9.3 Arquitetura correta de redirect

A arquitetura soberana deve funcionar assim:

### Cenário A — Usuário sem sessão

* rota protegida detecta ausência de sessão
* usuário é redirecionado para `/painel/login`
* se possível, preserva-se o destino pretendido

### Cenário B — Usuário com sessão válida

* rota de entrada manda para área interna principal
* rota protegida permite continuidade

### Cenário C — Usuário autenticado sem permissão

* rota protegida bloqueia acesso
* sistema mostra acesso negado ou redireciona para área segura

---

# 10. CSRF

---

## 10.1 Estado atual real

O backend registra `@fastify/csrf-protection` e:

* permite header `x-csrf-token`
* expõe `csrfToken` em respostas de sessão bem-sucedidas por `generateCsrf()`, quando disponível

## 10.2 Leitura correta

A arquitetura de CSRF **já começou a ser implementada corretamente no backend**.

## 10.3 Problema atual

O ciclo ponta a ponta ainda não está completamente harmonizado no admin.

Hoje:

* a API já pode devolver `csrfToken`
* o CORS já aceita `x-csrf-token`
* mas o client admin e as páginas ainda não estão plenamente padronizados para usar isso em todas as mutações

## 10.4 Consequência

Temos uma arquitetura com **intenção correta**, mas com **fechamento incompleto**.

## 10.5 Diretriz soberana

Toda mutação administrativa deve, arquiteturalmente, estar preparada para:

* obter a sessão atual
* ler `csrfToken`
* enviar `x-csrf-token` nas operações mutantes, quando aplicável

### Operações mutantes afetadas

* login, se a política do ambiente exigir
* logout
* criação de rascunho
* edição de publicação
* transição de status editorial

---

# 11. Pontos de falha atuais

Esta seção é crítica. Ela registra os **gargalos reais** da arquitetura atual.

---

## 11.1 Falha 1 — Admin espera helpers de sessão que não existem

### Sintoma

Páginas do admin importam funções inexistentes.

### Impacto

* quebra em runtime/typecheck
* entrada do painel não confiável
* redirecionamento protegido inconsistente

### Cura arquitetural

Consolidar `apps/admin/src/lib/session.ts` como fonte soberana única de:

* leitura de sessão
* leitura do usuário atual
* require session
* require role
* build href/login redirect helpers

---

## 11.2 Falha 2 — Client admin não cobre o uso real das páginas

### Sintoma

As páginas tentam passar opções como:

* `includeServerCookies`
* `autoCsrf`

mas o client admin não suporta isso adequadamente.

### Impacto

* desalinhamento entre tela e client
* inconsistência entre server components e requisições reais
* risco de auth/CSRF quebrados

### Cura arquitetural

Reformar `apps/admin/src/lib/api/admin.ts` para assumir explicitamente:

* contexto server/client
* envio de cookies
* leitura de CSRF
* normalização de erro
* contrato único das chamadas administrativas

---

## 11.3 Falha 3 — Sessão é in-memory

### Sintoma

A store atual não persiste além do processo.

### Impacto

* reinício do backend apaga sessões
* não há escalabilidade real
* não há tolerância a múltiplas instâncias

### Leitura correta

Isso não invalida o P0, mas impede considerar a arquitetura “finalizada”.

### Cura arquitetural futura

Substituir a store por persistência real:

* Redis
* banco
* outro backend de sessão

---

## 11.4 Falha 4 — CSRF incompleto ponta a ponta

### Sintoma

O backend emite `csrfToken`, mas o admin ainda não está integralmente organizado em torno dele.

### Impacto

* mutações administrativas ainda não têm uma disciplina única de segurança
* inconsistência futura entre ambientes

### Cura arquitetural

Criar política única:

* onde obter o token
* como armazenar/encaminhar
* quais chamadas sempre o exigem
* como o client deve reenviar

---

## 11.5 Falha 5 — Expiração não é sliding renewal completo

### Sintoma

`lastAccessedAt` é atualizado, mas `expiresAt` não é renovado.

### Impacto

* a sessão “vive operando”, mas ainda morre pelo TTL original fixo
* isso pode ser aceitável, mas deve ser decisão explícita

### Cura arquitetural

Decidir soberanamente entre:

* TTL fixo
* sliding expiration real

Hoje o comportamento é de **TTL fixo com touch operacional**.

---

# 12. Arquitetura soberana desejada a partir de agora

---

## 12.1 Backend continua sendo fonte soberana da autenticação

A lógica principal de autenticação, autorização e sessão deve continuar concentrada no backend.

## 12.2 O admin deve ser consumidor disciplinado, não autor paralelo da regra

O admin não deve reinventar autenticação.
Ele deve consumir corretamente:

* sessão
* logout
* redirects protegidos
* CSRF

## 12.3 Sessão deve ter uma única camada soberana no admin

`apps/admin/src/lib/session.ts` deve virar a fonte única de:

* ler sessão
* ler usuário
* exigir sessão
* exigir papel
* construir redirects
* tratar 401 como sessão expirada

## 12.4 O client admin deve centralizar a política HTTP administrativa

`apps/admin/src/lib/api/admin.ts` deve ser o gateway único para:

* cookies
* headers
* CSRF
* parse de erro
* tipagem

## 12.5 O fluxo de autenticação deve obedecer a esta sequência

1. login
2. criação de sessão
3. cookie assinado
4. leitura da sessão
5. redirect protegido
6. uso interno do painel
7. expiração tratada
8. logout
9. limpeza de cookie e sessão

---

# 13. Fluxos arquiteturais soberanos

---

## 13.1 Fluxo de login

1. usuário acessa `/painel/login`
2. preenche `email` e `password`
3. admin envia `POST /v1/admin/auth/login`
4. backend valida payload
5. backend valida bootstrap
6. backend cria sessão
7. backend define cookie `wa_admin_session`
8. backend responde com `user` + `csrfToken`
9. admin redireciona para área interna

---

## 13.2 Fluxo de leitura de sessão

1. rota protegida ou entrypoint precisa conhecer o estado do usuário
2. admin chama `GET /v1/admin/auth/session`
3. backend lê cookie
4. backend valida sessão
5. backend responde com usuário autenticado
6. admin decide o fluxo de navegação

---

## 13.3 Fluxo de acesso protegido

1. usuário tenta abrir rota interna
2. camada de sessão do admin verifica autenticação
3. sem sessão:

   * redirect para login
4. com sessão válida:

   * seguir
5. com papel insuficiente:

   * negar acesso ou redirecionar para área segura

---

## 13.4 Fluxo de expiração

1. sessão some ou expira
2. backend responde `401 SESSION_EXPIRED`
3. admin interpreta isso como sessão inválida
4. usuário é redirecionado ao login
5. fluxo não deve parecer erro genérico do sistema

---

## 13.5 Fluxo de logout

1. usuário aciona logout
2. admin chama `POST /v1/admin/auth/logout`
3. backend remove sessão
4. backend limpa cookie
5. admin trata logout como encerramento do contexto autenticado
6. usuário volta ao login ou ao estado não autenticado

---

# 14. Regras soberanas de correção para apps/api e apps/admin

---

## 14.1 Regras para `apps/api`

* manter `admin-auth.ts` como núcleo soberano da autenticação
* preservar cookie assinado e `httpOnly`
* preservar `sameSite: strict`
* manter limpeza de cookie quando a sessão não existir
* manter distinção clara entre `401` e `403`
* consolidar política de CSRF nas mutações

---

## 14.2 Regras para `apps/admin/src/lib/session.ts`

Deve passar a centralizar, explicitamente:

* leitura de sessão
* leitura do usuário autenticado
* require session
* require role
* helpers de login href
* helpers de redirect protegido
* tratamento consistente de `401`

---

## 14.3 Regras para `apps/admin/src/lib/api/admin.ts`

Deve passar a centralizar, explicitamente:

* `credentials` coerentes
* contexto server/client
* cookies quando necessário
* uso de `csrfToken`
* parse único de erro administrativo
* contratos de request/response sem improviso

---

## 14.4 Regras para páginas do admin

Páginas administrativas não devem:

* importar helpers inexistentes
* decidir política de auth por conta própria
* espalhar lógica de cookie/CSRF
* reinventar tratamento de sessão expirada

Devem apenas consumir a camada soberana.

---

# 15. Critérios soberanos de aceite desta arquitetura

A arquitetura de autenticação e sessão só pode ser considerada aprovada quando:

* login funciona com sessão real utilizável
* `GET /auth/session` representa corretamente o estado do usuário
* `401` é tratado como sessão ausente/expirada
* `403` é tratado como falta de permissão
* logout limpa cookie e sessão
* entrypoint do admin redireciona corretamente
* rotas protegidas não dependem de helpers inexistentes
* CSRF tem política explícita de uso nas mutações
* a camada de auth no admin deixa de estar fragmentada
* backend e admin passam a refletir o mesmo contrato real

---

# 16. Leitura soberana final

A arquitetura atual do `personal-site` já contém um núcleo bom de autenticação administrativa:

* bootstrap real
* sessão por cookie assinado
* leitura de sessão
* papéis
* logout
* CSRF iniciado
* proteção backend coerente

O problema principal não é ausência de arquitetura.
O problema principal é **desalinhamento entre a arquitetura já existente no backend e a forma como o admin ainda a consome**.

Portanto, a direção correta não é reinventar auth, e sim:

> consolidar o admin como consumidor disciplinado da autenticação que o backend já desenhou razoavelmente bem.

---

# 17. Próxima utilização correta deste documento

Este documento deve orientar imediatamente a reforma de:

* `apps/admin/src/lib/session.ts`
* `apps/admin/src/lib/api/admin.ts`
* `apps/admin/app/page.tsx`
* `apps/admin/app/painel/login/page.tsx`
* `apps/admin/app/painel/publicacoes/page.tsx`
* `apps/admin/app/painel/publicacoes/[id]/editar/page.tsx`
* `apps/api/src/routes/auth.ts`

Também deve ser lido em conjunto com:

* `DOC-08-requisitos-funcionais-painel-interno.md`
* `API-07-openapi-admin.yaml`
* `UIUX-11-contratos-de-tela-por-rota.md`
