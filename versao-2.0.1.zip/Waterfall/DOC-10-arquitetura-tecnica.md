# DOC-10 — Arquitetura Técnica

## Endereço

`/home/walbarellos/personal-site/personal-site(Graciliano)/Waterfall/DOC-10-arquitetura-tecnica.md`

## Status

Arquivo existente e reformado neste ciclo para aderência estrita ao estado físico do repositório.

---

## 1. Objetivo

Definir a arquitetura técnica **real** do monorepo `personal-site` para auditoria e continuidade de implementação.

Este documento cobre:

- estrutura de apps e packages
- fronteiras de responsabilidade
- integração por contrato
- pipeline técnico de validação

---

## 2. Topologia do monorepo

Diretórios principais:

- `apps/api`
- `apps/web`
- `apps/admin`
- `packages/contracts`
- `packages/ui`
- `APIs`
- `Waterfall`, `UI_UX`, `Scaffold`, `Implementacao`, `Diagrama`

Workspace (`pnpm-workspace.yaml`):

- `apps/*`
- `packages/*`

---

## 3. Fronteiras de responsabilidade

### 3.1 `apps/api`

Backend Fastify. Responsável por:

- infra (`/health`, `/ready`)
- auth/sessão admin
- dashboard admin
- publicações públicas e administrativas
- envelope HTTP padrão com `meta.traceId`

Arquivos-chave:

- `apps/api/src/index.ts`
- `apps/api/src/server.ts`
- `apps/api/src/lib/env.ts`
- `apps/api/src/lib/http-contract.ts`
- `apps/api/src/routes/*.ts`

### 3.2 `apps/web`

Frontend público Next.js. Responsável por:

- home pública (`/`)
- listagem (`/publicacoes`)
- detalhe por slug (`/publicacoes/[slug]`)
- metadados/canonical no contexto público

Arquivos-chave:

- `apps/web/src/lib/routes.ts`
- `apps/web/src/lib/api/public.ts`
- `apps/web/app/page.tsx`
- `apps/web/app/publicacoes/page.tsx`
- `apps/web/app/publicacoes/[slug]/page.tsx`

### 3.3 `apps/admin`

Painel administrativo Next.js. Responsável por:

- entrada admin e redirect protegido
- login/sessão
- listagem administrativa
- edição e transição editorial

Arquivos-chave:

- `apps/admin/src/lib/routes.ts`
- `apps/admin/src/lib/session.ts`
- `apps/admin/src/lib/api/admin.ts`
- `apps/admin/app/page.tsx`
- `apps/admin/app/painel/login/page.tsx`
- `apps/admin/app/painel/publicacoes/*`

### 3.4 `packages/contracts`

Contrato compartilhado entre API/web/admin.

Módulos centrais:

- `routes.ts`
- `session.ts`
- `publications.ts`
- `index.ts` (barrel + aliases de compatibilidade)

### 3.5 `packages/ui`

Componentes compartilhados de interface.

Exports centrais (estado atual):

- admin: `AdminPageHeader`, `AdminPageShell`, `AdminSectionCard`, `AdminSupportBlock`
- feedback: `AlertBanner`, `EmptyState`, `StatusBadge`

---

## 4. Integração por contrato

A integração é válida quando há coerência entre:

1. `packages/contracts`
2. OpenAPI (`APIs/API-06-openapi-public.yaml`, `APIs/API-07-openapi-admin.yaml`)
3. rotas Fastify (`apps/api/src/routes/*`)
4. clients (`apps/web/src/lib/api/public.ts`, `apps/admin/src/lib/api/admin.ts`)

Mudança em rota/payload/status exige atualização coordenada nessas quatro camadas.

---

## 5. Protocolo HTTP e observabilidade

Padrão definido em `apps/api/src/lib/http-contract.ts`:

- sucesso: `{ data, meta: { traceId } }`
- sucesso paginado: `{ data, meta: { traceId, page, pageSize, totalItems, totalPages } }`
- erro: `{ error: { code, message, details? }, meta: { traceId } }`

No servidor (`apps/api/src/server.ts`):

- request id por `x-trace-id` com fallback `randomUUID()`
- logs estruturados
- redaction de headers sensíveis
- mapeamento de erros para códigos padronizados

---

## 6. Segurança de borda da API

Implementado em `apps/api/src/server.ts`:

- CORS por allowlist (`CORS_ORIGINS`)
- cookie assinado
- CSRF plugin
- rate limit global
- headers de segurança
- no-cache para `/health`, `/ready`, `/v1/admin/*`

---

## 7. Toolchain e build

### 7.1 TypeScript base

`tsconfig.base.json` (regras globais):

- `strict`
- `noUncheckedIndexedAccess`
- `moduleResolution: Bundler`
- `resolveJsonModule`

### 7.2 Scripts de orquestração (raiz)

- `build:*` por escopo
- `typecheck:*` por escopo
- `verify:hardening` como sequência integrada

Sequência de referência operacional:

- `Scaffold/SCF-04-bootstrap-de-qualidade-local-e-ci.md`

---

## 8. Decisões arquiteturais vigentes

1. Monorepo com isolamento por app/package.
2. Contrato compartilhado em TypeScript como base de integração.
3. OpenAPI mantido como contrato HTTP explícito.
4. Admin e web com clients dedicados (sem consumo direto de fetch ad hoc nas páginas).
5. Envelope HTTP único com `traceId` em toda superfície da API.

---

## 9. Riscos técnicos atuais

- ausência de suíte automatizada ponta a ponta no estado atual
- risco de divergência documental se OpenAPI/contracts não forem atualizados junto com código
- componentes OpenAPI comuns recém-materializados exigem adoção progressiva nas specs principais

---

## 10. Critérios de aceite do documento

Este documento é aderente quando:

- descreve apenas estrutura e comportamento comprováveis no repositório
- referencia os arquivos corretos por responsabilidade
- define integração por contrato sem ambiguidade
- mantém coerência com README raiz e SCF-04
