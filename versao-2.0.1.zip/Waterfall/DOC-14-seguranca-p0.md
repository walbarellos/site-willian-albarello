# DOC-14 — Segurança P0

## Endereço

`/home/walbarellos/personal-site/personal-site(Graciliano)/Waterfall/DOC-14-seguranca-p0.md`

## Objetivo

Definir o baseline de segurança **realmente implementado** no ciclo atual para API e painel administrativo, com foco em autenticação, sessão, proteção de mutação, superfície HTTP e rastreabilidade.

Este documento não descreve segurança futura. Ele registra o estado físico do código.

## Fontes auditadas

- `apps/api/src/server.ts`
- `apps/api/src/lib/admin-auth.ts`
- `apps/api/src/routes/auth.ts`
- `apps/api/src/routes/dashboard.ts`
- `apps/api/src/routes/publications-admin.ts`
- `apps/admin/src/lib/api/admin.ts`
- `apps/admin/src/lib/session.ts`
- `.env.example`

## Escopo P0

Incluído neste baseline:

- autenticação bootstrap administrativa
- sessão administrativa por cookie assinado
- autorização por papel (`admin`, `editor`)
- proteção CSRF no backend
- CORS por allowlist
- rate limit global
- headers HTTP de segurança
- `traceId` propagado em resposta e envelope de erro

Fora do escopo P0:

- MFA
- IAM completo com múltiplas contas persistidas
- trilha de auditoria persistente por usuário/ação
- SIEM/WAF dedicados

## Controles implementados

### 1) Bootstrap administrativo

Arquivo: `apps/api/src/lib/admin-auth.ts`.

- Credenciais bootstrap via `ADMIN_BOOTSTRAP_EMAIL` e `ADMIN_BOOTSTRAP_PASSWORD`.
- Em produção, ausência dessas variáveis interrompe o boot (fail-closed).
- Em desenvolvimento, fallback local controlado (`admin@local.test` / `ChangeMe123!`).
- Papel permitido no bootstrap: `admin` ou `editor`.

### 2) Validação de login

Arquivos: `apps/api/src/routes/auth.ts` e `apps/api/src/lib/admin-auth.ts`.

- Payload de login validado com `zod` (`email` válido e `password` com 8..256).
- Comparação de senha usando `timingSafeEqual`.
- Falha de credencial responde `401` com código de contrato `UNAUTHENTICATED`.

### 3) Sessão por cookie assinado

Arquivo: `apps/api/src/lib/admin-auth.ts`.

Cookie `wa_admin_session`:

- `httpOnly: true`
- `signed: true`
- `sameSite: 'strict'`
- `secure` em produção
- `maxAge` alinhado ao TTL da sessão

Leitura e limpeza:

- leitura com validação de assinatura
- sessão inválida/ausente responde `SESSION_EXPIRED`
- logout idempotente limpa cookie mesmo sem sessão ativa

### 4) Autorização de rotas administrativas

Arquivos:

- `apps/api/src/routes/dashboard.ts`
- `apps/api/src/routes/publications-admin.ts`
- `apps/admin/src/lib/session.ts`

Estado atual:

- rotas `/v1/admin/*` exigem sessão administrativa
- papéis aceitos: `admin` e `editor`
- painel admin aplica proteção server-side com redirect quando não autenticado/sem permissão

### 5) CSRF para mutações

Arquivos:

- `apps/api/src/server.ts`
- `apps/api/src/lib/admin-auth.ts`
- `apps/admin/src/lib/api/admin.ts`

Estado atual:

- `@fastify/csrf-protection` registrado com cookie (`sameSite: strict`, `httpOnly`, `secure` em produção)
- payload de sessão pode carregar `csrfToken` quando disponível
- mutações no client admin tentam anexar `x-csrf-token` automaticamente
- erro CSRF é normalizado para `CSRF_INVALID_TOKEN`

Observação técnica do ciclo:

- backend está preparado para CSRF de forma consistente; uso ponta a ponta no admin depende de fluxo completo de sessão/token em runtime real.

### 6) CORS e superfície HTTP

Arquivo: `apps/api/src/server.ts`.

- `credentials: true`
- allowlist por `CORS_ORIGINS`
- origens sem header `Origin` permitidas (health checks e server-to-server)
- headers permitidos explícitos, incluindo `x-csrf-token` e `x-trace-id`
- `x-trace-id` exposto em resposta

### 7) Rate limit global

Arquivo: `apps/api/src/server.ts`.

- limite global: `120` requisições por minuto
- excedente retorna envelope padronizado com `RATE_LIMITED` e `meta.traceId`

### 8) Headers de segurança e cache

Arquivo: `apps/api/src/server.ts`.

Headers aplicados em `onRequest`:

- `x-content-type-options: nosniff`
- `x-frame-options: DENY`
- `referrer-policy: strict-origin-when-cross-origin`
- `permissions-policy` restritiva
- `content-security-policy-report-only` mínima

Cache:

- `no-store/no-cache` em `/health`, `/ready` e `/v1/admin/*`

### 9) Rastreabilidade mínima

Arquivo: `apps/api/src/server.ts`.

- request id usa `x-trace-id` quando válido, senão gera UUID
- `x-trace-id` retornado no header de resposta
- envelopes de erro/sucesso incluem `meta.traceId`
- logs de resposta incluem trace, rota, status e tempo
- logger redige `authorization`, `cookie` e `set-cookie`

## Variáveis de ambiente críticas

Referência: `.env.example`.

Obrigatórias para operação segura fora de desenvolvimento:

- `SESSION_SECRET`
- `ADMIN_BOOTSTRAP_EMAIL`
- `ADMIN_BOOTSTRAP_PASSWORD`
- `ADMIN_BOOTSTRAP_ROLE`
- `CORS_ORIGINS`

Diretriz:

- não promover valores de desenvolvimento para produção
- manter segredo fora de versionamento

## Critérios mínimos de aceite de segurança P0

1. Login inválido retorna `401 UNAUTHENTICATED`.
2. `/v1/admin/auth/session` sem cookie retorna `401 SESSION_EXPIRED`.
3. Mutações administrativas sem autorização retornam `401` ou `403` conforme contrato.
4. Requisição sem origem permitida falha em CORS.
5. Excesso de chamadas recebe `429 RATE_LIMITED` com `meta.traceId`.
6. Respostas administrativas retornam `x-trace-id`.
7. Rotas administrativas retornam `cache-control: no-store`.

## Riscos residuais aceitos neste ciclo

- ausência de MFA
- ausência de trilha persistente detalhada de auditoria
- ausência de stack dedicada de detecção de anomalias

Esses riscos não bloqueiam o P0 atual, mas entram no backlog de segurança para ciclos seguintes.
