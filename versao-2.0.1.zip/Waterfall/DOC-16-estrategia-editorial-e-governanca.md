# DOC-16 — Estratégia Editorial e Governança

## Endereço

`/home/walbarellos/personal-site/personal-site(Graciliano)/Waterfall/DOC-16-estrategia-editorial-e-governanca.md`

## Objetivo

Documentar o modelo editorial **implementado no código atual** e como ele é governado entre painel admin, API administrativa, contratos compartilhados e camada pública.

## Fontes auditadas

- `packages/contracts/src/publications.ts`
- `apps/api/src/routes/publications-admin.ts`
- `apps/admin/app/painel/publicacoes/page.tsx`
- `apps/admin/app/painel/publicacoes/[id]/editar/page.tsx`
- `apps/admin/src/lib/session.ts`
- `apps/admin/src/features/publicacoes/shared/types.ts`
- `apps/web/src/lib/api/public.ts`

## Escopo

Incluído:

- estados editoriais e transições válidas
- papéis autorizados para operação editorial
- responsabilidades por camada
- impacto direto no conteúdo público

Fora do escopo neste ciclo:

- fluxo multiaprovador por etapa
- trilha de auditoria persistente por alteração
- calendário editorial automatizado

## Modelo editorial soberano

### 1) Entidade de publicação

Contrato base: `packages/contracts/src/publications.ts`.

Campos centrais da publicação administrativa:

- identificação: `id`, `slug`
- conteúdo: `title`, `summary`, `content`
- classificação: `categoryId`, `tagIds`, `category`, `tags`
- SEO: `seo.metaTitle`, `seo.metaDescription`, `seo.canonicalUrl`, `seo.ogTitle`, `seo.ogDescription`, `seo.ogImageUrl`
- governança: `status`, `publishedAt`, `updatedAt`

### 2) Estados editoriais

Estados válidos no contrato e API:

- `draft`
- `review`
- `ready_to_publish`
- `published`
- `archived`

## Política de transição editorial

Fonte: `apps/api/src/routes/publications-admin.ts`.

Transições permitidas:

- `draft` → `review`, `archived`
- `review` → `draft`, `ready_to_publish`, `archived`
- `ready_to_publish` → `review`, `published`, `archived`
- `published` → `archived`
- `archived` → `draft`

Regras:

- transição fora da matriz é rejeitada com `INVALID_STATE_TRANSITION`
- rota de transição: `POST /v1/admin/publications/:id/status`

## Governança por papel

Fontes: `apps/api/src/routes/publications-admin.ts` e `apps/admin/src/lib/session.ts`.

Papéis aceitos para operação editorial:

- `admin`
- `editor`

Comportamento:

- API exige sessão administrativa para rotas editoriais
- painel admin redireciona para login em ausência de sessão
- papel fora da lista permitida gera bloqueio de acesso

## Responsabilidades por camada

### 1) API administrativa (`apps/api`)

Responsável por:

- validar query, params e body com schema
- aplicar regras de transição de estado
- normalizar erros de negócio e validação
- manter envelope de resposta padronizado

Rotas centrais:

- `GET /v1/admin/publications`
- `GET /v1/admin/publications/:id`
- `POST /v1/admin/publications`
- `PUT /v1/admin/publications/:id`
- `POST /v1/admin/publications/:id/status`

### 2) Painel administrativo (`apps/admin`)

Responsável por:

- listar e filtrar publicações (`/painel/publicacoes`)
- editar conteúdo e SEO (`/painel/publicacoes/[id]/editar`)
- acionar persistência e transição de status
- exibir feedback operacional de sucesso/erro

### 3) Camada pública (`apps/web`)

Responsável por:

- consumir somente conteúdo publicado via API pública
- refletir slug, resumo, conteúdo e campos SEO na experiência pública

## Regras de qualidade editorial do ciclo

Antes de manter publicação em estado público, o fluxo deve preservar:

- título, slug e resumo consistentes
- conteúdo legível e finalizado
- SEO mínimo preenchido quando necessário ao contexto
- transição de estado feita por operação explícita

## Critérios de aceite deste baseline

1. Estados editoriais do contrato e da API são idênticos.
2. Transições inválidas são rejeitadas no backend.
3. Rotas administrativas de publicação exigem sessão e papel autorizado.
4. Painel admin usa leitura de sessão server-side para proteger acesso.
5. Edição e transição ocorrem por endpoints explícitos, sem promoção implícita.
6. Camada pública depende dos contratos editoriais já definidos.

## Riscos residuais aceitos

- ausência de aprovação em múltiplas etapas
- ausência de histórico persistido de auditoria editorial

Esses itens ficam para o ciclo seguinte de governança avançada.
