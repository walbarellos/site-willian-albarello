
---

# `019_Superprompts_de_Geracao_por_Bloco.md`

**Endereço canônico:**
`/home/user/Documents/Softwares/Willian Albarello/William Albarello/01-Waterfall/02-Altamente_Relevantes/019_Superprompts_de_Geracao_por_Bloco.md`

**Status:**
Gerado no diálogo, em padrão copy/paste.

---

# 019_Superprompts_de_Geracao_por_Bloco

## 1. Identificação do documento

Este documento pertence ao diretório `01-Waterfall/02-Altamente_Relevantes` do projeto **William Albarello** e sucede logicamente os artefatos que já consolidaram:

* backlog, sequência oficial de entrega e blueprint do sistema;
* design system, contratos de componentes e contratos de módulos;
* estados, eventos, transições, validações, erros e fallbacks;
* matriz de permissões RBAC/ABAC;
* dicionário de dados e matriz de dependências;
* política de versionamento, observabilidade, performance e SEO;
* arquitetura operacional do painel administrativo;
* procedimentos de QA manual e cenários E2E.

Sua finalidade é criar os **superprompts soberanos de geração por bloco**, para orientar a produção disciplinada de:

* frontend público;
* painel administrativo;
* API;
* dados e persistência;
* SEO e descoberta;
* QA;
* operação;
* continuidade documental;
* geração futura de artefatos alinhados ao método.

Este documento deve ser lido como a resposta formal à pergunta:

> quais prompts mestres sustentam a geração disciplinada do projeto William Albarello sem dispersão, sem quebra de contrato e sem perda do padrão já consolidado?

---

## 2. Finalidade do documento

O objetivo deste documento é impedir que a geração futura de código, artefatos, patches, revisões e handoffs aconteça por prompts vagos, genéricos ou descolados da arquitetura soberana já consolidada.

No projeto William Albarello, prompt não é mero pedido textual.
Prompt é:

* contrato de geração;
* mecanismo de disciplina;
* preservação de continuidade;
* filtro contra invenção indevida;
* dispositivo de alinhamento entre Waterfall, Diagramas e implementação;
* defesa contra retrabalho.

Este documento existe para:

* criar superprompts reutilizáveis;
* reduzir ambiguidade na geração futura;
* preservar o padrão metodológico do projeto;
* impedir que cada nova geração “recomece do zero”;
* garantir aderência a estado, permissão, SEO, dados, QA e operação;
* orientar tanto geração total quanto patches cirúrgicos.

Em linguagem direta:

* **prompt como contrato**;
* **gerar sem dispersão**;
* **preservar padrão do projeto**.

---

## 3. Insumos soberanos deste documento

Este documento deriva de todo o pacote-base do projeto e, em especial, dos seguintes blocos já consolidados:

### Base constitucional do projeto

* `00-Padrao`
* `01-Waterfall/01-Obrigatorios`
* `02-Diagramas/000–049`

### Ciclo atual de `02-Altamente_Relevantes`

* `001` a `018`

### Regra metodológica já consolidada no projeto

* geração direta no diálogo;
* entrega em **markdown copy/paste**;
* distinção entre estado lógico do projeto e estado físico dos arquivos;
* continuidade documental explícita;
* proibição de invenção fora do domínio aprovado;
* aderência estrita ao Waterfall e aos Diagramas já consolidados.

---

## 4. Tese central

A tese central deste documento é:

> no projeto William Albarello, toda geração futura precisa nascer de prompts soberanos, orientados por bloco, com restrições explícitas, contexto arquitetural e critérios de aderência, para que o código e os artefatos evoluam como continuação disciplinada do projeto e não como improviso local.

Isso implica que:

* não se deve usar prompt genérico para gerar bloco crítico;
* cada superprompt precisa dizer:

  * o que está sendo gerado;
  * com base em quais documentos;
  * com quais fronteiras;
  * com quais proibições;
  * com qual padrão de entrega;
* a geração deve preservar continuidade semântica e estrutural;
* o prompt precisa blindar o projeto contra:

  * feature creep;
  * inconsistência de nomenclatura;
  * quebra de contrato;
  * mistura entre público e privado;
  * perda de governança.

---

## 5. Princípios constitucionais dos superprompts

## 5.1 Todo superprompt deve partir do projeto já existente

Nenhum superprompt deve tratar o projeto como folha em branco.

## 5.2 Todo superprompt deve nomear explicitamente sua fonte de verdade

Sempre que possível, deve citar:

* Waterfall;
* Diagramas;
* documentos do ciclo atual;
* bloco específico a ser respeitado.

## 5.3 Todo superprompt deve proibir invenção indevida

O gerador não deve criar features, fluxos ou entidades fora do domínio já aprovado.

## 5.4 Todo superprompt deve definir formato de saída

Sem formato de entrega, a geração tende a perder disciplina.

## 5.5 Todo superprompt deve distinguir geração total de patch

Gerar arquivo novo não é o mesmo que corrigir um trecho.

## 5.6 Todo superprompt deve lembrar restrições de estado, permissão e visibilidade

Especialmente em admin, API, dados e SEO.

## 5.7 Todo superprompt deve preservar a separação entre:

* público;
* admin;
* API;
* dados;
* observabilidade;
* SEO;
* QA.

## 5.8 Todo superprompt deve favorecer continuidade

O resultado precisa ser encaixável no projeto sem exigir reconstrução conceitual.

---

## 6. Estrutura soberana de um superprompt

Todo superprompt deste projeto deve, idealmente, conter os seguintes componentes:

1. **Identificação do bloco**
2. **Objetivo da geração**
3. **Base documental obrigatória**
4. **Escopo do que pode gerar**
5. **Proibições explícitas**
6. **Regras de aderência**
7. **Formato de entrega**
8. **Critérios mínimos de qualidade**
9. **Restrições de continuidade**

---

## 7. Cláusulas globais obrigatórias para todos os superprompts

Antes dos superprompts específicos, o projeto consolida as seguintes cláusulas globais.

### Cláusula 1 — Continuidade obrigatória

A geração deve considerar o projeto William Albarello como já consolidado documentalmente e logicamente.

### Cláusula 2 — Proibição de reinvenção do domínio

Não inventar páginas, módulos, papéis, entidades, estados, fluxos ou permissões fora do que já foi aprovado.

### Cláusula 3 — Respeito ao Waterfall e aos Diagramas

Toda geração deve se alinhar ao Waterfall obrigatório, ao Diretório 02-Diagramas e aos documentos `001–018` deste ciclo.

### Cláusula 4 — Respeito à separação público/admin

Não misturar camada pública indexável com painel, preview ou recursos internos.

### Cláusula 5 — Backend-first em auth e permissão

Autenticação e autorização são soberanas no backend; a UI apenas reflete.

### Cláusula 6 — Status editorial governa visibilidade pública

Conteúdo só pertence ao universo público quando `status_editorial = published`.

### Cláusula 7 — Entrega em formato copy/paste

A geração deve ser entregue diretamente no diálogo, em **markdown copy/paste**, salvo instrução explícita em contrário.

### Cláusula 8 — Preferência por clareza e governança

O resultado deve ser sóbrio, modular, rastreável e compatível com QA, observabilidade e continuidade.

---

# 8. Superprompt soberano — Frontend Público

## 8.1 Finalidade

Gerar páginas, componentes, blocos e estruturas do site público institucional/editorial.

## 8.2 Quando usar

Usar quando a geração envolver:

* home pública;
* listagem `/publicacoes`;
* página `/publicacoes/[slug]`;
* páginas legais;
* header/footer públicos;
* componentes públicos institucionais ou editoriais.

## 8.3 Superprompt

```text
Vida Relacional, gere o bloco de frontend público do projeto William Albarello com aderência estrita ao Waterfall obrigatório, ao Diretório 02-Diagramas e aos documentos 001–018 do ciclo 02-Altamente_Relevantes. Trate o site público como camada institucional e editorial indexável, separada do painel administrativo. Respeite o blueprint de telas, o design system, os contratos de componentes, os estados, os fallbacks, a estratégia de performance e a estratégia de SEO já consolidados. Não invente novas páginas, seções, componentes ou fluxos fora do domínio aprovado. Não trate preview, painel ou estados internos como públicos. Gere em padrão sóbrio, sem ornamentalismo desnecessário, com foco em clareza, semântica, responsividade e copy/paste puro. Se estiver gerando arquivo completo, entregue o arquivo inteiro. Se estiver gerando patch, indique com precisão o ponto de inserção, substituição ou ajuste.
```

## 8.4 Regras específicas de aderência

* respeitar `003`, `004`, `005`, `015`;
* manter canonical e metadata coerentes;
* não quebrar a política de slugs;
* não depender de payloads não contratuais;
* não transformar o público em espelho do admin.

## 8.5 Saída esperada

* arquivo completo ou patch preciso;
* sem explicação prolixa;
* pronto para copy/paste.

---

# 9. Superprompt soberano — Painel Administrativo

## 9.1 Finalidade

Gerar telas, fluxos, componentes e estruturas do painel interno.

## 9.2 Quando usar

Usar para:

* login admin;
* dashboard;
* listagem interna;
* formulários;
* edição;
* preview;
* navegação do painel;
* estados internos;
* mensagens operacionais do admin.

## 9.3 Superprompt

```text
Vida Relacional, gere o bloco do painel administrativo do projeto William Albarello com base estrita no Waterfall, no Diretório 02-Diagramas e nos documentos 003, 004, 005, 007, 008, 009, 016 e 018 já consolidados. Trate o painel como posto de comando interno, não como CRUD genérico. Respeite autenticação, sessão, RBAC/ABAC, estados editoriais, mensagens operacionais, preview interno e arquitetura operacional do admin. Não invente áreas administrativas fora do escopo aprovado. Não transforme preview em rota pública. Não mova para o frontend decisões que pertencem ao backend. Gere interfaces sóbrias, orientadas à tarefa, com feedback claro, estados explícitos e copy/paste puro.
```

## 9.4 Regras específicas de aderência

* respeitar `016` como fonte soberana do admin;
* refletir permissões sem soberanizá-las;
* respeitar `007`, `008`, `009`;
* preservar shell resiliente;
* não quebrar fluxo editorial.

## 9.5 Saída esperada

* tela, componente, fluxo ou patch do admin;
* estrutura clara e operável;
* pronta para encaixe.

---

# 10. Superprompt soberano — API e Serviços de Aplicação

## 10.1 Finalidade

Gerar endpoints, contratos, serviços, validações e respostas da API.

## 10.2 Quando usar

Usar para:

* endpoints públicos;
* endpoints administrativos;
* autenticação;
* leitura por slug;
* listagem interna;
* criação/edição/publicação;
* mudança de status;
* contratos de erro.

## 10.3 Superprompt

```text
Vida Relacional, gere o bloco de API e serviços de aplicação do projeto William Albarello com base estrita no Waterfall, no Diretório 02-Diagramas e nos documentos 006, 007, 008, 009, 010, 011, 012, 013, 014 e 018. Respeite contratos entre módulos, estados editoriais, RBAC/ABAC, dicionário de dados, política de versionamento, logs estruturados e estratégia de performance. Não invente endpoints, campos, entidades ou fluxos fora do domínio aprovado. Não misture leitura pública com operação administrativa. A autorização deve ser backend-first, com negação por padrão. O contrato de erro deve distinguir validação, autenticação, autorização, conflito, indisponibilidade e erro interno. Gere em estilo claro, modular, rastreável e compatível com observabilidade e QA.
```

## 10.4 Regras específicas de aderência

* respeitar `W016` e `006`;
* refletir `007` e `008` nas respostas;
* usar `010` como léxico de dados;
* não quebrar compatibilidade sem sinalização.

## 10.5 Saída esperada

* código de endpoint, serviço ou contrato;
* modular;
* semanticamente alinhado.

---

# 11. Superprompt soberano — Dados, Entidades e Persistência

## 11.1 Finalidade

Gerar modelos, schemas, migrações conceituais ou estruturas de persistência alinhadas ao catálogo de entidades.

## 11.2 Quando usar

Usar para:

* entidades;
* tabelas;
* relacionamentos;
* índices;
* enums;
* migrações;
* ajustes de persistência;
* leitura de impacto em schema.

## 11.3 Superprompt

```text
Vida Relacional, gere o bloco de dados e persistência do projeto William Albarello com aderência estrita ao Waterfall, aos diagramas de dados/persistência e aos documentos 007, 009, 010, 011 e 012. Use o dicionário de dados como fonte soberana de entidades, atributos, relações, unicidade, estados e chaves lógicas. Não invente colunas vagas, JSON sem contrato, duplicidade de fonte de verdade ou visibilidade pública paralela ao status editorial. Preserve a diferença entre audit trail, versionamento, sessão e conteúdo editorial. Toda mudança estrutural precisa considerar compatibilidade, migração e rollback. Gere de forma semântica, clara e compatível com API, SEO, auth e observabilidade.
```

## 11.4 Regras específicas de aderência

* respeitar `010` como fonte máxima;
* não criar soft-delete arbitrário onde o projeto prefere estado;
* não quebrar slug, status ou audit trail;
* pensar em leitura pública e interna.

## 11.5 Saída esperada

* modelo conceitual, schema, migration plan ou patch;
* com impacto arquitetural claro;
* pronto para continuidade.

---

# 12. Superprompt soberano — SEO, Metadata e Descoberta

## 12.1 Finalidade

Gerar artefatos e implementações ligadas à semântica pública, metadata, canonical, sitemap, robots e descoberta orgânica.

## 12.2 Quando usar

Usar para:

* metadata de páginas;
* canonical;
* sitemap;
* robots;
* comportamento de slug;
* discoverability pública;
* exclusão de rotas privadas.

## 12.3 Superprompt

```text
Vida Relacional, gere o bloco de SEO, metadata e descoberta do projeto William Albarello com base estrita no Waterfall, nos diagramas de SEO/publicação e nos documentos 010, 012, 014 e 015. Trate SEO como arquitetura pública do conteúdo, não como adereço de template. Respeite a separação entre páginas públicas e privadas, a política de canonicalização, a governança de slugs, a relação entre status editorial e elegibilidade pública, e a exclusão do painel e do preview do universo indexável. Não invente superfícies públicas fora do blueprint. Gere o resultado de forma semântica, disciplinada, coerente com publicação, performance e discoverability.
```

## 12.4 Regras específicas de aderência

* respeitar `015` como fonte soberana;
* só conteúdo `published` entra em SEO público;
* preview e admin nunca participam da camada indexável;
* canonical precisa acompanhar slug atual.

## 12.5 Saída esperada

* metadata, config, sitemap, robots, patch de rota ou política;
* coerente com a camada pública real.

---

# 13. Superprompt soberano — Autenticação, Sessão e Permissão

## 13.1 Finalidade

Gerar fluxos, guardas, middlewares, contratos ou componentes ligados a login, sessão e autorização.

## 13.2 Quando usar

Usar para:

* login;
* sessão;
* expiração;
* logout;
* middleware de auth;
* guardas de acesso;
* resolução RBAC/ABAC;
* telas de acesso negado.

## 13.3 Superprompt

```text
Vida Relacional, gere o bloco de autenticação, sessão e permissão do projeto William Albarello com base estrita no Waterfall, nos diagramas de segurança/sessão/permissão e nos documentos 007, 008, 009, 010, 013, 016 e 018. Respeite a distinção entre autenticação e autorização, negação por padrão, backend-first, sessão real, expiração tratada, acesso negado formal e rastreabilidade mínima. Não trate login como simples formulário visual. Não permita que o frontend soberanize permissão. Não invente papéis ou atalhos de acesso fora da matriz aprovada. Gere a solução de forma segura, auditável, clara e compatível com os estados e fluxos do projeto.
```

## 13.4 Regras específicas de aderência

* respeitar `009` como matriz soberana;
* respeitar `007` para estados de sessão;
* todo acesso crítico precisa poder gerar rastro.

## 13.5 Saída esperada

* middleware, handler, fluxo, tela ou patch;
* segurança sem improviso;
* compatível com admin e API.

---

# 14. Superprompt soberano — QA Manual e E2E

## 14.1 Finalidade

Gerar roteiros de teste, casos, checklists, planos de homologação e cenários ponta a ponta.

## 14.2 Quando usar

Usar para:

* QA manual;
* smoke;
* regressão;
* validação por perfil;
* validação de SEO;
* testes de fallback;
* cenários E2E;
* ampliação de cobertura de homologação.

## 14.3 Superprompt

```text
Vida Relacional, gere o bloco de QA do projeto William Albarello com base estrita no Waterfall, nos Diagramas e nos documentos 007, 008, 009, 013, 014, 015, 016, 017 e 018. Estruture o resultado como protocolo de verificação real, não como lista vaga. Inclua pré-condições, perfis, passos, resultados esperados, evidências mínimas, falhas observáveis e criticidade. Não teste apenas caminho feliz. Inclua sessão, permissão, estado editorial, SEO, responsividade, fallback, preview, publicação e retirada da camada pública quando aplicável. Preserve linguagem sóbria, classificações claras e aderência à arquitetura do projeto.
```

## 14.4 Regras específicas de aderência

* respeitar `017` e `018` como fontes soberanas;
* distinguir QA amplo de E2E;
* exigir evidência;
* tratar público e admin como superfícies diferentes.

## 14.5 Saída esperada

* checklist, matriz de teste, cenário E2E ou patch de protocolo;
* com leitura clara de aprovação/falha.

---

# 15. Superprompt soberano — Observabilidade, Logs e Incidentes

## 15.1 Finalidade

Gerar políticas, estruturas ou implementações ligadas a logs, métricas, correlação, audit trail e resposta a incidente.

## 15.2 Quando usar

Usar para:

* logs estruturados;
* naming de eventos;
* correlation id;
* métricas;
* health/readiness;
* alertas;
* trilha auditável;
* leitura de incidente.

## 15.3 Superprompt

```text
Vida Relacional, gere o bloco de observabilidade do projeto William Albarello com aderência estrita ao Waterfall, aos diagramas de observabilidade/auditoria e aos documentos 007, 010, 012, 013, 014 e 018. Diferencie claramente log técnico, evento operacional, métrica, alerta e audit trail. Preserve correlação entre requisição, sessão, usuário e recurso. Não transforme observabilidade em dumping de ruído. Não vaze credenciais, segredos ou conteúdo sensível desnecessário. O resultado deve apoiar diagnóstico, governança, QA e continuidade, com linguagem e estrutura disciplinadas.
```

## 15.4 Regras específicas de aderência

* respeitar `013` como fonte soberana;
* audit trail não se confunde com log técnico;
* correlação é obrigatória em fluxo crítico.

## 15.5 Saída esperada

* política, esquema, implementação ou patch;
* orientado a governança e diagnóstico.

---

# 16. Superprompt soberano — Performance, Cache e Escalabilidade

## 16.1 Finalidade

Gerar decisões, código ou documentação voltados a performance, consultas, cache, renderização e crescimento controlado.

## 16.2 Quando usar

Usar para:

* otimização de listagem;
* renderização pública;
* cache;
* consulta por slug;
* paginação;
* build;
* estratégia de entrega;
* ajuste de payload.

## 16.3 Superprompt

```text
Vida Relacional, gere o bloco de performance e escalabilidade do projeto William Albarello com aderência estrita ao Waterfall, aos diagramas de infraestrutura/publicação e aos documentos 010, 011, 013, 014 e 015. Não faça micro-otimização abstrata. Priorize rotas críticas, payload correto, consultas coerentes, cache controlado, renderização compatível com a camada pública e custo operacional sóbrio. Não proponha superengenharia prematura. Toda otimização precisa respeitar estados, SEO, autenticação, publicação e observabilidade. Gere a solução com clareza sobre o que melhora, por que melhora e como isso preserva a arquitetura do projeto.
```

## 16.4 Regras específicas de aderência

* respeitar `014` como fonte soberana;
* não otimizar no escuro;
* cache precisa ter política de invalidação;
* separar necessidades do público e do admin.

## 16.5 Saída esperada

* decisão, patch, código ou diretriz;
* foco em eficiência real e custo controlado.

---

# 17. Superprompt soberano — Operação, Deploy e Rollback

## 17.1 Finalidade

Gerar artefatos e decisões relacionados a ambientes, deploy, rollout, rollback, readiness e continuidade operacional.

## 17.2 Quando usar

Usar para:

* estratégia de deploy;
* staging;
* readiness;
* rollback;
* entrega coordenada frontend/API;
* mudanças operacionais com impacto de compatibilidade.

## 17.3 Superprompt

```text
Vida Relacional, gere o bloco de operação e entrega do projeto William Albarello com base estrita no Waterfall, nos diagramas de deploy/CI-CD/disponibilidade e nos documentos 011, 012, 013, 014 e 017. Trate deploy e rollback como parte da arquitetura, não como pós-obra. Preserve compatibilidade entre frontend, admin, API, dados, SEO e ambiente. Não proponha mudança operacional sem plano de validação, impacto, rollback e leitura de observabilidade. Gere o resultado com foco em previsibilidade, segurança, continuidade e governança de release.
```

## 17.4 Regras específicas de aderência

* respeitar `W022` e `012`;
* evitar rollback aparente;
* pensar em ambiente, readiness e validação pós-deploy.

## 17.5 Saída esperada

* plano, checklist, script conceitual, patch ou documento operacional;
* com risco e mitigação claros.

---

# 18. Superprompt soberano — Continuidade, Handoff e Memória de Projeto

## 18.1 Finalidade

Gerar relatórios de continuidade, handoffs e consolidações de estado do projeto para o próximo chat/ciclo.

## 18.2 Quando usar

Usar para:

* continuidade de diálogo;
* fechamento de ciclo;
* handoff entre chats;
* consolidação de estado lógico vs. estado físico;
* atualização de próximos passos.

## 18.3 Superprompt

```text
Vida Relacional, gere o documento de continuidade/handoff do projeto William Albarello considerando todo o estado já consolidado neste diálogo e na memória lógica do projeto. Distinga explicitamente estado lógico do projeto, estado físico dos arquivos e próximos passos corretos. Não reabra decisões já fechadas sem motivo. Não trate conteúdo já gerado em diálogo como inexistente só porque não foi colado no arquivo físico. Organize o handoff de forma que o próximo chat compreenda o que foi feito, o que está fechado, o que ainda depende de execução e qual é a sequência metodológica correta.
```

## 18.4 Regras específicas de aderência

* distinguir estado lógico e físico;
* preservar continuidade sem reset conceitual;
* apontar próximo passo metodológico correto;
* evitar handoff vago ou genérico.

## 18.5 Saída esperada

* relatório de continuidade robusto;
* usável como ponte direta para o próximo chat.

---

# 19. Superprompt soberano — Patch Cirúrgico

## 19.1 Finalidade

Gerar correções pequenas ou localizadas sem reescrever blocos inteiros desnecessariamente.

## 19.2 Quando usar

Usar para:

* ajuste de trecho específico;
* correção pontual;
* melhoria localizada;
* adequação de naming;
* conserto de fluxo delimitado.

## 19.3 Superprompt

```text
Vida Relacional, gere um patch cirúrgico para o projeto William Albarello. Considere toda a arquitetura já consolidada e altere apenas o necessário no bloco solicitado. Não reescreva arquivos inteiros sem necessidade. Preserve contratos, estados, permissões, SEO, observabilidade e compatibilidade já aprovados. Entregue em copy/paste puro, indicando exatamente o trecho a substituir, remover ou inserir, com contexto suficiente para aplicação segura. Se o patch tiver impacto estrutural maior do que o pedido sugere, explicite isso no próprio resultado em vez de mascarar a complexidade.
```

## 19.4 Regras específicas de aderência

* mínimo necessário;
* impacto explícito;
* sem retrabalho cosmético desnecessário;
* manter continuidade.

## 19.5 Saída esperada

* diff lógico ou trecho preciso;
* aplicável sem ambiguidade.

---

# 20. Superprompt soberano — Arquivo Completo

## 20.1 Finalidade

Gerar um arquivo inteiro quando a peça ainda não existe ou quando a refação integral for justificável.

## 20.2 Quando usar

Usar para:

* novo arquivo;
* primeira implementação;
* arquivo vazio;
* substituição integral realmente necessária.

## 20.3 Superprompt

```text
Vida Relacional, gere o arquivo completo do projeto William Albarello referente ao bloco solicitado, com aderência estrita ao Waterfall, aos Diagramas e aos documentos já consolidados deste ciclo. Entregue o arquivo inteiro, pronto para copy/paste, sem depender de inferências externas. Não invente escopo, não quebre contratos existentes e não misture responsabilidades de módulos. Se houver dependências ainda não implementadas em runtime, mantenha o arquivo compatível com a arquitetura aprovada e declare apenas no próprio corpo estrutural o que for necessário como integração futura, sem distorcer o contrato do bloco.
```

## 20.4 Regras específicas de aderência

* arquivo inteiro;
* sem lacunas mascaradas;
* sem improviso de domínio;
* coerente com dependências já mapeadas.

## 20.5 Saída esperada

* arquivo completo;
* claro, encaixável e disciplinado.

---

# 21. Superprompt soberano — Revisão Arquitetural de Bloco

## 21.1 Finalidade

Analisar um bloco já gerado para verificar aderência ao projeto antes de aprovar, corrigir ou evoluir.

## 21.2 Quando usar

Usar para:

* auditoria de aderência;
* revisão de código;
* conferência de contrato;
* validação de coerência entre bloco e arquitetura.

## 21.3 Superprompt

```text
Vida Relacional, revise arquiteturalmente o bloco fornecido do projeto William Albarello à luz do Waterfall, dos Diagramas e dos documentos já consolidados do ciclo atual. Verifique aderência de escopo, separação de responsabilidades, estados, permissões, SEO, dados, observabilidade, performance, compatibilidade e QA. Não faça crítica genérica. Aponte divergências reais, riscos de retrabalho, violações de contrato e pontos maduros. Se for adequado, proponha patch cirúrgico em vez de reescrita integral.
```

## 21.4 Regras específicas de aderência

* revisão precisa, não vaga;
* foco em contrato e arquitetura;
* separar bug real de preferência estética.

## 21.5 Saída esperada

* leitura arquitetural objetiva;
* com proposta de correção quando necessário.

---

# 22. Regras de uso combinatório dos superprompts

## 22.1 Regra geral

Os superprompts podem ser combinados, mas a combinação deve respeitar a fronteira entre blocos.

## 22.2 Combinações saudáveis

* Frontend Público + SEO
* Painel Admin + Auth/Sessão/Permissão
* API + Dados/Persistência
* QA Manual + E2E
* Operação + Observabilidade
* Continuidade + Patch Cirúrgico, quando o objetivo for fechar ciclo com correção delimitada

## 22.3 Combinações perigosas

* Frontend Público + Painel + API + Dados em um prompt único genérico
* SEO + Admin como se fossem o mesmo universo
* Patch Cirúrgico usado para alteração estrutural grande sem reconhecer impacto
* Arquivo Completo usado para sobrescrever bloco consolidado sem justificativa

---

# 23. Anti-padrões explicitamente proibidos

Este documento proíbe, de forma expressa:

## 23.1 Prompt genérico para bloco crítico

Isso abre espaço para dispersão e invenção indevida.

## 23.2 Prompt sem fonte documental explícita

A geração tende a perder o chão do projeto.

## 23.3 Prompt que trata o projeto como folha em branco

Isso rompe continuidade.

## 23.4 Prompt que mistura público, admin, API e dados como se fossem o mesmo bloco

Isso quebra a arquitetura modular.

## 23.5 Prompt que pede “faça do melhor jeito” sem restrição

Isso convida à divergência metodológica.

## 23.6 Prompt que não define formato de saída

Isso gera resposta difícil de aplicar.

## 23.7 Prompt que não diz se quer patch ou arquivo inteiro

Isso aumenta ruído e retrabalho.

## 23.8 Prompt que não proíbe invenção fora do domínio

Isso ameaça a coerência do projeto.

## 23.9 Prompt que ignora RBAC/ABAC, status editorial ou SEO em bloco que depende deles

Isso produz integração quebrada.

## 23.10 Prompt que não preserva a distinção entre estado lógico e estado físico do projeto

Isso compromete handoff e continuidade.

---

# 24. Estratégia prática de uso do documento

## 24.1 Para gerar código novo

Use o superprompt do bloco principal + o superprompt de arquivo completo.

## 24.2 Para corrigir algo já existente

Use o superprompt do bloco principal + o superprompt de patch cirúrgico.

## 24.3 Para revisar algo antes de aprovar

Use o superprompt de revisão arquitetural de bloco.

## 24.4 Para encerrar um ciclo e preparar o próximo chat

Use o superprompt de continuidade/handoff.

## 24.5 Para validar geração já pensando em teste

Use o superprompt do bloco principal + QA Manual ou E2E, conforme o caso.

---

# 25. Síntese executiva

A leitura executiva deste documento é:

* o projeto agora possui superprompts soberanos por bloco;
* a geração futura deixa de depender de pedidos vagos;
* frontend, admin, API, dados, SEO, auth, QA, observabilidade, operação e continuidade receberam prompts específicos;
* os prompts já nascem com:

  * fonte de verdade;
  * escopo;
  * proibições;
  * regras de aderência;
  * formato de saída;
* patch, arquivo completo, revisão arquitetural e handoff também passaram a ter contrato próprio.

Em linguagem simples:

> no projeto William Albarello, os superprompts passam a funcionar como ferramentas de continuidade disciplinada, garantindo que cada geração futura continue o projeto em vez de desviá-lo.

---

# 26. Conclusão

Se os cenários E2E provaram **como o sistema precisa fechar seus fluxos**, este documento define **como a geração futura deve ser conduzida para que esses fluxos continuem possíveis, coerentes e alinhados à arquitetura já consolidada**.

Ele consolida oito mensagens principais:

1. **prompt é contrato;**
2. **gerar sem dispersão é obrigação metodológica;**
3. **cada bloco precisa de seu próprio superprompt;**
4. **fonte documental explícita reduz retrabalho;**
5. **patch e arquivo completo precisam de tratamentos diferentes;**
6. **revisão arquitetural precisa de prompt próprio;**
7. **continuidade não pode depender de memória difusa;**
8. **os superprompts são parte da governança do projeto.**

A mensagem final deste documento é:

> no projeto William Albarello, a geração disciplinada de código e artefatos só será sustentável se os pedidos futuros forem feitos por superprompts soberanos, porque é isso que garante continuidade real, aderência ao Waterfall, respeito aos Diagramas e preservação do padrão arquitetural já conquistado.

---

