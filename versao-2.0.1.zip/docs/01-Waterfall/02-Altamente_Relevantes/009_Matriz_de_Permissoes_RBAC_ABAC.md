
# `009_Matriz_de_Permissoes_RBAC_ABAC.md`

**Endereço canônico:**
`/home/user/Documents/Softwares/Willian Albarello/William Albarello/01-Waterfall/02-Altamente_Relevantes/009_Matriz_de_Permissoes_RBAC_ABAC.md`

**Status:**
Gerado no diálogo, em padrão copy/paste.

---

# 009_Matriz_de_Permissoes_RBAC_ABAC

## 1. Identificação do documento

Este documento pertence ao diretório `01-Waterfall/02-Altamente_Relevantes` do projeto **William Albarello** e sucede logicamente os artefatos que já consolidaram:

* módulos;
* superfícies;
* componentes;
* estados;
* eventos;
* transições;
* validações;
* mensagens de erro;
* fallbacks.

Sua finalidade é estabelecer a **matriz formal de permissões do sistema**, definindo quem pode fazer o quê, sobre qual recurso, em qual contexto e sob quais restrições.

Este documento deve ser lido como a resposta oficial à pergunta:

> quem pode o quê, quando e em qual contexto?

---

## 2. Finalidade do documento

O objetivo deste documento é impedir que o sistema trate acesso como simples presença de login.

No projeto William Albarello, autenticação e autorização não são a mesma coisa.

Um operador pode:

* estar autenticado;
* estar com sessão ativa;
* ainda assim **não** poder:

  * editar determinado conteúdo;
  * publicar;
  * arquivar;
  * ver trilha auditável;
  * acessar recursos sensíveis.

Este documento existe para:

* formalizar perfis canônicos;
* definir recursos protegidos;
* nomear ações autorizáveis;
* consolidar regra de **negação por padrão**;
* fixar a política de **autorização backend-first**;
* estabelecer o uso de RBAC como base e ABAC como refinamento;
* reduzir ambiguidade entre leitura, edição, revisão, publicação e auditoria;
* orientar painel, API, QA e governança.

Em linguagem direta:

* **acesso é arquitetura**;
* **não basta logar**;
* **quem pode o quê, quando e em qual contexto** precisa estar formalizado.

---

## 3. Insumos soberanos deste documento

Este documento deriva principalmente dos seguintes artefatos já consolidados:

### Waterfall obrigatório

* `W015` — Segurança, Privacidade, Auditoria e Permissões
* `W016` — API Contract Mestre
* `W021` — Critérios de Aceite Gerais
* `W024` — Registro de Decisões Arquiteturais

### Diretório 02-Diagramas

* `D038` — Diagrama de Segurança da Aplicação
* `D039` — Diagrama de Fluxo de Sessão
* `D040` — Diagrama de Permissões por Perfil
* `D041` — Diagrama de Auditoria e Rastreabilidade

### Ciclo atual

* `006_Contratos_de_Modulos.md`
* `007_Estados_Eventos_e_Transicoes.md`
* `008_Validacoes_Mensagens_de_Erro_e_Fallbacks.md`

---

## 4. Tese central

A tese central deste documento é:

> no projeto William Albarello, autorização é uma decisão formal baseada em papel, recurso, ação e contexto, sempre com negação por padrão e validação soberana no backend.

Isso implica que:

* a interface pode orientar e esconder ações indisponíveis;
* mas a decisão final de permissão **nunca** pertence ao frontend;
* a função de cada perfil precisa ser reconhecível;
* o mesmo usuário pode acumular papéis, mas isso não elimina regras de contexto;
* publicar, arquivar, ver auditoria e acessar áreas internas sensíveis são ações distintas e precisam permanecer distintas;
* o estado atual do recurso influencia a permissão;
* a existência de sessão não autoriza automaticamente qualquer ação.

---

## 5. Princípios constitucionais da política de acesso

## 5.1 Negação por padrão

Tudo que não estiver explicitamente permitido deve ser tratado como negado.

## 5.2 Autorização backend-first

O frontend pode ocultar, desabilitar ou orientar, mas o backend é a fonte de verdade da decisão.

## 5.3 Menor privilégio

Cada perfil deve possuir apenas o conjunto mínimo de permissões necessário ao seu papel.

## 5.4 Separação entre autenticação e autorização

Autenticar identifica; autorizar permite ou nega ação sobre recurso.

## 5.5 Contexto importa

Permissão não depende só do papel, mas também de:

* estado do recurso;
* autoria;
* visibilidade;
* sessão válida;
* escopo da ação;
* criticidade do recurso.

## 5.6 Recursos públicos e internos não podem ser confundidos

Ver conteúdo público publicado não equivale a poder operá-lo internamente.

## 5.7 Ações críticas precisam deixar rastro

Login, acesso negado, mudança de status, publicação, arquivamento e leitura de auditoria precisam ser rastreáveis.

## 5.8 Admin não invalida invariantes do sistema

Mesmo o administrador não deve burlar regras estruturais como:

* publicar item inexistente;
* publicar conteúdo sem slug válido, se este for requisito;
* executar transição proibida pelo contrato editorial.

---

## 6. Modelo de autorização adotado

O modelo adotado é **híbrido**:

* **RBAC** como camada base
* **ABAC** como camada de refinamento contextual

---

## 6.1 RBAC — Role-Based Access Control

RBAC responde à pergunta:

> este papel, em tese, pode atuar sobre este recurso com este tipo de ação?

É a camada de base da autorização.

---

## 6.2 ABAC — Attribute-Based Access Control

ABAC responde à pergunta:

> mesmo que o papel tenha permissão em tese, este contexto concreto permite a ação agora?

Os atributos contextuais mínimos previstos são:

* estado editorial do recurso;
* autoria do recurso;
* existência do recurso;
* visibilidade do recurso;
* validade da sessão;
* criticidade da ação;
* ambiente/escopo operacional, quando aplicável.

---

## 6.3 Regra de decisão

A decisão final deve seguir esta ordem lógica:

1. identificar o sujeito;
2. verificar autenticação/sessão;
3. resolver recurso alvo;
4. resolver ação desejada;
5. aplicar RBAC base;
6. aplicar ABAC contextual;
7. registrar decisão sensível;
8. responder contratualmente com sucesso, negação ou erro.

---

## 7. Perfis canônicos do sistema

Para este estágio do projeto, os perfis soberanos são os seguintes.

---

## 7.1 `VISITANTE_PUBLICO`

### Função

Usuário externo não autenticado, consumidor do site público e do conteúdo publicado.

### Natureza

Perfil público, sem acesso ao painel.

### Escopo

* navegar no domínio público;
* ver home;
* ver listagem pública;
* ler publicação publicada;
* acessar páginas legais.

---

## 7.2 `OPERADOR_EDITORIAL`

### Função

Criar e manter conteúdo em elaboração dentro do painel.

### Natureza

Perfil interno operacional de base.

### Escopo típico

* acessar painel;
* ver dashboard;
* listar publicações internamente;
* criar rascunhos;
* editar conteúdo permitido;
* solicitar revisão;
* abrir preview interno quando permitido.

### Limite estrutural

Não publica nem arquiva por padrão.

---

## 7.3 `REVISOR_EDITORIAL`

### Função

Atuar na etapa de revisão editorial, validando ou devolvendo conteúdo para ajuste.

### Natureza

Perfil interno de governança editorial intermediária.

### Escopo típico

* ler conteúdo interno;
* abrir preview interno;
* aprovar revisão;
* devolver para rascunho;
* preparar item para publicação.

### Limite estrutural

Não publica nem arquiva por padrão.

---

## 7.4 `PUBLICADOR_EDITORIAL`

### Função

Controlar a transição para a camada pública e a retirada da camada pública.

### Natureza

Perfil interno com responsabilidade de exposição e retirada editorial.

### Escopo típico

* publicar conteúdo apto;
* arquivar conteúdo publicado;
* restaurar conteúdo para novo ciclo editorial, quando permitido;
* atuar sobre estados de visibilidade pública.

### Limite estrutural

Não equivale automaticamente a administrador do sistema.

---

## 7.5 `AUDITOR_INTERNO`

### Função

Ler rastros, trilhas auditáveis e eventos relevantes de governança sem, por padrão, operar o conteúdo editorial.

### Natureza

Perfil interno de supervisão e rastreabilidade.

### Escopo típico

* acessar relatórios/trilhas auditáveis;
* verificar eventos críticos;
* inspecionar histórico relevante;
* visualizar recursos internos conforme política de necessidade de conhecimento.

### Limite estrutural

Não cria, não edita e não publica conteúdo por padrão.

---

## 7.6 `ADMINISTRADOR_SISTEMA`

### Função

Perfil de maior abrangência administrativa, com permissão ampla sobre o ambiente interno, respeitando invariantes arquiteturais.

### Natureza

Perfil interno soberano de administração do sistema.

### Escopo típico

* tudo que os perfis internos anteriores podem fazer;
* acesso ampliado a recursos administrativos;
* capacidade de governança geral do ambiente.

### Limite estrutural

Não deve burlar:

* regras de integridade;
* contratos de transição;
* validações obrigatórias;
* auditoria mínima;
* negação de ações estruturalmente inválidas.

---

## 7.7 Regra sobre acúmulo de perfis

Um mesmo usuário pode acumular mais de um papel interno, por exemplo:

* `OPERADOR_EDITORIAL` + `REVISOR_EDITORIAL`
* `REVISOR_EDITORIAL` + `PUBLICADOR_EDITORIAL`
* `PUBLICADOR_EDITORIAL` + `AUDITOR_INTERNO`

A permissão resultante é **aditiva**, mas continua sujeita a:

* negação por padrão;
* invariantes do sistema;
* ABAC contextual;
* validação backend-first.

---

## 8. Recursos protegidos canônicos

Os recursos mínimos tratados por esta matriz são:

1. **Rotas públicas**
2. **Tela de login administrativo**
3. **Dashboard administrativo**
4. **Listagem interna de publicações**
5. **Criação de publicação**
6. **Edição de publicação**
7. **Preview interno**
8. **Mudança de status editorial**
9. **Publicação**
10. **Arquivamento**
11. **Retorno ao ciclo editorial**
12. **Trilha auditável / auditoria**
13. **Recursos administrativos sensíveis**

---

## 9. Ações canônicas do sistema

As ações autorizáveis mínimas são:

* `read_public`
* `read_internal`
* `create`
* `update`
* `request_review`
* `approve_review`
* `reject_review`
* `preview_internal`
* `publish`
* `archive`
* `restore_to_draft`
* `read_audit`
* `access_sensitive_admin_area`

---

## 10. Legenda da matriz

Nesta matriz, serão usados os seguintes marcadores:

* **P** = permitido
* **C** = permitido com contexto/ABAC
* **N** = negado por padrão

### Observação importante

O marcador **P** nunca elimina a necessidade de:

* sessão válida, quando a área é interna;
* existência do recurso;
* integridade do estado;
* validação de payload;
* auditoria quando exigível.

---

# 11. Matriz RBAC principal

## 11.1 Matriz por perfil, recurso e ação

| Recurso / Ação                           | Visitante Público | Operador Editorial | Revisor Editorial | Publicador Editorial | Auditor Interno | Administrador Sistema |
| ---------------------------------------- | ----------------: | -----------------: | ----------------: | -------------------: | --------------: | --------------------: |
| Acessar home pública                     |                 P |                  P |                 P |                    P |               P |                     P |
| Acessar listagem pública `/publicacoes`  |                 P |                  P |                 P |                    P |               P |                     P |
| Ler publicação pública publicada         |                 P |                  P |                 P |                    P |               P |                     P |
| Acessar `/painel/login`                  |                 P |                  P |                 P |                    P |               P |                     P |
| Acessar dashboard do painel              |                 N |                  P |                 P |                    P |               P |                     P |
| Ler listagem interna de publicações      |                 N |                  P |                 P |                    P |               C |                     P |
| Criar nova publicação                    |                 N |                  P |                 C |                    C |               N |                     P |
| Editar publicação                        |                 N |                  C |                 C |                    C |               N |                     P |
| Solicitar revisão                        |                 N |                  C |                 C |                    C |               N |                     P |
| Aprovar revisão para `ready_to_publish`  |                 N |                  N |                 P |                    P |               N |                     P |
| Rejeitar revisão e devolver para `draft` |                 N |                  N |                 P |                    P |               N |                     P |
| Abrir preview interno                    |                 N |                  C |                 P |                    P |               C |                     P |
| Publicar conteúdo apto                   |                 N |                  N |                 N |                    P |               N |                     P |
| Arquivar conteúdo publicado              |                 N |                  N |                 N |                    P |               N |                     P |
| Restaurar conteúdo para `draft`          |                 N |                  N |                 C |                    P |               N |                     P |
| Ler trilha auditável                     |                 N |                  N |                 N |                    C |               P |                     P |
| Acessar área administrativa sensível     |                 N |                  N |                 N |                    C |               C |                     P |

---

## 11.2 Leitura interpretativa da matriz

### Visitante Público

Pode consumir a camada pública, mas não possui qualquer permissão operacional interna.

### Operador Editorial

Pode iniciar e manter trabalho editorial, mas não governa a publicação final.

### Revisor Editorial

Pode intervir no ciclo de revisão e preparar o conteúdo para etapa final, sem publicar por padrão.

### Publicador Editorial

Pode atuar sobre a exposição pública do conteúdo e sobre estados críticos de circulação.

### Auditor Interno

Pode ler rastros e inspecionar governança, mas não opera conteúdo por padrão.

### Administrador do Sistema

Possui abrangência máxima, respeitando as invariantes e os contratos do sistema.

---

# 12. Matriz de transições editoriais por perfil

A matriz abaixo detalha o controle sobre as transições de estado editorial.

## 12.1 Legenda

* **P** = permitido
* **C** = permitido com contexto
* **N** = negado

| Transição editorial              | Operador Editorial | Revisor Editorial | Publicador Editorial | Auditor Interno | Administrador Sistema |
| -------------------------------- | -----------------: | ----------------: | -------------------: | --------------: | --------------------: |
| `null` → `draft`                 |                  P |                 C |                    C |               N |                     P |
| `draft` → `draft` (edição)       |                  C |                 C |                    C |               N |                     P |
| `draft` → `review`               |                  C |                 C |                    C |               N |                     P |
| `review` → `draft`               |                  N |                 P |                    P |               N |                     P |
| `review` → `ready_to_publish`    |                  N |                 P |                    P |               N |                     P |
| `ready_to_publish` → `published` |                  N |                 N |                    P |               N |                     P |
| `published` → `archived`         |                  N |                 N |                    P |               N |                     P |
| `published` → `draft`            |                  N |                 N |                    P |               N |                     P |
| `archived` → `draft`             |                  N |                 C |                    P |               N |                     P |
| `draft` → `published` direto     |                  N |                 N |                    N |               N |                     N |
| `review` → `published` direto    |                  N |                 N |                    N |               N |                     N |
| `archived` → `published` direto  |                  N |                 N |                    N |               N |                     N |

---

## 12.2 Regra soberana sobre atalhos proibidos

As seguintes transições são proibidas para todos os perfis, inclusive administrador, salvo criação futura de mecanismo extraordinário formal e auditado:

* `draft` → `published` direto
* `review` → `published` direto
* `archived` → `published` direto

A arquitetura do sistema exige que a publicação respeite o fluxo editorial soberano.

---

# 13. Regras ABAC complementares

RBAC sozinho não resolve o projeto.
As permissões acima precisam ser refinadas pelos seguintes atributos contextuais.

---

## 13.1 Atributo de autoria (`ownership`)

### Regra

Algumas permissões marcadas como **C** dependem de o usuário ser autor ou responsável direto pelo item.

### Exemplos

* `OPERADOR_EDITORIAL` pode editar conteúdo de sua responsabilidade, mas não necessariamente conteúdo de terceiros.
* `OPERADOR_EDITORIAL` pode solicitar revisão de item sob sua responsabilidade.
* `REVISOR_EDITORIAL` pode restaurar item arquivado para `draft` apenas se a política editorial permitir essa intervenção.

---

## 13.2 Atributo de estado do recurso (`resource_status`)

### Regra

A ação só é permitida se o estado atual do recurso for compatível com a transição.

### Exemplos

* não se publica item em `draft` se o fluxo exigir `ready_to_publish`;
* não se arquiva item que não está `published`;
* não se abre preview interno de recurso inexistente;
* não se devolve para `draft` um item que não comporta essa transição.

---

## 13.3 Atributo de sessão (`session_state`)

### Regra

Toda ação interna depende de:

* sessão válida;
* sessão não expirada;
* identidade resolvida;
* contexto de permissão íntegro.

### Consequência

Uma permissão RBAC positiva com sessão inválida resulta em negação operacional.

---

## 13.4 Atributo de existência do recurso (`resource_exists`)

### Regra

Não existe autorização útil sobre recurso inexistente.

### Consequência

A verificação de recurso precisa ocorrer antes da decisão final de ação executável.

---

## 13.5 Atributo de visibilidade (`resource_visibility`)

### Regra

Conteúdo não publicado não deve ser tratado como publicamente legível.

### Consequência

Mesmo um usuário que possa operar internamente o recurso não pode convertê-lo em legível público sem passar pela transição formal de publicação.

---

## 13.6 Atributo de necessidade de conhecimento (`need_to_know`)

### Regra

Leitura de auditoria, rastros e áreas sensíveis deve respeitar escopo mínimo de conhecimento necessário.

### Consequência

Mesmo quando um perfil possui `read_audit`, a consulta pode ser limitada por contexto, escopo ou sensibilidade.

---

## 13.7 Atributo de criticidade da ação (`action_criticality`)

### Regra

Ações como:

* publicar;
* arquivar;
* ler auditoria;
* acessar área sensível

devem ser tratadas como mais críticas que leitura comum de dashboard.

### Consequência

Essas ações podem exigir:

* contexto mais rigoroso;
* auditoria obrigatória;
* checagem reforçada;
* tratamento mais cuidadoso de erro e fallback.

---

## 13.8 Atributo de ambiente (`environment_scope`)

### Regra

Algumas ações administrativas sensíveis podem ser diferentes em:

* local;
* staging;
* produção.

### Consequência

A arquitetura admite refinamento futuro em que determinados comportamentos sejam mais restritos em produção, sem romper o modelo RBAC base.

---

# 14. Regras específicas por superfície

---

## 14.1 Site público

### Regra

O site público deve permitir livre navegação às rotas públicas aprovadas.

### Proibição

O site público não deve revelar:

* rotas internas protegidas;
* estados editoriais internos;
* existência de preview;
* detalhes de autorização.

---

## 14.2 Painel administrativo

### Regra

O painel deve:

* exigir autenticação;
* consumir autorização backend-first;
* refletir permissões em UI sem tratá-las como fonte soberana.

### Consequência

A interface pode:

* ocultar ações;
* desabilitar botões;
* redirecionar para acesso negado;
* impedir submit visual.

Mas o backend permanece responsável pela decisão definitiva.

---

## 14.3 API

### Regra

A API deve:

* autenticar;
* autorizar;
* validar;
* registrar;
* responder contratualmente.

### Consequência

A API precisa distinguir, no mínimo:

* `401` para ausência/invalidade de autenticação;
* `403` para falta de permissão;
* `404` para recurso inexistente;
* `409` para conflito de estado;
* resposta de sucesso apenas após checagem RBAC + ABAC + integridade.

---

# 15. Política de negação e resposta

## 15.1 Negação por ausência de autenticação

Quando a sessão é ausente, inválida ou expirada:

* negar;
* informar necessidade de login;
* não prosseguir com ação protegida.

## 15.2 Negação por falta de permissão

Quando há identidade, mas o papel não autoriza a ação:

* negar;
* informar limitação de acesso;
* registrar evento sensível quando couber.

## 15.3 Negação por contexto incompatível

Quando o papel permitiria em tese, mas o contexto não:

* negar por ABAC;
* informar conflito ou inadequação do estado;
* manter integridade do recurso.

## 15.4 Negação por transição proibida

Quando a ação viola a máquina de estados editorial:

* negar para todos os papéis;
* não mascarar com falso sucesso;
* registrar tentativa se crítica.

---

# 16. Regras de auditoria associadas à autorização

Devem gerar trilha auditável, no mínimo:

* login bem-sucedido;
* login rejeitado;
* logout;
* sessão expirada em ação protegida;
* acesso negado a recurso sensível;
* mudança de status editorial;
* publicação;
* arquivamento;
* leitura de trilha auditável, quando a criticidade justificar;
* tentativa de transição editorial proibida.

Campos mínimos recomendados:

* sujeito;
* perfil efetivo utilizado;
* recurso;
* ação;
* resultado;
* timestamp;
* contexto mínimo relevante.

---

# 17. Regras de UI derivadas da matriz

A matriz de permissão gera efeitos visuais e operacionais no frontend/admin.

---

## 17.1 Botões e ações devem refletir permissão

A interface deve:

* ocultar ação claramente indisponível, quando isso não prejudicar compreensão;
* ou desabilitar com clareza e contexto, quando o bloqueio precisar ser compreendido.

---

## 17.2 UI não pode prometer ação que o backend negará trivialmente

Sempre que possível, a tela deve refletir o estado de permissão já conhecido.

---

## 17.3 UI não substitui backend

Mesmo quando o botão aparece habilitado, a API ainda precisa decidir.

---

## 17.4 Acesso negado deve ser distinto de item inexistente

A experiência precisa diferenciar:

* “você não pode”;
* “isto não existe”;
* “isto existe, mas não está disponível neste estado”.

---

# 18. Recursos administrativos sensíveis

Embora nem todos estejam necessariamente expostos em UI no primeiro ciclo, o contrato já reserva a noção de recursos sensíveis, como:

* áreas avançadas de governança;
* trilhas auditáveis detalhadas;
* políticas internas de acesso;
* instrumentos de administração técnica.

### Regra

Esses recursos devem permanecer:

* negados por padrão;
* restritos a `ADMINISTRADOR_SISTEMA` e, quando apropriado, `AUDITOR_INTERNO` ou `PUBLICADOR_EDITORIAL` em contexto controlado.

### Observação

A existência conceitual desses recursos **não** obriga a existência imediata de tela específica no MVP.

---

# 19. Anti-padrões explicitamente proibidos

Este documento proíbe, de forma expressa:

## 19.1 Logou, então pode tudo

Autenticação não equivale a autorização.

## 19.2 Frontend decidindo soberanamente permissão

O cliente pode refletir, nunca soberanizar.

## 19.3 Ação crítica sem auditoria

Publicar, arquivar, negar acesso e ler trilha auditável sem rastro compromete governança.

## 19.4 Papel amplo demais sem necessidade

Perfil “faz tudo” enfraquece controle e leitura de responsabilidade.

## 19.5 Permissão sem estado

Não basta o papel permitir; o recurso precisa estar em estado compatível.

## 19.6 Tratar `404` e `403` como equivalentes em todo contexto

Recurso inexistente e acesso negado são problemas diferentes.

## 19.7 Admin como perfil acima da arquitetura

Administrador possui abrangência máxima, mas continua submetido aos contratos do sistema.

## 19.8 Exposição pública de estados internos

Draft, review, ready_to_publish e preview não pertencem à camada pública.

---

# 20. Relação deste documento com os próximos artefatos

Este documento prepara diretamente:

## `010_Dicionario_de_Dados_e_Catalogo_de_Entidades.md`

Porque usuários, perfis, publicações, status e rastros agora precisam de definição semântica precisa.

## `011_Matriz_de_Dependencias_entre_Bloco_e_Modulos.md`

Porque a autorização evidencia dependências formais entre auth, API, admin, dados e auditoria.

## `017_Procedimentos_de_QA_Manual.md`

Porque a matriz de permissões precisará ser validada por cenário e por perfil.

## `018_Cenarios_Fim_a_Fim_E2E.md`

Porque login, acesso negado, revisão, publicação e auditoria precisarão ser exercitados ponta a ponta.

---

# 21. Síntese executiva

A leitura executiva deste documento é:

* o sistema adota **negação por padrão**;
* a autorização é **backend-first**;
* RBAC fornece a base da decisão;
* ABAC refina a decisão por contexto;
* os perfis soberanos do projeto foram formalizados;
* os recursos e ações protegidos foram identificados;
* publicar, arquivar, revisar, editar e auditar são capacidades distintas;
* a camada pública permanece separada da camada interna;
* o administrador possui abrangência máxima, mas não poder absoluto contra as invariantes do sistema.

Em linguagem simples:

> no projeto William Albarello, acesso não é um detalhe de tela; é uma decisão arquitetural formal, baseada em papel, recurso, ação e contexto.

---

# 22. Conclusão

Se o documento anterior definiu como o sistema responde a falhas, este documento define como ele **decide permissão** antes, durante e depois das ações sensíveis.

Ele consolida oito mensagens principais:

1. **não basta logar;**
2. **negação por padrão é a base do sistema;**
3. **o backend é a fonte de verdade da autorização;**
4. **papel sem contexto não basta;**
5. **publicação, revisão, edição e auditoria precisam permanecer separadas;**
6. **admin não está acima da arquitetura;**
7. **ações críticas exigem rastro;**
8. **quem pode o quê precisa estar formalmente declarado.**

A mensagem final deste documento é:

> no projeto William Albarello, a maturidade da segurança e da governança dependerá da fidelidade com que RBAC e ABAC forem aplicados em conjunto, porque é essa combinação que impede permissões difusas, preserva o fluxo editorial, protege o painel e mantém a arquitetura coerente sob uso real.

---

