---

# `020_Ordem_Oficial_de_Geracao_do_Codigo.md`

**Endereço canônico:**
`/home/user/Documents/Softwares/Willian Albarello/William Albarello/01-Waterfall/02-Altamente_Relevantes/020_Ordem_Oficial_de_Geracao_do_Codigo.md`

**Status:**
Gerado no diálogo, em padrão copy/paste.

---

# 020_Ordem_Oficial_de_Geracao_do_Codigo

## 1. Identificação do documento

Este documento pertence ao diretório `01-Waterfall/02-Altamente_Relevantes` do projeto **William Albarello** e fecha logicamente o ciclo documental iniciado neste diretório, sucedendo os artefatos que já consolidaram:

* backlog estruturado;
* story map e sequência oficial de entrega;
* blueprint de telas, páginas e seções;
* design system e contratos de componentes;
* contratos de módulos;
* estados, eventos e transições;
* validações, mensagens, erros e fallbacks;
* matriz de permissões RBAC/ABAC;
* dicionário de dados;
* matriz de dependências;
* política de versionamento e compatibilidade;
* estratégia de observabilidade, performance e SEO;
* arquitetura operacional do painel;
* QA manual;
* cenários E2E;
* superprompts de geração por bloco.

Sua finalidade é consolidar a **ordem soberana de geração do código**, transformando todo o ciclo `02-Altamente_Relevantes` em **plano real de implementação**, com:

* precedência entre blocos;
* ordem de arquivos e camadas;
* critérios de entrada e saída;
* dependências;
* pontos de paralelização segura;
* critérios anti-retrabalho;
* condições de teste e homologação;
* fechamento metodológico do ciclo documental em direção à execução real.

Este documento deve ser lido como a resposta formal à pergunta:

> em que ordem o código do projeto William Albarello deve nascer para respeitar a arquitetura já consolidada, evitar retrabalho e transformar documentação em execução real?

---

## 2. Finalidade do documento

O objetivo deste documento é impedir que a implementação real do projeto aconteça por impulso local, conveniência momentânea ou sequência aleatória de arquivos.

Neste projeto, código não deve nascer em desordem.
Deve nascer em sequência arquitetural.

Sem uma ordem oficial de geração, o projeto corre o risco de:

* começar por telas sem contrato;
* gerar admin antes de auth;
* gerar público antes de semântica e SEO coerentes;
* gerar API antes do léxico de entidades;
* gerar dados sem política de estados e permissões;
* gerar QA tarde demais;
* corrigir depois o que já deveria nascer alinhado.

Este documento existe para:

* converter arquitetura em cronologia técnica;
* declarar precedências obrigatórias;
* distinguir scaffold de implementação madura;
* definir critérios de entrada e saída por bloco;
* orientar geração por superprompts;
* reduzir refação estrutural;
* encerrar o ciclo `02-Altamente_Relevantes` como plano de execução soberano.

Em linguagem direta:

* **código nasce em ordem**;
* **geração sem sequência produz retrabalho**;
* **o ciclo termina virando plano de execução**.

---

## 3. Insumos soberanos deste documento

Este documento deriva de todo o pacote-base do projeto e, especialmente, de:

### Base do projeto

* `00-Padrao`
* `01-Waterfall/01-Obrigatorios`
* `02-Diagramas/000–049`

### Ciclo atual

* `001` a `019` de `02-Altamente_Relevantes`

### Documentos mais diretamente decisivos para esta ordem

* `001_Backlog_Estruturado_por_Modulo.md`
* `002_Story_Map_e_Sequencia_Oficial_de_Entrega.md`
* `006_Contratos_de_Modulos.md`
* `010_Dicionario_de_Dados_e_Catalogo_de_Entidades.md`
* `011_Matriz_de_Dependencias_entre_Bloco_e_Modulos.md`
* `012_Politica_de_Versionamento_e_Compatibilidade.md`
* `016_Arquitetura_Operacional_do_Painel_Admin.md`
* `017_Procedimentos_de_QA_Manual.md`
* `018_Cenarios_Fim_a_Fim_E2E.md`
* `019_Superprompts_de_Geracao_por_Bloco.md`

---

## 4. Tese central

A tese central deste documento é:

> no projeto William Albarello, a geração do código deve seguir a ordem da dependência arquitetural, e não a ordem da vontade local de implementar.

Isso implica que:

* primeiro se consolida a base compartilhada;
* depois se consolida identidade, dados, estados, auth e contratos;
* só então se materializam API, público e admin de forma madura;
* depois se fecha SEO, observabilidade, QA e operação;
* e só ao final a solução pode ser tratada como bloco executável coerente.

---

## 5. Princípios constitucionais da ordem de geração

## 5.1 Toda camada nasce apoiada em outra já estabilizada

Não se deve gerar camada dependente sobre base ainda fluida.

## 5.2 A ordem é arquitetural, não estética

Tela bonita antes de contrato estável não é avanço maduro.

## 5.3 Primeiro o que funda, depois o que consome

Base, estados, dados, auth e API precedem superfícies dependentes.

## 5.4 Público e admin podem caminhar juntos só após base comum clara

Paralelização precoce sem contrato comum é ruído.

## 5.5 QA e E2E não são apêndices finais improvisados

Devem entrar quando os blocos já são testáveis, mas antes de qualquer conclusão séria.

## 5.6 SEO e descoberta dependem da existência pública correta

Não se fecha indexação antes de rotas, slugs, metadata e publicação estarem coerentes.

## 5.7 Observabilidade e rollback precisam nascer antes do “pronto”

Sistema sem leitura operacional não está pronto.

## 5.8 Todo bloco só avança para o próximo quando cumpre critério de saída

A ordem precisa ter portas de entrada e saída, não apenas intenção de sequência.

---

## 6. Estrutura da ordem oficial

A ordem soberana de geração do código será organizada em:

1. **Pré-fase de preparação**
2. **Onda A — Fundação compartilhada**
3. **Onda B — Domínio, dados, estados e segurança**
4. **Onda C — API soberana**
5. **Onda D — Frontend público**
6. **Onda E — Painel administrativo**
7. **Onda F — Publicação, descoberta e SEO**
8. **Onda G — Observabilidade, operação e hardening**
9. **Onda H — QA, E2E e fechamento operacional**

Cada onda possui:

* objetivo;
* critérios de entrada;
* ordem interna;
* critérios de saída;
* riscos de retrabalho se invertida.

---

# 7. Pré-fase de preparação

## 7.1 Objetivo

Garantir que a execução real comece com o projeto devidamente ancorado na documentação já consolidada.

## 7.2 O que deve estar pronto antes de qualquer geração de código madura

* ciclo `01-Obrigatorios` fechado logicamente;
* Diretório `02-Diagramas` fechado logicamente;
* ciclo `02-Altamente_Relevantes` fechado logicamente até `020`;
* superprompts soberanos disponíveis;
* distinção clara entre:

  * estado lógico do projeto;
  * estado físico do repositório/arquivos;
* topologia macro do projeto aprovada;
* definição do primeiro bloco real a ser implementado.

## 7.3 Critério de saída da pré-fase

A pré-fase é concluída quando:

* existe base documental suficiente para impedir geração improvisada;
* a ordem arquitetural já pode ser seguida como plano;
* a implementação deixa de depender de perguntas conceituais fundamentais.

---

# 8. Onda A — Fundação compartilhada

## 8.1 Objetivo

Criar a base técnica comum sobre a qual público, admin e API poderão nascer sem divergência estrutural.

## 8.2 Natureza da onda

Esta é a onda que prepara o “solo”:

* convenções;
* estrutura de pastas;
* base visual;
* base de ambiente;
* base de contratos compartilháveis.

## 8.3 Ordem interna da Onda A

### A.1 — Estrutura base do repositório/projeto

Gerar:

* organização inicial de diretórios;
* convenções de nomes;
* pontos de entrada gerais;
* separação explícita entre público, admin, API, dados e artefatos operacionais.

### A.2 — Tokens, design base e primitives compartilhadas

Gerar:

* tokens de cor, tipografia, espaçamento, container e estados;
* base visual compartilhada do projeto;
* elementos neutros reutilizáveis.

### A.3 — Casca estrutural do frontend

Gerar:

* shell conceitual do site público;
* shell conceitual do admin;
* sem lógica madura ainda, mas com estruturas estáveis.

### A.4 — Configuração mínima de ambiente e versionamento do projeto

Gerar:

* configuração por ambiente;
* base de build/deploy local/staging;
* leitura inicial de versionamento e compatibilidade.

## 8.4 Critérios de entrada da Onda A

* `003`, `004`, `005`, `011`, `012`, `019`, `020` consolidados;
* topologia macro aprovada.

## 8.5 Critérios de saída da Onda A

A Onda A é concluída quando:

* a base compartilhada existe;
* público e admin já têm linguagem comum;
* o projeto possui estrutura coerente para receber blocos reais;
* não há necessidade de reinventar foundation depois.

## 8.6 Risco de retrabalho se invertida

Se se tentar gerar API, público ou admin sem esta onda:

* haverá duplicação de padrões;
* naming inconsistente;
* refação de componentes base;
* desalinhamento entre superfícies.

---

# 9. Onda B — Domínio, dados, estados e segurança

## 9.1 Objetivo

Materializar a base semântica e operacional do sistema antes das camadas que a consomem diretamente.

## 9.2 Natureza da onda

Esta é a onda do núcleo duro:

* entidades;
* enums;
* status;
* sessão;
* permissões;
* invariantes do domínio.

## 9.3 Ordem interna da Onda B

### B.1 — Entidades soberanas e tipos de domínio

Gerar:

* `UsuarioInterno`
* `PerfilAcesso`
* `UsuarioPerfil`
* `SessaoAdministrativa`
* `Publicacao`
* `PublicacaoVersao`
* `HistoricoSlugPublicacao`
* `AuditoriaEvento`

### B.2 — Estados e enums do sistema

Gerar:

* enums de status editorial;
* enums de status de sessão;
* enums de eventos auditáveis;
* domínios finitos associados.

### B.3 — RBAC/ABAC base

Gerar:

* matriz aplicada;
* resolução de perfis;
* regras contextuais mínimas;
* negação por padrão.

### B.4 — Autenticação e sessão

Gerar:

* login;
* sessão válida;
* expiração;
* logout;
* guardas de proteção.

### B.5 — Contratos de transição editorial

Gerar:

* regras de `draft`, `review`, `ready_to_publish`, `published`, `archived`;
* transições válidas;
* transições proibidas.

## 9.4 Critérios de entrada da Onda B

* Onda A concluída;
* `006`, `007`, `009`, `010`, `011`, `012`, `019`, `020` consolidados.

## 9.5 Critérios de saída da Onda B

A Onda B é concluída quando:

* o sistema já sabe quem é quem;
* o sistema já sabe o que é uma publicação;
* o sistema já sabe o que é sessão;
* o sistema já sabe quem pode o quê;
* o sistema já sabe em quais estados o conteúdo vive.

## 9.6 Risco de retrabalho se invertida

Sem esta onda madura:

* API nasce sem léxico;
* admin promete ações indevidas;
* SEO não sabe o que é público;
* QA não sabe o que validar.

---

# 10. Onda C — API soberana

## 10.1 Objetivo

Criar a camada de aplicação que conecta dados, segurança, estados e consumidores internos/externos.

## 10.2 Natureza da onda

Esta é a onda onde o projeto deixa de ser apenas estrutura e passa a responder como sistema.

## 10.3 Ordem interna da Onda C

### C.1 — Contratos de entrada/saída

Gerar:

* payloads;
* respostas;
* contratos de erro;
* tipologia de validação.

### C.2 — Endpoints de auth

Gerar:

* login;
* logout;
* validação de sessão;
* tratamento de expiração.

### C.3 — Endpoints administrativos de publicação

Gerar:

* listagem interna;
* detalhe interno;
* criação;
* edição;
* preview;
* mudança de status;
* publicação;
* arquivamento;
* retorno a rascunho.

### C.4 — Endpoints públicos

Gerar:

* listagem pública;
* leitura pública por slug.

### C.5 — Logs estruturados, correlação e eventos operacionais mínimos

Gerar:

* request_id/correlation_id;
* nomenclatura de eventos principais;
* trilha mínima de ações sensíveis.

## 10.4 Critérios de entrada da Onda C

* Onda B concluída;
* `008`, `013`, `014`, `018`, `019`, `020` consolidados.

## 10.5 Critérios de saída da Onda C

A Onda C é concluída quando:

* login existe;
* listagem interna existe;
* criação e edição existem;
* leitura pública existe;
* publicar e arquivar existem;
* erros são tipificados;
* logs mínimos já são observáveis.

## 10.6 Risco de retrabalho se invertida

Gerar frontend real antes desta onda leva a:

* mocks permanentes;
* contratos frágeis;
* UI dependente de resposta improvisada;
* refação massiva de fluxo.

---

# 11. Onda D — Frontend público

## 11.1 Objetivo

Materializar a camada pública real do projeto em coerência com a API, os estados editoriais e a estratégia semântica.

## 11.2 Natureza da onda

Esta é a onda da presença pública executável:

* site institucional;
* listagem editorial;
* publicação por slug;
* páginas legais;
* navegação pública.

## 11.3 Ordem interna da Onda D

### D.1 — Header e footer públicos reais

Gerar:

* navegação pública;
* estrutura institucional base;
* rodapé coerente.

### D.2 — Home pública

Gerar:

* hero institucional;
* blocos de apresentação;
* ponte para conteúdo;
* fallbacks públicos.

### D.3 — Listagem pública `/publicacoes`

Gerar:

* rota;
* listagem;
* estado vazio;
* fallback de erro.

### D.4 — Publicação individual `/publicacoes/[slug]`

Gerar:

* cabeçalho editorial;
* corpo;
* comportamento para slug válido;
* 404/indisponibilidade coerente.

### D.5 — Páginas legais

Gerar:

* `/privacidade`
* `/termos`

## 11.4 Critérios de entrada da Onda D

* Onda A concluída;
* Onda C com endpoints públicos vivos;
* `003`, `004`, `005`, `008`, `014`, `015`, `019`, `020` consolidados.

## 11.5 Critérios de saída da Onda D

A Onda D é concluída quando:

* o domínio público já existe de forma real;
* home, listagem, publicação e páginas legais funcionam;
* conteúdo publicado pode ser lido publicamente;
* rotas inválidas respondem com coerência.

## 11.6 Paralelização segura nesta onda

A home e as páginas legais podem amadurecer antes da camada editorial completa, desde que:

* a integração com listagem/publicação real esteja claramente contratada;
* fallbacks não mintam.

## 11.7 Risco de retrabalho se invertida

Fazer SEO ou E2E público antes desta onda madura gera:

* semântica frágil;
* URLs inconsistentes;
* conteúdo público só aparente.

---

# 12. Onda E — Painel administrativo

## 12.1 Objetivo

Materializar o ambiente interno real de operação editorial e administrativa.

## 12.2 Natureza da onda

Esta é a onda do posto de comando:

* login;
* shell admin;
* dashboard;
* listagem interna;
* criação;
* edição;
* preview;
* ações editoriais.

## 12.3 Ordem interna da Onda E

### E.1 — Login administrativo real

Integrado a auth, com erro e expiração coerentes.

### E.2 — Shell do painel

Header, navegação, contexto do operador, logout e resiliência básica.

### E.3 — Dashboard

Resumo operacional mínimo e atalhos úteis.

### E.4 — Listagem interna de publicações

Tabela/lista, estados, ações por item.

### E.5 — Nova publicação

Formulário funcional com validação e persistência.

### E.6 — Edição de publicação

Carga de item, alteração e salvamento.

### E.7 — Preview interno

Visualização autorizada, não pública.

### E.8 — Ações editoriais

Solicitar revisão, aprovar, publicar, arquivar, retornar a rascunho, conforme perfis.

## 12.4 Critérios de entrada da Onda E

* Onda B concluída;
* Onda C com endpoints administrativos vivos;
* `016`, `019`, `020` consolidados.

## 12.5 Critérios de saída da Onda E

A Onda E é concluída quando:

* operador entra no painel;
* vê dashboard;
* lista publicações;
* cria e edita;
* abre preview;
* executa transições permitidas;
* recebe bloqueio correto quando não pode agir.

## 12.6 Paralelização segura nesta onda

Dashboard, listagem e formulários podem andar em paralelo depois que:

* auth já existe;
* shell admin já existe;
* endpoints administrativos básicos já existem.

## 12.7 Risco de retrabalho se invertida

Sem API, RBAC e estados maduros:

* o painel nasce como CRUD genérico;
* preview se confunde com público;
* publicação vira botão sem governança.

---

# 13. Onda F — Publicação, descoberta e SEO

## 13.1 Objetivo

Fechar a ligação entre fluxo editorial interno e camada pública descobrível.

## 13.2 Natureza da onda

Esta é a onda que transforma conteúdo publicado em conteúdo semanticamente existente no universo público.

## 13.3 Ordem interna da Onda F

### F.1 — Política real de slugs

Garantir geração, unicidade, persistência e histórico.

### F.2 — Metadata por tipo de página

Home, listagem, publicação, páginas legais.

### F.3 — Canonicalização

Canonicals públicas corretas por rota e por slug atual.

### F.4 — Sitemap

Listar apenas o universo público elegível.

### F.5 — Robots

Separar público e privado corretamente.

### F.6 — Efeito de publicação/arquivamento na camada pública

Garantir que:

* publicar torna o conteúdo elegível;
* arquivar o retira da camada pública corrente;
* preview nunca participa da descoberta.

## 13.4 Critérios de entrada da Onda F

* Onda C concluída;
* Onda D concluída;
* Onda E madura o suficiente para publicar/arquivar;
* `015`, `018`, `019`, `020` consolidados.

## 13.5 Critérios de saída da Onda F

A Onda F é concluída quando:

* publicação vira rota pública correta;
* metadata está coerente;
* canonical existe;
* sitemap reflete o universo público;
* robots protege o universo privado;
* arquivamento altera a camada pública corretamente.

## 13.6 Risco de retrabalho se invertida

Fazer isso antes de fluxo editorial real resultar em:

* sitemap descartável;
* canonical incoerente;
* indexação prematura;
* retrabalho semântico.

---

# 14. Onda G — Observabilidade, operação e hardening

## 14.1 Objetivo

Consolidar a legibilidade operacional do sistema e preparar sua sustentação em ambiente real.

## 14.2 Natureza da onda

Esta é a onda do endurecimento:

* logs;
* métricas;
* alertas;
* readiness;
* deploy;
* rollback;
* rastreabilidade.

## 14.3 Ordem interna da Onda G

### G.1 — Logs estruturados e correlação

Aplicar nomenclatura e contexto em:

* auth;
* API;
* ações editoriais;
* falhas críticas.

### G.2 — Audit trail mínimo

Garantir rastro de:

* login
* logout
* acesso negado
* criação
* edição
* mudança de status
* publicação
* arquivamento

### G.3 — Health e readiness

Definir sinais mínimos de saúde.

### G.4 — Estratégia de alertas e leitura de incidente

Consolidar observabilidade útil.

### G.5 — Pipeline, staging e rollback

Fechar entrega operacional disciplinada.

## 14.4 Critérios de entrada da Onda G

* Onda C viva;
* ondas D, E e F minimamente operacionais;
* `012`, `013`, `017`, `018`, `019`, `020` consolidados.

## 14.5 Critérios de saída da Onda G

A Onda G é concluída quando:

* o sistema já fala sobre si;
* falhas relevantes deixam contexto;
* ações sensíveis deixam rastro;
* existe caminho de deploy e rollback coerente;
* operação consegue ler incidente e não apenas sofrer incidente.

## 14.6 Risco de retrabalho se invertida

Se for deixada para “depois”:

* bugs ficam cegos;
* QA perde força;
* rollback vira ilusão;
* produção vira ambiente de descoberta caótica.

---

# 15. Onda H — QA, E2E e fechamento operacional

## 15.1 Objetivo

Provar que os fluxos existem de verdade, que a camada pública e privada estão coerentes, e que o sistema pode ser tratado como bloco funcional real.

## 15.2 Natureza da onda

Esta é a onda da prova:

* smoke;
* QA manual;
* E2E;
* critérios de aprovação;
* fechamento com ou sem ressalvas.

## 15.3 Ordem interna da Onda H

### H.1 — Smoke soberano

Público e admin vivos.

### H.2 — QA manual por superfície

* público
* admin
* sessão
* permissão
* SEO
* responsividade
* fallback

### H.3 — E2E por ondas

* acesso e segurança
* operação editorial
* governança editorial
* exposição pública e retirada
* fluxo soberano total

### H.4 — Classificação de falhas

Crítica, alta, média, baixa.

### H.5 — Fechamento de release

* aprovado
* aprovado com ressalvas
* reprovado

## 15.4 Critérios de entrada da Onda H

* Ondas C, D, E e F funcionalmente vivas;
* G minimamente presente;
* `017`, `018`, `019`, `020` consolidados.

## 15.5 Critérios de saída da Onda H

A Onda H é concluída quando:

* o sistema fecha fluxos reais;
* as falhas remanescentes estão classificadas;
* a aprovação ou reprovação tem evidência;
* o projeto pode avançar para ciclo de implementação madura ou correção dirigida.

## 15.6 Risco de retrabalho se invertida

Sem esta onda:

* “pronto” vira opinião;
* bugs críticos passam despercebidos;
* permissão, publicação e SEO podem estar quebrados sem prova visível.

---

# 16. Ordem soberana resumida de geração do código

A sequência oficial consolidada é:

## 16.1 Macroordem

1. Preparação
2. Fundação compartilhada
3. Domínio, dados, estados e segurança
4. API soberana
5. Frontend público
6. Painel administrativo
7. Publicação, descoberta e SEO
8. Observabilidade, operação e hardening
9. QA, E2E e fechamento

---

## 16.2 Ordem operacional direta

### Fase 0

* estrutura do projeto
* tokens e base compartilhada
* shells estruturais

### Fase 1

* entidades
* estados
* auth
* sessão
* permissões
* regras editoriais

### Fase 2

* contratos de API
* endpoints de auth
* endpoints administrativos
* endpoints públicos
* erro e validação

### Fase 3

* home pública
* listagem pública
* publicação individual
* páginas legais

### Fase 4

* login admin
* shell admin
* dashboard
* listagem interna
* criação
* edição
* preview
* ações editoriais

### Fase 5

* slug/histórico
* metadata
* canonical
* sitemap
* robots
* consistência de publicação/arquivamento

### Fase 6

* logs estruturados
* audit trail
* metrics/health
* deploy
* rollback
* operação

### Fase 7

* smoke
* QA manual
* E2E
* fechamento

---

# 17. Critérios de entrada e saída por bloco de geração

## 17.1 Regra geral de entrada

Um bloco só deve ser gerado de forma madura quando:

* sua base documental está consolidada;
* suas dependências arquiteturais mínimas já existem;
* seu superprompt soberano está claro;
* sua camada anterior já cumpriu critério de saída.

## 17.2 Regra geral de saída

Um bloco só deve ser tratado como concluído quando:

* cumpre seu papel arquitetural;
* não depende de suposição oculta para existir;
* responde coerentemente a seu conjunto mínimo de estados e erros;
* está pronto para ser consumido pela próxima camada;
* pode ser testado em seu nível.

---

# 18. Paralelização segura dentro da ordem oficial

## 18.1 Paralelos permitidos

### Público + Admin shell

Depois da Onda A.

### Auth + Dados base

Dentro da Onda B.

### API pública + API administrativa

Dentro da Onda C, desde que compartilhem o mesmo léxico.

### Home pública + páginas legais

Dentro da Onda D.

### Dashboard + listagem interna + formulário

Dentro da Onda E, após shell e auth.

### Metadata + sitemap + robots

Dentro da Onda F, após rotas públicas reais.

### Logs + audit trail + readiness

Dentro da Onda G, após endpoints e fluxos sensíveis existirem.

## 18.2 Paralelos proibidos ou perigosos

* SEO antes de publicação pública real
* painel antes de auth real
* API antes de entidades e estados
* E2E antes de fluxo vivo
* observabilidade plena antes de evento nomeado
* rollout final antes de rollback e readiness mínimos

---

# 19. Estratégia anti-retrabalho

## 19.1 Regra soberana

A melhor defesa contra retrabalho neste projeto é obedecer à ordem de geração.

---

## 19.2 Mecanismos explícitos anti-retrabalho

### Primeiro contrato, depois código

Usar sempre os documentos e superprompts do bloco.

### Primeiro base, depois consumo

Evitar gerar consumidor antes do fornecedor arquitetural.

### Primeiro bloco mínimo viável coerente, depois enriquecimento

Não inflar o bloco antes de cumprir sua função central.

### Primeiro output copy/paste estável, depois refinamento

A geração deve ser encaixável desde o início.

### Primeiro fluxo real, depois polimento

Priorizar fechamento do circuito sobre microacabamento precoce.

---

## 19.3 Perguntas obrigatórias antes de gerar qualquer bloco

1. Este bloco depende de qual documento soberano?
2. Este bloco depende de qual camada anterior?
3. O superprompt correto foi escolhido?
4. É arquivo completo ou patch?
5. O bloco já pode ser testado ao final?
6. Esta geração cria dívida se vier agora?

---

# 20. Matriz resumida de geração por bloco

## 20.1 Legenda

* **Antes** = deve existir antes
* **Depois** = blocos que dependem dele

| Bloco de código              | Antes                                    | Depois                       |
| ---------------------------- | ---------------------------------------- | ---------------------------- |
| Estrutura base / foundation  | documentação + ordem oficial             | tudo                         |
| Entidades e enums            | foundation                               | auth, API, SEO, admin        |
| Auth e sessão                | entidades + permissões                   | painel, guardas, E2E         |
| Permissões RBAC/ABAC         | entidades + auth base                    | painel, ações editoriais, QA |
| Estados editoriais           | entidades                                | API, admin, SEO, E2E         |
| API administrativa           | auth + entidades + estados               | painel                       |
| API pública                  | entidades + estados + slug               | público, SEO                 |
| Frontend público             | API pública + foundation                 | SEO, QA                      |
| Painel admin                 | auth + API administrativa + foundation   | workflow editorial, QA       |
| SEO/canonical/sitemap/robots | público + publicação real + slug         | QA, discoverability          |
| Observabilidade/audit trail  | API + auth + ações reais                 | incidente, QA, operação      |
| Deploy/rollback/readiness    | blocos executáveis mínimos               | staging/release              |
| QA manual                    | público + admin + fluxos vivos           | E2E, release                 |
| E2E                          | QA base + fluxos vivos + permissão + SEO | fechamento                   |

---

# 21. Anti-padrões explicitamente proibidos

Este documento proíbe, de forma expressa:

## 21.1 Gerar código em ordem de empolgação

Isso rompe a cadeia arquitetural.

## 21.2 Começar por telas finais sem base

Isso cria refação em cascata.

## 21.3 Tratar mock como fechamento de bloco

Mock é apoio, não conclusão.

## 21.4 Gerar admin antes de auth e RBAC

Isso compromete toda a governança interna.

## 21.5 Gerar SEO antes de publicação real

Isso produz descarte semântico.

## 21.6 Gerar API antes do léxico de dados e estados

Isso produz contratos frágeis e inconsistentes.

## 21.7 Deixar QA para o fim absoluto sem preparar testabilidade antes

Isso torna a correção mais cara.

## 21.8 Ignorar critérios de saída

Sem isso, a sequência vira só lista de desejos.

## 21.9 Misturar patch e arquivo completo sem clareza

Isso aumenta ruído e risco.

## 21.10 Saltar ondas porque “já dá para fazer”

Poder fazer não significa dever fazer agora.

---

# 22. Fechamento metodológico do ciclo 02-Altamente_Relevantes

## 22.1 O que este documento realiza

Este documento transforma o ciclo `02-Altamente_Relevantes` em:

* plano real de execução;
* cronologia arquitetural;
* defesa contra improviso;
* ponte entre documentação e código.

## 22.2 O que fica oficialmente consolidado ao final do ciclo

Fica consolidado que a implementação real do projeto William Albarello deve obedecer, em essência, à seguinte lógica:

* primeiro a base compartilhada;
* depois o núcleo de domínio, dados, segurança e estados;
* depois a API;
* depois as superfícies públicas e privadas;
* depois descoberta pública e camada semântica;
* depois observabilidade e operação;
* por fim QA, E2E e fechamento.

## 22.3 Próximo uso natural deste documento

Este documento deve ser usado como base soberana para:

* iniciar a geração real de código por ondas;
* escolher o superprompt correto por bloco;
* decidir se a próxima peça é arquivo completo ou patch;
* verificar se a geração pretendida está na ordem correta;
* produzir handoff seguro para o próximo chat/ciclo.

---

# 23. Síntese executiva

A leitura executiva deste documento é:

* o ciclo `02-Altamente_Relevantes` foi convertido em ordem real de implementação;
* a geração do código passou a ter precedência formal;
* fundação, domínio, auth, API, público, admin, SEO, observabilidade, operação e QA foram colocados em sequência soberana;
* critérios de entrada e saída foram reconhecidos;
* paralelização segura foi delimitada;
* retrabalho estrutural passou a ter defesa metodológica explícita;
* a arquitetura documental agora já pode virar execução sem reset conceitual.

Em linguagem simples:

> no projeto William Albarello, o código não deve mais nascer por impulso; deve nascer na ordem certa, sobre a base certa, para que cada bloco entre no projeto como continuação coerente e não como problema futuro.

---

# 24. Conclusão

Se o documento `019` definiu **como pedir bem a geração futura**, este documento define **em que ordem essa geração precisa acontecer para que o projeto continue íntegro**.

Ele consolida oito mensagens principais:

1. **código nasce em ordem;**
2. **a ordem correta é arquitetural, não emocional;**
3. **base compartilhada vem antes de consumo;**
4. **dados, estados, auth e permissões vêm antes de UI madura;**
5. **público e admin só amadurecem depois da API e do núcleo de domínio;**
6. **SEO, observabilidade e operação dependem do sistema vivo, não do mock;**
7. **QA e E2E são prova final, não decoração tardia;**
8. **o ciclo 02 termina virando plano soberano de execução.**

A mensagem final deste documento é:

> no projeto William Albarello, a qualidade da implementação real dependerá da disciplina com que a ordem soberana de geração do código for respeitada, porque é essa disciplina que transforma arquitetura em software vivo sem quebrar continuidade, sem misturar responsabilidades e sem desperdiçar esforço em retrabalho evitável.

---
