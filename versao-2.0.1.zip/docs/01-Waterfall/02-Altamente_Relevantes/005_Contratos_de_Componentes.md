
# `005_Contratos_de_Componentes.md`

**Endereço canônico:**
`/home/user/Documents/Softwares/Willian Albarello/William Albarello/01-Waterfall/02-Altamente_Relevantes/005_Contratos_de_Componentes.md`

**Status:**
Gerado no diálogo, em padrão copy/paste.

---

# 005_Contratos_de_Componentes

## 1. Identificação do documento

Este documento pertence ao diretório `01-Waterfall/02-Altamente_Relevantes` do projeto **William Albarello** e sucede logicamente os documentos:

* `003_Blueprint_de_Telas_Paginas_e_Secoes.md`
* `004_Design_System_Fundacional.md`

Sua finalidade é transformar a superfície mapeada no blueprint e os fundamentos estabelecidos no design system em **contratos formais de componentes reutilizáveis**, válidos para:

* frontend público institucional/editorial;
* painel administrativo interno;
* zonas compartilhadas entre público e admin.

Este documento deve ser lido como a resposta oficial à pergunta:

> quais componentes existem, para que servem, como se compõem, em que estados operam, onde podem ser usados e quais restrições precisam respeitar?

---

## 2. Finalidade do documento

O objetivo deste documento é impedir que a implementação do frontend seja conduzida com base em peças soltas, componentes improvisados ou variações arbitrárias.

Neste projeto, componente não é apenas um pedaço visual.
Componente é:

* contrato de uso;
* unidade de composição;
* portador de estado;
* superfície de acessibilidade;
* ponto de consistência do design system;
* mecanismo de redução de retrabalho.

Este documento existe para:

* definir os componentes centrais do sistema;
* explicitar finalidade, composição e limites;
* formalizar estados e variações;
* registrar dependências visuais e funcionais;
* orientar reuso seguro;
* evitar inflação desnecessária de primitives;
* preparar implementação e QA.

---

## 3. Insumos soberanos deste documento

Este documento deriva principalmente dos seguintes artefatos já consolidados:

### Ciclo atual

* `003_Blueprint_de_Telas_Paginas_e_Secoes.md`
* `004_Design_System_Fundacional.md`

### Waterfall obrigatório

* `W017` — UI/UX e Arquitetura da Informação
* `W018` — Plano de Testes, Homologação e Qualidade

### Diretório 02-Diagramas

* `D025–D031` — Frontend e jornadas

---

## 4. Tese central

A tese central deste documento é:

> no projeto William Albarello, componente é contrato, não peça avulsa.

Isso implica que todo componente relevante precisa ter, no mínimo:

* finalidade clara;
* composição identificável;
* props conceituais previsíveis;
* estados explícitos;
* variações controladas;
* critérios de acessibilidade;
* dependências conhecidas;
* restrições de uso;
* indicação objetiva de onde pode ou não pode aparecer.

Em linguagem direta:

* **componente é contrato**;
* **reuso com previsibilidade**;
* **estado explícito evita improviso**.

---

## 5. Regras constitucionais dos contratos de componente

## 5.1 Todo componente precisa justificar existência

Se ele não resolve uma função recorrente do sistema, não deve nascer como componente soberano.

## 5.2 Variação não é licença para caos

Toda variante precisa ser semanticamente necessária e visualmente coerente.

## 5.3 Estado faz parte do contrato

Não existe componente sério definido apenas no estado “bonito”.

## 5.4 Componente não substitui página

Ele resolve um papel local e compõe estruturas maiores.

## 5.5 Reuso não significa uso indiscriminado

Cada componente possui contexto de uso apropriado e restrições claras.

## 5.6 Acessibilidade é parte do contrato

Foco, teclado, semântica e contraste não são anexos posteriores.

## 5.7 Público e admin compartilham base, não confusão

Alguns componentes são comuns; outros pertencem claramente a um dos contextos.

---

## 6. Estrutura padrão de leitura de cada contrato

Cada componente deste documento será descrito pelos seguintes campos:

* **Finalidade**
* **Composição**
* **Props conceituais**
* **Estados**
* **Variações**
* **Acessibilidade**
* **Dependências**
* **Uso previsto**
* **Restrições de uso**

---

## 7. Classificação geral dos componentes do sistema

Para fins metodológicos, os componentes serão organizados nas seguintes famílias:

1. Componentes estruturais compartilhados
2. Componentes de navegação pública
3. Componentes editoriais públicos
4. Componentes de feedback e estado
5. Componentes de formulário e ação
6. Componentes operacionais do admin
7. Componentes de layout e composição

---

# 8. Componentes estruturais compartilhados

---

## 8.1 `AppShellPublic`

### Finalidade

Estruturar páginas públicas com header, área principal e footer, preservando consistência entre home, listagens, publicações e páginas legais.

### Composição

* `HeaderPublic`
* `MainContainer`
* `FooterPublic`

### Props conceituais

* `pageKind` — institucional, editorial, legal, sistema
* `hasHero` — indica presença de hero ou não
* `containerMode` — padrão, estreito, amplo
* `seoContext` — contexto semântico da página

### Estados

* padrão
* carregando conteúdo interno
* com erro localizado na área principal

### Variações

* institucional
* editorial
* legal
* sistema

### Acessibilidade

* landmark semântico
* ordem lógica de leitura
* header e footer navegáveis por teclado

### Dependências

* grid
* tokens de espaçamento
* `HeaderPublic`
* `FooterPublic`

### Uso previsto

* `/`
* `/publicacoes`
* `/publicacoes/[slug]`
* `/privacidade`
* `/termos`
* `/404`

### Restrições de uso

* não deve ser usado no painel
* não deve assumir sidebar administrativa
* não deve carregar responsabilidades editoriais internas

---

## 8.2 `AppShellAdmin`

### Finalidade

Estruturar telas internas do painel com barra superior, navegação administrativa e área operacional.

### Composição

* `HeaderAdmin`
* `SidebarAdmin` ou `NavAdmin`
* `MainAdminContainer`

### Props conceituais

* `currentArea`
* `operatorContext`
* `layoutDensity`
* `hasSidebar`

### Estados

* carregando sessão
* autenticado
* sessão expirada
* acesso negado

### Variações

* dashboard
* listagem
* formulário
* preview
* sistema interno

### Acessibilidade

* landmarks semânticos do admin
* foco previsível entre header, navegação e conteúdo
* leitura coerente por teclado

### Dependências

* autenticação
* sessão
* permissão
* tokens do admin

### Uso previsto

* `/painel`
* `/painel/publicacoes`
* `/painel/publicacoes/nova`
* `/painel/publicacoes/[id]/editar`
* `/painel/publicacoes/[id]/preview`
* `/painel/acesso-negado`

### Restrições de uso

* não deve ser usado em tela pública
* não deve depender de conteúdo editorial público para funcionar

---

## 8.3 `SectionBlock`

### Finalidade

Servir como primitive de seção para páginas públicas, organizando ritmo vertical, agrupamento de conteúdo e largura útil.

### Composição

* wrapper semântico
* heading opcional
* área de conteúdo

### Props conceituais

* `tone` — neutro, destaque, apoio
* `spacingSize`
* `backgroundMode`
* `containerMode`
* `sectionTitle`

### Estados

* padrão
* vazio controlado
* carregando conteúdo dinâmico

### Variações

* institucional
* editorial
* legal
* sistema

### Acessibilidade

* heading semântico quando houver título
* hierarquia coerente com a página

### Dependências

* grid
* spacing scale
* tipografia

### Uso previsto

* home
* listagens públicas
* páginas legais
* blocos auxiliares de páginas institucionais

### Restrições de uso

* não deve ser usado como substituto de componente de card
* não deve conter lógica operacional complexa por si só

---

# 9. Componentes de navegação pública

---

## 9.1 `HeaderPublic`

### Finalidade

Fornecer identidade pública, navegação principal e ponto de orientação global do site.

### Composição

* marca
* nav principal
* trigger mobile, se necessário
* ações contextuais, se aprovadas

### Props conceituais

* `activeRoute`
* `isSticky`
* `menuMode`
* `brandMode`

### Estados

* padrão
* hover nos itens
* menu aberto/fechado
* foco de teclado
* responsivo

### Variações

* padrão institucional
* simplificado
* sobre hero, se aplicável

### Acessibilidade

* navegação por teclado
* indicação do item ativo
* contraste adequado
* trigger mobile acessível

### Dependências

* tipografia
* tokens de cor
* `NavLink`
* responsividade

### Uso previsto

* todas as rotas públicas

### Restrições de uso

* não deve conter ações internas do painel
* não deve virar centro de excesso de CTA

---

## 9.2 `FooterPublic`

### Finalidade

Encerrar a navegação pública com links permanentes, identidade mínima e estrutura legal.

### Composição

* bloco institucional resumido
* links estruturais
* links legais
* copyright

### Props conceituais

* `linkGroups`
* `legalLinks`
* `brandSummary`
* `footerMode`

### Estados

* padrão
* responsivo

### Variações

* completo
* compacto

### Acessibilidade

* links claros
* ordem de leitura coerente
* contraste suficiente

### Dependências

* mapa de rotas
* páginas legais
* tipografia
* spacing scale

### Uso previsto

* todas as rotas públicas

### Restrições de uso

* não deve ser usado no painel
* não deve concentrar conteúdo que pertença ao corpo principal da página

---

## 9.3 `NavLink`

### Finalidade

Representar item unitário de navegação pública ou administrativa, com estado ativo claro.

### Composição

* texto do link
* estado ativo
* ícone opcional

### Props conceituais

* `label`
* `href`
* `isActive`
* `icon`
* `tone`

### Estados

* default
* hover
* focus
* active
* disabled, quando aplicável

### Variações

* público
* admin
* inline editorial

### Acessibilidade

* foco visível
* texto claro
* não depender só de cor para ativo

### Dependências

* tokens de tipografia
* tokens de cor
* estado de rota atual

### Uso previsto

* header público
* navegação do painel
* links auxiliares

### Restrições de uso

* não substituir botão quando a ação não for navegação
* não conter ícone sem rótulo em contextos críticos

---

# 10. Componentes editoriais públicos

---

## 10.1 `HeroInstitutional`

### Finalidade

Concentrar a mensagem principal da home, com posição institucional clara e CTA orientador.

### Composição

* título principal
* subtítulo
* CTA principal
* CTA secundário opcional
* bloco de apoio opcional

### Props conceituais

* `headline`
* `subheadline`
* `primaryAction`
* `secondaryAction`
* `tone`
* `alignment`

### Estados

* padrão
* sem CTA secundário
* responsivo
* com conteúdo reduzido

### Variações

* institucional
* institucional com ponte editorial

### Acessibilidade

* heading principal claro
* CTA com rótulo objetivo
* estrutura semântica estável

### Dependências

* tipografia de destaque
* spacing
* `Button`
* layout público

### Uso previsto

* página inicial

### Restrições de uso

* não deve ser reaproveitado em telas operacionais do admin
* não deve ser inflado com elementos ornamentais sem função

---

## 10.2 `PublicationCard`

### Finalidade

Representar uma publicação em listagens, destaques e pontes editoriais.

### Composição

* título
* resumo
* metadado opcional
* link para leitura

### Props conceituais

* `title`
* `excerpt`
* `slug`
* `statusPublicVisibility`
* `meta`
* `size`

### Estados

* padrão
* hover
* focus
* sem metadados
* skeleton/loading

### Variações

* destaque
* listagem padrão
* compacto

### Acessibilidade

* título clicável claro
* ordem de leitura coerente
* contraste adequado
* área de clique suficiente

### Dependências

* dados de publicação
* tipografia editorial
* `NavLink` ou wrapper de rota

### Uso previsto

* `/publicacoes`
* home, em bloco de destaques editoriais

### Restrições de uso

* não deve exibir conteúdo não publicado
* não deve carregar excesso de metadata que roube foco do conteúdo

---

## 10.3 `PublicationList`

### Finalidade

Orquestrar a exibição de múltiplas publicações públicas.

### Composição

* lista ou grid de `PublicationCard`
* estado vazio
* loading state
* paginação ou continuidade

### Props conceituais

* `items`
* `layoutMode`
* `loading`
* `emptyState`
* `pagination`

### Estados

* loading
* com itens
* vazio
* erro parcial

### Variações

* grid
* lista vertical
* destaque resumido na home

### Acessibilidade

* sequência navegável
* heading contextual na área
* paginação acessível

### Dependências

* `PublicationCard`
* `EmptyState`
* `Pagination`
* API pública

### Uso previsto

* `/publicacoes`
* seções editoriais da home

### Restrições de uso

* não deve ser usado para listagem operacional interna
* não deve misturar itens públicos e administrativos

---

## 10.4 `PublicationHeader`

### Finalidade

Apresentar o topo semântico da página de publicação individual.

### Composição

* título
* resumo/subtítulo opcional
* metadata essencial opcional
* breadcrumb opcional

### Props conceituais

* `title`
* `summary`
* `meta`
* `breadcrumbs`
* `readingMode`

### Estados

* padrão
* sem resumo
* sem meta
* carregando skeleton

### Variações

* simples
* enriquecido

### Acessibilidade

* heading principal da página
* metadados em ordem semântica
* breadcrumb acessível, se houver

### Dependências

* tipografia editorial
* spacing
* estrutura da página de publicação

### Uso previsto

* `/publicacoes/[slug]`

### Restrições de uso

* não deve ser usado como cabeçalho de listagem
* não deve competir com o corpo do texto

---

## 10.5 `RichTextContent`

### Finalidade

Renderizar o corpo da publicação com hierarquia tipográfica, legibilidade e semântica.

### Composição

* headings
* parágrafos
* listas
* links
* citações, se aprovadas no conteúdo

### Props conceituais

* `content`
* `readingWidth`
* `contentMode`
* `linkBehavior`

### Estados

* padrão
* loading
* conteúdo vazio inválido
* erro de renderização

### Variações

* editorial
* legal

### Acessibilidade

* semântica HTML correta
* headings hierárquicos
* links compreensíveis
* contraste e line-height adequados

### Dependências

* tipografia
* largura de leitura
* dados editoriais

### Uso previsto

* página de publicação
* páginas legais

### Restrições de uso

* não deve ser usado para formulário
* não deve receber conteúdo sem sanitização/coerência de origem

---

# 11. Componentes de feedback e estado

---

## 11.1 `EmptyState`

### Finalidade

Responder a ausência de conteúdo, resultado ou itens de forma clara e útil.

### Composição

* título curto
* descrição
* ação opcional
* ícone opcional

### Props conceituais

* `title`
* `description`
* `action`
* `tone`
* `context`

### Estados

* padrão
* com ação
* sem ação

### Variações

* editorial público
* listagem admin
* busca sem resultado
* sistema

### Acessibilidade

* mensagem textual explícita
* CTA navegável por teclado
* não depender só de ícone

### Dependências

* tipografia
* `Button`
* tokens de estado

### Uso previsto

* listagens vazias
* dashboards sem conteúdo
* áreas sem resultados

### Restrições de uso

* não deve substituir tratamento de erro
* não deve mascarar falha técnica real

---

## 11.2 `ErrorState`

### Finalidade

Comunicar falhas de carregamento, leitura ou operação com clareza.

### Composição

* título
* descrição
* ação de retry ou retorno
* detalhe técnico opcional não exposto ao público geral

### Props conceituais

* `title`
* `description`
* `action`
* `severity`
* `context`

### Estados

* padrão
* com retry
* sem retry

### Variações

* público
* admin
* inline em bloco
* página inteira

### Acessibilidade

* mensagem textual clara
* ação acessível
* cor de erro não ser único indicador

### Dependências

* tokens de estado
* `Button`
* contexto operacional

### Uso previsto

* falha de listagem
* falha de submissão
* falha de leitura de publicação
* falha de dashboard

### Restrições de uso

* não usar para validação de campo individual
* não transformar todo erro em tela cheia sem necessidade

---

## 11.3 `StatusBadge`

### Finalidade

Representar estados compactos de conteúdo, operação ou permissão.

### Composição

* rótulo curto
* cor de estado
* ícone opcional

### Props conceituais

* `status`
* `tone`
* `size`
* `icon`

### Estados

* padrão
* foco, quando clicável
* disabled, se interativo

### Variações

* `draft`
* `published`
* `archived`
* `success`
* `warning`
* `error`
* `info`

### Acessibilidade

* rótulo textual obrigatório
* contraste adequado
* não depender só de cor

### Dependências

* design tokens de estado
* tipografia de label

### Uso previsto

* listagens admin
* cabeçalhos editoriais internos
* resumos operacionais

### Restrições de uso

* não usar badge para substituir explicação complexa
* não inflar páginas públicas com excesso de badges

---

## 11.4 `LoadingBlock`

### Finalidade

Representar carregamento em áreas localizadas sem quebrar layout.

### Composição

* skeleton lines
* blocos de placeholder
* área reservada

### Props conceituais

* `shape`
* `density`
* `context`
* `size`

### Estados

* ativo
* oculto após carregamento

### Variações

* card
* listagem
* formulário
* header editorial

### Acessibilidade

* indicar carregamento sem poluir leitura
* ocultação adequada quando conteúdo real chega

### Dependências

* spacing
* tokens de superfície
* layout do contexto

### Uso previsto

* listagens públicas
* listagens admin
* dashboard
* formulário em preload

### Restrições de uso

* não substituir loading global quando a navegação inteira depende disso
* não permanecer visível sem timeout/controle

---

# 12. Componentes de formulário e ação

---

## 12.1 `Button`

### Finalidade

Materializar ações do sistema com hierarquia previsível.

### Composição

* label
* ícone opcional
* container clicável

### Props conceituais

* `variant`
* `size`
* `label`
* `icon`
* `loading`
* `disabled`
* `destructive`

### Estados

* default
* hover
* active
* focus
* disabled
* loading

### Variações

* primário
* secundário
* terciário/ghost
* destrutivo

### Acessibilidade

* rótulo explícito
* foco visível
* área de toque adequada
* loading comunicado sem ambiguidade

### Dependências

* tokens de cor
* tipografia
* estados de interação

### Uso previsto

* CTAs públicos
* login
* salvar publicação
* cancelar
* publicar
* retry

### Restrições de uso

* não usar botão para navegação simples quando link resolve melhor
* não ter múltiplos primários concorrentes sem justificativa

---

## 12.2 `TextField`

### Finalidade

Capturar entradas curtas e objetivas em formulários.

### Composição

* label
* input
* helper text opcional
* error message

### Props conceituais

* `label`
* `name`
* `value`
* `placeholder`
* `required`
* `disabled`
* `error`
* `helperText`

### Estados

* default
* focus
* filled
* invalid
* disabled
* loading contextual, se houver

### Variações

* texto simples
* slug
* senha
* busca

### Acessibilidade

* label associado
* erro legível
* não depender só de placeholder
* teclado e autofill coerentes

### Dependências

* tipografia
* tokens de borda/estado
* sistema de validação

### Uso previsto

* login
* título
* slug
* busca no admin, quando aprovada

### Restrições de uso

* não usar para conteúdo longo
* não esconder label real

---

## 12.3 `TextareaField`

### Finalidade

Capturar conteúdo médio ou longo, especialmente resumo e corpo inicial.

### Composição

* label
* textarea
* helper text
* error message

### Props conceituais

* `label`
* `name`
* `value`
* `rows`
* `required`
* `error`
* `helperText`

### Estados

* default
* focus
* invalid
* disabled

### Variações

* resumo
* corpo curto
* observação interna, se futuramente aprovada

### Acessibilidade

* label claro
* erro visível
* contraste adequado
* foco perceptível

### Dependências

* spacing
* tokens de formulário
* validação

### Uso previsto

* resumo
* corpo de publicação

### Restrições de uso

* não usar como editor rico avançado sem política própria
* não quebrar largura de leitura com resize descontrolado, se isso afetar UX

---

## 12.4 `SelectField`

### Finalidade

Permitir escolha entre opções discretas de estado ou contexto.

### Composição

* label
* trigger/select
* lista de opções
* helper/error

### Props conceituais

* `label`
* `name`
* `options`
* `value`
* `placeholder`
* `disabled`
* `error`

### Estados

* default
* open
* selected
* invalid
* disabled

### Variações

* status editorial
* filtro
* ordenação, se aprovada

### Acessibilidade

* navegação por teclado
* opção selecionada clara
* foco visível
* rótulo associado

### Dependências

* formulário
* opções de domínio
* tokens de estado

### Uso previsto

* status da publicação
* filtros internos

### Restrições de uso

* não usar quando rádio ou botões forem semanticamente melhores
* não esconder estado atual do item

---

## 12.5 `FormActions`

### Finalidade

Agrupar ações principais e secundárias de um formulário com hierarquia clara.

### Composição

* botão primário
* botão secundário
* ação terciária opcional

### Props conceituais

* `primaryAction`
* `secondaryAction`
* `destructiveAction`
* `layoutMode`

### Estados

* padrão
* loading da ação principal
* ação desabilitada

### Variações

* criação
* edição
* login
* confirmação

### Acessibilidade

* ordem de foco coerente
* hierarquia legível
* labels de ação claros

### Dependências

* `Button`
* spacing
* contexto do formulário

### Uso previsto

* login
* nova publicação
* editar publicação

### Restrições de uso

* não usar mais de uma ação primária equivalente sem necessidade
* não misturar ação destrutiva com salvar sem separação clara

---

# 13. Componentes operacionais do admin

---

## 13.1 `HeaderAdmin`

### Finalidade

Identificar o ambiente interno e oferecer contexto do operador.

### Composição

* título/identificação do painel
* contexto da área
* bloco do usuário
* logout

### Props conceituais

* `currentArea`
* `operatorName`
* `showLogout`
* `compact`

### Estados

* autenticado
* carregando sessão
* sessão expirada

### Variações

* completo
* compacto

### Acessibilidade

* landmarks claros
* logout acessível
* ordem de foco coerente

### Dependências

* autenticação
* sessão
* `Button`/link de sair

### Uso previsto

* todas as telas internas autenticadas

### Restrições de uso

* não usar em `/painel/login`
* não acumular excesso de indicadores secundários

---

## 13.2 `SidebarAdmin`

### Finalidade

Organizar a navegação principal do painel.

### Composição

* grupo de links internos
* item ativo
* permissões contextuais

### Props conceituais

* `items`
* `activeItem`
* `collapsed`
* `permissionContext`

### Estados

* padrão
* item ativo
* item indisponível
* collapsed/expanded

### Variações

* completa
* compacta
* mobile drawer, se adotado

### Acessibilidade

* navegação por teclado
* item atual identificado
* ícone não substituir texto

### Dependências

* `NavLink`
* autenticação
* RBAC

### Uso previsto

* telas internas autenticadas

### Restrições de uso

* não usar em páginas públicas
* não exibir itens que o perfil não pode acessar apenas “desabilitados” sem critério claro

---

## 13.3 `PageHeaderAdmin`

### Finalidade

Introduzir a área operacional atual e organizar contexto e ação principal da tela.

### Composição

* título
* descrição curta opcional
* ação principal
* ações auxiliares opcionais

### Props conceituais

* `title`
* `description`
* `primaryAction`
* `secondaryActions`
* `breadcrumbs`, se adotado

### Estados

* padrão
* sem descrição
* com ação
* sem ação

### Variações

* dashboard
* listagem
* formulário
* preview

### Acessibilidade

* heading claro
* ação principal navegável
* descrição legível

### Dependências

* tipografia
* `Button`
* layout admin

### Uso previsto

* dashboard
* listagem de publicações
* nova publicação
* edição
* preview

### Restrições de uso

* não substituir o header global do painel
* não acumular CTAs demais

---

## 13.4 `PublicationTable`

### Finalidade

Representar o acervo editorial interno em leitura operacional compacta.

### Composição

* cabeçalho de colunas
* linhas
* células de título, status, slug, atualização, ações
* paginação opcional

### Props conceituais

* `items`
* `columns`
* `sort`
* `pagination`
* `emptyState`

### Estados

* loading
* com itens
* vazio
* erro de carregamento

### Variações

* tabela completa
* lista compacta
* mobile list

### Acessibilidade

* cabeçalhos claros
* leitura navegável
* ações identificáveis
* estado vazio textual

### Dependências

* dados administrativos
* `StatusBadge`
* `RowActions`
* API admin

### Uso previsto

* `/painel/publicacoes`

### Restrições de uso

* não usar no público
* não depender de largura de desktop para ser minimamente funcional

---

## 13.5 `RowActions`

### Finalidade

Agrupar ações contextuais por item de listagem sem poluir a tabela.

### Composição

* editar
* preview
* ações adicionais permitidas

### Props conceituais

* `itemId`
* `permissions`
* `availableActions`
* `compact`

### Estados

* padrão
* hover
* focus
* action loading
* action disabled

### Variações

* inline
* menu contextual, se adotado

### Acessibilidade

* rótulos claros
* teclado navegável
* não depender só de ícones

### Dependências

* permissão
* `Button`/links
* dados do item

### Uso previsto

* listagem administrativa

### Restrições de uso

* não concentrar ações destrutivas sem separação
* não esconder ação principal a ponto de prejudicar operação

---

## 13.6 `DashboardMetricCard`

### Finalidade

Exibir resumo operacional simples no dashboard do painel.

### Composição

* rótulo
* valor
* indicador opcional
* link contextual opcional

### Props conceituais

* `label`
* `value`
* `statusTone`
* `href`
* `icon`

### Estados

* loading
* com dado
* vazio
* erro parcial

### Variações

* neutro
* destaque
* status

### Acessibilidade

* valor legível
* rótulo explícito
* contraste adequado

### Dependências

* dados do dashboard
* tokens de superfície
* tipografia

### Uso previsto

* `/painel`

### Restrições de uso

* não virar painel analítico excessivo no primeiro ciclo
* não disputar com ações centrais da tela

---

## 13.7 `PreviewFrame`

### Finalidade

Exibir o preview interno da publicação em contexto controlado.

### Composição

* barra de contexto do preview
* conteúdo renderizado
* ações de retorno/edição/publicação

### Props conceituais

* `publication`
* `status`
* `actions`
* `previewMode`

### Estados

* loading
* preview disponível
* sem permissão
* erro de renderização
* item não encontrado

### Variações

* simples
* com barra operacional reforçada

### Acessibilidade

* rótulo explícito de preview interno
* ações acessíveis
* sem confusão com página pública indexável

### Dependências

* API admin
* renderização editorial
* autenticação
* permissão

### Uso previsto

* `/painel/publicacoes/[id]/preview`

### Restrições de uso

* não servir conteúdo público diretamente por esta estrutura
* não ser indexável
* não mascarar ausência de status válido

---

# 14. Componentes de layout e composição

---

## 14.1 `MainContainer`

### Finalidade

Controlar largura útil, alinhamento e respiro de áreas principais.

### Composição

* wrapper/container semântico

### Props conceituais

* `size`
* `align`
* `readingMode`

### Estados

* padrão

### Variações

* estreito
* padrão
* amplo
* admin

### Acessibilidade

* semântica apropriada ao contexto

### Dependências

* tokens de container
* grid

### Uso previsto

* páginas públicas
* áreas centrais do admin

### Restrições de uso

* não carregar semântica de seção por conta própria

---

## 14.2 `ContentStack`

### Finalidade

Organizar blocos verticais com ritmo consistente.

### Composição

* wrapper vertical
* espaçamento controlado entre filhos

### Props conceituais

* `gap`
* `density`
* `align`

### Estados

* padrão

### Variações

* confortável
* compacto
* editorial

### Acessibilidade

* manter ordem semântica dos filhos

### Dependências

* spacing tokens

### Uso previsto

* formulários
* seções públicas
* áreas administrativas

### Restrições de uso

* não substituir grid quando relação horizontal for central

---

## 14.3 `InlineActions`

### Finalidade

Agrupar ações pequenas ou contextuais em linha.

### Composição

* links
* botões secundários
* divisores opcionais

### Props conceituais

* `actions`
* `alignment`
* `density`

### Estados

* padrão
* responsivo

### Variações

* pública
* admin
* editorial

### Acessibilidade

* foco claro
* separação perceptível
* labels compreensíveis

### Dependências

* `Button`
* `NavLink`
* spacing

### Uso previsto

* retorno da publicação
* cabeçalhos internos
* áreas de ação secundária

### Restrições de uso

* não substituir bloco de ação principal de formulário
* não concentrar ações destrutivas importantes sem destaque

---

## 14.4 `Pagination`

### Finalidade

Permitir continuidade navegável em listas extensas.

### Composição

* anterior
* próximo
* números ou resumo contextual

### Props conceituais

* `currentPage`
* `totalPages`
* `onNavigate`
* `mode`

### Estados

* padrão
* disabled em limites
* loading contextual

### Variações

* numérica
* simples anterior/próximo
* carregar mais, se aprovado

### Acessibilidade

* labels claros
* indicação da página atual
* foco visível

### Dependências

* listagens
* API pública/admin

### Uso previsto

* `/publicacoes`
* `/painel/publicacoes`, se necessário

### Restrições de uso

* não usar quando o volume de itens não justifica
* não criar paginação incoerente entre público e admin sem necessidade real

---

# 15. Props conceituais transversais

Para preservar coerência, os contratos de componente devem privilegiar props conceituais e semânticas, não props acidentais demais.

As famílias transversais mais aceitáveis neste projeto são:

* `variant`
* `size`
* `tone`
* `status`
* `loading`
* `disabled`
* `error`
* `emptyState`
* `context`
* `permissions`
* `layoutMode`
* `containerMode`

Devem ser evitadas props excessivamente frágeis ou acidentais, como:

* ajustes visuais pontuais que quebrem tokens;
* múltiplos booleans conflitantes;
* flags visuais sem semântica clara;
* override de cor, tamanho ou espaçamento fora do design system.

---

# 16. Regras de acessibilidade comuns aos componentes

Todos os componentes interativos deste sistema devem respeitar, no mínimo, as seguintes regras:

* foco visível;
* rótulo claro;
* contraste adequado;
* área clicável/toque suficiente;
* dependência de cor evitada como único indicador;
* navegação por teclado coerente;
* semântica compatível com a função;
* mensagens de erro textualizadas;
* estados disabled, loading e active distinguíveis.

---

# 17. Regras de dependência entre componentes

## 17.1 Componentes estruturais podem compor componentes menores

Ex.: `AppShellAdmin` compõe `HeaderAdmin`, `SidebarAdmin` e `MainContainer`.

## 17.2 Componentes de domínio devem depender de primitives estáveis

Ex.: `PublicationCard` deve depender de tokens, tipografia e containers compartilhados, não reinventá-los.

## 17.3 Componentes operacionais não devem vazar para o público

Ex.: `PublicationTable`, `RowActions`, `DashboardMetricCard`.

## 17.4 Componentes editoriais públicos não devem carregar lógica interna do admin

Ex.: `PublicationHeader`, `RichTextContent`, `PublicationList`.

## 17.5 Estados e feedbacks devem ser compartilháveis quando semântica coincidir

Ex.: `ErrorState`, `EmptyState`, `StatusBadge`, `LoadingBlock`.

---

# 18. Anti-padrões proibidos

Este documento proíbe implicitamente os seguintes erros:

## 18.1 Criar componente para ocorrência única sem recorrência real

Nem toda marcação vira componente soberano.

## 18.2 Misturar papel visual e papel de negócio sem critério

O componente precisa ter fronteira clara.

## 18.3 Esconder estados problemáticos

Loading, erro, vazio e acesso negado precisam estar no contrato.

## 18.4 Permitir override arbitrário de tokens

Isso destrói consistência.

## 18.5 Duplicar componente quase idêntico por contexto sem necessidade

Se a base é a mesma, a variante deve ser controlada.

## 18.6 Deixar o componente depender de improviso textual

Label, mensagem e hierarquia precisam ter direção clara.

## 18.7 Criar componentes “inteligentes” demais no papel

O contrato deve ser robusto, mas não inflado além do estágio real do projeto.

---

# 19. Relação deste documento com os próximos artefatos

Este documento prepara diretamente:

## `006_Contratos_de_Modulos.md`

Porque agora já existe fronteira entre blocos de interface e o restante da arquitetura.

## `007_Estados_Eventos_e_Transicoes.md`

Porque os componentes já foram enquadrados em estados mínimos.

## `008_Validacoes_Mensagens_de_Erro_e_Fallbacks.md`

Porque componentes de formulário, erro e vazio já estão formalizados.

## Implementação futura do frontend

Porque o sistema já possui primitives, shells, componentes editoriais, componentes de feedback e componentes operacionais identificados.

---

# 20. Síntese executiva

A leitura executiva deste documento é:

* o projeto já possui um conjunto soberano de componentes centrais;
* cada componente foi tratado como contrato de uso;
* público e admin compartilham base, mas não se confundem;
* estados foram incluídos como parte da definição;
* acessibilidade não foi tratada como apêndice;
* reuso foi enquadrado com previsibilidade e restrição.

Em linguagem simples:

> no projeto William Albarello, componente não nasce como peça solta de interface; nasce como unidade previsível de composição, estado e governança visual.

---

# 21. Conclusão

Se o blueprint definiu **quais superfícies existem** e o design system definiu **como essas superfícies se comportam visualmente**, este documento define **quais peças compõem essas superfícies e sob quais contratos elas devem existir**.

Ele consolida cinco mensagens principais:

1. **componente é contrato, não ornamento técnico;**
2. **reuso precisa de fronteira, não de improviso;**
3. **estado explícito é parte essencial do contrato;**
4. **acessibilidade e consistência pertencem ao núcleo do componente;**
5. **público e admin exigem componentes articulados, mas semanticamente bem delimitados.**

A mensagem final deste documento é:

> no projeto William Albarello, a implementação do frontend só será madura se cada componente nascer com finalidade, composição, estado, restrição e previsibilidade formalmente definidos.

---

