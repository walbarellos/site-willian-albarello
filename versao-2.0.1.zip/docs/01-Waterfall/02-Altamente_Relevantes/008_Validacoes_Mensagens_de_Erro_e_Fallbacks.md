
# `008_Validacoes_Mensagens_de_Erro_e_Fallbacks.md`

**Endereço canônico:**
`/home/user/Documents/Softwares/Willian Albarello/William Albarello/01-Waterfall/02-Altamente_Relevantes/008_Validacoes_Mensagens_de_Erro_e_Fallbacks.md`

**Status:**
Gerado no diálogo, em padrão copy/paste.

---

# 008_Validacoes_Mensagens_de_Erro_e_Fallbacks

## 1. Identificação do documento

Este documento pertence ao diretório `01-Waterfall/02-Altamente_Relevantes` do projeto **William Albarello** e sucede logicamente os documentos de blueprint de telas, design system, contratos de componentes, contratos de módulos e modelagem de estados, eventos e transições.

Sua finalidade é consolidar, em nível arquitetural e operacional, o tratamento de:

* validações;
* mensagens ao usuário;
* erros previsíveis;
* estados vazios;
* fallbacks funcionais;
* fallbacks editoriais;
* fallbacks operacionais;
* respostas coerentes entre:

  * site público;
  * painel administrativo;
  * API.

Este documento deve ser lido como a resposta formal à pergunta:

> como o sistema reage quando algo falta, falha, expira, diverge, não carrega, não é permitido ou não encontra o que procura?

---

## 2. Finalidade do documento

O objetivo deste documento é impedir que tratamento de erro, validação e fallback sejam deixados para improviso de implementação.

Em sistemas maduros, a confiança do usuário não depende apenas do caminho feliz.
Ela depende, principalmente, de como o sistema se comporta quando:

* a entrada está errada;
* a sessão expira;
* um conteúdo não existe;
* uma ação não é permitida;
* o backend falha;
* um recurso está indisponível;
* não há itens para mostrar;
* o estado atual do recurso impede a ação solicitada.

Este documento existe para:

* padronizar validações de entrada;
* enquadrar mensagens operacionais;
* distinguir categorias de erro;
* explicitar estados vazios;
* formalizar fallbacks previsíveis;
* preservar consistência de voz e seriedade do projeto;
* evitar UX hostil, ambígua ou infantilizada;
* orientar frontend, admin, API, QA e operação.

Em linguagem direta:

* **falha bem tratada preserva confiança**;
* **mensagem ruim destrói UX**;
* **fallback é parte do projeto**.

---

## 3. Insumos soberanos deste documento

Este documento deriva principalmente dos seguintes artefatos já consolidados:

### Waterfall obrigatório

* `W007` — Requisitos Não Funcionais
* `W016` — API Contract Mestre
* `W017` — UI/UX e Arquitetura da Informação
* `W018` — Plano de Testes, Homologação e Qualidade
* `W021` — Critérios de Aceite Gerais

### Diretório 02-Diagramas

* `D018` — Diagrama de Fluxo das Requisições API
* `D025–D031` — Frontend e Jornadas
* `D039` — Diagrama de Fluxo de Sessão
* `D044` — Diagrama de Geração e Publicação de Posts

### Ciclo atual

* `005_Contratos_de_Componentes.md`
* `006_Contratos_de_Modulos.md`
* `007_Estados_Eventos_e_Transicoes.md`

---

## 4. Tese central

A tese central deste documento é:

> no projeto William Albarello, erro, validação e fallback não são apêndices da interface; são contratos de comportamento do sistema.

Isso implica que:

* toda entrada relevante precisa ter validação coerente;
* toda falha previsível precisa ter classe reconhecível;
* toda mensagem precisa preservar clareza, sobriedade e utilidade;
* toda ausência de dado precisa ser tratada como estado legítimo;
* toda indisponibilidade precisa ter resposta proporcional;
* nenhum trecho crítico do sistema pode depender do “depois a gente melhora a mensagem”.

---

## 5. Princípios constitucionais

## 5.1 O sistema deve explicar sem humilhar

Mensagem de erro não deve culpar, ridicularizar ou infantilizar o usuário.

## 5.2 A mensagem deve corresponder ao problema real

Não se deve responder “algo deu errado” quando o erro real é de validação simples, sessão expirada ou acesso negado.

## 5.3 Fallback não pode mentir

Fallback serve para preservar navegação e confiança, não para mascarar incoerência.

## 5.4 Validação deve acontecer em múltiplas camadas

O frontend pode orientar; o backend deve garantir.

## 5.5 Erros diferentes precisam gerar respostas diferentes

Autenticação, autorização, validação, conflito, indisponibilidade e não encontrado não são a mesma coisa.

## 5.6 Estado vazio é estado legítimo

Ausência de conteúdo não é, por si só, falha técnica.

## 5.7 O sistema deve ser claro sem expor internals indevidos

A mensagem ao usuário deve ser útil, mas não vazar detalhes técnicos sensíveis.

## 5.8 O tom do projeto deve ser preservado

A linguagem deve ser:

* séria;
* clara;
* sóbria;
* útil;
* sem dramatização excessiva;
* sem jargão técnico desnecessário no público.

---

## 6. Estrutura de leitura adotada

Este documento será organizado nos seguintes blocos:

1. Princípios de validação
2. Taxonomia de erros
3. Política de mensagens ao usuário
4. Validações de formulários e entradas
5. Estados vazios
6. Fallbacks do site público
7. Fallbacks do painel administrativo
8. Fallbacks da API e da aplicação
9. Fallbacks editoriais
10. Fallbacks de sessão, permissão e segurança
11. Padrões de resposta por tipo de falha
12. Regras de auditoria e observabilidade associadas

---

# 7. Princípios de validação

## 7.1 Validação em camadas

O sistema deve operar com pelo menos duas camadas de validação:

### Validação de interface

Finalidade:

* orientar preenchimento;
* reduzir erro evitável;
* melhorar experiência;
* antecipar inconsistências óbvias.

### Validação de aplicação/backend

Finalidade:

* garantir integridade;
* impedir bypass de regra;
* aplicar contratos soberanos;
* proteger domínio, segurança e persistência.

---

## 7.2 Regra geral

A validação do frontend **não substitui** a validação do backend.
Ela apenas melhora a qualidade da interação.

---

## 7.3 Tipos principais de validação

O sistema deve reconhecer, ao menos, estas famílias de validação:

* obrigatoriedade;
* formato;
* comprimento;
* unicidade;
* elegibilidade de transição;
* autorização;
* consistência contextual;
* existência de recurso;
* integridade do estado atual;
* disponibilidade do serviço.

---

## 7.4 Regra de exposição da validação

A interface deve exibir:

* o que está errado;
* onde está errado;
* o que o usuário pode fazer para corrigir.

A interface não deve:

* exibir mensagens genéricas demais;
* deslocar o erro para área distante do campo;
* depender só de cor;
* exibir stack traces ou detalhes internos em contexto público.

---

# 8. Taxonomia de erros do sistema

O sistema deve distinguir, de forma clara, ao menos as seguintes classes de erro:

## 8.1 `validation_error`

Entrada inválida, incompleta ou malformada.

## 8.2 `authentication_error`

Ausência de autenticação válida ou sessão expirada/inexistente.

## 8.3 `authorization_error`

Usuário autenticado, mas sem permissão para recurso/ação.

## 8.4 `not_found_error`

Recurso, rota ou conteúdo não encontrado.

## 8.5 `conflict_error`

O recurso existe, mas o estado atual impede a ação solicitada.

## 8.6 `unavailable_error`

Serviço, recurso, dependência ou operação temporariamente indisponível.

## 8.7 `application_error`

Falha interna de processamento não atribuída a entrada inválida nem indisponibilidade simples.

## 8.8 `editorial_state_error`

Tentativa de executar transição editorial proibida ou incoerente.

---

## 8.9 Regra de ouro

Essas classes podem ser traduzidas em mensagens mais simples para o usuário, mas **não podem ser colapsadas internamente** como se fossem a mesma falha.

---

# 9. Política de mensagens ao usuário

## 9.1 Objetivo da mensagem

Toda mensagem do sistema deve cumprir ao menos um dos seguintes papéis:

* orientar;
* informar;
* corrigir;
* proteger;
* preservar continuidade;
* explicar limite;
* confirmar ação.

---

## 9.2 Tom de voz

A linguagem padrão do projeto deve ser:

* objetiva;
* elegante;
* clara;
* respeitosa;
* profissional;
* sem humor deslocado;
* sem agressividade;
* sem “culpar o usuário”.

---

## 9.3 Estrutura ideal da mensagem

Quando possível, a mensagem deve responder a três pontos:

1. o que aconteceu;
2. o impacto imediato;
3. o que pode ser feito agora.

---

## 9.4 Exemplos estruturais de boa formulação

### Em vez de:

“Erro inesperado.”

### Preferir:

“Não foi possível concluir esta ação agora. Tente novamente em instantes.”

---

### Em vez de:

“Campo inválido.”

### Preferir:

“Informe um título para continuar.”

---

### Em vez de:

“Acesso negado.”

### Preferir:

“Você não tem permissão para acessar esta área.”

---

### Em vez de:

“Token inválido.”

### Preferir:

“Sua sessão não é mais válida. Faça login novamente para continuar.”

---

## 9.5 O que evitar

Evitar:

* sarcasmo;
* excesso de tecnicismo;
* frases vagas demais;
* mensagens longas demais para erros simples;
* mensagens que escondem completamente o problema real;
* uso indiscriminado de “ops”.

---

# 10. Validações de formulários e entradas

---

## 10.1 Formulário de login

### Campos principais

* identificação
* senha

### Validações mínimas de interface

* campo obrigatório;
* senha obrigatória;
* bloqueio de submit vazio;
* tratamento de submit duplicado.

### Validações de backend

* credenciais válidas;
* conta apta ao acesso;
* perfil compatível com área administrativa;
* sessão passível de criação.

### Mensagens recomendadas

#### Campo de identificação ausente

“Informe seu acesso para continuar.”

#### Campo de senha ausente

“Informe sua senha para continuar.”

#### Credenciais inválidas

“Não foi possível autenticar com os dados informados.”

#### Sessão indisponível

“Não foi possível iniciar sua sessão agora. Tente novamente em instantes.”

#### Sessão expirada

“Sua sessão expirou. Faça login novamente para continuar.”

### Fallbacks previstos

* manter campos preenchidos, exceto senha, conforme política de segurança;
* retornar foco ao primeiro erro;
* impedir múltiplos submits concorrentes.

---

## 10.2 Formulário de nova publicação

### Campos principais mínimos

* título
* resumo
* corpo
* slug, quando aplicável
* status inicial

### Validações mínimas de interface

* título obrigatório;
* corpo obrigatório, conforme mínimo editorial adotado;
* resumo opcional ou obrigatório segundo política final;
* slug, se manual, com formato válido;
* status dentro do conjunto permitido.

### Validações de backend

* integridade do payload;
* unicidade de slug, se já definido;
* permissão de criação;
* coerência entre status e ação solicitada.

### Mensagens recomendadas

#### Título ausente

“Informe um título para continuar.”

#### Corpo ausente

“Adicione o conteúdo da publicação para continuar.”

#### Slug inválido

“O identificador da publicação não está em formato válido.”

#### Slug em conflito

“Já existe uma publicação com este identificador.”

#### Status inválido

“O status informado não é válido para esta operação.”

#### Falha de salvamento

“Não foi possível salvar a publicação agora. Tente novamente.”

### Fallbacks previstos

* preservar conteúdo digitado sempre que possível;
* destacar campos inválidos;
* manter contexto da tela;
* não perder a edição por erro simples de validação.

---

## 10.3 Formulário de edição de publicação

### Validações mínimas

As mesmas da criação, acrescidas de:

* existência do item;
* permissão de edição;
* compatibilidade entre estado atual e nova transição;
* integridade do recurso no momento da atualização.

### Mensagens recomendadas

#### Item inexistente

“A publicação solicitada não foi encontrada.”

#### Sem permissão de edição

“Você não tem permissão para editar esta publicação.”

#### Conflito de estado

“Esta alteração não pode ser concluída no estado atual da publicação.”

#### Alteração salva

“Alterações salvas com sucesso.”

#### Alteração rejeitada por conflito

“A publicação foi modificada ou não está mais disponível para esta operação.”

### Fallbacks previstos

* bloquear ação incompatível;
* recarregar estado atual do item quando houver conflito recuperável;
* manter feedback claro após sucesso.

---

## 10.4 Mudança de status editorial

### Validações mínimas

* recurso existe;
* operador tem permissão;
* transição é permitida;
* slug e conteúdo atendem requisitos para publicação, quando aplicável.

### Mensagens recomendadas

#### Tentativa de publicar sem elegibilidade

“A publicação ainda não atende os requisitos para ser publicada.”

#### Mudança não permitida

“Esta mudança de status não é permitida no estado atual.”

#### Publicação concluída

“Publicação disponibilizada com sucesso.”

#### Arquivamento concluído

“Publicação arquivada com sucesso.”

#### Retorno para rascunho concluído

“A publicação voltou para edição.”

### Fallbacks previstos

* impedir ação inválida antes do submit, quando possível;
* validar novamente no backend;
* atualizar badge/status da interface após sucesso;
* registrar e exibir falha contratual clara quando houver conflito.

---

## 10.5 Preview interno

### Validações mínimas

* item existe;
* operador autenticado;
* operador autorizado;
* conteúdo elegível para preview interno;
* recurso ainda disponível.

### Mensagens recomendadas

#### Preview indisponível

“Não foi possível abrir a visualização desta publicação agora.”

#### Sem permissão para preview

“Você não tem permissão para visualizar esta prévia.”

#### Conteúdo não encontrado

“A publicação solicitada não foi encontrada.”

### Fallbacks previstos

* retorno seguro para edição ou listagem;
* não expor conteúdo interno sem permissão;
* não confundir preview com publicação pública.

---

# 11. Estados vazios

## 11.1 Princípio geral

Estado vazio não deve parecer falha, desde que a ausência de conteúdo seja legítima.

A resposta do sistema deve deixar claro se estamos diante de:

* ausência natural de dados;
* ausência por filtro;
* ausência temporária;
* recurso inexistente;
* indisponibilidade técnica.

---

## 11.2 Estados vazios públicos

### Home sem destaques editoriais

Mensagem recomendada:
“Publicações serão exibidas aqui quando estiverem disponíveis.”

Fallback:

* manter a home íntegra;
* não quebrar a página por ausência de destaque.

### Listagem pública sem publicações

Mensagem recomendada:
“Ainda não há publicações disponíveis.”

Fallback:

* manter cabeçalho e contexto da página;
* não substituir por erro técnico.

---

## 11.3 Estados vazios do painel

### Dashboard sem dados editoriais

Mensagem recomendada:
“Ainda não há publicações cadastradas.”

Fallback:

* exibir CTA claro para nova publicação;
* preservar utilidade do painel.

### Listagem administrativa vazia

Mensagem recomendada:
“Nenhuma publicação foi encontrada.”

Fallback:

* exibir ação de criação;
* manter filtros e contexto, se existirem.

---

## 11.4 Regra de UX para estados vazios

Todo estado vazio deve, quando fizer sentido:

* dizer o que está ausente;
* contextualizar a ausência;
* oferecer próxima ação útil.

---

# 12. Fallbacks do site público

---

## 12.1 Falha de carregamento da home

### Situação

Bloco dinâmico ou conteúdo complementar não pôde ser carregado.

### Regra

A home deve continuar funcional sempre que a falha estiver restrita a um bloco secundário.

### Mensagem recomendada

“Não foi possível carregar este conteúdo agora.”

### Fallback

* manter hero;
* manter navegação;
* remover ou substituir apenas o bloco falho;
* não colapsar a página inteira por falha local.

---

## 12.2 Falha na listagem pública de publicações

### Situação

A listagem editorial não pôde ser resolvida.

### Mensagem recomendada

“Não foi possível carregar as publicações agora.”

### Fallback

* exibir cabeçalho da página;
* exibir `ErrorState` com ação de tentar novamente;
* não misturar esse estado com “lista vazia”.

---

## 12.3 Slug inexistente

### Situação

Rota `/publicacoes/[slug]` não resolve conteúdo existente.

### Mensagem/resultado recomendado

* encaminhamento para 404 editorial ou 404 pública coerente.

### Fallback

* não exibir conteúdo genérico indevido;
* não servir outro item no lugar;
* preservar consistência semântica de página inexistente.

---

## 12.4 Conteúdo não publicado ou indisponível

### Situação

O conteúdo existe internamente, mas não pode ser exibido ao público.

### Resultado recomendado

* tratar como indisponível ou não encontrado, conforme política de segurança e visibilidade;
* não revelar estados internos sensíveis ao visitante.

### Fallback

* não vazar que o conteúdo está em draft/review;
* não mostrar preview público;
* manter postura sóbria.

---

## 12.5 Páginas legais indisponíveis

### Situação

Conteúdo legal não foi resolvido.

### Mensagem recomendada

“Não foi possível exibir este conteúdo agora.”

### Fallback

* manter estrutura pública;
* registrar falha operacional;
* evitar erro bruto quebrando a página.

---

# 13. Fallbacks do painel administrativo

---

## 13.1 Sessão expirada em tela interna

### Situação

Operador está em área interna e perde validade de sessão.

### Mensagem recomendada

“Sua sessão expirou. Faça login novamente para continuar.”

### Fallback

* interromper ações protegidas;
* redirecionar para login ou exibir camada de reautenticação, conforme arquitetura;
* não permitir continuidade silenciosa.

---

## 13.2 Acesso negado a recurso interno

### Situação

Operador autenticado tenta acessar área ou ação sem permissão.

### Mensagem recomendada

“Você não tem permissão para acessar esta área.”

### Fallback

* direcionar para tela de acesso negado;
* oferecer retorno seguro ao painel, quando fizer sentido;
* registrar evento auditável.

---

## 13.3 Falha de carregamento da listagem administrativa

### Situação

A tela de `/painel/publicacoes` não consegue obter dados.

### Mensagem recomendada

“Não foi possível carregar a lista de publicações agora.”

### Fallback

* manter shell do painel;
* exibir `ErrorState` local;
* preservar navegação;
* oferecer nova tentativa.

---

## 13.4 Item não encontrado na edição

### Situação

Operador tenta editar item inexistente ou indisponível.

### Mensagem recomendada

“A publicação solicitada não foi encontrada.”

### Fallback

* redirecionar para listagem ou exibir erro contextual;
* não abrir formulário vazio como se fosse item válido.

---

## 13.5 Falha de salvamento

### Situação

O usuário enviou edição/criação e a aplicação não concluiu.

### Mensagem recomendada

“Não foi possível salvar esta publicação agora.”

### Fallback

* preservar conteúdo local, sempre que viável;
* liberar nova tentativa;
* não perder contexto da tela;
* registrar falha operacional.

---

## 13.6 Preview falho

### Situação

A visualização interna não pôde ser montada.

### Mensagem recomendada

“Não foi possível abrir a visualização desta publicação agora.”

### Fallback

* oferecer retorno para edição;
* não confundir com página pública;
* não quebrar shell do painel.

---

# 14. Fallbacks da API e da aplicação

---

## 14.1 Regra geral da API

A API deve responder de forma:

* consistente;
* categorizada;
* contratual;
* auditável quando necessário;
* semanticamente alinhada à falha real.

---

## 14.2 Respostas mínimas por categoria

### Validação

Retornar erro contratual indicando:

* campo ou aspecto inválido;
* motivo;
* impossibilidade de prosseguir sem correção.

### Autenticação

Retornar resposta coerente com sessão ausente/inválida.

### Autorização

Retornar resposta coerente com falta de permissão.

### Não encontrado

Retornar resposta compatível com recurso inexistente.

### Conflito

Retornar resposta indicando que o estado atual do recurso impede a operação.

### Indisponibilidade

Retornar resposta clara de indisponibilidade temporária.

### Erro interno

Retornar resposta segura, sem vazamento indevido, com correlação operacional adequada.

---

## 14.3 Estrutura conceitual recomendada de erro

Toda resposta de erro contratual deve, idealmente, comportar:

* tipo da falha;
* mensagem legível;
* contexto ou campo afetado, quando aplicável;
* identificador de correlação/diagnóstico, quando relevante;
* indicação se a ação pode ser tentada novamente.

---

## 14.4 Fallbacks internos da aplicação

Quando a aplicação falhar em recursos não centrais, deve-se priorizar:

* degradação controlada;
* preservação do shell principal;
* manutenção da navegação;
* separação entre falha local e falha sistêmica.

---

# 15. Fallbacks editoriais

---

## 15.1 Conteúdo em estado inadequado para publicação

### Situação

Usuário tenta publicar item sem cumprir precondições.

### Mensagem recomendada

“A publicação ainda não está pronta para ser disponibilizada.”

### Fallback

* impedir mudança de status;
* manter item em estado anterior;
* destacar pendência quando viável.

---

## 15.2 Tentativa de transição proibida

### Situação

Ex.: item `archived` tentando ir direto a `published` sem fluxo permitido.

### Mensagem recomendada

“Esta transição não é permitida no estado atual da publicação.”

### Fallback

* rejeitar operação;
* manter estado íntegro;
* registrar tentativa sensível.

---

## 15.3 Falha na exposição pública após publicação

### Situação

A mudança de status ocorreu, mas há falha de atualização da camada pública, indexação ou leitura.

### Mensagem recomendada no admin

“A publicação foi atualizada, mas a disponibilidade pública ainda não pôde ser confirmada.”

### Fallback

* registrar evento operacional;
* não afirmar sucesso pleno sem consistência mínima;
* prever reconciliação/reprocessamento quando aplicável.

---

## 15.4 Publicação arquivada acessada por rota pública

### Situação

Usuário externo chega a slug anteriormente válido.

### Resultado recomendado

* tratar como indisponível ou não encontrado, segundo política;
* nunca exibir conteúdo arquivado por engano.

---

# 16. Fallbacks de sessão, permissão e segurança

---

## 16.1 Sessão ausente em requisição protegida

### Resposta recomendada

Indicar necessidade de autenticação.

### Fallback

* interromper ação;
* redirecionar ao login no admin;
* registrar contexto técnico quando necessário.

---

## 16.2 Sessão expirada no meio do fluxo

### Resposta recomendada

Informar expiração de sessão e necessidade de novo login.

### Fallback

* não continuar persistindo ação protegida;
* evitar estado ambíguo de “aparentemente salvo”.

---

## 16.3 Permissão insuficiente

### Resposta recomendada

Informar falta de permissão sem vazar política interna desnecessária.

### Fallback

* bloquear ação;
* mostrar tela ou mensagem coerente;
* auditar tentativa.

---

## 16.4 Recurso interno consultado sem autorização

### Resposta recomendada

Negar acesso formalmente.

### Fallback

* não expor existência detalhada do recurso além do necessário;
* preservar segurança sem comprometer legibilidade do comportamento.

---

# 17. Regras de exibição por camada

---

## 17.1 No site público

As mensagens devem ser:

* mais curtas;
* mais institucionais;
* menos técnicas;
* suficientes para orientar o visitante.

---

## 17.2 No painel administrativo

As mensagens podem ser:

* um pouco mais operacionais;
* mais específicas quanto à ação;
* mais orientadas à correção;
* sem, ainda assim, vazar detalhe técnico bruto.

---

## 17.3 Na API

As mensagens devem ser:

* consistentes;
* classificáveis;
* úteis para o consumidor da interface;
* seguras;
* semanticamente alinhadas ao contrato.

---

## 17.4 Nos logs e auditoria

Os detalhes técnicos e contextuais mais ricos pertencem:

* à observabilidade;
* ao audit trail;
* ao suporte técnico;
* à análise operacional.

Não à interface pública.

---

# 18. Tabela de referência rápida por tipo de falha

## 18.1 Validação

**Mensagem-base:** orientar correção
**Ação seguinte:** corrigir entrada
**Fallback:** manter contexto e campos

## 18.2 Sessão expirada

**Mensagem-base:** informar reautenticação
**Ação seguinte:** login
**Fallback:** bloquear fluxo protegido

## 18.3 Acesso negado

**Mensagem-base:** informar limitação de permissão
**Ação seguinte:** retorno seguro
**Fallback:** tela ou mensagem de acesso negado

## 18.4 Recurso não encontrado

**Mensagem-base:** informar inexistência
**Ação seguinte:** voltar/listar
**Fallback:** 404 ou erro contextual

## 18.5 Lista vazia

**Mensagem-base:** informar ausência legítima
**Ação seguinte:** explorar ou criar
**Fallback:** CTA contextual

## 18.6 Indisponibilidade temporária

**Mensagem-base:** informar tentativa futura
**Ação seguinte:** tentar novamente
**Fallback:** retry e preservação do shell

## 18.7 Conflito de estado

**Mensagem-base:** informar impossibilidade no estado atual
**Ação seguinte:** revisar contexto atual
**Fallback:** manter integridade do recurso

---

# 19. Regras de auditoria e observabilidade associadas

## 19.1 Devem gerar audit trail

* login;
* logout;
* sessão expirada em ação protegida;
* acesso negado relevante;
* mudança de status;
* publicação;
* arquivamento;
* tentativa de transição proibida.

## 19.2 Devem gerar log operacional com bom contexto

* falha de carregamento de listagem;
* erro de API;
* conflito de unicidade;
* indisponibilidade temporária;
* falha de preview;
* falha de persistência.

## 19.3 Regra de separação

O usuário vê uma mensagem clara.
A operação vê o contexto técnico necessário.
A governança vê o rastro sensível.

Essas três camadas não devem ser confundidas.

---

# 20. Anti-padrões explicitamente proibidos

Este documento proíbe, de forma expressa:

## 20.1 Mensagem genérica para tudo

“Algo deu errado” não pode ser resposta universal.

## 20.2 Campo inválido sem indicação de campo

Erro de validação precisa apontar onde agir.

## 20.3 Estado vazio tratado como erro técnico

Ausência legítima de conteúdo não deve parecer pane.

## 20.4 Fallback que mascara violação de regra

O sistema não pode “seguir em frente” fingindo que a ação foi válida.

## 20.5 Vazamento de detalhe interno ao público

Stack trace, query, identificador interno sensível ou estrutura privada não devem ir para a UI pública.

## 20.6 Sessão expirada silenciosa

O usuário não pode acreditar que ainda está autenticado quando não está.

## 20.7 Preview tratado como publicação

Pré-visualização é interna e deve permanecer distinta.

## 20.8 Perda de conteúdo editado por erro recuperável

Sempre que possível, o sistema deve preservar contexto e dados inseridos.

## 20.9 Uso de tom infantilizado ou jocoso

Não pertence à identidade do projeto.

---

# 21. Relação deste documento com os próximos artefatos

Este documento prepara diretamente:

## `009_Matriz_de_Permissoes_RBAC_ABAC.md`

Porque várias mensagens e bloqueios dependem de decisão formal de autorização.

## `017_Procedimentos_de_QA_Manual.md`

Porque estados de erro, vazio e fallback precisam ser testados deliberadamente.

## `018_Cenarios_Fim_a_Fim_E2E.md`

Porque fluxos ponta a ponta precisam prever falha, expiração e conflito, não apenas sucesso.

## Implementação futura do frontend e da API

Porque contratos de erro, validação e fallback deixam de ser vagos e passam a ser parte do desenho do sistema.

---

# 22. Síntese executiva

A leitura executiva deste documento é:

* validação, mensagem e fallback pertencem à arquitetura;
* o sistema deve distinguir classes de falha;
* o site público precisa ser claro e sóbrio;
* o painel precisa ser claro, operacional e corretivo;
* a API precisa ser consistente e contratual;
* estados vazios são legítimos e distintos de falhas;
* sessão, permissão, preview, publicação e indisponibilidade precisam ter respostas próprias;
* logs, audit trail e mensagens ao usuário pertencem a camadas diferentes.

Em linguagem simples:

> o projeto William Albarello deve reagir bem quando algo falha, porque a confiança no sistema depende tanto do tratamento do erro quanto do funcionamento do caminho feliz.

---

# 23. Conclusão

Se o documento anterior modelou **como o sistema muda de estado**, este documento modela **como ele comunica, contém e governa essas falhas, ausências e interrupções**.

Ele consolida sete mensagens principais:

1. **falha previsível precisa de resposta previsível;**
2. **mensagem ruim corrói confiança;**
3. **estado vazio não é necessariamente erro;**
4. **fallback é parte do sistema e não remendo tardio;**
5. **frontend, admin e API precisam falar a mesma gramática de erro;**
6. **o usuário precisa ser orientado, não punido;**
7. **observabilidade, auditoria e interface devem cooperar sem se confundir.**

A mensagem final deste documento é:

> no projeto William Albarello, a maturidade do sistema será medida não apenas pela elegância do fluxo ideal, mas pela qualidade com que ele valida entradas, responde a falhas, preserva contexto, limita dano e mantém a confiança quando o caminho deixa de ser perfeito.

---

