
# `007_Estados_Eventos_e_Transicoes.md`

**Endereço canônico:**
`/home/user/Documents/Softwares/Willian Albarello/William Albarello/01-Waterfall/02-Altamente_Relevantes/007_Estados_Eventos_e_Transicoes.md`

**Status:**
Gerado no diálogo, em padrão copy/paste.

---

# 007_Estados_Eventos_e_Transicoes

## 1. Identificação do documento

Este documento pertence ao diretório `01-Waterfall/02-Altamente_Relevantes` do projeto **William Albarello** e sucede logicamente os documentos de backlog, sequência de entrega, blueprint de telas, design system, contratos de componentes e contratos de módulos.

Sua finalidade é modelar a **dinâmica do sistema**, deixando explícito:

* o que muda;
* quando muda;
* por que muda;
* por quais eventos muda;
* quais transições são válidas;
* quais transições são proibidas;
* quais efeitos colaterais precisam ocorrer;
* que rastro auditável deve ser produzido;
* como essas mudanças impactam:

  * frontend público;
  * painel administrativo;
  * API;
  * descoberta pública.

Este documento deve ser lido como a resposta formal à pergunta:

> quais são os estados centrais do sistema, quais eventos os disparam e sob quais regras as transições podem ou não acontecer?

---

## 2. Finalidade do documento

O objetivo deste documento é impedir que o sistema seja implementado como um conjunto de mudanças implícitas, mutações informais de status ou comportamentos ocultos entre frontend, admin, API e persistência.

Sem uma modelagem explícita de estados, eventos e transições, o sistema tende a colapsar em:

* mudanças de status sem regra clara;
* telas que assumem estados não autorizados;
* preview tratado como publicação pública;
* sessão tratada como permanente;
* erros sem comportamento consistente;
* ações administrativas sem auditoria;
* frontend e backend divergindo sobre o que é permitido.

Este documento existe para:

* modelar os estados soberanos do sistema;
* nomear eventos disparadores;
* estabelecer transições permitidas;
* proibir transições inválidas;
* definir efeitos colaterais obrigatórios;
* enquadrar auditoria mínima;
* orientar implementação, QA e governança.

Em linguagem direta:

* **sistema vive de transição**;
* **estado sem regra gera caos**;
* **evento precisa deixar rastro**.

---

## 3. Insumos soberanos deste documento

Este documento deriva principalmente dos seguintes artefatos já consolidados:

### Waterfall obrigatório

* `W006` — Requisitos Funcionais
* `W015` — Segurança, Privacidade, Auditoria e Permissões
* `W016` — API Contract Mestre
* `W017` — UI/UX e Arquitetura da Informação

### Diretório 02-Diagramas

* `D018` — Diagrama de Fluxo das Requisições API
* `D039` — Diagrama de Fluxo de Sessão
* `D041` — Diagrama de Auditoria e Rastreabilidade
* `D042` — Diagrama de Fluxo Editorial
* `D044` — Diagrama de Geração e Publicação de Posts

---

## 4. Tese central

A tese central deste documento é:

> no projeto William Albarello, todo estado relevante precisa ter nome, toda transição precisa ter regra, e todo evento crítico precisa deixar efeito e rastro.

Isso implica que:

* estados não podem ser apenas inferidos por conveniência de interface;
* eventos não podem ser tratados como “cliques soltos” sem semântica;
* mudanças de status editoriais precisam ser governadas;
* sessão precisa ser tratada como ciclo, não como condição mágica;
* preview precisa ser formalmente distinto de publicação pública;
* erro precisa ser parte do sistema, não exceção sem modelagem;
* auditoria não é opcional nas transições sensíveis.

---

## 5. Princípios constitucionais de estados e transições

## 5.1 Todo estado relevante precisa ser nomeável

Se o sistema depende de uma condição importante, essa condição precisa ser nomeada formalmente.

## 5.2 Toda transição relevante precisa ter disparador

Mudança sem evento claro vira comportamento implícito e instável.

## 5.3 Toda transição crítica precisa ter precondições

Nem todo evento pode disparar qualquer mudança em qualquer contexto.

## 5.4 Toda transição sensível precisa ter efeitos colaterais explícitos

Mudanças importantes precisam atualizar mais do que apenas um campo visual.

## 5.5 O frontend não legitima a transição por conta própria

A validação final da transição pertence à aplicação/backend.

## 5.6 Estados públicos e estados internos não podem ser confundidos

O que é visível publicamente depende de regra editorial e não apenas de existência de conteúdo.

## 5.7 Evento crítico sem rastro é falha de governança

Login, logout, mudança de status, publicação e acesso negado precisam deixar trilha.

## 5.8 Transição proibida deve ser explicitamente tratada

O sistema não pode “aceitar silenciosamente” ações inválidas.

---

## 6. Estrutura de leitura adotada

Este documento organiza a dinâmica do sistema em seis domínios de estado:

1. **Estados de sessão e acesso**
2. **Estados editoriais de conteúdo**
3. **Estados de preview e visibilidade**
4. **Estados operacionais de API e formulários**
5. **Estados públicos de leitura e navegação**
6. **Estados de erro, restrição e exceção**

Cada domínio será tratado com:

* estados canônicos;
* eventos disparadores;
* transições válidas;
* transições proibidas;
* efeitos colaterais;
* auditoria mínima;
* impactos sobre frontend, admin e API.

---

# 7. Domínio de estados de sessão e acesso

---

## 7.1 Estados canônicos de sessão

O sistema reconhece os seguintes estados principais de sessão:

* `anonymous`
* `authenticating`
* `authenticated_active`
* `authenticated_expired`
* `access_denied`
* `logged_out`

### Descrição dos estados

#### `anonymous`

Usuário não autenticado e sem sessão válida.

#### `authenticating`

Credenciais foram submetidas e aguardam validação.

#### `authenticated_active`

Sessão válida, operador identificado e autorizado a acessar o painel conforme perfil.

#### `authenticated_expired`

Sessão antes válida tornou-se inválida por expiração, invalidação ou perda de contexto.

#### `access_denied`

Operador autenticado, porém sem permissão suficiente para o recurso ou ação solicitada.

#### `logged_out`

Sessão encerrada deliberadamente ou invalidada com retorno ao estado não autenticado.

---

## 7.2 Eventos de sessão

Eventos canônicos:

* `login_requested`
* `login_succeeded`
* `login_failed`
* `session_validated`
* `session_expired`
* `logout_requested`
* `logout_succeeded`
* `protected_resource_requested`
* `permission_check_failed`

---

## 7.3 Transições válidas de sessão

### `anonymous` → `authenticating`

**Evento:** `login_requested`
**Precondição:** credenciais fornecidas
**Efeito colateral:** bloquear submit duplicado; iniciar validação; registrar tentativa

### `authenticating` → `authenticated_active`

**Evento:** `login_succeeded`
**Precondição:** credenciais válidas e perfil permitido
**Efeito colateral:** criar/atualizar sessão; redirecionar para `/painel`; carregar contexto do operador; auditar sucesso

### `authenticating` → `anonymous`

**Evento:** `login_failed`
**Precondição:** credenciais inválidas ou conta inapta
**Efeito colateral:** exibir erro; liberar novo envio; auditar falha

### `authenticated_active` → `authenticated_expired`

**Evento:** `session_expired`
**Precondição:** timeout, revogação, invalidação ou falha de sessão
**Efeito colateral:** bloquear ações internas pendentes; forçar reautenticação; registrar expiração

### `authenticated_active` → `access_denied`

**Evento:** `permission_check_failed`
**Precondição:** sessão válida, mas sem autorização para recurso/ação
**Efeito colateral:** redirecionar ou exibir tela de acesso negado; registrar tentativa negada

### `authenticated_active` → `logged_out`

**Evento:** `logout_requested` seguido de `logout_succeeded`
**Precondição:** sessão ativa
**Efeito colateral:** invalidar sessão; limpar contexto local; redirecionar para login; auditar logout

### `logged_out` → `anonymous`

**Evento:** finalização do fluxo de logout
**Precondição:** sessão destruída
**Efeito colateral:** estado inicial não autenticado

---

## 7.4 Transições proibidas de sessão

### `anonymous` → `authenticated_active` sem `login_requested`

Proibido pular autenticação formal.

### `authenticated_expired` → ação protegida

Sessão expirada não autoriza continuação silenciosa da operação.

### `access_denied` → execução da ação bloqueada

Negação de acesso deve encerrar a tentativa, não apenas decorá-la.

### `logged_out` → persistência de contexto protegido

Após logout, o contexto interno deve ser invalidado.

---

## 7.5 Auditoria mínima de sessão

Devem gerar trilha auditável:

* tentativa de login;
* login bem-sucedido;
* login rejeitado;
* logout;
* expiração de sessão;
* acesso negado a recurso sensível.

Campos mínimos recomendados no rastro:

* identificador do operador, quando existir;
* timestamp;
* recurso/rota alvo;
* tipo de evento;
* resultado;
* origem contextual mínima.

---

## 7.6 Impactos sobre frontend, admin e API

### Frontend/Admin

* login precisa refletir `authenticating`, `erro`, `sucesso`
* telas protegidas precisam reagir a `authenticated_expired`
* acesso negado precisa ser distinguido de erro técnico

### API

* deve validar sessão a cada requisição protegida
* deve negar por padrão
* deve diferenciar `401/unauthenticated` de `403/forbidden`

---

# 8. Domínio de estados editoriais de conteúdo

---

## 8.1 Estados editoriais canônicos

O contrato editorial soberano do projeto adota os seguintes estados:

* `draft`
* `review`
* `ready_to_publish`
* `published`
* `archived`

### Descrição dos estados

#### `draft`

Conteúdo em elaboração, ainda não aprovado para exposição pública.

#### `review`

Conteúdo entrou em fase de revisão interna.

#### `ready_to_publish`

Conteúdo está validado internamente e apto para publicação, aguardando disparo final.

#### `published`

Conteúdo tornou-se público, legível e indexável conforme políticas do sistema.

#### `archived`

Conteúdo foi retirado da circulação pública corrente, preservando histórico conforme política adotada.

---

## 8.2 Observação sobre implementação mínima

Caso uma implementação inicial use subconjunto reduzido, o mapeamento aceitável é:

* `draft`
* `published`
* `archived`

Mas a arquitetura documental oficial do projeto considera a máquina de estados completa acima como **alvo soberano**.

---

## 8.3 Eventos editoriais canônicos

* `publication_created`
* `content_updated`
* `review_requested`
* `review_approved`
* `review_rejected`
* `publish_requested`
* `publish_succeeded`
* `archive_requested`
* `archive_succeeded`
* `restore_to_draft_requested`

---

## 8.4 Transições válidas editoriais

### `null` → `draft`

**Evento:** `publication_created`
**Precondição:** operador autenticado com permissão de criação
**Efeito colateral:** persistir item; gerar identificador; registrar autoria operacional

### `draft` → `draft`

**Evento:** `content_updated`
**Precondição:** permissão de edição
**Efeito colateral:** atualizar conteúdo; atualizar timestamp; registrar edição

### `draft` → `review`

**Evento:** `review_requested`
**Precondição:** conteúdo mínimo válido segundo regras editoriais
**Efeito colateral:** atualizar status; registrar solicitação; sinalizar etapa seguinte

### `review` → `draft`

**Evento:** `review_rejected`
**Precondição:** revisão concluiu que conteúdo precisa voltar para elaboração
**Efeito colateral:** registrar retorno; manter histórico; impedir publicação

### `review` → `ready_to_publish`

**Evento:** `review_approved`
**Precondição:** validações editoriais atendidas
**Efeito colateral:** atualizar status; tornar item elegível para publicação

### `ready_to_publish` → `published`

**Evento:** `publish_requested` seguido de `publish_succeeded`
**Precondição:** permissão de publicação; conteúdo íntegro; slug válido; regras mínimas de visibilidade atendidas
**Efeito colateral:** tornar conteúdo público; expor rota pública; atualizar descoberta/SEO; registrar publicação

### `published` → `draft`

**Evento:** `restore_to_draft_requested`
**Precondição:** política permitir despublicação para retrabalho
**Efeito colateral:** retirar exposição pública; remover de listagens públicas; registrar reversão

### `published` → `archived`

**Evento:** `archive_requested` seguido de `archive_succeeded`
**Precondição:** permissão adequada
**Efeito colateral:** retirar de circulação pública principal; atualizar listagens; registrar arquivamento

### `archived` → `draft`

**Evento:** `restore_to_draft_requested`
**Precondição:** permissão adequada e intenção explícita de reedição
**Efeito colateral:** reabrir ciclo editorial; item deixa de ser arquivado

---

## 8.5 Transições proibidas editoriais

### `draft` → `published` sem validações mínimas

Proibido publicar diretamente se contrato operacional exigir revisão/ready.

### `review` → `published` sem passar por `ready_to_publish`

Proibido pular etapa de autorização final quando ela existir.

### `archived` → `published` sem reativação formal

Conteúdo arquivado não deve reaparecer publicamente sem transição explícita.

### `published` → `review`

Transição proibida por ambiguidade operacional.
O retorno deve ser a `draft`, não a um meio estado obscuro.

### qualquer estado → `published` com slug inválido

Proibido expor conteúdo público sem identidade de rota válida.

---

## 8.6 Efeitos colaterais obrigatórios das transições editoriais

Mudanças relevantes de estado editorial devem, quando aplicável:

* atualizar `status`;
* atualizar `updated_at`;
* persistir identidade do operador responsável;
* registrar evento auditável;
* recalcular elegibilidade de exibição pública;
* recalcular metadata/indexação quando o estado público for afetado;
* invalidar caches ou revalidar superfícies públicas, se houver estratégia de cache.

---

## 8.7 Auditoria mínima editorial

Devem ser auditáveis:

* criação de publicação;
* edição de conteúdo;
* mudança de status;
* publicação;
* arquivamento;
* retorno para rascunho;
* tentativa inválida de transição sensível.

Campos mínimos recomendados:

* publicação alvo;
* status anterior;
* status novo;
* operador;
* timestamp;
* motivo/contexto, quando houver.

---

## 8.8 Impactos sobre frontend, admin e API

### Frontend público

* só deve exibir conteúdo em `published`
* listagens e slug pages devem respeitar regra de visibilidade

### Admin

* precisa mostrar status atual com clareza
* precisa habilitar/desabilitar ações conforme estado e permissão

### API

* valida transição
* aplica efeitos colaterais
* persiste histórico e rastros
* recusa mudança inválida com erro contratual claro

---

# 9. Domínio de estados de preview e visibilidade

---

## 9.1 Estados canônicos de visibilidade

* `not_public`
* `preview_internal`
* `public_visible`
* `public_unavailable`

### Descrição

#### `not_public`

Conteúdo existe internamente, mas não pode ser consumido pelo público.

#### `preview_internal`

Conteúdo pode ser renderizado internamente para operador autorizado, sem exposição pública.

#### `public_visible`

Conteúdo pode ser lido publicamente em rota própria.

#### `public_unavailable`

Rota pública não deve servir o conteúdo, seja por ausência, estado inválido ou despublicação.

---

## 9.2 Relação entre estado editorial e visibilidade

### Tabela soberana de correspondência

* `draft` → `not_public`
* `review` → `not_public`
* `ready_to_publish` → `not_public`
* `published` → `public_visible`
* `archived` → `public_unavailable`

### Observação

`preview_internal` não é um estado editorial autônomo; é um **modo de visualização permitido** para estados internos elegíveis.

---

## 9.3 Eventos de preview/visibilidade

* `preview_requested`
* `preview_rendered`
* `public_route_requested`
* `public_route_resolved`
* `public_route_denied`
* `content_despublished`

---

## 9.4 Transições válidas de preview/visibilidade

### `not_public` → `preview_internal`

**Evento:** `preview_requested`
**Precondição:** operador autenticado com permissão; item existente
**Efeito colateral:** renderizar preview interno; registrar acesso

### `not_public` → `public_visible`

**Evento:** `publish_succeeded`
**Precondição:** estado editorial `published`
**Efeito colateral:** conteúdo entra em listagem pública e rota por slug

### `public_visible` → `public_unavailable`

**Evento:** `archive_succeeded` ou `content_despublished`
**Precondição:** mudança editorial válida
**Efeito colateral:** retirada da camada pública; atualização de descoberta

### `preview_internal` → `not_public`

**Evento:** encerramento do preview ou perda de permissão
**Precondição:** fim da visualização
**Efeito colateral:** nenhum efeito público

---

## 9.5 Transições proibidas de preview/visibilidade

### `preview_internal` → `public_visible` sem publicação formal

Preview não publica.

### `not_public` → leitura pública por slug

Conteúdo interno não deve vazar para a rota pública.

### `archived` → `preview_internal` sem permissão

Preview também depende de controle de acesso.

---

## 9.6 Auditoria mínima de preview

Devem ser rastreáveis:

* solicitações de preview;
* preview de conteúdo sensível/interno;
* tentativas indevidas de acessar preview sem permissão.

---

# 10. Domínio de estados operacionais de API e formulários

---

## 10.1 Estados canônicos de requisição/aplicação

* `idle`
* `validating`
* `processing`
* `succeeded`
* `failed_validation`
* `failed_application`
* `failed_authorization`
* `failed_unavailable`

### Descrição

#### `idle`

Nenhuma ação em andamento.

#### `validating`

Payload/contexto sendo validado.

#### `processing`

A aplicação aceitou a entrada e está processando.

#### `succeeded`

A operação foi concluída com sucesso.

#### `failed_validation`

Entrada inválida ou precondição não atendida.

#### `failed_application`

Falha de regra, persistência ou processamento.

#### `failed_authorization`

Usuário sem autorização suficiente.

#### `failed_unavailable`

Serviço/recurso momentaneamente indisponível.

---

## 10.2 Eventos operacionais

* `submit_requested`
* `validation_passed`
* `validation_failed`
* `authorization_failed`
* `processing_started`
* `processing_succeeded`
* `processing_failed`
* `resource_unavailable`

---

## 10.3 Transições válidas operacionais

### `idle` → `validating`

**Evento:** `submit_requested`

### `validating` → `processing`

**Evento:** `validation_passed`
**Precondição:** payload válido e contexto autorizado

### `validating` → `failed_validation`

**Evento:** `validation_failed`

### `validating` → `failed_authorization`

**Evento:** `authorization_failed`

### `processing` → `succeeded`

**Evento:** `processing_succeeded`

### `processing` → `failed_application`

**Evento:** `processing_failed`

### `processing` → `failed_unavailable`

**Evento:** `resource_unavailable`

### `failed_*` → `idle`

**Evento:** nova edição do usuário ou nova tentativa autorizada

---

## 10.4 Transições proibidas operacionais

### `idle` → `succeeded` sem validação/processamento

Sucesso sem fluxo formal é proibido.

### `failed_authorization` → `processing`

Sem correção de permissão/contexto, a ação não pode prosseguir.

### `processing` → múltiplos `processing` concorrentes para mesma ação sem controle

Deve haver proteção contra duplicidade de submit quando aplicável.

---

## 10.5 Efeitos colaterais operacionais

* bloquear UI durante submit crítico, quando necessário;
* evitar duplo envio;
* exibir mensagens de erro coerentes por tipo;
* registrar falhas relevantes;
* devolver payload contratual consistente;
* atualizar tela/admin após sucesso.

---

## 10.6 Impactos sobre frontend/admin/API

### Frontend/Admin

* formulários precisam refletir `loading`, `erro`, `sucesso`
* mensagens devem diferenciar validação, autorização e falha técnica

### API

* precisa devolver erro semanticamente correto
* precisa manter consistência entre contrato HTTP e motivo real da falha

---

# 11. Domínio de estados públicos de leitura e navegação

---

## 11.1 Estados públicos canônicos

* `page_loading`
* `page_ready`
* `list_empty`
* `content_found`
* `content_not_found`
* `content_unavailable`
* `page_error`

### Descrição

#### `page_loading`

Página ou bloco público está carregando.

#### `page_ready`

Estrutura pública carregada e apta à navegação.

#### `list_empty`

A listagem pública não possui itens elegíveis.

#### `content_found`

Conteúdo público publicado foi encontrado.

#### `content_not_found`

Slug ou rota não corresponde a conteúdo existente.

#### `content_unavailable`

Conteúdo existe, mas não está publicamente disponível.

#### `page_error`

Falha técnica impediu leitura ou renderização adequada.

---

## 11.2 Eventos públicos

* `public_page_requested`
* `public_page_loaded`
* `public_list_resolved_empty`
* `public_content_resolved`
* `public_slug_not_found`
* `public_content_blocked`
* `public_render_failed`

---

## 11.3 Transições válidas públicas

### `page_loading` → `page_ready`

**Evento:** `public_page_loaded`

### `page_loading` → `list_empty`

**Evento:** `public_list_resolved_empty`

### `page_loading` → `content_found`

**Evento:** `public_content_resolved`

### `page_loading` → `content_not_found`

**Evento:** `public_slug_not_found`

### `page_loading` → `content_unavailable`

**Evento:** `public_content_blocked`

### `page_loading` → `page_error`

**Evento:** `public_render_failed`

---

## 11.4 Transições proibidas públicas

### `content_unavailable` → exibição integral do conteúdo

Conteúdo não elegível não pode ser servido como se estivesse publicado.

### `content_not_found` → fallback com conteúdo incorreto

Não se deve mascarar erro de slug com conteúdo de outro item.

---

## 11.5 Efeitos colaterais públicos

* exibir estado adequado;
* preservar consistência semântica;
* não indexar indevidamente conteúdo indisponível;
* encaminhar corretamente para 404 quando aplicável.

---

# 12. Domínio de estados de erro, restrição e exceção

---

## 12.1 Classes principais de erro/restrição

* `validation_error`
* `authorization_error`
* `authentication_error`
* `not_found_error`
* `conflict_error`
* `unavailable_error`
* `unexpected_error`

---

## 12.2 Regras de distinção

### `validation_error`

A entrada está errada ou incompleta.

### `authentication_error`

Falta autenticação ou sessão válida.

### `authorization_error`

Existe identidade, mas não há permissão suficiente.

### `not_found_error`

Recurso/rota inexistente.

### `conflict_error`

Estado atual do recurso impede a operação solicitada.

### `unavailable_error`

Serviço ou dependência indisponível.

### `unexpected_error`

Falha não prevista ou não classificada adequadamente.

---

## 12.3 Regra obrigatória

Essas classes não devem ser colapsadas em uma única mensagem genérica no backend.
A interface pode simplificar a exposição, mas a aplicação deve distingui-las.

---

# 13. Matriz resumida de transições críticas

## 13.1 Sessão

* `anonymous` → `authenticating` → `authenticated_active`
* `authenticated_active` → `authenticated_expired`
* `authenticated_active` → `access_denied`
* `authenticated_active` → `logged_out`

## 13.2 Editorial

* `draft` → `review`
* `review` → `ready_to_publish`
* `ready_to_publish` → `published`
* `published` → `archived`
* `published` → `draft`
* `archived` → `draft`

## 13.3 Visibilidade

* `not_public` → `preview_internal`
* `not_public` → `public_visible`
* `public_visible` → `public_unavailable`

## 13.4 Operação

* `idle` → `validating` → `processing` → `succeeded`
* `validating` → `failed_validation`
* `validating` → `failed_authorization`
* `processing` → `failed_application`
* `processing` → `failed_unavailable`

---

# 14. Regras gerais de auditoria

## 14.1 Eventos obrigatoriamente auditáveis

Devem gerar rastro mínimo:

* login;
* logout;
* sessão expirada;
* acesso negado;
* criação de publicação;
* edição de publicação;
* mudança de status;
* publicação;
* arquivamento;
* preview interno;
* falhas críticas de aplicação em ação sensível.

## 14.2 Eventos tecnicamente relevantes, mas não necessariamente auditáveis no mesmo nível

Podem ser tratados como logs operacionais, conforme criticidade:

* carregamento de listagem pública;
* erro transitório de leitura;
* timeout de recurso não sensível;
* falha de UI sem ação administrativa.

## 14.3 Princípio de separação

* **audit trail** = ação relevante de governança e segurança
* **log operacional** = observabilidade técnica e diagnóstico

---

# 15. Impactos arquiteturais por camada

## 15.1 Impacto sobre o frontend público

O público deve refletir corretamente:

* loading;
* conteúdo encontrado;
* conteúdo indisponível;
* slug inexistente;
* erro de leitura.

Sem vazar estados internos indevidos.

## 15.2 Impacto sobre o painel admin

O admin deve:

* mostrar estado editorial com clareza;
* habilitar apenas transições permitidas;
* reagir a sessão expirada e acesso negado;
* diferenciar preview de publicação;
* distinguir erro de validação, permissão e falha técnica.

## 15.3 Impacto sobre a API

A API deve:

* validar precondições;
* aplicar regras de transição;
* rejeitar transições proibidas;
* persistir mudanças válidas;
* produzir resposta contratual coerente;
* acionar rastro operacional e auditável.

## 15.4 Impacto sobre persistência

Persistência deve:

* garantir integridade do status;
* registrar timestamps;
* evitar mudanças ilegítimas silenciosas;
* sustentar leitura pública coerente.

## 15.5 Impacto sobre SEO e descoberta

A camada pública e a indexação devem reagir às transições:

* `published` ativa exposição pública;
* `archived` ou despublicação retiram elegibilidade pública;
* estados internos não devem gerar indexação.

---

# 16. Anti-padrões explicitamente proibidos

Este documento proíbe, de forma expressa:

## 16.1 Mudança de status sem evento nomeado

Toda mudança sensível precisa ter disparador explícito.

## 16.2 Publicação pública a partir de preview

Preview não publica.

## 16.3 Sessão tratada como infinita

Expiração precisa ser prevista e tratada.

## 16.4 Transição proibida silenciosamente aceita

A API deve rejeitar com contrato claro.

## 16.5 Frontend assumindo que ação foi concluída sem confirmação da API

Transição só se consolida com resposta válida da aplicação.

## 16.6 Conteúdo interno indexável

Estados internos não podem vazar para descoberta pública.

## 16.7 Auditoria parcial de eventos sensíveis

Ações críticas sem rastro comprometem governança.

## 16.8 Colapsar todos os erros em “algo deu errado”

O sistema precisa saber e comunicar que tipo de falha ocorreu.

---

# 17. Relação deste documento com os próximos artefatos

Este documento prepara diretamente:

## `008_Validacoes_Mensagens_de_Erro_e_Fallbacks.md`

Porque os estados de falha, restrição e exceção já foram modelados.

## `009_Matriz_de_Permissoes_RBAC_ABAC.md`

Porque as transições agora já reconhecem pré-condições de autorização.

## `011_Matriz_de_Dependencias_entre_Bloco_e_Modulos.md`

Porque a dinâmica entre estados evidencia dependências formais entre módulos.

## `018_Cenarios_Fim_a_Fim_E2E.md`

Porque os cenários ponta a ponta serão construídos sobre estas transições.

---

# 18. Síntese executiva

A leitura executiva deste documento é:

* o sistema possui estados nomeados para sessão, conteúdo, visibilidade, operação, navegação e erro;
* eventos relevantes foram explicitados;
* transições válidas e proibidas foram separadas;
* efeitos colaterais obrigatórios foram reconhecidos;
* auditoria foi acoplada aos pontos sensíveis;
* frontend, admin e API receberam implicações claras.

Em linguagem simples:

> o projeto William Albarello não deve mudar de condição por improviso; deve mudar por eventos formais, em estados reconhecíveis, sob regras explícitas e com rastreabilidade adequada.

---

# 19. Conclusão

Se os contratos de módulo definiram **quem responde por quê**, este documento define **como o sistema se movimenta ao longo do tempo e sob quais regras essas mudanças acontecem**.

Ele consolida seis mensagens principais:

1. **estado sem nome enfraquece o sistema;**
2. **evento sem semântica enfraquece a implementação;**
3. **transição sem regra enfraquece a governança;**
4. **preview, publicação e visibilidade precisam permanecer distintos;**
5. **sessão e permissão precisam ser tratadas como ciclos reais;**
6. **toda mudança crítica precisa deixar efeito e rastro.**

A mensagem final deste documento é:

> no projeto William Albarello, a maturidade do sistema dependerá de sua capacidade de tratar estados, eventos e transições como contratos explícitos de comportamento, e não como efeitos colaterais implícitos de telas, cliques ou suposições locais.

---

