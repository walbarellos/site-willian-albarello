
# `004_Design_System_Fundacional.md`

**Endereço canônico:**
`/home/user/Documents/Softwares/Willian Albarello/William Albarello/01-Waterfall/02-Altamente_Relevantes/004_Design_System_Fundacional.md`

**Status:**
Gerado no diálogo, em padrão copy/paste.

---

# 004_Design_System_Fundacional

## 1. Identificação do documento

Este documento pertence ao diretório `01-Waterfall/02-Altamente_Relevantes` do projeto **William Albarello** e sucede logicamente os documentos:

* `001_Backlog_Estruturado_por_Modulo.md`
* `002_Story_Map_e_Sequencia_Oficial_de_Entrega.md`
* `003_Blueprint_de_Telas_Paginas_e_Secoes.md`

Sua finalidade é estabelecer o **alicerce visual, semântico e operacional do frontend** do projeto, cobrindo tanto:

* o **site público institucional/editorial**;
* quanto o **painel administrativo interno**.

Este documento deve ser lido como a base soberana para responder:

> como o sistema deve se apresentar visualmente, comportar-se semanticamente e manter consistência entre telas, componentes, estados e ambientes?

---

## 2. Finalidade do documento

O objetivo deste documento é impedir que o frontend do projeto seja construído com base em decisões visuais dispersas, preferências estéticas casuais ou componentes sem linguagem comum.

Este design system existe para:

* transformar design em infraestrutura do sistema;
* definir princípios visuais e semânticos compartilhados;
* fixar tokens, regras de tipografia, cores, grid e espaçamento;
* organizar estados de interface;
* estabelecer critérios de acessibilidade e responsividade;
* garantir coerência entre site público e painel administrativo;
* preparar o terreno para contratos de componentes e implementação real.

Este documento **não é um catálogo decorativo**.
Ele é a constituição visual e semântica do frontend.

---

## 3. Insumos soberanos deste documento

Este design system deriva principalmente dos seguintes artefatos já consolidados:

### Waterfall obrigatório

* `W007` — Requisitos Não Funcionais
* `W017` — UI/UX e Arquitetura da Informação
* `W018` — Plano de Testes, Homologação e Qualidade
* `W021` — Critérios de Aceite Gerais
* `W024` — Registro de Decisões Arquiteturais

### Diretório 02-Diagramas

* `D025–D031` — Frontend e Jornadas
* `D038–D041` — Segurança e Controle de Acesso
* `D042–D045` — SEO, CMS e Publicação

### Ciclo atual

* `003_Blueprint_de_Telas_Paginas_e_Secoes.md`

---

## 4. Tese central do design system

A tese central deste documento é a seguinte:

> no projeto William Albarello, design não é enfeite; design é infraestrutura visual, semântica e operacional do sistema.

Isso significa que:

* a interface precisa ser coerente com a arquitetura;
* o visual precisa refletir a seriedade do domínio;
* o painel e o site público precisam conversar entre si sem se confundirem;
* cada componente precisa nascer com identidade, função e previsibilidade;
* decisões visuais devem reduzir ruído, e não produzir distração.

Em linguagem direta:

* **sistema, não decoração**;
* **reutilização com identidade**;
* **consistência soberana**.

---

## 5. Princípios constitucionais do design system

## 5.1 Clareza acima de ornamentalismo

O projeto deve privilegiar legibilidade, hierarquia, foco e compreensão.

## 5.2 Sobriedade com presença

O sistema deve transmitir autoridade, inteligência, organização e maturidade, sem cair em frieza estéril nem em espetáculo visual gratuito.

## 5.3 Unidade entre público e admin

Site público e painel administrativo pertencem ao mesmo ecossistema visual, ainda que possuam ritmos e prioridades diferentes.

## 5.4 Componentes como contratos visuais

Nenhum componente deve existir como peça improvisada.
Cada um precisa respeitar regras de forma, espaçamento, estados e comportamento.

## 5.5 Semântica antes de estética isolada

A escolha visual precisa reforçar função, prioridade e leitura.

## 5.6 Responsividade nativa

A interface não deve ser “adaptada depois”.
Ela deve nascer com comportamento responsivo previsto.

## 5.7 Acessibilidade como critério estrutural

Contraste, foco, legibilidade, navegação por teclado e semântica não são opcionais.

## 5.8 Escalabilidade visual

O sistema precisa suportar crescimento futuro sem reinvenção constante da linguagem.

---

## 6. Escopo deste design system

Este documento cobre:

* tokens fundacionais;
* sistema de cores;
* tipografia;
* grid;
* espaçamento;
* raios, bordas e sombras;
* ícones e elementos de apoio;
* estados de interface;
* regras de componentes estruturais;
* princípios de acessibilidade;
* responsividade;
* consistência entre público e admin.

Este documento **não detalha ainda**:

* o contrato individual de cada componente;
* o inventário exaustivo de componentes;
* a implementação em CSS/Tailwind/design tokens reais;
* o detalhamento de motion avançado.

Esses pontos serão tratados nos próximos documentos do ciclo.

---

# 7. Arquitetura visual geral do sistema

## 7.1 Duas superfícies, uma linguagem

O projeto possui duas superfícies principais:

### Superfície pública

Função:

* apresentar;
* posicionar;
* comunicar;
* publicar;
* permitir descoberta e leitura.

### Superfície administrativa

Função:

* operar;
* governar;
* editar;
* revisar;
* acompanhar.

Ambas compartilham:

* base tipográfica;
* sistema de espaçamento;
* lógica de grid;
* tokens de cor;
* estados de interface;
* regras de acessibilidade.

Mas cada uma possui ênfase distinta:

### Público

* maior peso narrativo;
* maior atenção à leitura e à percepção institucional;
* ritmo mais editorial;
* linguagem mais aberta e convidativa.

### Admin

* maior peso funcional;
* maior densidade operacional;
* foco em legibilidade de ação e estado;
* linguagem mais contida e utilitária.

---

## 7.2 Identidade visual pretendida

A identidade visual do projeto deve comunicar:

* sobriedade;
* inteligência;
* organização;
* clareza;
* autoridade serena;
* densidade sem opacidade;
* modernidade controlada;
* confiança.

O sistema **não deve** comunicar:

* informalidade excessiva;
* exagero de efeitos;
* infantilização visual;
* excesso de ornamento;
* experimentação estética sem função;
* ruído visual em áreas operacionais.

---

# 8. Sistema de tokens fundacionais

## 8.1 Princípio geral dos tokens

Os tokens devem ser a fonte única de verdade visual do sistema.

Eles existem para:

* evitar hardcodes arbitrários;
* padronizar escalas;
* permitir evolução consistente;
* unificar site público e painel;
* reduzir divergência entre telas e componentes.

Categorias mínimas de tokens:

* cor;
* tipografia;
* espaçamento;
* tamanho;
* raio;
* borda;
* sombra;
* z-index;
* duração;
* opacidade;
* largura de container;
* breakpoints;
* estados.

---

## 8.2 Convenção recomendada de nomenclatura

A nomenclatura deve ser semântica, previsível e escalável.

Exemplo de famílias:

* `color.*`
* `font.*`
* `space.*`
* `radius.*`
* `border.*`
* `shadow.*`
* `container.*`
* `breakpoint.*`
* `motion.*`
* `state.*`

Recomendação de níveis:

* tokens de fundação;
* tokens semânticos;
* tokens de componente.

Exemplo conceitual:

* fundação: `color.neutral.900`
* semântico: `color.text.primary`
* componente: `button.primary.bg`

---

# 9. Sistema de cores

## 9.1 Função da cor no projeto

A cor, neste sistema, não existe para exuberância gratuita.
Ela precisa desempenhar funções claras:

* organizar hierarquia;
* separar planos;
* sinalizar estados;
* reforçar identidade;
* manter legibilidade;
* sustentar contraste;
* guiar ação.

---

## 9.2 Estrutura mínima da paleta

A paleta deve ser composta por:

### Base neutra

Usada para:

* fundo;
* superfícies;
* texto;
* separadores;
* contraste estrutural.

### Cor primária institucional

Usada para:

* CTAs principais;
* links de destaque;
* elementos ativos;
* foco de ação;
* reforço identitário.

### Cor secundária de apoio

Usada com parcimônia para:

* diferenciação complementar;
* reforços de composição;
* apoio a blocos específicos.

### Cores de estado

Usadas para:

* sucesso;
* atenção;
* erro;
* informação.

---

## 9.3 Regras de uso de cor

### Regra 1 — neutros sustentam a maior parte do sistema

O projeto deve se apoiar fortemente em uma base neutra bem calibrada.

### Regra 2 — a cor primária deve ter função

Ela não deve ser derramada em excesso.
Deve marcar prioridade, ação, identidade e foco.

### Regra 3 — estados precisam ser inequívocos

Erro, sucesso, alerta e informação devem ser visualmente distintos.

### Regra 4 — o painel deve ser mais contido

A área administrativa precisa usar cor com disciplina operacional.

### Regra 5 — o público pode ter maior amplitude controlada

A camada pública pode sustentar um pouco mais de respiro visual, sem quebrar sobriedade.

---

## 9.4 Camadas cromáticas recomendadas

### Fundo global

Plano principal da aplicação.

### Superfície primária

Cards, blocos, painéis, formulários.

### Superfície secundária

Elementos de apoio, agrupamentos, estados sutis.

### Texto principal

Leitura prioritária.

### Texto secundário

Apoio, contexto, metadata.

### Borda/sutileza estrutural

Separação de áreas.

### Ação principal

Botões e links prioritários.

### Ação secundária

Ações auxiliares.

### Destrutivo

Ações irreversíveis ou mensagens de erro grave.

### Sucesso

Confirmações e estados positivos.

### Atenção

Alertas, incompletudes, precauções.

### Informação

Mensagens neutras de orientação.

---

## 9.5 Contraste

O sistema deve priorizar contraste suficiente para:

* texto sobre fundo;
* botões sobre superfície;
* links em contexto editorial;
* foco de teclado;
* estados de erro/sucesso;
* leitura prolongada em páginas públicas e editoriais.

A prioridade é:

* leitura estável;
* distinção clara de estados;
* conforto visual;
* conformidade mínima com acessibilidade.

---

# 10. Tipografia

## 10.1 Princípio tipográfico geral

A tipografia do projeto precisa cumprir quatro funções simultâneas:

* dar identidade;
* garantir legibilidade;
* sustentar hierarquia;
* estabilizar leitura longa e leitura operacional.

O sistema deve evitar:

* excesso de famílias tipográficas;
* fontes decorativas sem função;
* variações exageradas;
* instabilidade de pesos e tamanhos.

---

## 10.2 Estratégia recomendada

### Família principal

Uma fonte principal versátil, altamente legível, adequada tanto para:

* títulos institucionais;
* interface;
* corpo de texto;
* painel administrativo.

### Família secundária

Opcional, apenas se houver justificativa forte para:

* destaque editorial;
* acento institucional controlado.

A recomendação estrutural é:

* usar **uma família principal muito bem explorada**;
* evitar abrir múltiplas assinaturas tipográficas cedo demais.

---

## 10.3 Papéis tipográficos mínimos

O sistema deve possuir, no mínimo, os seguintes papéis:

* display institucional;
* heading 1;
* heading 2;
* heading 3;
* heading 4;
* body large;
* body regular;
* body small;
* label;
* caption;
* mono opcional para contextos técnicos, se necessário.

---

## 10.4 Regras de tipografia

### Títulos

Devem comunicar direção, não espetáculo.

### Corpo

Deve privilegiar leitura contínua e conforto visual.

### Labels

Devem ser claros, compactos e funcionais.

### Metadata

Deve existir, mas nunca competir com o conteúdo principal.

### Painel admin

Deve usar tipografia mais compacta e objetiva.

### Página editorial pública

Deve favorecer leitura longa, ritmo vertical e semântica.

---

## 10.5 Hierarquia tipográfica

A hierarquia deve ser perceptível por:

* tamanho;
* peso;
* espaçamento;
* contexto;
* respiro entre blocos.

Ela **não deve depender apenas de cor**.

---

## 10.6 Leitura longa

Páginas de publicação precisam respeitar:

* largura confortável de linha;
* altura de linha generosa;
* distância adequada entre títulos e parágrafos;
* bom contraste;
* diferenciação clara entre títulos, subtítulos e corpo.

---

# 11. Grid e layout

## 11.1 Função do grid

O grid organiza:

* alinhamento;
* proporção;
* ritmo horizontal;
* distribuição de conteúdo;
* consistência entre telas.

Ele existe para evitar:

* blocos desalinhados;
* hierarquia instável;
* interfaces improvisadas;
* variações arbitrárias entre páginas.

---

## 11.2 Estrutura geral recomendada

### Público

Grid mais respirado, com:

* containers bem definidos;
* largura confortável para leitura;
* seções com respiro;
* possibilidade de composições 1 coluna / 2 colunas / destaques.

### Admin

Grid mais utilitário, com:

* melhor aproveitamento horizontal;
* foco em clareza operacional;
* organização de áreas, tabela, formulário e sidebar.

---

## 11.3 Containers

O sistema deve possuir containers semânticos ao menos para:

* largura padrão pública;
* largura estreita de leitura;
* largura ampla para hero ou seções especiais;
* largura administrativa.

---

## 11.4 Colunas

Recomendação estrutural:

* sistema de 12 colunas como base conceitual;
* uso flexível por contexto;
* sem rigidez cega.

O importante é a coerência entre:

* layout público;
* cards;
* seções;
* listas;
* formulários;
* dashboard.

---

## 11.5 Largura de leitura editorial

As páginas de publicação devem respeitar uma largura de coluna textual que favoreça leitura prolongada.

O corpo do texto não deve ocupar linhas excessivamente longas.

---

# 12. Sistema de espaçamento

## 12.1 Função do espaçamento

Espaçamento é uma das fundações mais importantes do design system.

Ele organiza:

* respiração;
* agrupamento;
* hierarquia;
* percepção de prioridade;
* ritmo de leitura.

---

## 12.2 Escala de espaçamento

O sistema deve possuir uma escala fixa e previsível para:

* microespaçamentos;
* espaçamentos internos;
* espaçamentos entre componentes;
* espaçamentos entre seções;
* espaçamentos de página.

A escala deve ser:

* simples;
* crescente;
* memorável;
* reutilizável.

---

## 12.3 Regras de espaçamento

### Dentro do componente

Precisa haver consistência entre padding, alinhamento e altura útil.

### Entre componentes do mesmo grupo

Deve haver proximidade visual clara.

### Entre grupos distintos

Deve haver separação perceptível.

### Entre seções de página

Deve haver ritmo vertical coerente.

### Em mobile

O espaçamento precisa comprimir sem colapsar a legibilidade.

---

## 12.4 Ritmo vertical

O sistema deve ter ritmo vertical explícito nas páginas públicas, especialmente:

* home;
* listagem de publicações;
* publicação individual;
* páginas legais.

No admin, o ritmo vertical precisa ser:

* mais contido;
* mais funcional;
* menos cênico;
* ainda assim legível.

---

# 13. Raios, bordas e sombras

## 13.1 Função desses elementos

Raios, bordas e sombras ajudam a comunicar:

* agrupamento;
* profundidade;
* separação de superfície;
* clicabilidade;
* estado;
* refinamento.

---

## 13.2 Regras gerais

### Raios

Devem ser consistentes por família de componentes.

### Bordas

Devem ser sutis, mas suficientes para separar superfícies quando necessário.

### Sombras

Devem ser econômicas.
O sistema não deve depender de sombra excessiva para parecer “moderno”.

---

## 13.3 Diretriz estética

O projeto deve preferir:

* solidez;
* superfície clara;
* profundidade discreta;
* materialidade controlada.

Evitar:

* glow excessivo;
* sombras difusas demais;
* bordas decorativas;
* excesso de gradientes sem função.

---

# 14. Ícones e elementos auxiliares

## 14.1 Função dos ícones

Os ícones devem:

* orientar;
* resumir ação;
* reforçar compreensão;
* economizar espaço em contexto operacional.

Eles não devem:

* competir com texto;
* substituir rótulo essencial;
* funcionar como ornamento gratuito.

---

## 14.2 Uso recomendado

### Público

Uso moderado, mais pontual.

### Admin

Uso mais frequente, especialmente em:

* navegação;
* ações;
* estados;
* feedbacks;
* tabelas ou listas operacionais.

---

## 14.3 Regras

* mesma família visual;
* peso coerente;
* tamanhos previsíveis;
* alinhamento com texto;
* contraste suficiente;
* uso consistente por contexto.

---

# 15. Estados de interface

## 15.1 Princípio geral

Uma interface séria precisa prever estados.
O design system deve tratar estados como parte da linguagem visual, e não como improviso tardio.

---

## 15.2 Estados mínimos a serem padronizados

### Interação

* default
* hover
* active
* focus
* disabled

### Carregamento

* skeleton ou loading state
* envio em progresso
* espera de retorno assíncrono

### Sucesso

* confirmação de ação bem-sucedida

### Erro

* erro de validação
* erro de submissão
* erro de leitura

### Atenção

* aviso
* informação incompleta
* ação sensível

### Vazio

* lista vazia
* sem resultados
* ausência de conteúdo

### Restrição

* acesso negado
* sessão expirada
* item indisponível

---

## 15.3 Estado de foco

Foco de teclado deve ser:

* visível;
* consistente;
* contrastante;
* presente em componentes interativos.

Nunca deve ser removido sem substituto acessível.

---

## 15.4 Estado desabilitado

O estado disabled deve comunicar:

* indisponibilidade;
* redução de ênfase;
* impossibilidade de interação.

Mas não deve parecer:

* quebrado;
* invisível;
* ambíguo.

---

# 16. Formulários

## 16.1 Função dos formulários no sistema

Os formulários, especialmente no admin, são centrais para:

* login;
* criação de publicação;
* edição de publicação;
* mudança de status;
* busca e filtros.

---

## 16.2 Princípios

* clareza acima de densidade excessiva;
* labels explícitos;
* mensagens de erro próximas ao campo;
* agrupamento lógico de campos;
* ações primárias e secundárias claramente distintas;
* estado de carregamento visível.

---

## 16.3 Elementos mínimos padronizáveis

* campo de texto;
* textarea;
* select;
* checkbox, se necessário;
* botão primário;
* botão secundário;
* mensagem de erro;
* mensagem de ajuda;
* mensagem de sucesso.

---

## 16.4 Regras

* label não deve depender só de placeholder;
* placeholder não substitui instrução real;
* erro precisa ser claro e localizado;
* ação principal precisa ter destaque inequívoco;
* distância entre campos deve seguir escala consistente.

---

# 17. Botões e ações

## 17.1 Função

Botões organizam prioridade de ação.

---

## 17.2 Hierarquia mínima

### Primário

Ação principal da área.

### Secundário

Ação de apoio.

### Terciário ou ghost

Ação contextual discreta.

### Destrutivo

Ação sensível/irreversível.

---

## 17.3 Regras

* não deve haver múltiplos primários competindo sem motivo;
* ação destrutiva deve ser claramente distinta;
* botão desabilitado precisa parecer desabilitado;
* botões em mobile precisam manter área de toque adequada;
* texto do botão deve ser claro, curto e orientado à ação.

---

# 18. Cards, listas e superfícies

## 18.1 Papel no público

No site público, cards servem para:

* destacar publicações;
* organizar blocos institucionais;
* estruturar navegação editorial.

## 18.2 Papel no admin

No painel, cards servem para:

* resumos operacionais;
* agrupamentos;
* indicadores;
* blocos de atalho.

---

## 18.3 Regras

* card não pode ser apenas um retângulo decorativo;
* cada card precisa ter propósito claro;
* conteúdo interno deve respeitar hierarquia;
* densidade do admin deve ser maior que a do público;
* legibilidade da listagem deve sempre prevalecer.

---

# 19. Tabelas e listagens operacionais

## 19.1 Função

No painel, listagens e tabelas organizam:

* publicações;
* status;
* ações;
* leitura rápida do acervo.

---

## 19.2 Regras

* cabeçalhos claros;
* densidade controlada;
* alinhamento previsível;
* ação contextual visível;
* estados vazios claros;
* comportamento responsivo planejado;
* sem sobrecarregar mobile com tabelas ilegíveis.

---

# 20. Acessibilidade

## 20.1 Princípio geral

Acessibilidade deve ser considerada parte do sistema desde a fundação.

---

## 20.2 Critérios mínimos

* contraste suficiente;
* navegação por teclado;
* foco visível;
* labels consistentes;
* ordem lógica de leitura;
* semântica HTML coerente;
* títulos hierárquicos;
* feedback textual além de cor;
* áreas clicáveis adequadas.

---

## 20.3 Conteúdo editorial

Nas páginas de publicação, atenção especial para:

* legibilidade tipográfica;
* títulos semânticos;
* links compreensíveis;
* bom contraste;
* espaçamento adequado.

---

## 20.4 Admin

No painel, atenção especial para:

* formulário acessível;
* estados visíveis;
* erros claros;
* atalhos e ações discerníveis;
* foco coerente entre campos e botões.

---

# 21. Responsividade

## 21.1 Princípio geral

Responsividade não deve ser tratada como compressão mecânica da interface desktop.

Ela deve reorganizar:

* grid;
* espaçamento;
* hierarquia;
* navegação;
* densidade;
* ações.

---

## 21.2 Público

Em mobile, o site público deve preservar:

* clareza do hero;
* leitura confortável;
* navegação simples;
* boa hierarquia editorial;
* CTAs legíveis.

---

## 21.3 Admin

Em mobile, o painel deve priorizar:

* tarefas essenciais;
* leitura de listagem;
* formulários utilizáveis;
* ações com toque adequado;
* redução de ruído.

O painel pode ser mais contido em mobile, mas não pode se tornar impraticável.

---

## 21.4 Breakpoints

Os breakpoints devem ser padronizados como tokens do sistema e usados de forma consistente.

A decisão central não é “quantos breakpoints”, mas:

* coerência;
* previsibilidade;
* estabilidade entre páginas.

---

# 22. Consistência entre público e admin

## 22.1 O que deve ser compartilhado

* tokens;
* tipografia base;
* cores de estado;
* escala de espaçamento;
* lógica de borda e raio;
* foco;
* comportamento de botão;
* princípios de acessibilidade.

## 22.2 O que pode variar

* densidade;
* ritmo;
* largura de área útil;
* peso narrativo;
* quantidade de informação simultânea;
* protagonismo visual.

## 22.3 Regra central

Público e admin **não devem parecer produtos distintos**.
Devem parecer partes diferentes do mesmo sistema.

---

# 23. Anti-padrões proibidos

Este documento proíbe implicitamente os seguintes erros:

## 23.1 Hardcode visual arbitrário

Não deve haver dispersão de tamanhos, cores e espaçamentos fora dos tokens.

## 23.2 Excesso de ornamento

Efeitos visuais sem função devem ser evitados.

## 23.3 Múltiplas linguagens visuais concorrentes

O sistema precisa parecer uno.

## 23.4 Hierarquia tipográfica instável

Títulos e corpos não podem variar sem regra.

## 23.5 Estados invisíveis ou ambíguos

Erro, foco, loading e disabled precisam ser claros.

## 23.6 Acessibilidade tratada como “ajuste posterior”

Ela deve nascer na base.

## 23.7 Público exuberante e admin cru

Ambos precisam ser coerentes e igualmente projetados, cada um segundo sua função.

---

# 24. Relação deste documento com os próximos artefatos

Este documento prepara diretamente:

## `005_Contratos_de_Componentes.md`

Porque os fundamentos visuais já estão definidos e agora podem ser convertidos em contratos de componente.

## `008_Validacoes_Mensagens_de_Erro_e_Fallbacks.md`

Porque os estados visuais e operacionais já foram enquadrados.

## `016_Arquitetura_Operacional_do_Painel_Admin.md`

Porque a linguagem do admin já ganhou base visual e funcional.

## Implementação futura do frontend

Porque os tokens, grids, escalas e estados já passam a ter direção soberana.

---

# 25. Síntese executiva

A leitura executiva deste design system é:

* o frontend do projeto deve nascer como sistema;
* design é infraestrutura, não acabamento;
* público e admin compartilham base comum;
* tokens são a fonte única de verdade;
* tipografia, grid, espaçamento, cor e estados precisam ser previsíveis;
* acessibilidade e responsividade são critérios fundacionais;
* a estética do projeto deve ser:

  * sóbria;
  * clara;
  * consistente;
  * institucionalmente forte;
  * operacionalmente confiável.

Em linguagem simples:

> o projeto William Albarello não deve “ganhar um visual”; ele deve nascer com uma linguagem visual arquitetada.

---

# 26. Conclusão

Se o blueprint anterior definiu **quais superfícies existem**, este documento define **como essas superfícies devem se comportar visual e semanticamente**.

Ele consolida as seguintes mensagens principais:

1. **o frontend precisa de constituição visual, não de improviso;**
2. **site público e painel devem compartilhar a mesma base sistêmica;**
3. **design deve sustentar identidade, leitura, operação e governança;**
4. **tokens, estados e acessibilidade são parte da arquitetura;**
5. **consistência é ativo estratégico do projeto.**

A mensagem final deste documento é:

> no projeto William Albarello, design não é camada cosmética: é a malha visual, semântica e operacional que permite ao sistema parecer uno, funcionar com clareza e crescer sem perder identidade.

---

