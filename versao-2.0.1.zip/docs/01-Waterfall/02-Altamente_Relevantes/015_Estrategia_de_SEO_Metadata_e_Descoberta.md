---

# `015_Estrategia_de_SEO_Metadata_e_Descoberta.md`

**Endereço canônico:**
`/home/user/Documents/Softwares/Willian Albarello/William Albarello/01-Waterfall/02-Altamente_Relevantes/015_Estrategia_de_SEO_Metadata_e_Descoberta.md`

**Status:**
Gerado no diálogo, em padrão copy/paste.

---

# 015_Estrategia_de_SEO_Metadata_e_Descoberta

## 1. Identificação do documento

Este documento pertence ao diretório `01-Waterfall/02-Altamente_Relevantes` do projeto **William Albarello** e sucede logicamente os artefatos que já consolidaram:

* backlog, sequência de entrega e blueprint do sistema;
* design system e contratos de componentes;
* contratos de módulos;
* estados, eventos e transições;
* validações, erros e fallbacks;
* matriz de permissões;
* dicionário de dados;
* matriz de dependências;
* política de versionamento e compatibilidade;
* estratégia de observabilidade, logs, performance e escalabilidade.

Sua finalidade é estabelecer a **estratégia soberana de SEO, metadata e descoberta orgânica** do projeto, cobrindo:

* metadados;
* canonicalização;
* sitemap;
* robots;
* slugs;
* indexação;
* discoverability;
* diferenciação entre páginas públicas e privadas;
* relação entre publicação, arquitetura e camada pública.

Este documento deve ser lido como a resposta formal à pergunta:

> como o projeto William Albarello deve tornar suas páginas públicas identificáveis, indexáveis, coerentes e descobríveis sem misturar SEO com improviso de interface ou publicação?

---

## 2. Finalidade do documento

O objetivo deste documento é impedir que SEO seja tratado como acabamento tardio, checklist superficial ou plugin conceitualmente separado da arquitetura do sistema.

No projeto William Albarello, SEO não é cosmética de título e descrição.
SEO é:

* governança estrutural da camada pública;
* disciplina de identidade de rota;
* coerência entre conteúdo e visibilidade;
* política de descoberta;
* organização semântica das páginas;
* extensão da arquitetura editorial e institucional.

Este documento existe para:

* definir quais superfícies públicas devem ser indexáveis;
* formalizar metadados mínimos e específicos por tipo de página;
* disciplinar canonicalização;
* organizar a política de sitemap e robots;
* estabelecer a governança de slugs;
* separar páginas públicas de áreas privadas;
* alinhar publicação, visibilidade e indexação;
* reduzir duplicidade, ambiguidade e ruído semântico.

Em linguagem direta:

* **SEO é arquitetura**;
* **descoberta orgânica depende de disciplina**;
* **cada página pública precisa saber quem é**.

---

## 3. Insumos soberanos deste documento

Este documento deriva principalmente dos seguintes artefatos já consolidados:

### Waterfall obrigatório

* `W006` — Requisitos Funcionais
* `W007` — Requisitos Não Funcionais
* `W017` — UI/UX e Arquitetura da Informação
* `W021` — Critérios de Aceite Gerais

### Diretório 02-Diagramas

* `D042` — Diagrama de Fluxo Editorial
* `D043` — Diagrama de Indexação e SEO
* `D045` — Diagrama de Canonicals, Sitemap e Metadata

### Ciclo atual

* `003_Blueprint_de_Telas_Paginas_e_Secoes.md`
* `006_Contratos_de_Modulos.md`
* `007_Estados_Eventos_e_Transicoes.md`
* `010_Dicionario_de_Dados_e_Catalogo_de_Entidades.md`
* `014_Estrategia_de_Performance_e_Escalabilidade.md`

---

## 4. Tese central

A tese central deste documento é:

> no projeto William Albarello, a descoberta orgânica só será madura se cada página pública possuir identidade semântica, política de indexação, canonicalização e metadata coerentes com sua função arquitetural e com o estado editorial do conteúdo que representa.

Isso implica que:

* não basta existir HTML acessível;
* não basta ter título e descrição genéricos;
* não basta publicar conteúdo se a camada pública não o reconhece corretamente;
* canonical, slug, metadata, sitemap e robots precisam conversar entre si;
* o painel administrativo e superfícies privadas não pertencem ao universo indexável;
* a visibilidade pública precisa derivar do estado editorial soberano, não de atalhos informais.

---

## 5. Princípios constitucionais de SEO e descoberta

## 5.1 Toda página pública precisa ter identidade semântica

Se a página é pública e relevante, ela precisa ter:

* título;
* descrição;
* canonical;
* rota clara;
* contexto de indexação.

## 5.2 Nem toda página acessível deve ser indexável

Existência técnica não equivale a elegibilidade de descoberta.

## 5.3 Rota pública precisa ser estável

Mudança de slug sem política de continuidade destrói descoberta, histórico e coerência pública.

## 5.4 A publicação governa a descoberta editorial

Conteúdo não publicado não pertence ao universo indexável.

## 5.5 O privado deve ser explicitamente privado

Painel, preview e áreas internas não devem competir com o público na camada de descoberta.

## 5.6 Canonical não é opcional em sistema com conteúdo público

Ele é parte da disciplina de identidade da página.

## 5.7 Sitemap e robots são artefatos de arquitetura

Não são anexos de deploy sem responsabilidade semântica.

## 5.8 Metadata precisa servir à página real

Não deve haver metadado genérico quando o tipo de página exige especificidade.

---

## 6. Escopo da estratégia

Esta estratégia cobre:

1. identidade semântica das páginas públicas;
2. política de títulos, descrições e metadados;
3. política de canonicalização;
4. política de slugs e URLs públicas;
5. política de sitemap;
6. política de robots;
7. política de indexação por tipo de superfície;
8. relação entre estado editorial e elegibilidade pública;
9. discoverability institucional e editorial;
10. implicações operacionais, de QA e de continuidade.

---

# 7. Topologia pública e universo indexável

## 7.1 Superfícies públicas soberanas

O universo público elegível do projeto, neste estágio, é composto principalmente por:

* `/`
* `/publicacoes`
* `/publicacoes/[slug]`
* `/privacidade`
* `/termos`
* `/404` apenas como página de sistema, não como objetivo de descoberta

### Observação

A página 404 pode existir e ser semântica, mas não é um ativo de descoberta a ser promovido.

---

## 7.2 Superfícies privadas ou não indexáveis

As seguintes superfícies não pertencem ao universo indexável:

* `/painel/login`
* `/painel`
* `/painel/publicacoes`
* `/painel/publicacoes/nova`
* `/painel/publicacoes/[id]/editar`
* `/painel/publicacoes/[id]/preview`
* `/painel/acesso-negado`

### Regra soberana

Toda área administrativa, operacional, de preview ou governança interna deve ser tratada como **não indexável**.

---

## 7.3 Princípio de separação

O projeto deve operar com separação explícita entre:

### Camada pública indexável

* institucional;
* editorial publicada;
* legal pública.

### Camada pública não prioritariamente indexável

* 404;
* respostas de erro;
* estados transitórios.

### Camada privada não indexável

* painel;
* preview;
* autenticação interna;
* rastros de administração.

---

# 8. Identidade semântica por tipo de página

## 8.1 Home pública `/`

### Função semântica

Ser a porta de entrada institucional do domínio principal.

### Requisitos mínimos de SEO

* título institucional soberano;
* descrição institucional clara;
* canonical absoluta;
* marcação semântica coerente de headings;
* possibilidade de preview social coerente;
* conteúdo principal legível e não dependente de script pesado para existir semanticamente.

### Papel na descoberta

* ancoragem da presença institucional;
* distribuição de autoridade interna para o restante das páginas públicas;
* ponto de entrada para navegação editorial.

---

## 8.2 Listagem pública `/publicacoes`

### Função semântica

Organizar o acervo editorial público do projeto como unidade de descoberta e navegação.

### Requisitos mínimos

* título específico de listagem editorial;
* descrição contextual da área;
* canonical própria;
* estrutura clara de listagem;
* links consistentes para as páginas individuais das publicações.

### Papel na descoberta

* consolidar a camada editorial pública;
* distribuir rastreabilidade e navegabilidade ao acervo;
* funcionar como índice humano e rastreável de publicações.

---

## 8.3 Página pública de publicação `/publicacoes/[slug]`

### Função semântica

Materializar cada unidade editorial soberana do projeto.

### Requisitos mínimos

* título específico da publicação;
* descrição específica ou derivada do resumo;
* canonical específica da publicação;
* slug único e estável;
* renderização textual semântica;
* heading principal coerente;
* elegibilidade pública derivada de `status_editorial = published`.

### Papel na descoberta

* unidade principal de indexação editorial;
* objeto central de compartilhamento;
* superfície de autoridade pública por conteúdo.

---

## 8.4 Páginas legais

### Função semântica

Atender exigências mínimas de clareza jurídica e navegabilidade institucional.

### Requisitos mínimos

* título claro;
* descrição simples e coerente;
* canonical própria;
* estrutura textual semântica;
* presença no rodapé e, quando cabível, no sitemap.

### Papel na descoberta

* não são o foco principal de aquisição orgânica, mas fazem parte da integridade pública do domínio.

---

# 9. Política de metadata

## 9.1 Princípio geral

Toda página pública relevante deve possuir metadata derivada de sua função real, e não de um template genérico sem identidade.

---

## 9.2 Camadas mínimas de metadata

O projeto deve tratar, no mínimo, as seguintes camadas:

* título da página;
* descrição;
* canonical;
* metadata social/preview;
* política de indexação;
* identificação contextual do tipo de página.

---

## 9.3 Regras do título

### Regra soberana

O título precisa identificar a página de forma:

* clara;
* específica;
* coerente com sua função;
* distinta o bastante para evitar confusão entre tipos de página.

### Diretriz por tipo

#### Home

Título institucional, representando o projeto como presença principal do domínio.

#### Listagem de publicações

Título que identifique a área editorial/listagem.

#### Publicação individual

Título centrado no conteúdo específico da publicação.

#### Páginas legais

Título funcional e jurídico, sem pretensão editorial.

---

## 9.4 Regras da descrição

### Regra soberana

A descrição deve:

* resumir com clareza a proposta ou o conteúdo da página;
* não repetir mecanicamente o título;
* evitar vaguidão;
* evitar excesso de comprimento ou ambiguidade.

### Diretriz por tipo

#### Home

Síntese institucional do projeto e sua proposta pública.

#### Listagem editorial

Descrição do acervo ou da área de publicações.

#### Publicação individual

Descrição derivada do resumo editorial ou campo específico de SEO.

#### Legal

Descrição simples, funcional e institucional.

---

## 9.5 Regras de metadata social

As páginas públicas principais devem prever camada coerente de compartilhamento social.

### Prioridades

* home pública;
* páginas de publicação.

### Diretrizes

* título coerente com a página;
* descrição coerente;
* imagem social quando houver estratégia de imagem aprovada;
* não usar preview genérico quando a página exigir identidade própria.

---

## 9.6 Regras de fallback de metadata

Quando campos específicos de SEO estiverem ausentes, o sistema deve derivar metadata de forma controlada:

### Publicação

* `seo_titulo` ausente → usar `titulo`
* `seo_descricao` ausente → usar `resumo`
* `og_image_url` ausente → usar política padrão do projeto, se houver

### Regra

Fallback precisa ser:

* previsível;
* coerente;
* semântico;
* não degradante.

---

# 10. Política de canonicalização

## 10.1 Princípio geral

Toda página pública relevante deve saber qual é sua URL canônica soberana.

---

## 10.2 Função do canonical

O canonical existe para:

* afirmar identidade principal da página;
* reduzir ambiguidade de rota;
* evitar duplicidade semântica;
* estabilizar descoberta e referência pública.

---

## 10.3 Regras de canonical por superfície

### Home

Canonical deve apontar para a URL soberana da home pública.

### Listagem editorial

Canonical deve apontar para a URL soberana de `/publicacoes`.

### Publicação individual

Canonical deve apontar para a URL soberana de `/publicacoes/[slug_atual]`.

### Páginas legais

Canonical própria e estável.

---

## 10.4 Relação entre slug e canonical

Canonical editorial depende diretamente de:

* `slug_atual`
* política de rota pública
* estabilidade de identidade da publicação

### Regra soberana

Mudança de slug exige revisão imediata da canonical da publicação.

---

## 10.5 Casos proibidos de canonical

É proibido:

* apontar páginas diferentes para canonical incorreta por conveniência;
* deixar publicação pública sem canonical;
* manter canonical antiga após troca de slug;
* aplicar canonical pública a páginas administrativas;
* permitir que preview interno seja tratado como canonical pública.

---

# 11. Política de slugs e identidade pública de rota

## 11.1 Princípio geral

Slug não é adereço estético.
Slug é identidade pública de rota e, portanto, dado estratégico do sistema.

---

## 11.2 Requisitos do slug

O slug deve ser:

* único;
* estável;
* semanticamente legível;
* compatível com a política de URL do projeto;
* governado pelo histórico da publicação.

---

## 11.3 Fonte de verdade

A fonte de verdade do slug público é:

* `Publicacao.slug_atual`

E sua memória histórica é preservada por:

* `HistoricoSlugPublicacao`

---

## 11.4 Mudança de slug

Mudança de slug só é aceitável quando:

* for deliberada;
* for registrada;
* atualizar canonical;
* atualizar identidade pública da publicação;
* preservar histórico;
* acionar a política de continuidade correspondente.

### Regra soberana

Slug antigo não deve ser simplesmente perdido.

---

## 11.5 Anti-caos de slug

É proibido:

* slug duplicado;
* slug mutável sem rastreabilidade;
* slug gerado sem política semântica mínima;
* publicação pública sem slug válido;
* reuso informal de slug histórico para conteúdo diferente.

---

# 12. Política de sitemap

## 12.1 Princípio geral

O sitemap deve representar o conjunto de páginas públicas elegíveis à descoberta, não o conjunto total de rotas tecnicamente existentes.

---

## 12.2 Conteúdo mínimo do sitemap

Devem ser elegíveis ao sitemap, em regra:

* home pública;
* listagem pública de publicações;
* páginas de publicação em `published`;
* páginas legais públicas, quando a política do projeto assim mantiver.

---

## 12.3 Exclusões do sitemap

Não devem constar no sitemap:

* rotas administrativas;
* login administrativo;
* preview interno;
* páginas privadas;
* conteúdo não publicado;
* conteúdo arquivado, salvo estratégia pública muito específica e deliberada;
* rotas de erro.

---

## 12.4 Regras de atualização do sitemap

O sitemap deve ser atualizado ou recomposto quando ocorrer, ao menos:

* publicação de novo conteúdo;
* arquivamento de conteúdo antes elegível;
* alteração de slug/canonical;
* introdução de nova rota pública soberana.

---

## 12.5 Regra de consistência

Sitemap não pode listar:

* URL inválida;
* rota privada;
* publicação não elegível;
* canonical que já não corresponde à identidade atual da página.

---

# 13. Política de robots

## 13.1 Princípio geral

`robots.txt` deve refletir a política arquitetural de indexação do projeto.

---

## 13.2 Função do robots

O `robots.txt` existe para:

* orientar rastreamento;
* reforçar fronteiras entre público e privado;
* apontar para sitemap;
* reduzir confusão entre camadas do sistema.

---

## 13.3 Regras mínimas

O `robots.txt` deve:

* permitir rastreamento das rotas públicas soberanas, salvo decisão contrária explícita;
* desencorajar ou proibir rastreamento do painel e áreas privadas;
* apontar corretamente para o sitemap público;
* permanecer coerente com a topologia real do domínio.

---

## 13.4 Regras de exclusão

As áreas administrativas devem ser tratadas como não rastreáveis no contexto do projeto:

* `/painel`
* subrotas de `/painel`
* rotas de preview
* qualquer superfície privada de operação

---

## 13.5 Regra de integridade

É proibido:

* manter `robots.txt` contraditório com a intenção real de indexação;
* bloquear acidentalmente a camada pública principal;
* deixar a área administrativa aberta por omissão de política.

---

# 14. Política de indexação por tipo de superfície

## 14.1 Matriz soberana de elegibilidade

| Superfície                                       |            Indexável | Observação                        |
| ------------------------------------------------ | -------------------: | --------------------------------- |
| Home pública `/`                                 |                  Sim | Página institucional principal    |
| Listagem `/publicacoes`                          |                  Sim | Área editorial pública            |
| Publicação `/publicacoes/[slug]` com `published` |                  Sim | Unidade editorial soberana        |
| Publicação não `published`                       |                  Não | Não pertence à descoberta pública |
| `/privacidade`                                   |                  Sim | Página legal pública              |
| `/termos`                                        |                  Sim | Página legal pública              |
| `/404`                                           | Não prioritariamente | Página de sistema                 |
| `/painel/login`                                  |                  Não | Superfície administrativa         |
| `/painel/*`                                      |                  Não | Área privada                      |
| Preview interno                                  |                  Não | Ferramenta administrativa         |

---

## 14.2 Regra de correspondência com estado editorial

### `draft`

Não indexável.

### `review`

Não indexável.

### `ready_to_publish`

Não indexável.

### `published`

Indexável e elegível à camada pública.

### `archived`

Não deve permanecer elegível ao fluxo editorial público corrente.

---

## 14.3 Regra de segurança semântica

O sistema não deve revelar ao visitante ou ao mecanismo de descoberta detalhes internos como:

* “este conteúdo está em review”;
* “este slug existe mas ainda não foi publicado”;
* “este preview está pronto”.

---

# 15. Discoverability institucional e editorial

## 15.1 Princípio geral

Descoberta orgânica não depende apenas de indexar.
Depende de clareza estrutural.

---

## 15.2 Discoverability institucional

A home e eventuais páginas institucionais públicas precisam:

* afirmar claramente o projeto;
* oferecer contexto semântico;
* distribuir navegação para áreas relevantes;
* manter identidade coerente do domínio.

---

## 15.3 Discoverability editorial

A camada editorial precisa:

* possuir listagem clara;
* possuir páginas individuais canônicas;
* operar com slugs coerentes;
* ter metadata derivada do conteúdo real;
* manter consistência entre publicação, sitemap e canonical.

---

## 15.4 Discoverability interna proibida

O painel não deve ser descoberto como conteúdo público.

Preview interno não deve ser descoberto como conteúdo público.

A área administrativa não deve competir com o universo indexável do projeto.

---

# 16. Relação entre publicação, SEO e arquitetura

## 16.1 Regra soberana

SEO do conteúdo editorial depende do workflow editorial, não o substitui.

---

## 16.2 Publicação como evento de descoberta

Quando uma publicação muda para `published`, isso deve impactar, quando aplicável:

* elegibilidade pública;
* canonical;
* sitemap;
* metadata da página;
* discoverability orgânica.

---

## 16.3 Arquivamento como evento de retirada

Quando uma publicação é arquivada, isso deve impactar, quando aplicável:

* sua permanência em listagens públicas;
* sua permanência no sitemap;
* sua elegibilidade de descoberta;
* sua política de resposta pública.

---

## 16.4 Preview não participa de SEO

Preview é ferramenta administrativa e não deve:

* gerar indexação;
* gerar sitemap;
* disputar canonical;
* ser tratado como página pública.

---

# 17. Política de metadata por entidade editorial

## 17.1 Fonte de verdade editorial para SEO

Para publicações, a camada de SEO deve se apoiar prioritariamente em:

* `titulo`
* `resumo`
* `slug_atual`
* `seo_titulo`
* `seo_descricao`
* `og_image_url`
* `status_editorial`

---

## 17.2 Regras de derivação

### Título SEO

* usar `seo_titulo` quando houver
* fallback para `titulo`

### Descrição SEO

* usar `seo_descricao` quando houver
* fallback para `resumo`

### URL pública

* derivar de `slug_atual`

### Elegibilidade

* derivar de `status_editorial = published`

---

## 17.3 Regra de consistência

Metadata não deve contradizer:

* o título principal da publicação;
* o estado editorial;
* a canonical;
* a política pública da rota.

---

# 18. Regras operacionais e de QA para SEO

## 18.1 O que precisa ser validado

A estratégia de SEO precisa ser verificável em QA, ao menos nos seguintes pontos:

* existência de título coerente por página pública;
* descrição coerente;
* canonical correta;
* slug correto;
* exclusão de rotas privadas;
* presença de sitemap consistente;
* coerência de robots;
* comportamento correto de conteúdo arquivado ou não publicado.

---

## 18.2 Casos de validação prioritários

### Home pública

* canonical correta
* título institucional correto
* descrição coerente

### `/publicacoes`

* título de listagem
* canonical
* indexabilidade

### `/publicacoes/[slug]`

* slug correto
* canonical correspondente
* metadata editorial
* não servir conteúdo não publicado

### Painel

* não indexável
* não presente em sitemap
* sem canonical pública indevida

---

## 18.3 Relação com observabilidade

A estratégia de SEO precisa ser acompanhável quando houver automação ou comportamento dinâmico relevante, especialmente em:

* geração/atualização de sitemap;
* mudança de slug;
* publicação/arquivamento;
* inconsistência entre conteúdo publicado e camada pública.

---

# 19. Anti-padrões explicitamente proibidos

Este documento proíbe, de forma expressa:

## 19.1 Tratar SEO como plugin sem arquitetura

SEO precisa derivar da estrutura pública real.

## 19.2 Deixar páginas públicas sem identidade semântica

Página pública sem título, descrição ou canonical coerentes enfraquece descoberta.

## 19.3 Indexar painel ou preview interno

Isso rompe a fronteira entre público e privado.

## 19.4 Tratar qualquer conteúdo existente como conteúdo descobrível

Só conteúdo elegível deve ser indexável.

## 19.5 Trocar slug sem política de continuidade

Isso quebra identidade pública e memória de descoberta.

## 19.6 Sitemap listar o que não deve ser público

Isso produz ruído e incoerência semântica.

## 19.7 Robots contraditório com a política real

Isso transforma descoberta em loteria operacional.

## 19.8 Metadata genérica em todas as páginas

Cada tipo de página precisa saber quem é e o que comunica.

## 19.9 Canonical incorreta ou ausente em páginas públicas relevantes

Isso degrada identidade e clareza semântica.

## 19.10 Confundir discoverability com simples volume de páginas

Descoberta depende de qualidade estrutural, não de proliferação desgovernada.

---

# 20. Relação deste documento com os próximos artefatos

Este documento prepara diretamente:

## `016_Arquitetura_Operacional_do_Painel_Admin.md`

Porque a fronteira entre público e privado agora ficou semanticamente endurecida.

## `017_Procedimentos_de_QA_Manual.md`

Porque SEO, indexação, slugs, canonical e exclusão de rotas privadas precisam ser testados deliberadamente.

## `018_Cenarios_Fim_a_Fim_E2E.md`

Porque os fluxos ponta a ponta precisarão validar a cadeia:

* criar;
* revisar;
* publicar;
* expor;
* retirar da camada pública.

## `020_Ordem_Oficial_de_Geracao_do_Codigo.md`

Porque a implementação real precisa respeitar a precedência entre:

* dados editoriais;
* estado editorial;
* slug;
* metadata;
* canonical;
* sitemap;
* política de robots.

---

# 21. Síntese executiva

A leitura executiva deste documento é:

* o projeto agora possui política explícita de SEO e descoberta;
* canonical, sitemap, robots, metadata e slug deixaram de ser acessórios e passaram a ser partes da arquitetura;
* páginas públicas e privadas foram formalmente separadas;
* a publicação editorial passou a ser a unidade principal de indexação do domínio;
* a elegibilidade pública passou a depender claramente de `status_editorial`;
* painel, preview e áreas internas foram formalmente excluídos do universo indexável;
* discoverability passou a ser tratada como disciplina de identidade e consistência semântica.

Em linguagem simples:

> no projeto William Albarello, SEO não é escrever palavras soltas em meta tags; é garantir que cada página pública tenha identidade, contexto, rota, visibilidade e relação correta com a arquitetura do sistema.

---

# 22. Conclusão

Se a estratégia de performance definiu **como o sistema permanece eficiente**, este documento define **como o sistema se torna semanticamente reconhecível, organizável e descobrível na camada pública**.

Ele consolida oito mensagens principais:

1. **SEO é arquitetura;**
2. **cada página pública precisa saber quem é;**
3. **descoberta orgânica depende de disciplina de rota, metadata e visibilidade;**
4. **canonical é identidade pública, não detalhe opcional;**
5. **slug é dado estratégico;**
6. **sitemap e robots são artefatos estruturais do sistema;**
7. **público e privado não podem se confundir na camada de indexação;**
8. **publicação editorial e descoberta pública precisam evoluir juntas.**

A mensagem final deste documento é:

> no projeto William Albarello, a maturidade da presença digital dependerá da fidelidade com que a arquitetura pública, o workflow editorial e a política de SEO forem mantidos como uma única disciplina coerente, porque somente assim a descoberta orgânica deixará de ser acaso e passará a ser consequência estruturada do próprio sistema.

---

