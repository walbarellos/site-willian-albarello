---

# `018_Cenarios_Fim_a_Fim_E2E.md`

**Endereço canônico:**
`/home/user/Documents/Softwares/Willian Albarello/William Albarello/01-Waterfall/02-Altamente_Relevantes/018_Cenarios_Fim_a_Fim_E2E.md`

**Status:**
Gerado no diálogo, em padrão copy/paste.

---

# 018_Cenarios_Fim_a_Fim_E2E

## 1. Identificação do documento

Este documento pertence ao diretório `01-Waterfall/02-Altamente_Relevantes` do projeto **William Albarello** e sucede logicamente os artefatos que já consolidaram:

* backlog, sequência oficial de entrega e blueprint do sistema;
* design system e contratos de componentes;
* contratos de módulos;
* estados, eventos e transições;
* validações, erros e fallbacks;
* matriz de permissões RBAC/ABAC;
* dicionário de dados;
* matriz de dependências;
* política de versionamento e compatibilidade;
* estratégia de observabilidade, performance e SEO;
* arquitetura operacional do painel administrativo;
* procedimentos de QA manual.

Sua finalidade é consolidar os **cenários ponta a ponta (E2E)** que comprovam funcionamento real do sistema, conectando de forma verificável:

* autenticação;
* sessão;
* permissões;
* fluxo editorial;
* camada pública;
* publicação;
* arquivamento;
* fallback;
* rastreabilidade;
* descoberta pública.

Este documento deve ser lido como a resposta formal à pergunta:

> quais travessias completas o sistema precisa conseguir executar, do começo ao fim, para que possamos dizer que ele realmente existe como produto funcional e governável?

---

## 2. Finalidade do documento

O objetivo deste documento é impedir que o projeto seja considerado “pronto” apenas porque telas abriram, componentes renderizaram ou endpoints responderam isoladamente.

No projeto William Albarello, o sistema só se prova quando fecha ciclos completos, como:

* entrar no painel;
* criar conteúdo;
* revisar;
* publicar;
* exibir no público;
* retirar da camada pública;
* negar acesso indevido;
* expirar sessão corretamente;
* manter coerência entre estado, permissão, URL pública e descoberta.

Este documento existe para:

* modelar cenários reais de negócio e operação;
* amarrar superfícies públicas e privadas;
* orientar QA manual avançado;
* preparar automação futura de E2E;
* reduzir falso positivo de homologação;
* tornar visíveis as dependências entre módulos;
* explicitar pré-condições, passos, resultados esperados, evidências e falhas observáveis.

Em linguagem direta:

* **o sistema só existe quando o fluxo fecha**;
* **E2E prova a travessia inteira**;
* **cenário de negócio, não só clique**.

---

## 3. Insumos soberanos deste documento

Este documento deriva principalmente dos seguintes artefatos já consolidados:

### Waterfall obrigatório

* `W018` — Plano de Testes, Homologação e Qualidade
* `W021` — Critérios de Aceite Gerais
* `W023` — Matriz de Rastreabilidade

### Diretório 02-Diagramas

* `D039` — Diagrama de Fluxo de Sessão
* `D040` — Diagrama de Permissões por Perfil
* `D042` — Diagrama de Fluxo Editorial
* `D044` — Diagrama de Geração e Publicação de Posts
* `D045` — Diagrama de Canonicals, Sitemap e Metadata

### Ciclo atual

* `007_Estados_Eventos_e_Transicoes.md`
* `008_Validacoes_Mensagens_de_Erro_e_Fallbacks.md`
* `009_Matriz_de_Permissoes_RBAC_ABAC.md`
* `015_Estrategia_de_SEO_Metadata_e_Descoberta.md`
* `016_Arquitetura_Operacional_do_Painel_Admin.md`
* `017_Procedimentos_de_QA_Manual.md`

---

## 4. Tese central

A tese central deste documento é:

> no projeto William Albarello, um cenário E2E só é válido quando atravessa camadas reais do sistema, respeita estado, permissão, contrato e efeito visível, produzindo resultado verificável do início ao fim.

Isso implica que:

* cenário E2E não é só sequência de cliques;
* precisa haver objetivo operacional claro;
* o fluxo precisa atravessar as camadas certas;
* o resultado precisa ser observável no local correto;
* falhas precisam ser classificáveis;
* permissão e estado precisam alterar o caminho;
* evidência precisa existir.

---

## 5. Princípios constitucionais dos cenários E2E

## 5.1 O cenário precisa ter começo, meio e fim

Não basta testar uma tela isolada.

## 5.2 O cenário precisa refletir um objetivo real

Cada cenário deve representar uma travessia de negócio, operação, segurança ou governança.

## 5.3 O cenário deve cruzar camadas reais

UI, API, estado, persistência e efeito visível precisam conversar.

## 5.4 O resultado precisa ser verificável

A travessia precisa deixar evidência de sucesso ou falha.

## 5.5 Permissão e estado mudam o cenário

Nem todo usuário percorre o mesmo fluxo.

## 5.6 O cenário precisa prever falha observável

Se o fluxo falhar, deve ficar claro onde falhou e como isso se manifesta.

## 5.7 O público e o admin se encontram no conteúdo publicado

Esse ponto de encontro é central para o projeto.

## 5.8 E2E não substitui QA manual detalhado

Ele consolida as travessias críticas, sem abolir a necessidade de inspeção manual mais ampla.

---

## 6. Estrutura de leitura adotada

Cada cenário deste documento será descrito pelos seguintes campos:

* **Identificador**
* **Nome do cenário**
* **Objetivo**
* **Perfis envolvidos**
* **Pré-condições**
* **Fluxo principal**
* **Resultado esperado**
* **Regras de permissão**
* **Evidências esperadas**
* **Falhas observáveis**
* **Classificação de criticidade**

---

# 7. Catálogo soberano de cenários E2E

Os cenários ponta a ponta mínimos soberanos do projeto, neste estágio, são:

1. Login administrativo bem-sucedido
2. Login administrativo rejeitado
3. Acesso indevido a rota protegida sem autenticação
4. Acesso negado a recurso interno por permissão insuficiente
5. Criação de rascunho editorial
6. Edição de publicação existente
7. Solicitação de revisão editorial
8. Aprovação de revisão para publicação
9. Publicação de conteúdo e exposição na camada pública
10. Arquivamento de publicação e retirada da camada pública
11. Retorno de publicação ao ciclo editorial
12. Preview interno autorizado
13. Preview interno negado
14. Sessão expirada durante operação protegida
15. Publicação com slug inválido ou conflito de slug
16. Coerência de SEO após publicação
17. Coerência de não indexação do painel
18. Fluxo completo soberano de publicação ponta a ponta

---

# 8. Cenários E2E formais

---

## E2E-001 — Login administrativo bem-sucedido

### Objetivo

Comprovar que um operador com credenciais válidas consegue entrar no ambiente interno e chegar ao painel com sessão ativa.

### Perfis envolvidos

* `OPERADOR_EDITORIAL`
* `REVISOR_EDITORIAL`
* `PUBLICADOR_EDITORIAL`
* `ADMINISTRADOR_SISTEMA`

### Pré-condições

* usuário interno ativo existe;
* credenciais válidas conhecidas;
* ambiente do painel acessível;
* endpoint de autenticação funcional.

### Fluxo principal

1. acessar `/painel/login`
2. preencher identificação válida
3. preencher senha válida
4. submeter o formulário
5. aguardar validação
6. ser redirecionado ao painel
7. verificar shell administrativo carregado

### Resultado esperado

* sessão válida é criada;
* painel abre corretamente;
* operador aparece como autenticado;
* navegação administrativa fica disponível conforme perfil.

### Regras de permissão

* apenas usuários internos ativos podem completar o cenário;
* perfil válido precisa existir;
* sessão precisa ser efetivamente iniciada.

### Evidências esperadas

* captura da tela de login preenchida
* captura do painel após redirecionamento
* registro de sessão ativa, quando observável
* rastro auditável de `login_succeeded`, quando acessível

### Falhas observáveis

* submit não responde;
* mensagem ambígua;
* redirecionamento não ocorre;
* painel abre sem contexto;
* sessão não se sustenta.

### Criticidade

**Crítica**

---

## E2E-002 — Login administrativo rejeitado

### Objetivo

Comprovar que credenciais inválidas não produzem sessão válida e que a resposta ao operador é clara.

### Perfis envolvidos

* qualquer usuário ou não usuário tentando autenticar

### Pré-condições

* tela de login acessível

### Fluxo principal

1. acessar `/painel/login`
2. preencher credencial inválida ou senha incorreta
3. submeter
4. observar a resposta

### Resultado esperado

* login é rejeitado;
* sessão não é criada;
* operador permanece fora do painel;
* mensagem de erro é clara;
* novo envio permanece possível.

### Regras de permissão

* credencial inválida não autoriza avanço para qualquer superfície protegida.

### Evidências esperadas

* captura da mensagem de erro
* confirmação de ausência de redirecionamento
* rastro auditável de `login_failed`, quando acessível

### Falhas observáveis

* sistema permite acesso indevido;
* erro genérico demais;
* formulário trava;
* estado da interface fica ambíguo.

### Criticidade

**Crítica**

---

## E2E-003 — Acesso indevido a rota protegida sem autenticação

### Objetivo

Comprovar que rotas internas protegidas não são acessíveis sem sessão válida.

### Perfis envolvidos

* visitante não autenticado

### Pré-condições

* nenhuma sessão válida ativa

### Fluxo principal

1. tentar acessar diretamente `/painel`
2. tentar acessar diretamente `/painel/publicacoes`
3. tentar acessar diretamente `/painel/publicacoes/nova`

### Resultado esperado

* acesso é bloqueado;
* usuário é redirecionado para login ou recebe resposta equivalente segura;
* nenhuma superfície interna sensível é exibida.

### Regras de permissão

* negação por padrão;
* ausência de autenticação impede acesso.

### Evidências esperadas

* capturas do redirecionamento ou bloqueio
* registro das rotas tentadas
* rastro técnico/operacional, quando acessível

### Falhas observáveis

* shell interno aparece parcialmente;
* conteúdo administrativo vaza;
* recurso abre sem login.

### Criticidade

**Crítica**

---

## E2E-004 — Acesso negado a recurso interno por permissão insuficiente

### Objetivo

Comprovar que usuário autenticado, mas sem permissão suficiente, não executa ação ou não acessa área restrita.

### Perfis envolvidos

* um perfil permitido
* um perfil não permitido

### Pré-condições

* usuário autenticado com papel restrito
* recurso/ação protegida existente

### Fluxo principal

1. autenticar com perfil restrito
2. tentar acessar área ou ação reservada
3. observar resposta da UI e do backend

### Resultado esperado

* acesso/ação é negado;
* mensagem ou tela de acesso negado é coerente;
* ação não é concluída;
* recurso permanece íntegro.

### Regras de permissão

* decisão backend-first;
* UI pode refletir bloqueio, mas backend deve confirmar a negação.

### Evidências esperadas

* captura da tentativa
* captura da resposta de acesso negado
* registro de que a ação não ocorreu
* rastro auditável de `access_denied`, quando acessível

### Falhas observáveis

* UI bloqueia, mas backend executa;
* UI promete a ação e falha sem clareza;
* acesso é concedido indevidamente.

### Criticidade

**Crítica**

---

## E2E-005 — Criação de rascunho editorial

### Objetivo

Comprovar que um operador autorizado consegue iniciar uma nova publicação e persisti-la como rascunho.

### Perfis envolvidos

* `OPERADOR_EDITORIAL`
* `ADMINISTRADOR_SISTEMA`

### Pré-condições

* sessão válida;
* permissão `create`;
* ambiente com formulário funcional.

### Fluxo principal

1. entrar no painel
2. navegar para `/painel/publicacoes/nova`
3. preencher título
4. preencher resumo
5. preencher corpo
6. preencher slug válido, quando aplicável
7. salvar como rascunho
8. retornar para listagem ou edição carregada

### Resultado esperado

* publicação é criada;
* estado inicial fica em `draft`;
* item aparece na listagem interna;
* feedback de sucesso é exibido.

### Regras de permissão

* somente perfis com `create` podem completar o cenário.

### Evidências esperadas

* captura do formulário preenchido
* captura da mensagem de sucesso
* captura da listagem com o item em `draft`
* rastro auditável de `publication_created`, quando acessível

### Falhas observáveis

* validação não funciona;
* conteúdo se perde em erro recuperável;
* item não aparece na listagem;
* status inicial incorreto.

### Criticidade

**Alta**

---

## E2E-006 — Edição de publicação existente

### Objetivo

Comprovar que uma publicação existente pode ser carregada, alterada e salva por perfil autorizado.

### Perfis envolvidos

* `OPERADOR_EDITORIAL` em contexto permitido
* `REVISOR_EDITORIAL` ou `ADMINISTRADOR_SISTEMA`, conforme política

### Pré-condições

* publicação existente
* sessão válida
* permissão `update`
* recurso em estado compatível com edição

### Fluxo principal

1. acessar a listagem interna
2. selecionar uma publicação existente
3. abrir `/painel/publicacoes/[id]/editar`
4. alterar conteúdo
5. salvar alteração
6. retornar ou permanecer com feedback de sucesso

### Resultado esperado

* alteração é persistida;
* `updated_at` ou equivalente é atualizado;
* estado permanece coerente;
* item continua consistente na listagem e na tela.

### Regras de permissão

* precisa haver permissão de edição;
* o estado do item precisa comportar edição segundo contrato.

### Evidências esperadas

* captura da edição antes
* captura após alteração
* confirmação do novo conteúdo salvo
* rastro auditável de `publication_updated`, quando acessível

### Falhas observáveis

* item não carrega;
* conflito não tratado;
* alteração não persiste;
* ação permitida incorretamente a perfil inadequado.

### Criticidade

**Alta**

---

## E2E-007 — Solicitação de revisão editorial

### Objetivo

Comprovar que uma publicação em rascunho pode seguir para revisão quando o perfil e o estado permitem.

### Perfis envolvidos

* `OPERADOR_EDITORIAL`
* `ADMINISTRADOR_SISTEMA`

### Pré-condições

* publicação em `draft`
* sessão válida
* permissão para solicitar revisão

### Fluxo principal

1. abrir publicação em `draft`
2. acionar a ação de solicitar revisão
3. confirmar a transição
4. observar novo estado

### Resultado esperado

* publicação muda de `draft` para `review`;
* feedback coerente é exibido;
* listagem interna reflete o novo estado.

### Regras de permissão

* somente perfil autorizado pode solicitar revisão;
* item precisa estar em estado compatível.

### Evidências esperadas

* captura do status anterior
* captura da ação
* captura do status novo
* rastro de `review_requested`, quando acessível

### Falhas observáveis

* transição ocorre sem estado válido;
* status não muda na UI;
* backend rejeita sem explicação coerente.

### Criticidade

**Alta**

---

## E2E-008 — Aprovação de revisão para publicação

### Objetivo

Comprovar que um revisor ou perfil superior consegue mover um item de revisão para pronto para publicação.

### Perfis envolvidos

* `REVISOR_EDITORIAL`
* `PUBLICADOR_EDITORIAL`
* `ADMINISTRADOR_SISTEMA`

### Pré-condições

* publicação em `review`
* sessão válida
* permissão `approve_review`

### Fluxo principal

1. abrir publicação em `review`
2. acionar aprovação de revisão
3. confirmar ação
4. observar mudança para `ready_to_publish`

### Resultado esperado

* item sai de `review` e vai para `ready_to_publish`;
* feedback coerente é mostrado;
* item fica elegível para publicação.

### Regras de permissão

* operador editorial sem permissão apropriada não deve completar o cenário;
* o item precisa estar realmente em `review`.

### Evidências esperadas

* captura do estado anterior
* captura da ação
* captura do estado `ready_to_publish`
* rastro de `review_approved`, quando acessível

### Falhas observáveis

* fluxo aprova do estado errado;
* perfil inadequado consegue aprovar;
* item não reflete novo estado.

### Criticidade

**Alta**

---

## E2E-009 — Publicação de conteúdo e exposição na camada pública

### Objetivo

Comprovar que um item elegível é publicado e aparece corretamente na camada pública.

### Perfis envolvidos

* `PUBLICADOR_EDITORIAL`
* `ADMINISTRADOR_SISTEMA`

### Pré-condições

* publicação em `ready_to_publish`
* slug válido
* sessão válida
* permissão `publish`

### Fluxo principal

1. abrir a publicação pronta para publicar
2. acionar `publish`
3. confirmar a ação
4. observar mudança de status para `published`
5. acessar `/publicacoes`
6. confirmar presença do item na listagem pública
7. acessar `/publicacoes/[slug]`
8. validar a página pública da publicação

### Resultado esperado

* status muda para `published`;
* item aparece em `/publicacoes`;
* slug público resolve corretamente;
* metadata e canonical ficam coerentes;
* conteúdo público corresponde ao publicado.

### Regras de permissão

* apenas perfis autorizados publicam;
* item precisa atender elegibilidade editorial;
* publicação não deve ocorrer com slug inválido.

### Evidências esperadas

* captura da mudança de estado no admin
* captura da listagem pública com o item
* captura da página pública por slug
* registro de canonical/título/descrição, quando verificado
* rastro de `publication_published`, quando acessível

### Falhas observáveis

* status muda, mas item não aparece no público;
* item aparece no público com slug errado;
* página pública resolve com conteúdo incorreto;
* publicação ocorre para perfil indevido.

### Criticidade

**Crítica**

---

## E2E-010 — Arquivamento de publicação e retirada da camada pública

### Objetivo

Comprovar que uma publicação publicada pode ser arquivada e deixa de fazer parte do universo público corrente.

### Perfis envolvidos

* `PUBLICADOR_EDITORIAL`
* `ADMINISTRADOR_SISTEMA`

### Pré-condições

* publicação em `published`
* sessão válida
* permissão `archive`

### Fluxo principal

1. abrir publicação publicada no admin
2. acionar `archive`
3. confirmar ação
4. observar status `archived`
5. acessar `/publicacoes`
6. confirmar retirada do item da listagem
7. tentar acessar `/publicacoes/[slug]`

### Resultado esperado

* item entra em `archived`;
* deixa de figurar na listagem pública;
* rota pública não continua servindo conteúdo como se estivesse publicado, conforme política do sistema.

### Regras de permissão

* somente perfil autorizado arquiva;
* item precisa estar em `published`.

### Evidências esperadas

* captura do status antes/depois
* captura da listagem pública sem o item
* registro do comportamento da rota por slug após arquivamento
* rastro de `publication_archived`, quando acessível

### Falhas observáveis

* item continua público após arquivamento;
* listagem pública fica inconsistente;
* slug antigo continua servindo conteúdo publicado sem política definida.

### Criticidade

**Crítica**

---

## E2E-011 — Retorno de publicação ao ciclo editorial

### Objetivo

Comprovar que um item pode voltar ao ciclo editorial quando a política permitir, sem quebrar coerência do fluxo.

### Perfis envolvidos

* `PUBLICADOR_EDITORIAL`
* `ADMINISTRADOR_SISTEMA`
* eventualmente `REVISOR_EDITORIAL`, conforme política

### Pré-condições

* publicação em `published` ou `archived`
* permissão `restore_to_draft`
* regra contratual permitindo retorno

### Fluxo principal

1. abrir publicação em estado elegível
2. acionar retorno para rascunho
3. confirmar ação
4. observar novo estado
5. verificar camada pública, se aplicável

### Resultado esperado

* item volta para `draft`;
* se estava público, deixa de pertencer à camada pública;
* edição volta a ser possível conforme fluxo;
* rastreabilidade da transição é preservada.

### Regras de permissão

* somente perfis autorizados;
* item precisa estar em estado compatível.

### Evidências esperadas

* captura do status anterior e novo
* evidência de retirada do público, quando aplicável
* rastro de transição correspondente

### Falhas observáveis

* retorno permitido a perfil indevido;
* item muda internamente, mas permanece público;
* fluxo não respeita estado.

### Criticidade

**Alta**

---

## E2E-012 — Preview interno autorizado

### Objetivo

Comprovar que um operador autorizado consegue abrir a visualização interna de uma publicação sem expô-la como pública.

### Perfis envolvidos

* `OPERADOR_EDITORIAL` em contexto permitido
* `REVISOR_EDITORIAL`
* `PUBLICADOR_EDITORIAL`
* `ADMINISTRADOR_SISTEMA`

### Pré-condições

* publicação existente
* sessão válida
* permissão `preview_internal`

### Fluxo principal

1. entrar no painel
2. acessar a publicação
3. acionar preview
4. abrir `/painel/publicacoes/[id]/preview`
5. verificar a renderização interna
6. retornar à edição ou listagem

### Resultado esperado

* preview abre corretamente;
* contexto deixa claro que se trata de visualização interna;
* conteúdo não é tratado como rota pública;
* ação de retorno funciona.

### Regras de permissão

* preview depende de autenticação e permissão;
* não é elegível à camada pública nem à indexação.

### Evidências esperadas

* captura do preview
* evidência da barra/contexto interno
* verificação de ausência de comportamento público indevido
* rastro de `preview_requested`, quando acessível

### Falhas observáveis

* preview abre sem autenticação;
* preview se parece ou se comporta como rota pública;
* operador sem permissão visualiza conteúdo.

### Criticidade

**Alta**

---

## E2E-013 — Preview interno negado

### Objetivo

Comprovar que um usuário sem permissão não consegue abrir preview interno.

### Perfis envolvidos

* perfil sem `preview_internal`

### Pré-condições

* publicação existente
* sessão válida de perfil restrito

### Fluxo principal

1. autenticar com perfil sem permissão
2. tentar abrir preview pela UI ou rota direta
3. observar a resposta

### Resultado esperado

* acesso negado;
* conteúdo não é exibido;
* sistema mantém segurança e clareza da mensagem.

### Regras de permissão

* negação por padrão;
* decisão final do backend.

### Evidências esperadas

* captura da tentativa
* captura da resposta de negação
* rastro de `access_denied`, quando acessível

### Falhas observáveis

* preview abre indevidamente;
* conteúdo parcial vaza;
* UI esconde, mas rota direta funciona.

### Criticidade

**Crítica**

---

## E2E-014 — Sessão expirada durante operação protegida

### Objetivo

Comprovar que uma sessão expirada interrompe corretamente uma ação protegida e exige reautenticação.

### Perfis envolvidos

* qualquer perfil interno autenticado

### Pré-condições

* sessão válida inicialmente
* ambiente que permita simular ou provocar expiração

### Fluxo principal

1. entrar no painel
2. abrir uma tela protegida
3. deixar a sessão expirar ou invalidá-la
4. tentar salvar, navegar ou executar ação protegida
5. observar resposta

### Resultado esperado

* ação é interrompida;
* operador é informado da expiração;
* reentrada é exigida;
* o sistema não finge ter concluído a operação.

### Regras de permissão

* sessão expirada invalida ação protegida, mesmo que o perfil em tese pudesse executá-la.

### Evidências esperadas

* registro do momento anterior à expiração
* captura da mensagem de sessão expirada
* confirmação de que a ação protegida não foi concluída
* rastro de `session_expired`, quando acessível

### Falhas observáveis

* ação prossegue com sessão inválida;
* UI aparenta sucesso sem persistência;
* operador permanece navegando como autenticado.

### Criticidade

**Crítica**

---

## E2E-015 — Publicação com slug inválido ou conflito de slug

### Objetivo

Comprovar que o sistema bloqueia publicação incoerente quando o slug está inválido ou em conflito.

### Perfis envolvidos

* `PUBLICADOR_EDITORIAL`
* `ADMINISTRADOR_SISTEMA`

### Pré-condições

* item pronto para publicar
* slug inválido ou colidente configurado para teste

### Fluxo principal

1. preparar item com slug inadequado
2. tentar publicar
3. observar validação e resposta

### Resultado esperado

* publicação é bloqueada;
* mensagem é clara;
* item não entra em `published`;
* camada pública não é afetada.

### Regras de permissão

* mesmo perfil autorizado a publicar não pode vencer a validação estrutural do slug.

### Evidências esperadas

* captura da tentativa
* captura da mensagem de erro
* prova de que o item não foi publicado
* registro de falha contratual

### Falhas observáveis

* item publica com slug inválido;
* colisão de slug não é detectada;
* estado muda parcialmente e camada pública fica inconsistente.

### Criticidade

**Crítica**

---

## E2E-016 — Coerência de SEO após publicação

### Objetivo

Comprovar que publicar um item gera efeito coerente na camada semântica pública.

### Perfis envolvidos

* `PUBLICADOR_EDITORIAL`
* `ADMINISTRADOR_SISTEMA`
* visitante público como consumidor final

### Pré-condições

* item elegível para publicação
* publicação realizada com sucesso

### Fluxo principal

1. publicar o item
2. abrir a página pública da publicação
3. verificar título da página
4. verificar descrição
5. verificar canonical
6. verificar presença coerente em `/publicacoes`
7. verificar elegibilidade em sitemap, quando o ambiente permitir

### Resultado esperado

* página pública possui identidade semântica coerente;
* canonical corresponde ao slug atual;
* publicação integra o universo público indexável;
* não há conflito entre metadata e estado editorial.

### Regras de permissão

* a cadeia só se consolida após publicação válida.

### Evidências esperadas

* captura da página pública
* inspeção manual de metadata
* verificação de canonical
* verificação de sitemap, quando aplicável

### Falhas observáveis

* título genérico incorreto;
* canonical errada ou ausente;
* item publicado fora da listagem;
* sitemap desatualizado ou incoerente.

### Criticidade

**Alta**

---

## E2E-017 — Coerência de não indexação do painel

### Objetivo

Comprovar que superfícies administrativas e de preview não entram no universo indexável do projeto.

### Perfis envolvidos

* visitante público
* operador interno
* QA técnico

### Pré-condições

* ambiente com páginas admin acessíveis internamente
* possibilidade de inspecionar metadata/robots/sitemap

### Fluxo principal

1. acessar rotas do painel
2. verificar que não são tratadas como páginas públicas elegíveis
3. verificar `robots.txt`
4. verificar `sitemap.xml`
5. verificar preview interno

### Resultado esperado

* painel e preview não aparecem no sitemap;
* `robots.txt` é coerente com a política;
* superfícies internas não recebem tratamento semântico de descoberta pública.

### Regras de permissão

* além da não indexação, as áreas continuam protegidas por autenticação.

### Evidências esperadas

* evidência de ausência das rotas privadas no sitemap
* evidência da política de robots
* observação de metadata/contexto das rotas internas

### Falhas observáveis

* rota administrativa indexável;
* preview tratado como página pública;
* sitemap listando superfícies privadas.

### Criticidade

**Crítica**

---

## E2E-018 — Fluxo completo soberano de publicação ponta a ponta

### Objetivo

Comprovar a travessia integral do sistema, do login à exposição pública, e depois à retirada controlada da camada pública.

### Perfis envolvidos

* `OPERADOR_EDITORIAL`
* `REVISOR_EDITORIAL`
* `PUBLICADOR_EDITORIAL`
* visitante público
* `ADMINISTRADOR_SISTEMA`, em cenário alternativo consolidado

### Pré-condições

* todos os perfis necessários disponíveis
* ambiente estável
* massa mínima de dados
* observabilidade mínima acessível, quando aplicável

### Fluxo principal

1. operador editorial faz login
2. cria nova publicação em `draft`
3. edita e salva o conteúdo
4. solicita revisão
5. revisor faz login e aprova a revisão
6. item passa a `ready_to_publish`
7. publicador faz login
8. abre preview interno
9. publica o item
10. visitante público acessa `/publicacoes`
11. visitante acessa `/publicacoes/[slug]`
12. verificar metadata/canonical
13. publicador arquiva o item
14. visitante deixa de encontrar o item no fluxo público corrente

### Resultado esperado

* todas as transições respeitam estado e permissão;
* o conteúdo nasce internamente, cruza revisão, alcança a camada pública e é retirado corretamente;
* não há confusão entre preview e público;
* não há exposição indevida antes da publicação;
* há rastros e sinais coerentes ao longo da travessia.

### Regras de permissão

* cada papel executa apenas sua parte;
* perfis indevidos não devem completar passos críticos;
* administrador pode executar o fluxo completo, respeitando invariantes.

### Evidências esperadas

* sequência de capturas das etapas principais
* tabela de status por etapa
* verificação do conteúdo na listagem pública
* verificação da página pública
* verificação da retirada após arquivamento
* referências de logs/auditoria/correlation ids, quando acessíveis

### Falhas observáveis

* qualquer ruptura do fluxo;
* mudança de estado sem efeito público correspondente;
* publicação sem revisão no fluxo que a exige;
* visibilidade pública prematura;
* item arquivado permanecendo público;
* erro de permissão permitindo salto indevido de papel.

### Criticidade

**Crítica máxima / cenária soberana de homologação**

---

# 9. Matriz resumida dos cenários por camada

## 9.1 Camadas cobertas

| Cenário | Público | Admin | Auth/Sessão | Permissão | API | Dados | SEO | Auditoria |
| ------- | ------: | ----: | ----------: | --------: | --: | ----: | --: | --------: |
| E2E-001 |       — |   Sim |         Sim |       Sim | Sim |   Sim |   — |       Sim |
| E2E-002 |       — |   Sim |         Sim |         — | Sim |   Sim |   — |       Sim |
| E2E-003 |       — |   Sim |         Sim |       Sim | Sim |     — |   — |  Opcional |
| E2E-004 |       — |   Sim |         Sim |       Sim | Sim |     — |   — |       Sim |
| E2E-005 |       — |   Sim |         Sim |       Sim | Sim |   Sim |   — |       Sim |
| E2E-006 |       — |   Sim |         Sim |       Sim | Sim |   Sim |   — |       Sim |
| E2E-007 |       — |   Sim |         Sim |       Sim | Sim |   Sim |   — |       Sim |
| E2E-008 |       — |   Sim |         Sim |       Sim | Sim |   Sim |   — |       Sim |
| E2E-009 |     Sim |   Sim |         Sim |       Sim | Sim |   Sim | Sim |       Sim |
| E2E-010 |     Sim |   Sim |         Sim |       Sim | Sim |   Sim | Sim |       Sim |
| E2E-011 |     Sim |   Sim |         Sim |       Sim | Sim |   Sim | Sim |       Sim |
| E2E-012 |       — |   Sim |         Sim |       Sim | Sim |   Sim |   — |       Sim |
| E2E-013 |       — |   Sim |         Sim |       Sim | Sim |     — |   — |       Sim |
| E2E-014 |       — |   Sim |         Sim |       Sim | Sim |     — |   — |       Sim |
| E2E-015 |       — |   Sim |         Sim |       Sim | Sim |   Sim | Sim |       Sim |
| E2E-016 |     Sim |   Sim |           — |         — | Sim |   Sim | Sim |  Opcional |
| E2E-017 |     Sim |   Sim |         Sim |       Sim |   — |     — | Sim |         — |
| E2E-018 |     Sim |   Sim |         Sim |       Sim | Sim |   Sim | Sim |       Sim |

---

# 10. Critérios de aprovação dos cenários E2E

## 10.1 Regra geral

Um cenário E2E é considerado **aprovado** quando:

* todas as pré-condições são satisfeitas;
* o fluxo principal é executado sem ruptura indevida;
* o resultado esperado é observado integralmente;
* permissões são respeitadas;
* efeitos públicos e internos permanecem coerentes;
* não há falha crítica mascarada por fallback silencioso.

---

## 10.2 Aprovado com ressalvas

Pode ocorrer quando:

* o fluxo principal fecha;
* existe falha não bloqueante;
* a falha não compromete segurança, permissão, estado, descoberta ou integridade do conteúdo;
* há plano claro de correção.

---

## 10.3 Reprovado

O cenário deve ser reprovado quando houver, por exemplo:

* ação crítica executada por perfil indevido;
* conteúdo não publicado aparecendo publicamente;
* conteúdo publicado não aparecendo quando deveria;
* sessão expirada tratada como válida;
* preview acessível indevidamente;
* slug/canonical incoerentes no fluxo editorial;
* falha semântica que destrói a travessia do cenário.

---

# 11. Evidência mínima por cenário

Cada cenário executado deve registrar, no mínimo:

* identificador do cenário
* data/hora
* ambiente
* versão/release
* perfis utilizados
* pré-condições confirmadas
* passos executados
* resultado esperado
* resultado obtido
* status final:

  * aprovado
  * aprovado com ressalvas
  * falhou
* evidências anexas ou referenciadas

---

## 11.1 Tipos recomendados de evidência

* capturas de tela por etapa
* vídeo curto do fluxo, quando útil
* tabela de estados/transições
* capturas de metadata/canonical
* referência a logs, `request_id` ou `correlation_id`
* anotação de falha e severidade

---

# 12. Relação entre E2E e QA manual

## 12.1 Diferença de papel

### QA manual

Mais amplo, mais exploratório, cobre comportamento, UX, responsividade, fallback e inspeção qualitativa.

### E2E

Mais concentrado em travessias soberanas que comprovam funcionamento integrado.

---

## 12.2 Regra de convivência

O projeto não deve escolher entre os dois.
Deve usar:

* QA manual para leitura ampla e disciplinada;
* E2E para provar fluxos centrais de negócio e operação.

---

# 13. Falhas observáveis críticas por cenário

As seguintes falhas, quando observadas em qualquer cenário relevante, devem ser tratadas como bloqueadoras de homologação séria:

* login bem-sucedido sem sessão válida real
* acesso a rota interna sem autenticação
* acesso a ação crítica por perfil não autorizado
* transição editorial proibida sendo aceita
* publicação pública sem passar pelo fluxo exigido
* preview exposto como público
* publicação arquivada permanecendo elegível publicamente
* painel ou preview indexável
* slug/canonical inconsistentes após publicação
* ausência total de rastro mínimo em ação auditável crítica, quando a camada estiver disponível

---

# 14. Ordem recomendada de execução dos E2E

A ordem mais inteligente de execução é:

## Onda 1 — Acesso e segurança básica

* E2E-001
* E2E-002
* E2E-003
* E2E-004

## Onda 2 — Operação editorial básica

* E2E-005
* E2E-006
* E2E-012
* E2E-013

## Onda 3 — Governança editorial

* E2E-007
* E2E-008
* E2E-015

## Onda 4 — Exposição pública e retirada

* E2E-009
* E2E-010
* E2E-011
* E2E-016
* E2E-017

## Onda 5 — Fluxo soberano total

* E2E-014
* E2E-018

---

# 15. Anti-padrões explicitamente proibidos

Este documento proíbe, de forma expressa:

## 15.1 Chamar de E2E um teste que não fecha o fluxo

Se não há travessia real, não há E2E.

## 15.2 Testar só UI sem verificar efeito visível do outro lado

A ação precisa produzir consequência observável.

## 15.3 Ignorar permissão no cenário

E2E sem permissão é travessia incompleta.

## 15.4 Ignorar SEO e camada pública no cenário de publicação

Publicar sem verificar exposição pública é meio fluxo.

## 15.5 Ignorar retirada pública no arquivamento

Arquivar sem validar o efeito externo não prova o sistema.

## 15.6 Aceitar fallback como se fosse fechamento correto do fluxo

Fallback pode preservar experiência, mas não substitui o resultado esperado do cenário.

## 15.7 Executar cenário sem massa de dados ou pré-condição conhecida

Isso compromete leitura e rastreabilidade.

## 15.8 Não registrar evidência do cenário

Sem evidência, o cenário vira relato oral.

## 15.9 Tratar cenário soberano E2E-018 como opcional para maturidade final

Ele é um dos principais testes de existência real do sistema.

---

# 16. Relação deste documento com os próximos artefatos

Este documento prepara diretamente:

## `019_Superprompts_de_Geracao_por_Bloco.md`

Porque os superprompts futuros poderão incorporar cenários E2E como critério de qualidade embutido.

## `020_Ordem_Oficial_de_Geracao_do_Codigo.md`

Porque a sequência oficial de geração do código precisa respeitar os fluxos que deverão fechar ponta a ponta.

---

# 17. Síntese executiva

A leitura executiva deste documento é:

* o projeto agora possui catálogo soberano de cenários E2E;
* login, permissão, criação, revisão, publicação, exposição pública, arquivamento, preview, sessão expirada e SEO foram convertidos em travessias verificáveis;
* cada cenário recebeu:

  * objetivo;
  * pré-condição;
  * fluxo;
  * resultado esperado;
  * regras de permissão;
  * evidência;
  * falhas observáveis;
  * criticidade;
* o cenário de publicação deixou de ser hipótese e passou a ter prova ponta a ponta;
* a relação entre público e admin foi formalizada como travessia, não como abstração.

Em linguagem simples:

> no projeto William Albarello, E2E serve para provar que o sistema não apenas possui peças, mas consegue atravessar seus fluxos centrais do início ao fim com integridade, restrição, efeito visível e coerência arquitetural.

---

# 18. Conclusão

Se os procedimentos de QA manual definiram **como testar com rigor**, este documento define **quais travessias completas precisam existir para que o sistema seja considerado real e não apenas parcialmente montado**.

Ele consolida oito mensagens principais:

1. **o sistema só existe quando o fluxo fecha;**
2. **E2E prova a travessia inteira;**
3. **cenário de negócio não é sequência aleatória de clique;**
4. **publicação só está provada quando chega ao público corretamente;**
5. **arquivamento só está provado quando retira do público corretamente;**
6. **permissão, sessão e preview precisam entrar no E2E;**
7. **SEO e identidade pública fazem parte da travessia editorial;**
8. **evidência e criticidade tornam o E2E governável.**

A mensagem final deste documento é:

> no projeto William Albarello, a maturidade do sistema será comprovada quando os cenários ponta a ponta conseguirem atravessar autenticação, operação editorial, publicação, camada pública, restrição, retirada e rastreabilidade sem quebrar contrato, porque é nesse ponto que a arquitetura deixa de ser promessa e passa a ser software real.

---

