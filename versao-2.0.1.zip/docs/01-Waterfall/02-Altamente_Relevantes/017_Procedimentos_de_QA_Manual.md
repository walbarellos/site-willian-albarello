---

# `017_Procedimentos_de_QA_Manual.md`

**Endereço canônico:**
`/home/user/Documents/Softwares/Willian Albarello/William Albarello/01-Waterfall/02-Altamente_Relevantes/017_Procedimentos_de_QA_Manual.md`

**Status:**
Gerado no diálogo, em padrão copy/paste.

---

# 017_Procedimentos_de_QA_Manual

## 1. Identificação do documento

Este documento pertence ao diretório `01-Waterfall/02-Altamente_Relevantes` do projeto **William Albarello** e sucede logicamente os artefatos que já consolidaram:

* backlog, sequência oficial de entrega e blueprint do sistema;
* design system e contratos de componentes;
* contratos de módulos;
* estados, eventos e transições;
* validações, erros e fallbacks;
* matriz de permissões RBAC/ABAC;
* dicionário de dados;
* matriz de dependências;
* política de versionamento e compatibilidade;
* estratégia de observabilidade, performance e SEO;
* arquitetura operacional do painel administrativo.

Sua finalidade é estabelecer o **protocolo soberano de QA manual** do projeto, definindo:

* roteiro de verificação;
* smoke tests;
* testes funcionais e regressivos;
* cenários críticos;
* validação de sessão e permissão;
* validação editorial;
* validação de SEO e descoberta;
* validação de erro e fallback;
* validação de responsividade;
* critérios de aprovação;
* evidências esperadas;
* leitura disciplinada de falhas.

Este documento deve ser lido como a resposta formal à pergunta:

> como validar manualmente o sistema William Albarello com rigor, método e rastreabilidade, antes ou além da automação total?

---

## 2. Finalidade do documento

O objetivo deste documento é impedir que a homologação do projeto seja conduzida de forma impressionista, fragmentada ou baseada apenas no “abriu aqui, então parece bom”.

No projeto William Albarello, QA manual não é etapa inferior à automação.
Ele é:

* instrumento de leitura real da experiência;
* mecanismo de validação de fluxo;
* prova de coerência entre arquitetura e execução;
* proteção contra regressão conceitual;
* filtro entre “parece funcionar” e “está operacionalmente confiável”.

Este documento existe para:

* formalizar o modo de testar;
* identificar rotas críticas;
* organizar checklists por camada do sistema;
* transformar critérios de aceite em prática verificável;
* estruturar evidência mínima de homologação;
* distinguir falha crítica de observação menor;
* orientar leitura de erro, degradação e comportamento inesperado;
* preparar o terreno para E2E, release e operação.

Em linguagem direta:

* **QA manual ainda é soberano**;
* **testar caminho feliz não basta**;
* **homologação precisa de protocolo**.

---

## 3. Insumos soberanos deste documento

Este documento deriva principalmente dos seguintes artefatos já consolidados:

### Waterfall obrigatório

* `W018` — Plano de Testes, Homologação e Qualidade
* `W021` — Critérios de Aceite Gerais
* `W022` — Plano de Implantação, Rollback e Suporte

### Diretório 02-Diagramas

* `D031` — Diagrama de Fluxo do Painel Interno
* `D032` — Diagrama de Deploy Vercel/Render
* `D033` — Diagrama de Infraestrutura Geral
* `D034` — Diagrama de DNS, Domínio e Subdomínios
* `D035` — Diagrama de CI/CD
* `D036` — Diagrama de Observabilidade e Logs
* `D037` — Diagrama de Disponibilidade e Recuperação
* `D038` — Diagrama de Segurança da Aplicação
* `D039` — Diagrama de Fluxo de Sessão
* `D040` — Diagrama de Permissões por Perfil
* `D041` — Diagrama de Auditoria e Rastreabilidade
* `D042` — Diagrama de Fluxo Editorial
* `D043` — Diagrama de Indexação e SEO
* `D044` — Diagrama de Geração e Publicação de Posts
* `D045` — Diagrama de Canonicals, Sitemap e Metadata

### Ciclo atual

* `007_Estados_Eventos_e_Transicoes.md`
* `008_Validacoes_Mensagens_de_Erro_e_Fallbacks.md`
* `009_Matriz_de_Permissoes_RBAC_ABAC.md`
* `010_Dicionario_de_Dados_e_Catalogo_de_Entidades.md`
* `013_Estrategia_de_Observabilidade_e_Logs.md`
* `014_Estrategia_de_Performance_e_Escalabilidade.md`
* `015_Estrategia_de_SEO_Metadata_e_Descoberta.md`
* `016_Arquitetura_Operacional_do_Painel_Admin.md`

---

## 4. Tese central

A tese central deste documento é:

> no projeto William Albarello, QA manual é disciplina de verificação operacional e arquitetural, e não mera checagem visual do caminho feliz.

Isso implica que:

* toda homologação precisa de roteiro;
* toda falha precisa ser classificada;
* o sistema deve ser testado por fluxo, não por clique isolado;
* público e admin exigem critérios diferentes;
* permissão, estado, sessão e descoberta pública precisam ser testados deliberadamente;
* falha de fallback, canonical, preview ou acesso negado é falha real, não detalhe cosmético;
* evidência importa.

---

## 5. Princípios constitucionais do QA manual

## 5.1 QA precisa validar comportamento real

A validação deve observar o sistema em uso, não apenas a intenção do código.

## 5.2 Caminho feliz é insuficiente

Todo fluxo crítico precisa ser testado também em:

* erro;
* permissão negada;
* estado inválido;
* ausência de conteúdo;
* sessão expirada;
* indisponibilidade parcial.

## 5.3 Evidência é parte do teste

Teste sem evidência tende a virar opinião.

## 5.4 O sistema deve ser lido por contexto

Uma mesma falha pesa diferente no:

* site público;
* painel;
* API;
* SEO;
* operação;
* segurança.

## 5.5 Falha precisa ser classificada

Nem toda falha bloqueia release, mas toda falha precisa ser entendida.

## 5.6 O painel deve ser testado como ambiente de trabalho

Não basta abrir as telas; é preciso operar.

## 5.7 SEO e camada pública precisam ser testados estruturalmente

Não basta a página “aparecer”; ela precisa saber quem é.

## 5.8 Responsividade é comportamento, não compressão

Mobile não é desktop encolhido.

---

## 6. Escopo do protocolo de QA manual

Este protocolo cobre:

1. smoke tests básicos;
2. validação do site público;
3. validação do painel administrativo;
4. validação de sessão e permissão;
5. validação editorial ponta a ponta;
6. validação de erros, estados vazios e fallbacks;
7. validação de SEO e descoberta;
8. validação de observabilidade mínima;
9. validação de responsividade;
10. critérios de aprovação e evidência.

---

# 7. Estrutura geral do protocolo

O QA manual será organizado em cinco níveis de leitura:

## 7.1 Nível 1 — Smoke

Verifica se o sistema está vivo e minimamente navegável.

## 7.2 Nível 2 — Fluxo funcional básico

Verifica os percursos principais do público e do admin.

## 7.3 Nível 3 — Governança e restrição

Verifica sessão, permissão, transição de estado, acesso negado e auditoria.

## 7.4 Nível 4 — Robustez e degradação

Verifica falhas previsíveis, estados vazios, conflitos, expiração e fallbacks.

## 7.5 Nível 5 — Qualidade transversal

Verifica SEO, responsividade, observabilidade, consistência e performance percebida.

---

# 8. Condições mínimas antes de iniciar o QA

Antes de qualquer rodada formal de QA manual, devem estar claros:

* ambiente alvo: local, staging ou produção controlada;
* versão ou release sob teste;
* data/hora da rodada;
* quem executou o teste;
* escopo da rodada;
* perfis disponíveis para teste;
* massa mínima de dados/editoriais existente;
* política de evidência;
* canal de registro de falha.

---

## 8.1 Pré-requisitos técnicos mínimos

O ambiente sob teste deve possuir, no mínimo:

* site público acessível;
* painel acessível;
* login administrativo operacional;
* API minimamente estável;
* ao menos uma publicação de teste;
* ao menos um usuário com papel editorial;
* ao menos um fluxo público rastreável;
* observabilidade mínima acessível para leitura de falha, quando necessário.

---

## 8.2 Perfis mínimos para teste

Recomenda-se, no mínimo, testar com:

* visitante público;
* operador editorial;
* revisor editorial;
* publicador editorial;
* administrador do sistema.

Quando aplicável:

* auditor interno.

---

# 9. Smoke test soberano

O smoke test verifica se o sistema pode ser considerado “testável”.

## 9.1 Checklist de smoke público

### Home pública

* abre sem erro bruto
* header aparece
* footer aparece
* conteúdo principal é legível
* página não colapsa em branco

### Listagem pública `/publicacoes`

* rota abre
* estado é coerente com existência ou ausência de conteúdo
* não há erro técnico visível indevido

### Publicação pública `/publicacoes/[slug]`

* uma publicação publicada abre corretamente
* slug inválido gera comportamento coerente

### Páginas legais

* `/privacidade` abre
* `/termos` abre

---

## 9.2 Checklist de smoke admin

### Login

* tela abre
* campos são visíveis
* submissão responde
* erro de credencial inválida é tratável
* sucesso leva ao painel

### Dashboard

* ambiente interno abre
* shell do admin aparece
* navegação principal aparece
* não há colapso imediato

### Listagem interna

* `/painel/publicacoes` abre para perfil permitido
* ao menos um dos estados a seguir é coerente:

  * lista com itens
  * lista vazia
  * erro localizado

### Nova publicação

* tela abre
* formulário é visível
* ações são compreensíveis

---

## 9.3 Critério de aprovação do smoke

O smoke é aprovado quando:

* público está navegável;
* painel entra com sessão válida;
* ao menos um fluxo editorial mínimo pode ser iniciado;
* não há falha catastrófica imediata nas rotas centrais.

---

# 10. QA manual do site público

## 10.1 Objetivo

Verificar se a camada pública do sistema:

* comunica o projeto;
* navega com coerência;
* apresenta conteúdo publicado corretamente;
* responde bem a vazio, erro e indisponibilidade;
* sustenta a identidade semântica esperada.

---

## 10.2 Checklist da home pública

Verificar:

* a home abre corretamente;
* hero institucional é legível;
* título principal existe;
* navegação principal funciona;
* rodapé contém links esperados;
* o bloco de ponte para publicações está coerente;
* ausência de destaques editoriais, se ocorrer, gera fallback correto;
* a página não depende de carregamento excessivo para fazer sentido.

### Evidência esperada

* captura da home carregada
* anotação de links testados
* anotação de eventuais falhas de layout ou semântica

---

## 10.3 Checklist da listagem pública `/publicacoes`

Verificar:

* título da página é coerente;
* listagem mostra apenas itens publicados;
* estado vazio é tratado adequadamente, se não houver itens;
* falha de carregamento, se simulada ou observada, não se confunde com lista vazia;
* links para publicações funcionam;
* paginação ou continuidade, se existir, opera corretamente.

### Evidência esperada

* captura da listagem
* evidência de clique em item válido
* observação do comportamento em lista vazia, se aplicável

---

## 10.4 Checklist da publicação individual `/publicacoes/[slug]`

Verificar:

* slug válido resolve publicação correta;
* título da publicação é exibido;
* resumo, se houver, está coerente;
* corpo é legível e semântico;
* link de retorno ou continuidade existe, se previsto;
* publicação arquivada ou não publicada não é servida como pública;
* slug inexistente resulta em comportamento coerente.

### Evidência esperada

* captura da publicação válida
* registro do teste com slug inválido
* anotação de canonical, título e descrição, quando aplicável

---

## 10.5 Checklist das páginas legais

Verificar:

* conteúdo abre;
* hierarquia textual faz sentido;
* links no rodapé apontam corretamente;
* canonical e título são coerentes, quando verificados.

---

# 11. QA manual do painel administrativo

## 11.1 Objetivo

Verificar se o painel opera como ambiente interno real e não apenas como conjunto de telas conectadas.

---

## 11.2 Checklist do login

Verificar:

* campo de acesso funciona;
* campo de senha funciona;
* submit vazio é bloqueado;
* credenciais inválidas geram mensagem coerente;
* credenciais válidas iniciam sessão;
* login não “trava” em submit duplicado;
* sessão iniciada leva ao painel correto.

### Evidência esperada

* captura do login inválido
* captura ou registro do login bem-sucedido
* anotação da mensagem exibida

---

## 11.3 Checklist do dashboard

Verificar:

* operador autenticado vê o dashboard;
* identificação do ambiente interno está clara;
* navegação está funcional;
* cards/blocos de resumo refletem estado coerente;
* ausência de dados editoriais gera estado vazio apropriado;
* falha localizada não derruba o painel inteiro.

### Evidência esperada

* captura do dashboard
* anotação dos blocos visíveis
* observação de estado vazio, quando aplicável

---

## 11.4 Checklist da listagem interna de publicações

Verificar:

* rota abre para perfil permitido;
* tabela ou lista exibe dados coerentes;
* status da publicação aparece corretamente;
* ações por linha são compreensíveis;
* sem itens, o estado vazio é útil;
* sem permissão, o acesso é negado adequadamente;
* falha de carregamento é localizada.

### Evidência esperada

* captura da listagem
* registro das ações visíveis por perfil
* observação de permissão/negação

---

## 11.5 Checklist da criação de publicação

Verificar:

* formulário abre corretamente;
* campos mínimos estão presentes;
* validações de obrigatoriedade funcionam;
* mensagem de erro aponta o campo certo;
* conteúdo digitado é preservado em falha recuperável;
* salvar rascunho funciona, se previsto;
* submit duplicado é evitado.

### Evidência esperada

* captura do formulário vazio
* captura de erro de validação
* captura/registro de sucesso de criação

---

## 11.6 Checklist da edição de publicação

Verificar:

* item existente abre corretamente;
* título/status/contexto da publicação aparecem;
* campos carregam o conteúdo correto;
* salvar alteração funciona;
* conflito de estado ou item inexistente é tratado com mensagem coerente;
* ações de transição respeitam estado e perfil;
* preview está acessível conforme permissão.

### Evidência esperada

* captura de edição carregada
* registro de alteração salva
* registro de tentativa inválida, quando aplicável

---

## 11.7 Checklist do preview interno

Verificar:

* preview abre para perfil autorizado;
* contexto deixa claro que a tela é interna;
* conteúdo renderizado é coerente com o esperado;
* preview não se confunde com a rota pública;
* usuário sem permissão é bloqueado;
* retorno à edição ou listagem funciona.

### Evidência esperada

* captura do preview
* captura de acesso negado, se testado
* observação de diferenciação entre preview e público

---

# 12. QA manual de sessão e permissão

## 12.1 Objetivo

Verificar se autenticação, sessão, expiração e autorização operam conforme a arquitetura.

---

## 12.2 Checklist de sessão

Verificar:

* login cria sessão válida;
* logout encerra a sessão;
* rota protegida não abre sem autenticação;
* sessão expirada interrompe fluxo protegido;
* usuário não permanece aparentemente autenticado após expiração;
* reentrada após expiração é coerente.

### Evidência esperada

* registro de login
* registro de logout
* captura ou anotação de expiração tratada

---

## 12.3 Checklist de permissão por perfil

Verificar, por perfil:

* acesso ao dashboard
* leitura da listagem interna
* criação de publicação
* edição de publicação
* preview interno
* aprovação/rejeição de revisão
* publicação
* arquivamento
* leitura de auditoria, quando existir superfície correspondente

### Regra de execução

Cada ação relevante deve ser testada em pelo menos um perfil que:

* pode executar;
* não pode executar.

### Evidência esperada

* tabela de “permitido / negado / negado por contexto”
* capturas ou registros de acesso negado
* observação da consistência entre UI e backend

---

# 13. QA manual do workflow editorial

## 13.1 Objetivo

Verificar que o fluxo editorial interno forma cadeia coerente do rascunho até a camada pública.

---

## 13.2 Cenário mínimo de workflow

O teste manual deve validar a seguinte sequência, quando o ambiente permitir:

1. criar publicação
2. salvar em `draft`
3. editar conteúdo
4. solicitar revisão
5. aprovar revisão
6. marcar como `ready_to_publish`
7. abrir preview interno
8. publicar
9. verificar publicação na camada pública
10. arquivar
11. verificar retirada da camada pública

---

## 13.3 Pontos obrigatórios de verificação

Em cada passo, verificar:

* status anterior;
* ação executada;
* status novo;
* mensagem exibida;
* coerência de permissão;
* efeito visível no painel;
* efeito visível no público, quando aplicável;
* presença de rastro ou sinal operacional, quando acessível.

### Evidência esperada

* tabela sequencial do fluxo
* capturas dos estados principais
* anotação de status e resultado

---

# 14. QA manual de erros, conflitos e fallbacks

## 14.1 Objetivo

Validar se o sistema responde bem quando algo não dá certo.

---

## 14.2 Casos mínimos obrigatórios

### Validação de formulário

* campo obrigatório ausente
* slug inválido, se aplicável
* ação bloqueada por estado inválido

### Sessão

* sessão expirada em rota protegida
* acesso sem login
* logout e tentativa de acesso posterior

### Permissão

* acesso negado a rota interna
* ação proibida por perfil
* ação permitida pelo perfil, mas negada por contexto

### Recurso

* publicação inexistente na edição
* slug inexistente no público
* preview de recurso inexistente

### Sistema

* falha de carregamento de listagem
* estado vazio legítimo
* comportamento do shell diante de falha localizada

---

## 14.3 Critério de aprovação desses casos

A resposta é considerada madura quando:

* o erro é distinguível;
* a mensagem é clara;
* a ação não prossegue indevidamente;
* o contexto é preservado quando recuperável;
* o fallback não mente;
* o público e o admin não se confundem.

---

# 15. QA manual de SEO e descoberta

## 15.1 Objetivo

Verificar se a camada pública indexável está semanticamente coerente e se a camada privada está protegida da descoberta.

---

## 15.2 Checklist de SEO por página pública

### Home

Verificar:

* título coerente
* descrição coerente
* canonical correta

### `/publicacoes`

Verificar:

* título de listagem
* descrição contextual
* canonical correta

### `/publicacoes/[slug]`

Verificar:

* título editorial correto
* descrição coerente
* canonical correspondente ao slug atual
* publicação arquivada ou não publicada não é exposta como pública

### Páginas legais

Verificar:

* título coerente
* canonical própria

---

## 15.3 Checklist de universo não indexável

Verificar que:

* `/painel/login` não é tratado como página pública indexável
* `/painel/*` não aparece como superfície pública
* preview interno não recebe tratamento de página pública
* sitemap não inclui rotas privadas
* `robots.txt` é coerente com a política pública/privada

### Evidência esperada

* inspeção manual de HTML/metadata quando aplicável
* verificação de sitemap
* verificação de robots
* tabela de páginas públicas e privadas testadas

---

# 16. QA manual de responsividade

## 16.1 Objetivo

Verificar se público e admin permanecem utilizáveis em larguras e contextos distintos.

---

## 16.2 Superfícies mínimas a verificar

### Público

* home
* listagem pública
* publicação individual
* páginas legais

### Admin

* login
* dashboard
* listagem interna
* nova publicação
* edição
* preview

---

## 16.3 Pontos de verificação

Verificar, em desktop e mobile, ao menos:

* navegação compreensível;
* textos legíveis;
* CTAs clicáveis;
* formulários utilizáveis;
* tabelas/listas não ilegíveis;
* foco visual não quebrado;
* overflow não controlado;
* ausência de colapso estrutural.

### Evidência esperada

* capturas comparativas desktop/mobile
* anotação de cortes, overflow, botões inacessíveis ou ruído visual

---

# 17. QA manual de observabilidade mínima

## 17.1 Objetivo

Verificar se o sistema produz sinais suficientes para leitura operacional básica.

---

## 17.2 O que verificar

Quando o ambiente permitir acesso:

* erro relevante gera log ou sinal observável;
* login e logout geram rastro mínimo;
* acesso negado gera rastro mínimo;
* publicação e arquivamento geram rastro mínimo;
* falha crítica de API possui `request_id` ou `correlation_id` utilizável, quando previsto.

### Evidência esperada

* anotação de evidência observável
* referência ao evento/log consultado
* vínculo com a ação executada

---

# 18. Classificação de falhas

Toda falha encontrada deve ser classificada, no mínimo, por:

## 18.1 Severidade

### Crítica

Impede uso do fluxo central ou quebra segurança/governança.

### Alta

Fluxo principal existe, mas com falha forte ou inconsistência relevante.

### Média

Há alternativa ou workaround, mas a qualidade está comprometida.

### Baixa

Falha limitada, sem bloqueio real do fluxo principal.

---

## 18.2 Natureza

* funcional
* visual
* editorial
* semântica/SEO
* permissão
* sessão
* observabilidade
* performance percebida
* conteúdo
* fallback/mensagem

---

## 18.3 Reprodutibilidade

* sempre
* intermitente
* não reproduzido de novo
* dependente de ambiente

---

# 19. Critérios formais de aprovação

## 19.1 Aprovação mínima de rodada

Uma rodada de QA manual pode ser considerada **aprovada** quando:

* smoke passa;
* rotas centrais públicas passam;
* login e painel básico passam;
* fluxo editorial mínimo passa ou falha apenas em itens não bloqueantes;
* permissão e expiração de sessão respondem corretamente;
* páginas privadas não se comportam como públicas;
* SEO mínimo das rotas principais está coerente;
* não há falha crítica aberta sem mitigação declarada.

---

## 19.2 Aprovação com ressalvas

Pode ocorrer quando:

* não há falha crítica;
* existem falhas médias ou baixas;
* existe plano claro de correção;
* o fluxo central continua íntegro.

---

## 19.3 Reprovação da rodada

A rodada deve ser reprovada quando houver, por exemplo:

* login quebrado;
* painel inacessível;
* criação/edição/publicação inviável;
* conteúdo não publicado aparecendo publicamente;
* painel ou preview indexável;
* sessão expirada não tratada;
* transição editorial proibida sendo aceita;
* falha crítica sem rastreabilidade mínima.

---

# 20. Modelo mínimo de evidência

Cada caso testado deve, idealmente, registrar:

* identificador do caso;
* data/hora;
* ambiente;
* perfil usado;
* pré-condição;
* passos executados;
* resultado esperado;
* resultado obtido;
* evidência associada;
* status:

  * aprovado
  * aprovado com ressalva
  * falhou

---

## 20.1 Tipos aceitáveis de evidência

* captura de tela;
* vídeo curto;
* tabela de execução;
* referência de log ou correlation id;
* anotação estruturada de falha;
* print de metadata/HTML quando aplicável a SEO.

---

# 21. Anti-padrões explicitamente proibidos

Este documento proíbe, de forma expressa:

## 21.1 Testar apenas o caminho feliz

Isso não qualifica homologação madura.

## 21.2 Declarar “ok” sem evidência mínima

Isso enfraquece confiança e continuidade.

## 21.3 Tratar estado vazio como erro automaticamente

É preciso distinguir ausência legítima de falha.

## 21.4 Considerar painel validado só porque abriu

O painel precisa ser operado.

## 21.5 Ignorar permissão, sessão e acesso negado

Isso invalida a maturidade do admin.

## 21.6 Testar SEO só pela aparência visual

SEO exige leitura estrutural.

## 21.7 Declarar release pronto com falha crítica em fluxo central

Isso é falso positivo de homologação.

## 21.8 Misturar bug visual com bug de governança como se tivessem o mesmo peso

A classificação precisa ser séria.

## 21.9 Não registrar ambiente e perfil do teste

Isso compromete reprodutibilidade.

## 21.10 Tomar fallback silencioso por sucesso

Fallback preserva fluxo; não substitui correção da causa.

---

# 22. Relação deste documento com os próximos artefatos

Este documento prepara diretamente:

## `018_Cenarios_Fim_a_Fim_E2E.md`

Porque agora os fluxos críticos já possuem protocolo manual de verificação e podem ser transformados em cenários formais ponta a ponta.

## `019_Superprompts_de_Geracao_por_Bloco.md`

Porque os superprompts futuros poderão já nascer com critérios concretos de teste e homologação.

## `020_Ordem_Oficial_de_Geracao_do_Codigo.md`

Porque a sequência oficial de geração do código precisa considerar a testabilidade manual de cada bloco.

---

# 23. Síntese executiva

A leitura executiva deste documento é:

* o projeto agora possui protocolo formal de QA manual;
* smoke, fluxo, permissão, sessão, erro, fallback, SEO, responsividade e observabilidade foram enquadrados como dimensões reais de validação;
* evidência passou a ser parte do processo;
* aprovação, aprovação com ressalvas e reprovação ganharam critérios;
* o painel foi reconhecido como ambiente de trabalho a ser testado em operação real;
* a camada pública foi reconhecida como superfície semântica, editorial e institucional a ser validada além da aparência.

Em linguagem simples:

> no projeto William Albarello, QA manual não é “dar uma olhada”; é executar um protocolo capaz de dizer com seriedade se o sistema está navegável, operável, seguro, publicável, descobrível e confiável.

---

# 24. Conclusão

Se a arquitetura operacional do painel definiu **como o ambiente interno funciona**, este documento define **como o sistema inteiro deve ser verificado manualmente antes de ser considerado confiável**.

Ele consolida oito mensagens principais:

1. **QA manual ainda é soberano;**
2. **testar caminho feliz não basta;**
3. **homologação precisa de protocolo;**
4. **público e admin exigem critérios diferentes, mas articulados;**
5. **sessão, permissão e estado precisam ser testados deliberadamente;**
6. **SEO, responsividade e fallback são parte da qualidade real;**
7. **evidência e classificação de falha importam;**
8. **release sem QA sério é só esperança técnica mal documentada.**

A mensagem final deste documento é:

> no projeto William Albarello, a maturidade da entrega dependerá da disciplina com que o sistema for testado manualmente em seus fluxos reais, estados críticos, restrições, falhas e superfícies públicas, porque somente um QA manual bem estruturado consegue transformar implementação aparente em homologação confiável.

---

