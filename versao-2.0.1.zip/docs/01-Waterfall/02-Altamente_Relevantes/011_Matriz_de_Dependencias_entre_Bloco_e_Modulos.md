---

# `011_Matriz_de_Dependencias_entre_Bloco_e_Modulos.md`

**Endereço canônico:**
`/home/user/Documents/Softwares/Willian Albarello/William Albarello/01-Waterfall/02-Altamente_Relevantes/011_Matriz_de_Dependencias_entre_Bloco_e_Modulos.md`

**Status:**
Gerado no diálogo, em padrão copy/paste.

---

# 011_Matriz_de_Dependencias_entre_Bloco_e_Modulos

## 1. Identificação do documento

Este documento pertence ao diretório `01-Waterfall/02-Altamente_Relevantes` do projeto **William Albarello** e sucede logicamente os documentos que já consolidaram:

* backlog por módulos;
* story map e sequência oficial de entrega;
* blueprint de telas, páginas e seções;
* design system fundacional;
* contratos de componentes;
* contratos de módulos;
* estados, eventos e transições;
* validações, erros e fallbacks;
* matriz de permissões RBAC/ABAC;
* dicionário de dados e catálogo de entidades.

Sua finalidade é tornar **explícitas as dependências entre blocos documentais, módulos funcionais, telas, serviços, entidades e fluxos**, deixando claro:

* o que depende do quê;
* o que bloqueia o quê;
* o que pode avançar em paralelo;
* o que não pode ser paralelizado sem produzir retrabalho;
* em que ordem a implementação deve ser organizada;
* quais dependências são estruturais, operacionais, semânticas ou de validação.

Este documento deve ser lido como a resposta formal à pergunta:

> quais são as dependências reais do projeto e em que ordem elas precisam ser respeitadas para evitar retrabalho, acoplamento indevido e falsa paralelização?

---

## 2. Finalidade do documento

O objetivo deste documento é impedir que o projeto seja executado como se todos os blocos pudessem nascer ao mesmo tempo, sem hierarquia, sem pré-requisito e sem restrição de sequência.

Projetos documentados, quando não possuem matriz de dependências, tendem a sofrer com:

* falsa sensação de paralelização;
* times ou etapas implementando blocos sem base pronta;
* frontend esperando API inexistente;
* painel nascendo sem auth;
* SEO tentando operar sobre rotas ainda instáveis;
* QA testando fluxos que ainda não têm contrato;
* entidades de dados sendo remendadas depois de telas prontas;
* módulos “concluídos” que precisam ser refeitos após descoberta de dependência estrutural ignorada.

Este documento existe para:

* explicitar precedências;
* classificar dependências;
* distinguir dependência direta de indireta;
* identificar bloqueios;
* indicar paralelização segura;
* orientar cronologia técnica real;
* proteger a coerência entre Waterfall, Diagramas e implementação.

Em linguagem direta:

* **dependência invisível vira retrabalho**;
* **sequência importa**;
* **não confundir paralelo com desordem**.

---

## 3. Insumos soberanos deste documento

Este documento deriva principalmente dos seguintes artefatos já consolidados:

### Ciclo atual

* `001_Backlog_Estruturado_por_Modulo.md`
* `002_Story_Map_e_Sequencia_Oficial_de_Entrega.md`
* `006_Contratos_de_Modulos.md`

### Waterfall obrigatório

* `W011` — Arquitetura Geral do Sistema
* `W012` — Módulos, Domínios e Limites
* `W023` — Matriz de Rastreabilidade

### Diretório 02-Diagramas

* `D003–D049` — Arquitetura, contexto, backend, API, dados, frontend, infra, segurança, SEO, publicação, rastreabilidade e apoio

---

## 4. Tese central

A tese central deste documento é:

> no projeto William Albarello, dependência é parte da arquitetura, e não detalhe de cronograma.

Isso significa que:

* módulos não podem ser tratados como ilhas;
* documentos não existem soltos; eles se apoiam mutuamente;
* telas dependem de dados, permissões, estados e contratos;
* fluxos dependem de identidade, integridade, persistência e visibilidade;
* a ordem de implementação precisa respeitar dependências reais;
* paralelização só é saudável quando a fronteira entre blocos já está suficientemente estabilizada.

---

## 5. Princípios constitucionais da matriz de dependências

## 5.1 Toda entrega depende de um chão anterior

Nenhum bloco crítico deve nascer sobre abstração vaga.

## 5.2 Dependência direta tem precedência forte

Se um bloco consome contrato, dado ou decisão de outro para existir, essa dependência precisa ser respeitada antes da implementação plena.

## 5.3 Dependência indireta influencia maturidade

Um bloco pode nascer de forma inicial sem toda a cadeia pronta, mas não amadurece sem seus suportes indiretos.

## 5.4 Paralelização só é legítima com contrato estabilizado

Dois blocos podem caminhar juntos quando a interface entre eles já está suficientemente clara.

## 5.5 Tela sem módulo, módulo sem dado, dado sem estado e estado sem regra geram dívida

A matriz precisa impedir esse tipo de nascimento invertido.

## 5.6 Dependência documental e dependência técnica não são a mesma coisa

Um documento pode depender conceitualmente de outro sem impedir um scaffold técnico mínimo, e vice-versa.

## 5.7 O que bloqueia precisa ser declarado

Dependências que bloqueiam são parte do plano, não acidente do caminho.

## 5.8 Sequência errada custa mais do que espera disciplinada

Refação estrutural é sempre mais cara que precedência respeitada.

---

## 6. Estrutura de leitura adotada

Esta matriz será organizada em cinco camadas:

1. **Dependências documentais**
2. **Dependências entre módulos funcionais**
3. **Dependências entre telas, fluxos e superfícies**
4. **Dependências entre entidades e serviços**
5. **Matriz de precedência, bloqueios e paralelização segura**

---

# 7. Classificação de dependências

## 7.1 Dependência estrutural

Sem ela, o bloco dependente não deveria ser implementado além de um mock ou scaffold superficial.

## 7.2 Dependência funcional

O bloco pode existir parcialmente, mas não pode funcionar de verdade sem ela.

## 7.3 Dependência semântica

O bloco depende de nomenclatura, estado, regra ou contrato para manter coerência.

## 7.4 Dependência operacional

O bloco depende de suporte de ambiente, observabilidade, deploy, sessão ou validação para ser executável de forma real.

## 7.5 Dependência de validação

O bloco pode até existir, mas não pode ser homologado com seriedade sem essa base.

---

# 8. Matriz de dependências documentais

---

## 8.1 Dependências centrais do ciclo `02-Altamente_Relevantes`

### `001_Backlog_Estruturado_por_Modulo`

Depende de:

* `W011`
* `W012`
* `W017`
* `W021`
* Diretório `02-Diagramas`

Função de base para:

* `002`
* `006`
* `011`
* `020`

Tipo de dependência:

* estrutural/documental

---

### `002_Story_Map_e_Sequencia_Oficial_de_Entrega`

Depende de:

* `001`
* `W006`
* `W011`
* `W017`
* `W018`

Função de base para:

* `003`
* `011`
* `017`
* `018`
* `020`

Tipo:

* estrutural/documental

---

### `003_Blueprint_de_Telas_Paginas_e_Secoes`

Depende de:

* `002`
* `W017`
* diagramas de frontend/jornadas/SEO/publicação

Função de base para:

* `004`
* `005`
* `016`
* `017`
* `018`

Tipo:

* estrutural/documental

---

### `004_Design_System_Fundacional`

Depende de:

* `003`
* `W007`
* `W017`
* `W018`

Função de base para:

* `005`
* implementação de frontend público
* implementação de admin

Tipo:

* estrutural + semântica

---

### `005_Contratos_de_Componentes`

Depende de:

* `003`
* `004`

Função de base para:

* frontend público
* painel admin
* QA visual/estrutural

Tipo:

* estrutural/documental

---

### `006_Contratos_de_Modulos`

Depende de:

* `001`
* `002`
* `W011`
* `W012`
* `W014`
* `W016`

Função de base para:

* `011`
* `012`
* implementação de backend
* implementação de integrações entre blocos

Tipo:

* estrutural/arquitetural

---

### `007_Estados_Eventos_e_Transicoes`

Depende de:

* `006`
* `W015`
* `W016`
* diagramas de sessão, editorial, auditoria

Função de base para:

* `008`
* `009`
* `017`
* `018`
* regras de backend
* status do painel

Tipo:

* semântica + funcional

---

### `008_Validacoes_Mensagens_de_Erro_e_Fallbacks`

Depende de:

* `007`
* `W016`
* `W017`
* `W018`

Função de base para:

* frontend público
* painel admin
* contrato de erro da API
* QA de falhas

Tipo:

* funcional + validação

---

### `009_Matriz_de_Permissoes_RBAC_ABAC`

Depende de:

* `006`
* `007`
* `W015`
* `W016`
* diagramas de segurança/sessão/permissão/auditoria

Função de base para:

* auth
* painel admin
* proteção de rotas
* QA por perfil

Tipo:

* estrutural + segurança

---

### `010_Dicionario_de_Dados_e_Catalogo_de_Entidades`

Depende de:

* `006`
* `007`
* `009`
* `W013`
* `W016`
* `D019–D024`

Função de base para:

* backend
* persistência
* SEO
* auditoria
* QA de integridade

Tipo:

* estrutural + semântica

---

### `011_Matriz_de_Dependencias_entre_Bloco_e_Modulos`

Depende de:

* `001`
* `002`
* `006`
* `010`
* `W011`
* `W012`
* `W023`
* `D003–D049`

Função de base para:

* `020`
* plano de implementação real
* estratégia anti-retrabalho

Tipo:

* estrutural/meta-arquitetural

---

## 8.2 Conclusão documental

A ordem documental correta até aqui mostra que:

* `001`, `002`, `003`, `004`, `005`, `006` formam a fundação de forma;
* `007`, `008`, `009`, `010` formam a fundação de comportamento, segurança e dado;
* `011` consolida a visão de dependência e precedência;
* qualquer geração de código séria após isso passa a ter chão muito mais estável.

---

# 9. Matriz de dependências entre módulos funcionais

Os módulos soberanos já definidos no projeto são:

1. Web Público Institucional
2. Editorial Público
3. Painel Administrativo
4. Auth/Sessão/Controle de Acesso
5. API e Serviços de Aplicação
6. Dados, Persistência e Versionamento
7. SEO, Metadata e Descoberta
8. Observabilidade, Auditoria e Operação
9. Infraestrutura, Ambientes e Entrega
10. Qualidade, Testes e Homologação

---

## 9.1 Web Público Institucional

### Depende diretamente de

* SEO, Metadata e Descoberta
* API e Serviços de Aplicação, quando houver blocos dinâmicos
* Design System / Contratos de Componentes
* Infraestrutura, Ambientes e Entrega

### Depende indiretamente de

* Dados/Persistência, via API
* Observabilidade, para leitura operacional
* QA, para homologação

### Bloqueios reais

* sem rotas públicas definidas, não há estrutura coerente;
* sem SEO mínimo, nasce semântica pública incompleta;
* sem design system/blueprint, tende a nascer incoerente.

### Paralelização segura

* pode evoluir em paralelo com Admin apenas após `003`, `004` e `005`;
* pode avançar visualmente antes da API completa, desde que os pontos dinâmicos estejam claramente mockados.

---

## 9.2 Editorial Público

### Depende diretamente de

* API e Serviços de Aplicação
* Dados, Persistência e Versionamento
* SEO, Metadata e Descoberta
* Web Público Institucional

### Depende indiretamente de

* Painel Administrativo
* Auth/Sessão, porque o conteúdo nasce do fluxo interno
* Observabilidade/Auditoria

### Bloqueios reais

* sem entidade `Publicacao`, não existe;
* sem regra de `status_editorial`, não há visibilidade soberana;
* sem slug, não há rota pública consistente.

### Paralelização segura

* layout editorial pode nascer junto do público;
* leitura pública real só deve sair do mock quando API + Dados + regras de status estiverem estáveis.

---

## 9.3 Painel Administrativo

### Depende diretamente de

* Auth/Sessão/Controle de Acesso
* API e Serviços de Aplicação
* Dados, Persistência e Versionamento
* Contratos de Componentes
* Design System

### Depende indiretamente de

* Observabilidade/Auditoria
* Infra
* QA

### Bloqueios reais

* sem auth, o painel é casca insegura;
* sem API administrativa, o painel vira mock permanente;
* sem matriz de permissões, a UI tende a prometer ações indevidas.

### Paralelização segura

* shell do painel pode nascer junto do site público;
* formulários reais precisam esperar contratos mínimos de API + dados + estados + permissões.

---

## 9.4 Auth/Sessão/Controle de Acesso

### Depende diretamente de

* Dados, Persistência e Versionamento
* API e Serviços de Aplicação
* Observabilidade/Auditoria

### Depende indiretamente de

* Infra, para ambiente seguro
* QA, para validação por perfil e sessão

### Bloqueios reais

* sem `UsuarioInterno`, `PerfilAcesso`, `UsuarioPerfil` e `SessaoAdministrativa`, não há auth séria;
* sem RBAC/ABAC, o painel não amadurece.

### Paralelização segura

* pode evoluir em paralelo com modelagem de dados;
* UI de login pode nascer antes, mas autenticação real depende da base.

---

## 9.5 API e Serviços de Aplicação

### Depende diretamente de

* Dados, Persistência e Versionamento
* Auth/Sessão/Controle de Acesso
* Estados/Eventos/Transições
* Validações/Erros/Fallbacks

### Depende indiretamente de

* Observabilidade/Auditoria
* SEO, para parte semântica da camada pública
* Infra

### Bloqueios reais

* sem dicionário de entidades e regras de estado, a API nasce caótica;
* sem auth, endpoints internos não são confiáveis;
* sem política de erro/validação, o contrato HTTP degrada.

### Paralelização segura

* contratos e stubs de rota podem nascer cedo;
* implementação real deve acompanhar modelagem de entidade, estados e permissão.

---

## 9.6 Dados, Persistência e Versionamento

### Depende diretamente de

* Dicionário de dados
* Estados editoriais
* Matriz de permissões, para entidades de auth
* Decisões arquiteturais

### Depende indiretamente de

* API
* Auditoria
* SEO

### Bloqueios reais

* sem léxico semântico (`010`), a modelagem tende a nascer errada;
* sem status claros, a visibilidade pública colapsa;
* sem histórico de slug, SEO e rotas sofrem.

### Paralelização segura

* pode avançar junto da API;
* pode avançar junto de Auth;
* precisa estar estabilizado antes de fechar Editorial Público real.

---

## 9.7 SEO, Metadata e Descoberta

### Depende diretamente de

* Editorial Público
* Web Público
* Dados editoriais corretos
* Infra, para sitemap/robots/canonical viáveis

### Depende indiretamente de

* API
* Estados editoriais
* Histórico de slug

### Bloqueios reais

* sem rotas públicas estáveis, SEO é prematuro;
* sem `published`, `slug_atual` e metadata mínima, SEO é decorativo.

### Paralelização segura

* política de SEO pode ser documentada antes;
* implementação plena deve esperar a estabilização de rotas e conteúdo público real.

---

## 9.8 Observabilidade, Auditoria e Operação

### Depende diretamente de

* API
* Auth/Sessão
* Dados, se parte da auditoria for persistida
* Infra

### Depende indiretamente de

* Painel
* Editorial
* QA

### Bloqueios reais

* sem eventos nomeados e críticos definidos, observabilidade nasce cega;
* sem correlação entre módulos, auditoria vira ruído.

### Paralelização segura

* modelo de eventos pode nascer cedo;
* integração plena acontece à medida que Auth, API e transições reais entram em operação.

---

## 9.9 Infraestrutura, Ambientes e Entrega

### Depende diretamente de

* topologia arquitetural definida
* módulos executáveis minimamente separados
* estratégia de deploy
* domínios e subdomínios aprovados

### Depende indiretamente de

* Web
* Admin
* API
* Observabilidade

### Bloqueios reais

* sem separação mínima entre web/admin/api, o deploy fica confuso;
* sem contratos de ambiente, staging e produção se misturam.

### Paralelização segura

* setup de base pode nascer cedo;
* deploy real exige artefatos executáveis minimamente coerentes.

---

## 9.10 Qualidade, Testes e Homologação

### Depende diretamente de

* critérios de aceite
* story map
* telas reais
* API real
* auth real
* estados e mensagens reais

### Depende indiretamente de

* todos os módulos executáveis
* observabilidade
* infra de staging

### Bloqueios reais

* sem fluxo executável, QA só valida mock;
* sem matriz de permissão, não há QA séria por perfil;
* sem fallbacks, QA de erro fica superficial.

### Paralelização segura

* roteiros e cenários podem ser desenhados cedo;
* homologação forte só vem depois de módulos minimamente vivos.

---

# 10. Matriz resumida de dependência entre módulos

## 10.1 Legenda

* **D** = dependência direta
* **I** = dependência indireta
* **—** = não aplicável ou irrelevante como dependência principal

| Módulo            | Web Público | Editorial Público | Painel Admin | Auth/Sessão | API | Dados | SEO | Observabilidade | Infra | QA |
| ----------------- | ----------: | ----------------: | -----------: | ----------: | --: | ----: | --: | --------------: | ----: | -: |
| Web Público       |           — |                 I |            — |           — |   D |     I |   D |               I |     D |  I |
| Editorial Público |           D |                 — |            I |           I |   D |     D |   D |               I |     I |  I |
| Painel Admin      |           — |                 I |            — |           D |   D |     D |   — |               I |     I |  D |
| Auth/Sessão       |           — |                 — |            I |           — |   D |     D |   — |               D |     I |  I |
| API               |           I |                 D |            I |           D |   — |     D |   I |               D |     I |  I |
| Dados             |           — |                 I |            I |           I |   I |     — |   I |               I |     I |  I |
| SEO               |           D |                 D |            — |           — |   I |     I |   — |               — |     D |  I |
| Observabilidade   |           — |                 I |            I |           D |   D |     I |   — |               — |     D |  I |
| Infra             |           I |                 I |            I |           I |   I |     I |   I |               I |     — |  I |
| QA                |           I |                 I |            I |           I |   I |     I |   I |               I |     I |  — |

### Leitura importante

Esta tabela não significa “quem chama quem” no código, mas sim **quem depende arquiteturalmente de quem para existir, amadurecer ou ser homologado**.

---

# 11. Dependências entre telas, fluxos e superfícies

---

## 11.1 Home pública `/`

Depende de:

* `HeaderPublic`
* `FooterPublic`
* arquitetura pública estável
* blocos institucionais
* opcionalmente, resumo de publicações

Bloqueios:

* sem estrutura pública e design base, a home fica incoerente;
* sem editorial estabilizado, a ponte para publicações deve operar em fallback.

---

## 11.2 Listagem pública `/publicacoes`

Depende de:

* entidade `Publicacao`
* API pública de leitura
* regra `status_editorial = published`
* `PublicationList`
* SEO mínimo

Bloqueios:

* sem publicação persistida e pública, a lista é apenas vazia ou mock;
* sem slug e visibilidade, não há listagem real.

---

## 11.3 Página de publicação `/publicacoes/[slug]`

Depende de:

* `Publicacao.slug_atual`
* `Publicacao.status_editorial`
* API pública por slug
* metadata/canonical
* `RichTextContent`

Bloqueios:

* sem slug único, não há resolução consistente;
* sem published, não há leitura pública legítima;
* sem histórico de slug, SEO e continuidade sofrem.

---

## 11.4 Login `/painel/login`

Depende de:

* `UsuarioInterno`
* `SessaoAdministrativa`
* endpoint de auth
* políticas de erro e expiração

Bloqueios:

* sem auth real, é somente formulário estético.

---

## 11.5 Dashboard `/painel`

Depende de:

* sessão válida
* autorização básica
* shell admin
* leitura mínima de dados internos

Bloqueios:

* sem auth, não deve existir acessível;
* sem API/admin shell, não passa de layout estático.

---

## 11.6 Listagem interna `/painel/publicacoes`

Depende de:

* sessão válida
* permissão de leitura interna
* `Publicacao`
* API administrativa de listagem
* `PublicationTable`

Bloqueios:

* sem permissão, não deve abrir;
* sem dados, cai em estado vazio;
* sem API, fica em mock.

---

## 11.7 Nova publicação `/painel/publicacoes/nova`

Depende de:

* permissão `create`
* formulário editorial
* entidade `Publicacao`
* validações
* endpoint de criação

Bloqueios:

* sem RBAC e auth, inseguro;
* sem regras editoriais, risco de persistência ruim.

---

## 11.8 Edição `/painel/publicacoes/[id]/editar`

Depende de:

* permissão `update`
* existência da publicação
* formulário editorial
* regras de transição/edição
* endpoint de atualização

Bloqueios:

* sem item encontrado, cai em erro contextual;
* sem estado atual carregado, edição é inconsistente.

---

## 11.9 Preview `/painel/publicacoes/[id]/preview`

Depende de:

* sessão válida
* permissão `preview_internal`
* entidade `Publicacao`
* distinção entre preview e público
* endpoint interno de leitura/preview

Bloqueios:

* sem auth e permissão, não pode existir;
* sem conteúdo resolvido, vira erro contextual.

---

## 11.10 Fluxo editorial completo

Fluxo:

* login
* dashboard
* listagem
* criar/editar
* revisão
* ready_to_publish
* publicar
* leitura pública
* arquivar/retornar

Depende de:

* auth
* API
* dados
* estados editoriais
* RBAC/ABAC
* auditoria
* SEO
* web público

Bloqueios:

* qualquer ruptura em auth, dados, estados ou API quebra o fluxo ponta a ponta.

---

# 12. Dependências entre entidades e serviços

---

## 12.1 `UsuarioInterno`

Depende semanticamente de:

* política de autenticação
* política de perfis

É pré-requisito para:

* `SessaoAdministrativa`
* `UsuarioPerfil`
* autoria de `Publicacao`
* `AuditoriaEvento`

---

## 12.2 `PerfilAcesso`

Depende semanticamente de:

* matriz RBAC/ABAC

É pré-requisito para:

* `UsuarioPerfil`
* decisões de autorização

---

## 12.3 `UsuarioPerfil`

Depende diretamente de:

* `UsuarioInterno`
* `PerfilAcesso`

É pré-requisito para:

* resolução de permissão efetiva

---

## 12.4 `SessaoAdministrativa`

Depende diretamente de:

* `UsuarioInterno`

É pré-requisito para:

* acesso interno real
* auditoria contextual
* proteção de rotas

---

## 12.5 `Publicacao`

Depende semanticamente de:

* estados editoriais
* regras de slug
* regras de visibilidade pública
* autoria/operador

É pré-requisito para:

* editorial público
* listagem interna
* preview
* SEO
* auditoria editorial
* versionamento

---

## 12.6 `PublicacaoVersao`

Depende diretamente de:

* `Publicacao`

É pré-requisito para:

* histórico editorial robusto
* inspeção de evolução
* reversão assistida futura

---

## 12.7 `HistoricoSlugPublicacao`

Depende diretamente de:

* `Publicacao`
* política de rotas/SEO

É pré-requisito para:

* continuidade de URL
* redirecionamento
* proteção semântica de slug

---

## 12.8 `AuditoriaEvento`

Depende diretamente de:

* eventos relevantes
* identidade/sessão, quando houver
* recurso afetado, quando houver
* correlação operacional

É pré-requisito para:

* governança
* investigação
* supervisão
* QA de rastreabilidade

---

# 13. Bloqueios arquiteturais principais

Os bloqueios centrais do projeto são os seguintes.

---

## 13.1 Auth bloqueia Painel real

Sem autenticação e sessão válidas, qualquer painel é só maquiagem funcional.

---

## 13.2 Dados bloqueiam API real

Sem entidades, estados e integridade, a API só consegue produzir mocks.

---

## 13.3 API bloqueia Admin e Editorial reais

Sem contratos de leitura e escrita, frontend e admin ficam estéticos.

---

## 13.4 Estados e permissões bloqueiam governança

Sem máquina editorial e RBAC/ABAC, o sistema não sabe quem pode fazer o quê nem quando.

---

## 13.5 Slug e status bloqueiam SEO sério

Sem identidade pública estável e estado editorial soberano, SEO é prematuro.

---

## 13.6 Observabilidade bloqueia operação madura

Sem trilha e correlação, o sistema roda às cegas.

---

## 13.7 Infra bloqueia regime real

Sem staging, deploy e topologia clara, a arquitetura fica presa ao ambiente local.

---

## 13.8 QA forte bloqueia conclusão formal

Sem critérios testáveis sobre fluxo vivo, não há homologação séria.

---

# 14. Paralelização segura

Nem tudo precisa esperar tudo.
Há pontos de paralelização saudável, desde que respeitados os contratos já consolidados.

---

## 14.1 Paralelo seguro A — Público + Admin shell

Pode acontecer em paralelo quando já existirem:

* `003`
* `004`
* `005`

Condição:

* ambos ainda podem operar com dados mockados e contratos estáveis de superfície.

---

## 14.2 Paralelo seguro B — Auth + Dados base

Pode acontecer em paralelo quando já existirem:

* `009`
* `010`

Condição:

* os contratos de usuário, perfil, sessão e permissão estejam estáveis.

---

## 14.3 Paralelo seguro C — API pública + API administrativa

Pode ocorrer em paralelo se:

* `006`
* `007`
* `010`
  já estiverem suficientemente consolidados.

Condição:

* compartilharem a mesma semântica de entidade, estado e erro.

---

## 14.4 Paralelo seguro D — SEO documental + público visual

Pode caminhar junto enquanto a camada pública é montada.

Condição:

* a implementação final de SEO só se fecha depois de rotas e conteúdo público reais.

---

## 14.5 Paralelo seguro E — QA de roteiros + desenvolvimento

Pode ocorrer cedo para documentação de teste.

Condição:

* a homologação real só avança conforme os fluxos executáveis surgem.

---

# 15. Paralelização perigosa

Os seguintes paralelos são considerados perigosos ou anti-método.

---

## 15.1 Público editorial real antes da regra de status

Risco:

* conteúdo vazar sem governança
* SEO nascer em base errada

---

## 15.2 Painel funcional antes de auth e RBAC mínimos

Risco:

* ações indevidas
* refação de rotas, proteção e botões

---

## 15.3 SEO operacional pleno antes de rotas estáveis

Risco:

* canonical inconsistente
* sitemap descartável
* retrabalho de URL

---

## 15.4 QA executivo antes de fluxo vivo

Risco:

* checklist vazio
* falsa sensação de validação

---

## 15.5 API final antes do léxico de entidades

Risco:

* rotas inconsistentes
* payloads frágeis
* refação massiva do backend

---

## 15.6 Auditoria detalhada antes de eventos nomeados

Risco:

* rastro sem semântica
* logging ruidoso
* governança confusa

---

# 16. Ordem técnica macro recomendada a partir desta matriz

A ordem técnica mais inteligente, depois desta base documental, é:

### Onda A — Base semântica e de segurança

* `009`
* `010`
* auth base
* dados base

### Onda B — API mínima viva

* endpoints de auth
* endpoints de publicações internas
* endpoints públicos de leitura
* contratos de erro/validação

### Onda C — Superfícies reais

* login
* shell admin
* home pública
* listagem pública
* publicação pública
* listagem interna
* criação/edição/preview

### Onda D — Governança editorial

* estados editoriais completos
* revisão
* ready_to_publish
* publicação
* arquivamento
* retorno para draft

### Onda E — Descoberta e operação

* metadata
* canonical
* sitemap
* robots
* observabilidade
* auditoria
* staging/deploy

### Onda F — Homologação forte

* QA manual
* E2E
* evidências
* estabilização

---

# 17. Matriz resumida de precedência

## 17.1 Legenda

* **Pré** = pré-requisito
* **Bloq** = bloqueia maturidade real
* **Par** = pode andar em paralelo com contrato estável

| Bloco                     | Pré-requisitos principais                  | Bloqueia o quê               | Paralelo seguro                |
| ------------------------- | ------------------------------------------ | ---------------------------- | ------------------------------ |
| Auth/Sessão               | `009`, `010`, API base                     | Painel real                  | Dados base                     |
| Dados/Persistência        | `010`, `007`                               | API real, Editorial real     | Auth base                      |
| API                       | `006`, `007`, `010`                        | Público dinâmico, Admin real | SEO documental, QA de roteiros |
| Web Público               | `003`, `004`, `005`                        | Presença pública coerente    | Shell admin                    |
| Editorial Público         | API + Dados + `status_editorial` + slug    | Conteúdo público real        | Web público visual             |
| Painel Admin              | Auth + API + RBAC                          | Operação interna real        | Web público                    |
| SEO                       | Rotas públicas + conteúdo publicado + slug | Descoberta séria             | Política documental            |
| Observabilidade/Auditoria | Eventos + API + Auth + Infra               | Governança operacional       | Infra base                     |
| Infra                     | topologia + artefatos mínimos              | Regime real                  | Observabilidade base           |
| QA forte                  | fluxos vivos + critérios + staging         | Homologação formal           | roteiros preliminares          |

---

# 18. Anti-padrões explicitamente proibidos

Este documento proíbe, de forma expressa:

## 18.1 Tratar mock como conclusão

Mock pode apoiar paralelização, mas não conta como fechamento do bloco dependente.

## 18.2 Chamar de paralelo o que é colisão de dependência

Se um bloco depende estruturalmente do outro, não há paralelização real.

## 18.3 Inverter semântica e interface

Tela pronta sem dado, estado, permissão ou regra ainda não é entrega madura.

## 18.4 Ignorar dependência porque “depois ajusta”

Esse é o caminho clássico do retrabalho estrutural.

## 18.5 Implementar SEO sobre rotas instáveis

Produz descarte técnico.

## 18.6 Implementar auditoria sem vocabulário de evento

Produz ruído, não governança.

## 18.7 Painel sem auth e sem RBAC tratado como “quase pronto”

Isso é falso positivo de progresso.

## 18.8 QA homologando fluxos incompletos como se fossem definitivos

A validação perde credibilidade.

---

# 19. Relação deste documento com os próximos artefatos

Este documento prepara diretamente:

## `012_Politica_de_Versionamento_e_Compatibilidade.md`

Porque agora já existe clareza sobre quem depende de quem e quais rupturas seriam perigosas.

## `017_Procedimentos_de_QA_Manual.md`

Porque as dependências aqui listadas definem a ordem segura de teste.

## `018_Cenarios_Fim_a_Fim_E2E.md`

Porque os cenários ponta a ponta exigem cadeias completas de dependência vivas.

## `020_Ordem_Oficial_de_Geracao_do_Codigo.md`

Porque este documento é uma das bases mais importantes para transformar arquitetura em sequência real de implementação.

---

# 20. Síntese executiva

A leitura executiva deste documento é:

* o projeto agora possui mapa explícito de dependências;
* documentos, módulos, telas, fluxos, entidades e serviços deixaram de parecer independentes quando não são;
* auth, dados, API, estados, permissões, slug, SEO, observabilidade, infra e QA foram colocados em relação clara;
* foi separada:

  * dependência estrutural;
  * dependência funcional;
  * dependência semântica;
  * dependência operacional;
  * dependência de validação;
* também foram distinguidos:

  * paralelos seguros;
  * paralelos perigosos;
  * bloqueios reais;
  * precedências macro.

Em linguagem simples:

> no projeto William Albarello, a implementação não deve seguir o que parece mais rápido, mas o que respeita a cadeia real de dependências que mantém a arquitetura íntegra.

---

# 21. Conclusão

Se os documentos anteriores definiram módulos, estados, permissões e dados, este documento define **como tudo isso se apoia mutuamente e em que ordem precisa amadurecer para não colapsar em retrabalho**.

Ele consolida oito mensagens principais:

1. **dependência invisível vira retrabalho;**
2. **sequência importa mais do que impulso local;**
3. **paralelização só é boa quando a fronteira está clara;**
4. **auth, dados e API formam o núcleo duro da execução real;**
5. **público e admin podem nascer em paralelo, mas só amadurecem com a base viva;**
6. **SEO, auditoria e QA dependem de estrutura já executável;**
7. **mock não equivale a fechamento;**
8. **arquitetura boa também é arquitetura que sabe esperar a ordem certa.**

A mensagem final deste documento é:

> no projeto William Albarello, a qualidade da implementação dependerá diretamente da disciplina com que a ordem de dependências for respeitada, porque é essa disciplina que transforma documentação madura em software coerente, testável, seguro e sustentável.

---

