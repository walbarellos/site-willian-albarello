
# `010_Dicionario_de_Dados_e_Catalogo_de_Entidades.md`

**Endereço canônico:**
`/home/user/Documents/Softwares/Willian Albarello/William Albarello/01-Waterfall/02-Altamente_Relevantes/010_Dicionario_de_Dados_e_Catalogo_de_Entidades.md`

**Status:**
Gerado no diálogo, em padrão copy/paste.

---

# 010_Dicionario_de_Dados_e_Catalogo_de_Entidades

## 1. Identificação do documento

Este documento pertence ao diretório `01-Waterfall/02-Altamente_Relevantes` do projeto **William Albarello** e sucede logicamente os artefatos que já consolidaram:

* backlog e sequência de entrega;
* blueprint de telas;
* design system;
* contratos de componentes;
* contratos de módulos;
* estados, eventos e transições;
* validações, mensagens, erros e fallbacks;
* matriz de permissões RBAC/ABAC.

Sua finalidade é estabelecer a **camada semântica formal dos dados do projeto**, catalogando:

* entidades soberanas;
* atributos;
* tipos conceituais;
* obrigatoriedade;
* unicidade;
* relacionamentos;
* origem dos dados;
* uso operacional;
* chaves lógicas;
* regras de integridade.

Este documento deve ser lido como a resposta formal à pergunta:

> quais dados o sistema realmente possui, o que eles significam, como se relacionam e por que existem?

---

## 2. Finalidade do documento

O objetivo deste documento é impedir que a base de dados do projeto seja construída como simples reflexo acidental da interface, do framework ou da implementação do momento.

Neste projeto, dado não é detalhe técnico.
Dado é:

* arquitetura;
* memória operacional;
* contrato de domínio;
* suporte à auditoria;
* suporte à segurança;
* suporte à publicação;
* suporte à descoberta pública;
* suporte à continuidade do sistema.

Este documento existe para:

* dar nome formal às entidades do sistema;
* definir atributos com significado e uso;
* evitar colunas vagas ou redundantes;
* distinguir o que é dado soberano do que é artefato derivado;
* orientar modelagem, API, backend, QA e evolução futura;
* preservar coerência entre publicação, sessão, perfis, auditoria e SEO.

Em linguagem direta:

* **sem nome certo, não há dado certo**;
* **entidade precisa servir ao negócio**;
* **dado também é arquitetura**.

---

## 3. Insumos soberanos deste documento

Este documento deriva principalmente dos seguintes artefatos já consolidados:

### Waterfall obrigatório

* `W013` — Modelo Conceitual de Dados
* `W016` — API Contract Mestre
* `W023` — Matriz de Rastreabilidade

### Diretório 02-Diagramas

* `D019–D024` — Dados e Persistência
* `D041` — Auditoria e Rastreabilidade
* `D042–D045` — Fluxo Editorial, Indexação, Geração/Publicação e Metadata

### Ciclo atual

* `006_Contratos_de_Modulos.md`
* `007_Estados_Eventos_e_Transicoes.md`
* `009_Matriz_de_Permissoes_RBAC_ABAC.md`

---

## 4. Tese central

A tese central deste documento é:

> no projeto William Albarello, cada dado relevante precisa ter significado explícito, função operacional clara e fronteira semântica preservada.

Isso implica que:

* nem tudo que aparece na interface merece virar entidade;
* nem tudo que é tecnicamente conveniente merece virar coluna;
* atributos precisam refletir domínio, não improviso;
* visibilidade pública deve derivar de estados soberanos;
* auditoria precisa ser tratada como dado de governança;
* sessão precisa ser tratada como ciclo formal;
* SEO deve se apoiar em dados corretos, não em remendos textuais.

---

## 5. Princípios constitucionais do dicionário de dados

## 5.1 Nome semântico acima de nome acidental

Atributos e entidades devem ser nomeados pelo que significam, não pelo componente ou tela que os usa.

## 5.2 Uma responsabilidade por entidade

Se uma entidade tenta resolver múltiplos domínios diferentes sem clareza, ela tende a se tornar confusa.

## 5.3 Dado derivado não deve competir com dado soberano

Quando uma informação pode ser derivada com segurança, deve-se evitar duplicação desnecessária.

## 5.4 Integridade acima de conveniência

O sistema deve preferir coerência estrutural a atalhos frágeis.

## 5.5 Auditoria é append-only por natureza

Rastros críticos não devem ser modelados como dados mutáveis comuns.

## 5.6 Status editoriais governam visibilidade pública

A camada pública não decide sozinha se um conteúdo é exibível.

## 5.7 Sessão é entidade operacional real

Sessão não deve ser tratada como efeito invisível.

## 5.8 SEO precisa de fonte de verdade

Slug, metadata e elegibilidade pública precisam nascer de dados consistentes.

---

## 6. Convenções gerais de modelagem

## 6.1 Identificadores

Todos os identificadores soberanos do sistema devem ser:

* opacos;
* estáveis;
* não semânticos;
* próprios para uso interno.

Padrão conceitual recomendado:

* `UUID`

Exemplos:

* `usuario_id`
* `perfil_id`
* `sessao_id`
* `publicacao_id`
* `publicacao_versao_id`
* `auditoria_evento_id`

---

## 6.2 Timestamps

Todos os timestamps críticos devem ser armazenados em referência temporal consistente, preferencialmente:

* `TimestampUTC`

Atributos temporais mínimos recorrentes:

* `criado_em`
* `atualizado_em`
* `publicado_em`
* `arquivado_em`
* `expira_em`
* `ocorrido_em`

---

## 6.3 Estados por enumeração controlada

Estados relevantes devem ser modelados por domínios finitos controlados, nunca por texto livre.

Principais enumerações conceituais:

* `EnumStatusUsuario`
* `EnumStatusSessao`
* `EnumStatusEditorial`
* `EnumResultadoAuditoria`
* `EnumTipoEventoAuditoria`

---

## 6.4 Soft delete vs. hard delete

Para entidades centrais do projeto, a regra arquitetural preferível é:

* evitar exclusão física irreversível como caminho comum;
* preferir:

  * inativação;
  * arquivamento;
  * revogação;
  * encerramento;
  * versionamento;
  * audit trail.

Especialmente:

* `Publicacao`
* `UsuarioInterno`
* `AuditoriaEvento`

---

## 6.5 Fonte de verdade

As seguintes regras são soberanas:

* a visibilidade pública da publicação deriva de `status_editorial`;
* a validade da sessão deriva de `status_sessao` + `expira_em`;
* a autorização deriva da combinação entre:

  * papéis;
  * contexto;
  * recurso;
  * ação;
* a indexabilidade pública depende de:

  * existência;
  * status;
  * rota canônica válida;
  * política de descoberta aplicável.

---

## 7. Tipos conceituais utilizados neste documento

Abaixo estão os principais tipos conceituais adotados.

| Tipo conceitual           | Significado                                          |
| ------------------------- | ---------------------------------------------------- |
| `UUID`                    | Identificador opaco soberano                         |
| `TextoCurto`              | Texto curto, controlado e de baixa extensão          |
| `TextoMedio`              | Texto de extensão moderada                           |
| `TextoLongo`              | Texto longo                                          |
| `RichText`                | Conteúdo textual estruturado para leitura pública    |
| `Slug`                    | Identificador textual amigável de rota pública       |
| `EmailLogin`              | E-mail usado para autenticação/identificação interna |
| `Bool`                    | Valor booleano                                       |
| `IntPositivo`             | Número inteiro positivo                              |
| `TimestampUTC`            | Data/hora em referência UTC                          |
| `URLPublica`              | URL absoluta ou pública válida                       |
| `HashSeguro`              | Hash ou referência segura de credencial/token        |
| `JsonControlado`          | Estrutura JSON com contrato conhecido                |
| `EnumStatusUsuario`       | Enum de estado do usuário                            |
| `EnumStatusSessao`        | Enum de estado da sessão                             |
| `EnumStatusEditorial`     | Enum de estado editorial                             |
| `EnumCodigoPerfil`        | Enum/código do perfil de acesso                      |
| `EnumTipoEventoAuditoria` | Enum/tipo do evento auditado                         |
| `EnumResultadoAuditoria`  | Sucesso, negação, falha, etc.                        |
| `CorrelationId`           | Identificador de correlação operacional              |

---

## 8. Visão geral do catálogo de entidades

As entidades soberanas mínimas deste projeto, neste estágio, são:

1. `UsuarioInterno`
2. `PerfilAcesso`
3. `UsuarioPerfil`
4. `SessaoAdministrativa`
5. `Publicacao`
6. `PublicacaoVersao`
7. `HistoricoSlugPublicacao`
8. `AuditoriaEvento`

### Observação importante

Nem tudo que existe conceitualmente no sistema precisa ser uma entidade soberana de persistência.

Exemplos de artefatos **derivados**, e não necessariamente entidades autônomas:

* `robots.txt`
* `sitemap.xml`
* canonical final de rota pública
* preview interno em si
* permissões calculadas em tempo de execução
* listagens públicas derivadas da entidade `Publicacao`

---

# 9. Catálogo formal de entidades

---

## 9.1 Entidade `UsuarioInterno`

### Missão

Representar a identidade interna autenticável do sistema, apta a operar o painel administrativo conforme seus perfis.

### Natureza

Entidade soberana de identidade interna.

### Chave lógica principal

* `usuario_id`

### Atributos

| Atributo          | Tipo conceitual     | Obrigatório | Único | Descrição / uso                                       |
| ----------------- | ------------------- | ----------: | ----: | ----------------------------------------------------- |
| `usuario_id`      | `UUID`              |         Sim |   Sim | Identificador soberano do usuário interno             |
| `nome_exibicao`   | `TextoCurto`        |         Sim |   Não | Nome utilizado no contexto administrativo e auditável |
| `email_login`     | `EmailLogin`        |         Sim |   Sim | Identificador principal de login                      |
| `senha_hash`      | `HashSeguro`        |         Sim |   Não | Credencial persistida em forma segura                 |
| `status_usuario`  | `EnumStatusUsuario` |         Sim |   Não | Estado operacional do usuário                         |
| `ultimo_login_em` | `TimestampUTC`      |         Não |   Não | Último login bem-sucedido registrado                  |
| `criado_em`       | `TimestampUTC`      |         Sim |   Não | Momento de criação do usuário                         |
| `atualizado_em`   | `TimestampUTC`      |         Sim |   Não | Última atualização do cadastro                        |

### Domínio recomendado de `status_usuario`

* `active`
* `inactive`
* `locked`

### Regras

* `email_login` deve ser único e tratado de forma canônica;
* usuário inativo ou bloqueado não deve autenticar;
* `senha_hash` nunca deve ser exposto ao cliente;
* `ultimo_login_em` é informacional/operacional e não substitui trilha de auditoria.

### Relacionamentos

* 1:N com `SessaoAdministrativa`
* N:N com `PerfilAcesso` por meio de `UsuarioPerfil`
* 1:N com `Publicacao` como autor/operador, conforme papel da ação
* 1:N com `PublicacaoVersao`
* 1:N com `AuditoriaEvento`

### Origem dominante

* API administrativa
* Módulo de autenticação/sessão
* Governança de usuários

### Uso operacional

* login
* autorização
* trilha de responsabilidade
* exibição de operador no painel
* auditoria

---

## 9.2 Entidade `PerfilAcesso`

### Missão

Representar um papel formal do sistema para fins de RBAC.

### Natureza

Catálogo soberano de perfis.

### Chave lógica principal

* `perfil_id`
* `codigo_perfil`

### Atributos

| Atributo           | Tipo conceitual    | Obrigatório | Único | Descrição / uso                                 |
| ------------------ | ------------------ | ----------: | ----: | ----------------------------------------------- |
| `perfil_id`        | `UUID`             |         Sim |   Sim | Identificador soberano do perfil                |
| `codigo_perfil`    | `EnumCodigoPerfil` |         Sim |   Sim | Código canônico do papel                        |
| `nome_perfil`      | `TextoCurto`       |         Sim |   Não | Nome de leitura humana                          |
| `descricao_perfil` | `TextoMedio`       |         Sim |   Não | Descrição semântica do papel                    |
| `ativo`            | `Bool`             |         Sim |   Não | Indica se o perfil está vigente para atribuição |
| `criado_em`        | `TimestampUTC`     |         Sim |   Não | Data de criação do perfil                       |
| `atualizado_em`    | `TimestampUTC`     |         Sim |   Não | Data da última atualização                      |

### Domínio inicial recomendado de `codigo_perfil`

* `OPERADOR_EDITORIAL`
* `REVISOR_EDITORIAL`
* `PUBLICADOR_EDITORIAL`
* `AUDITOR_INTERNO`
* `ADMINISTRADOR_SISTEMA`

### Regras

* perfil público visitante não precisa ser persistido como papel interno;
* `codigo_perfil` é fonte de verdade para leitura de RBAC;
* perfis podem ser acumulados por um mesmo usuário.

### Relacionamentos

* N:N com `UsuarioInterno` por `UsuarioPerfil`

### Origem dominante

* Governança administrativa
* Segurança/autorização

### Uso operacional

* resolução de permissão por papel
* construção de matriz RBAC
* leitura de responsabilidade organizacional

---

## 9.3 Entidade `UsuarioPerfil`

### Missão

Representar a atribuição de um ou mais perfis a um usuário interno.

### Natureza

Entidade associativa de autorização.

### Chave lógica principal

* `usuario_perfil_id`
* unicidade composta de (`usuario_id`, `perfil_id`, `ativo`), conforme estratégia

### Atributos

| Atributo                   | Tipo conceitual  | Obrigatório | Único | Descrição / uso                            |
| -------------------------- | ---------------- | ----------: | ----: | ------------------------------------------ |
| `usuario_perfil_id`        | `UUID`           |         Sim |   Sim | Identificador soberano da atribuição       |
| `usuario_id`               | `UUID`           |         Sim |   Não | Referência ao usuário interno              |
| `perfil_id`                | `UUID`           |         Sim |   Não | Referência ao perfil                       |
| `ativo`                    | `Bool`           |         Sim |   Não | Indica se a atribuição está vigente        |
| `escopo_contextual`        | `JsonControlado` |         Não |   Não | Contextos adicionais para ABAC/refinamento |
| `atribuido_por_usuario_id` | `UUID`           |         Não |   Não | Quem concedeu o perfil                     |
| `atribuido_em`             | `TimestampUTC`   |         Sim |   Não | Momento de atribuição                      |
| `revogado_em`              | `TimestampUTC`   |         Não |   Não | Momento de revogação, se houver            |

### Regras

* um mesmo usuário pode ter múltiplos perfis ativos;
* `escopo_contextual` só deve existir quando houver contrato claro;
* revogação deve preservar histórico, não apagar vínculo arbitrariamente.

### Relacionamentos

* N:1 com `UsuarioInterno`
* N:1 com `PerfilAcesso`
* N:1 opcional com `UsuarioInterno` em `atribuido_por_usuario_id`

### Origem dominante

* Gestão administrativa de acesso
* Módulo de autorização

### Uso operacional

* cálculo de permissões
* trilha de atribuição de acesso
* refinamento ABAC

---

## 9.4 Entidade `SessaoAdministrativa`

### Missão

Representar o ciclo de vida da sessão autenticada no ambiente interno.

### Natureza

Entidade operacional de autenticação/sessão.

### Chave lógica principal

* `sessao_id`
* `token_ref` ou `jti`, conforme implementação

### Atributos

| Atributo            | Tipo conceitual    | Obrigatório | Único | Descrição / uso                   |
| ------------------- | ------------------ | ----------: | ----: | --------------------------------- |
| `sessao_id`         | `UUID`             |         Sim |   Sim | Identificador soberano da sessão  |
| `usuario_id`        | `UUID`             |         Sim |   Não | Dono da sessão                    |
| `token_ref`         | `HashSeguro`       |         Sim |   Sim | Referência segura do token/sessão |
| `status_sessao`     | `EnumStatusSessao` |         Sim |   Não | Estado atual da sessão            |
| `iniciado_em`       | `TimestampUTC`     |         Sim |   Não | Início da sessão                  |
| `expira_em`         | `TimestampUTC`     |         Sim |   Não | Momento de expiração prevista     |
| `encerrado_em`      | `TimestampUTC`     |         Não |   Não | Momento de encerramento explícito |
| `ip_origem_hash`    | `HashSeguro`       |         Não |   Não | Hash contextual de origem         |
| `user_agent_resumo` | `TextoMedio`       |         Não |   Não | Resumo do agente de cliente       |
| `correlation_id`    | `CorrelationId`    |         Não |   Não | Correlação operacional da sessão  |

### Domínio recomendado de `status_sessao`

* `active`
* `expired`
* `revoked`
* `closed`

### Regras

* sessão ativa não pode ser tratada como eterna;
* sessão expirada, revogada ou encerrada não deve autorizar requisições protegidas;
* `token_ref` deve ser persistido de forma segura;
* sessão é fonte operacional, mas eventos sensíveis também precisam ir para auditoria.

### Relacionamentos

* N:1 com `UsuarioInterno`
* 1:N lógico com `AuditoriaEvento`

### Origem dominante

* Módulo de autenticação/sessão
* API administrativa

### Uso operacional

* controle de acesso
* expiração
* revogação
* trilha de login/logout
* investigação operacional

---

## 9.5 Entidade `Publicacao`

### Missão

Representar a unidade soberana de conteúdo editorial do projeto, base de leitura pública, operação interna e descoberta orgânica.

### Natureza

Entidade central de domínio editorial.

### Chave lógica principal

* `publicacao_id`
* `slug_atual` como chave pública amigável

### Atributos

| Atributo                     | Tipo conceitual       | Obrigatório | Único | Descrição / uso                                        |
| ---------------------------- | --------------------- | ----------: | ----: | ------------------------------------------------------ |
| `publicacao_id`              | `UUID`                |         Sim |   Sim | Identificador soberano da publicação                   |
| `titulo`                     | `TextoCurto`          |         Sim |   Não | Título principal da publicação                         |
| `resumo`                     | `TextoMedio`          |         Não |   Não | Síntese pública/editorial                              |
| `corpo`                      | `RichText`            |         Sim |   Não | Conteúdo principal                                     |
| `slug_atual`                 | `Slug`                |         Sim |   Sim | Rota pública amigável atual                            |
| `status_editorial`           | `EnumStatusEditorial` |         Sim |   Não | Estado editorial soberano                              |
| `seo_titulo`                 | `TextoCurto`          |         Não |   Não | Título SEO opcional, se diferente do título principal  |
| `seo_descricao`              | `TextoMedio`          |         Não |   Não | Descrição SEO opcional                                 |
| `og_image_url`               | `URLPublica`          |         Não |   Não | Imagem social/compartilhamento, quando houver          |
| `robots_policy_override`     | `TextoCurto`          |         Não |   Não | Exceção controlada de política de indexação, se houver |
| `autor_principal_usuario_id` | `UUID`                |         Não |   Não | Referência ao autor/operador principal                 |
| `criado_por_usuario_id`      | `UUID`                |         Sim |   Não | Quem criou a publicação internamente                   |
| `atualizado_por_usuario_id`  | `UUID`                |         Não |   Não | Último operador que alterou o conteúdo/estado          |
| `criado_em`                  | `TimestampUTC`        |         Sim |   Não | Criação do registro                                    |
| `atualizado_em`              | `TimestampUTC`        |         Sim |   Não | Última atualização                                     |
| `publicado_em`               | `TimestampUTC`        |         Não |   Não | Momento da publicação pública                          |
| `arquivado_em`               | `TimestampUTC`        |         Não |   Não | Momento do arquivamento                                |

### Domínio recomendado de `status_editorial`

* `draft`
* `review`
* `ready_to_publish`
* `published`
* `archived`

### Regras

* `slug_atual` deve ser globalmente único;
* visibilidade pública deriva de `status_editorial = published`;
* `publicado_em` só faz sentido quando o conteúdo entra em `published`;
* `arquivado_em` só faz sentido quando o conteúdo entra em `archived`;
* `seo_titulo` e `seo_descricao` são opcionais; se ausentes, a camada pública deriva de `titulo` e `resumo`;
* `robots_policy_override` deve ser excepcional e controlado;
* preview não cria atributo novo na entidade; é modo de leitura interna.

### Relacionamentos

* N:1 com `UsuarioInterno` em múltiplos papéis
* 1:N com `PublicacaoVersao`
* 1:N com `HistoricoSlugPublicacao`
* 1:N lógico com `AuditoriaEvento`

### Origem dominante

* Painel administrativo
* API editorial
* Workflow de publicação

### Uso operacional

* listagem pública
* página pública por slug
* listagem interna
* edição
* revisão
* publicação
* arquivamento
* metadata
* rastreabilidade

---

## 9.6 Entidade `PublicacaoVersao`

### Missão

Registrar snapshots imutáveis de uma publicação ao longo de seu ciclo editorial.

### Natureza

Entidade de versionamento append-only.

### Chave lógica principal

* `publicacao_versao_id`
* unicidade composta de (`publicacao_id`, `numero_versao`)

### Atributos

| Atributo                    | Tipo conceitual       | Obrigatório | Único | Descrição / uso                         |
| --------------------------- | --------------------- | ----------: | ----: | --------------------------------------- |
| `publicacao_versao_id`      | `UUID`                |         Sim |   Sim | Identificador soberano da versão        |
| `publicacao_id`             | `UUID`                |         Sim |   Não | Referência à publicação-mãe             |
| `numero_versao`             | `IntPositivo`         |         Sim |   Não | Sequencial da versão                    |
| `snapshot_titulo`           | `TextoCurto`          |         Sim |   Não | Título no momento da versão             |
| `snapshot_resumo`           | `TextoMedio`          |         Não |   Não | Resumo no momento da versão             |
| `snapshot_corpo`            | `RichText`            |         Sim |   Não | Corpo no momento da versão              |
| `snapshot_slug`             | `Slug`                |         Sim |   Não | Slug vigente no momento da versão       |
| `snapshot_status_editorial` | `EnumStatusEditorial` |         Sim |   Não | Estado editorial no momento do snapshot |
| `motivo_versao`             | `TextoMedio`          |         Não |   Não | Motivo contextual da nova versão        |
| `gerado_por_usuario_id`     | `UUID`                |         Não |   Não | Quem gerou a versão                     |
| `gerado_em`                 | `TimestampUTC`        |         Sim |   Não | Momento de criação da versão            |

### Regras

* versões são imutáveis;
* não se deve sobrescrever versão antiga;
* a versão serve à rastreabilidade editorial, não substitui audit trail;
* `numero_versao` deve crescer monotonicamente por `publicacao_id`.

### Relacionamentos

* N:1 com `Publicacao`
* N:1 opcional com `UsuarioInterno`

### Origem dominante

* API editorial
* workflow de criação/edição
* governança de histórico

### Uso operacional

* histórico de conteúdo
* reversão guiada, se futuramente adotada
* inspeção editorial
* evidência de mudança material

---

## 9.7 Entidade `HistoricoSlugPublicacao`

### Missão

Preservar o histórico de slugs usados por uma publicação, protegendo consistência de rota, SEO e possíveis redirecionamentos.

### Natureza

Entidade de histórico e identidade pública de rota.

### Chave lógica principal

* `historico_slug_publicacao_id`
* unicidade global do atributo `slug`

### Atributos

| Atributo                       | Tipo conceitual | Obrigatório | Único | Descrição / uso                                       |
| ------------------------------ | --------------- | ----------: | ----: | ----------------------------------------------------- |
| `historico_slug_publicacao_id` | `UUID`          |         Sim |   Sim | Identificador soberano do registro histórico          |
| `publicacao_id`                | `UUID`          |         Sim |   Não | Referência à publicação                               |
| `slug`                         | `Slug`          |         Sim |   Sim | Slug reservado ou anteriormente utilizado             |
| `e_slug_atual`                 | `Bool`          |         Sim |   Não | Indica se este registro corresponde ao slug vigente   |
| `vigente_desde_em`             | `TimestampUTC`  |         Sim |   Não | Início da vigência do slug                            |
| `vigente_ate_em`               | `TimestampUTC`  |         Não |   Não | Fim da vigência, quando substituído                   |
| `redirecionar_para_slug_atual` | `Bool`          |         Sim |   Não | Indica política de redirecionamento, quando aplicável |

### Regras

* slugs históricos também devem permanecer reservados para evitar colisão e ambiguidade;
* apenas um slug por publicação pode estar marcado como atual em dado momento;
* mudança de slug deve atualizar `Publicacao.slug_atual` e refletir neste histórico;
* este histórico é especialmente importante para SEO e integridade de rotas públicas.

### Relacionamentos

* N:1 com `Publicacao`

### Origem dominante

* API editorial
* lógica de publicação/SEO
* manutenção de rotas

### Uso operacional

* canonicalização
* redirecionamento
* proteção contra colisão
* histórico de rota pública

---

## 9.8 Entidade `AuditoriaEvento`

### Missão

Registrar eventos sensíveis de governança, segurança e operação com valor auditável.

### Natureza

Entidade append-only de trilha auditável.

### Chave lógica principal

* `auditoria_evento_id`

### Atributos

| Atributo              | Tipo conceitual           | Obrigatório | Único | Descrição / uso                         |
| --------------------- | ------------------------- | ----------: | ----: | --------------------------------------- |
| `auditoria_evento_id` | `UUID`                    |         Sim |   Sim | Identificador soberano do evento        |
| `tipo_evento`         | `EnumTipoEventoAuditoria` |         Sim |   Não | Tipo canônico do evento                 |
| `recurso_tipo`        | `TextoCurto`              |         Sim |   Não | Tipo do recurso afetado                 |
| `recurso_id`          | `UUID`                    |         Não |   Não | Identificador do recurso, quando houver |
| `usuario_id`          | `UUID`                    |         Não |   Não | Usuário associado ao evento             |
| `sessao_id`           | `UUID`                    |         Não |   Não | Sessão associada ao evento              |
| `estado_anterior`     | `JsonControlado`          |         Não |   Não | Estado relevante antes da ação          |
| `estado_novo`         | `JsonControlado`          |         Não |   Não | Estado relevante depois da ação         |
| `resultado`           | `EnumResultadoAuditoria`  |         Sim |   Não | Sucesso, negação, falha etc.            |
| `contexto_json`       | `JsonControlado`          |         Não |   Não | Contexto adicional estruturado          |
| `ip_origem_hash`      | `HashSeguro`              |         Não |   Não | Hash do IP de origem, quando relevante  |
| `user_agent_resumo`   | `TextoMedio`              |         Não |   Não | Resumo do agente do cliente             |
| `correlation_id`      | `CorrelationId`           |         Não |   Não | Correlação com requisição/log           |
| `ocorrido_em`         | `TimestampUTC`            |         Sim |   Não | Momento do evento                       |

### Domínio mínimo recomendado de `tipo_evento`

* `login_succeeded`
* `login_failed`
* `logout_succeeded`
* `session_expired`
* `access_denied`
* `publication_created`
* `publication_updated`
* `publication_status_changed`
* `publication_published`
* `publication_archived`
* `preview_requested`
* `transition_denied`

### Domínio mínimo recomendado de `resultado`

* `success`
* `denied`
* `failed`

### Regras

* auditoria é append-only;
* não se edita evento auditável como dado comum;
* campos de contexto devem seguir contrato controlado e não virar dumping genérico;
* audit trail não substitui logs técnicos, mas deve conversar com eles via `correlation_id`.

### Relacionamentos

* N:1 opcional com `UsuarioInterno`
* N:1 opcional com `SessaoAdministrativa`
* relação lógica polimórfica com recursos diversos, como `Publicacao`

### Origem dominante

* API
* autenticação/sessão
* transições editoriais
* autorização
* eventos críticos de governança

### Uso operacional

* trilha auditável
* investigação de incidente
* governança
* prova de ação
* supervisão interna

---

# 10. Relacionamentos estruturais do catálogo

## 10.1 Relações centrais

### `UsuarioInterno` ↔ `PerfilAcesso`

Relação:

* N:N via `UsuarioPerfil`

Função:

* modelar RBAC com potencial refinamento contextual.

---

### `UsuarioInterno` ↔ `SessaoAdministrativa`

Relação:

* 1:N

Função:

* um usuário pode possuir várias sessões ao longo do tempo.

---

### `UsuarioInterno` ↔ `Publicacao`

Relação:

* 1:N em papéis distintos:

  * criador;
  * atualizador;
  * autor principal, quando aplicável.

---

### `Publicacao` ↔ `PublicacaoVersao`

Relação:

* 1:N

Função:

* preservar snapshots editoriais.

---

### `Publicacao` ↔ `HistoricoSlugPublicacao`

Relação:

* 1:N

Função:

* preservar identidade pública de rota ao longo do tempo.

---

### `UsuarioInterno` / `SessaoAdministrativa` / `Publicacao` ↔ `AuditoriaEvento`

Relação:

* 1:N lógica

Função:

* vincular ação, sujeito, sessão e recurso a eventos auditáveis.

---

# 11. Chaves lógicas, unicidade e integridade

## 11.1 Regras mínimas de unicidade

Devem ser únicos, no mínimo:

* `UsuarioInterno.email_login`
* `PerfilAcesso.codigo_perfil`
* `SessaoAdministrativa.token_ref`
* `Publicacao.slug_atual`
* `HistoricoSlugPublicacao.slug`
* combinação (`publicacao_id`, `numero_versao`) em `PublicacaoVersao`

---

## 11.2 Regras mínimas de integridade

### Publicação

* não pode existir sem título, corpo, slug e status editorial válidos;
* `publicado_em` não deve ser preenchido sem publicação real;
* `arquivado_em` não deve ser preenchido sem arquivamento real.

### Sessão

* sessão ativa precisa ter `expira_em`;
* sessão encerrada/revogada não deve continuar válida.

### Usuário

* usuário bloqueado ou inativo não deve produzir sessão válida.

### Auditoria

* evento crítico precisa ter `tipo_evento`, `resultado` e `ocorrido_em`.

---

## 11.3 Regra sobre visibilidade pública

A visibilidade pública **não** deve ser modelada como fonte paralela soberana quando o sistema já possui `status_editorial`.

Regra recomendada:

* `published` = elegível à camada pública
* demais estados = não públicos

---

# 12. Entidades derivadas e artefatos não soberanos

Nem todo objeto importante do sistema precisa ser uma tabela/entidade própria.

## 12.1 `robots.txt`

Natureza:

* artefato derivado de política pública do site

Origem:

* configuração do projeto + regras de indexação

---

## 12.2 `sitemap.xml`

Natureza:

* artefato derivado

Origem:

* rotas públicas válidas
* publicações em estado `published`

---

## 12.3 Canonical de publicação

Natureza:

* valor derivado

Origem:

* `slug_atual`
* topologia do domínio
* política de canonicalização

---

## 12.4 Preview interno

Natureza:

* modo de acesso/visualização
* não entidade soberana

Origem:

* `Publicacao` + sessão válida + permissão adequada

---

## 12.5 Permissão efetiva

Natureza:

* decisão calculada
* não tabela soberana obrigatória neste estágio

Origem:

* `UsuarioPerfil`
* recurso
* ação
* estado do recurso
* contexto ABAC

---

# 13. Consultas e usos operacionais prioritários

A modelagem acima existe para sustentar algumas consultas centrais do sistema.

## 13.1 Consultas públicas

* listar publicações `published`
* resolver publicação por `slug_atual`
* compor metadata pública
* compor sitemap

## 13.2 Consultas administrativas

* listar publicações por status
* abrir publicação por ID para edição
* abrir preview interno
* validar elegibilidade para publicação
* recuperar histórico de versões

## 13.3 Consultas de autenticação

* localizar usuário por `email_login`
* validar estado do usuário
* localizar sessão por referência/token
* invalidar/revogar sessão

## 13.4 Consultas de autorização

* resolver perfis ativos do usuário
* combinar perfis com contexto e recurso

## 13.5 Consultas de auditoria

* listar eventos por usuário
* listar eventos por publicação
* listar eventos por sessão
* filtrar eventos críticos por período/tipo/resultado

---

# 14. Índices conceituais recomendados

Sem entrar ainda em DDL físico, a camada de dados deve prever, conceitualmente, índices úteis para:

* `email_login`
* `slug_atual`
* `status_editorial`
* `publicado_em`
* `usuario_id` em sessões
* `status_sessao` + `expira_em`
* `publicacao_id` + `numero_versao`
* `recurso_tipo` + `recurso_id` em auditoria
* `usuario_id` + `ocorrido_em` em auditoria
* `tipo_evento` + `ocorrido_em` em auditoria

---

# 15. Regras semânticas por campo sensível

## 15.1 `slug_atual`

Não é mero alias visual; é identidade pública de rota.

## 15.2 `status_editorial`

Não é etiqueta cosmética; governa ciclo de vida e visibilidade.

## 15.3 `token_ref`

Não é token bruto exposto; é referência segura de sessão.

## 15.4 `senha_hash`

Nunca é dado de leitura de interface nem de API pública.

## 15.5 `seo_titulo` / `seo_descricao`

São complementos estratégicos; não devem duplicar conteúdo sem necessidade.

## 15.6 `contexto_json` de auditoria

Não é depósito livre; precisa permanecer contratual.

---

# 16. Anti-padrões explicitamente proibidos

Este documento proíbe, de forma expressa:

## 16.1 Coluna “status” sem domínio explícito

Todo status relevante precisa indicar de qual domínio é.

## 16.2 Duplicar visibilidade pública fora do status editorial sem necessidade

Isso cria divergência estrutural.

## 16.3 Slug sem política de unicidade

Rota pública sem identidade estável compromete conteúdo e SEO.

## 16.4 Auditoria mutável como dado comum

Trilha auditável não pode ser tratada como campo decorativo.

## 16.5 Sessão implícita não persistível em contexto que exige governança

Quando a arquitetura exige controle, a sessão deve ser entidade real.

## 16.6 Campo genérico “dados” sem contrato

JSON livre sem semântica vira descarte de modelagem.

## 16.7 Confundir dado derivado com dado soberano

Canonical, sitemap e preview não devem competir com entidades centrais.

## 16.8 Misturar autoria editorial, operador técnico e auditoria como se fossem o mesmo papel

São relações diferentes e precisam permanecer distinguíveis.

---

# 17. Relação deste documento com os próximos artefatos

Este documento prepara diretamente:

## `011_Matriz_de_Dependencias_entre_Bloco_e_Modulos.md`

Porque agora já existe base semântica para mapear dependências reais entre dados, API, auth, SEO e auditoria.

## `012_Politica_de_Versionamento_e_Compatibilidade.md`

Porque `PublicacaoVersao`, `HistoricoSlugPublicacao` e integridade contratual já foram enquadrados.

## `017_Procedimentos_de_QA_Manual.md`

Porque entidades, estados e atributos agora podem ser verificados por cenário.

## Implementação futura do backend

Porque a modelagem deixa de ser intuitiva e passa a ter léxico soberano.

---

# 18. Síntese executiva

A leitura executiva deste documento é:

* o projeto agora possui um léxico formal de dados;
* as entidades soberanas do núcleo atual foram definidas;
* publicação, sessão, perfis, auditoria e SEO foram articulados de forma coerente;
* slug e status editorial foram tratados como dados estratégicos;
* audit trail e versionamento foram distinguidos;
* artefatos derivados foram separados das entidades principais;
* a modelagem agora sustenta:

  * publicação pública;
  * operação interna;
  * autenticação;
  * autorização;
  * rastreabilidade;
  * descoberta orgânica.

Em linguagem simples:

> no projeto William Albarello, os dados deixaram de ser uma hipótese solta e passaram a ser um catálogo arquitetural formal, com nomes, funções, regras e relações reconhecíveis.

---

# 19. Conclusão

Se os documentos anteriores definiram superfícies, módulos, estados, permissões e falhas, este documento define **o vocabulário semântico do que o sistema realmente guarda, lê, transforma e rastreia**.

Ele consolida oito mensagens principais:

1. **sem nome certo, não há dado certo;**
2. **entidade existe para servir ao domínio, não à pressa da implementação;**
3. **publicação é o centro editorial soberano do sistema;**
4. **sessão é parte real da arquitetura;**
5. **perfis e atribuições precisam ser modelados com clareza;**
6. **auditoria e versionamento não são a mesma coisa;**
7. **SEO depende de dados corretos e estáveis;**
8. **artefato derivado não deve competir com a fonte de verdade.**

A mensagem final deste documento é:

> no projeto William Albarello, a maturidade da implementação dependerá diretamente da qualidade com que o sistema nomeia, estrutura e preserva seus dados, porque é essa camada semântica que sustenta publicação, segurança, rastreabilidade, SEO e continuidade sem colapso conceitual.

---

