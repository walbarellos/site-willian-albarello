# 010 - SLI, SLO, SLA e Error Budget

## Objetivo
Definir o baseline de confiabilidade do `personal-site` com SLI, SLO, SLA e error budget aderentes ao estado atual de observabilidade e operacao do projeto.

## Escopo
Inclui:
1. indicadores de nivel de servico que podem ser medidos hoje;
2. metas internas (SLO) realistas para o estagio atual;
3. posicao de SLA no ciclo atual;
4. politica de error budget e governanca de release.

Nao inclui:
1. compromissos externos contratuais de SLA ainda nao formalizados;
2. metas que dependam de telemetria inexistente no repositorio;
3. modelo enterprise de confiabilidade fora da maturidade atual.

## Fontes soberanas usadas
1. `docs/01-Waterfall/04-High_Tech/009_Monitoramento_Metrics_Tracing_e_Alertas.md`
2. `apps/api/src/routes/health.ts`
3. `infra/scripts/smoke.sh`
4. `.github/workflows/deploy-readiness.yml`
5. `QA/QA-02-matriz-de-gates-ci-e-deploy-readiness.md`
6. `infra/ci/RELEASE-EVIDENCE-CHECKLIST.md`
7. `apps/api/src/server.ts`

## Premissas do estagio atual

1. observabilidade P0 existe (health/ready + logs + traceId + CI gates);
2. nao existe stack centralizada de metricas temporais no repositorio;
3. parte da operacao de confiabilidade ainda depende de disciplina de execucao dos runbooks/checklists.

## Definicoes praticas

- SLI: indicador mensuravel de comportamento do servico.
- SLO: meta interna para cada SLI.
- SLA: compromisso formal com parte externa.
- Error budget: margem de erro permitida antes de bloquear aceleracao de mudanca.

## 1) SLI oficiais do ciclo atual

## SLI-01 - Disponibilidade de health

Formula:
- sucesso quando `GET /health` retorna `200` com `meta.traceId`.

Fonte de medicao:
- `infra/scripts/smoke.sh` + verificacoes operacionais.

## SLI-02 - Disponibilidade de readiness

Formula:
- sucesso quando `GET /ready` retorna `200` (ou `503` somente em falha bloqueante de dependencia durante incidente controlado).

Fonte:
- health/readiness checks + triagem operacional.

## SLI-03 - Integridade de fluxo publico minimo

Formula:
- sucesso quando `GET /` e `GET /publicacoes` respondem `200` com HTML/conteudo esperado no smoke.

Fonte:
- `infra/scripts/smoke.sh`.

## SLI-04 - Integridade de fluxo admin minimo

Formula:
- sucesso quando `GET /painel/login` responde `200` e conteudo de login e identificado.

Fonte:
- `infra/scripts/smoke.sh`.

## SLI-05 - Confiabilidade de pipeline tecnico

Formula:
- sucesso quando pipeline de readiness permanece verde:
  1. `pnpm test:ci`
  2. `pnpm verify:hardening`
  3. `release-check` em modo CI

Fonte:
- `.github/workflows/deploy-readiness.yml`.

## SLI-06 - Rastreabilidade de incidente

Formula:
- sucesso quando falhas relevantes possuem `traceId` recuperavel no fluxo client/API.

Fonte:
- envelope HTTP + logs API + erros tipados de clients.

## 2) SLO internos propostos (estado atual)

## Janela de avaliacao

Padrao inicial: janela mensal (rolling 30 dias), com revisao por ciclo.

## Metas

1. SLO-01 (`/health`): >= 99.5% de sucesso na janela.
2. SLO-02 (`/ready`): >= 99.0% de sucesso na janela.
3. SLO-03 (smoke web+admin minimo): >= 99.0% de sucesso nas rodadas de readiness.
4. SLO-04 (pipeline deploy-readiness): >= 95% de execucoes verdes por janela de mudanca.
5. SLO-05 (rastreabilidade): >= 99% de incidentes com `traceId` correlacionavel.

Observacao:
- estes SLOs sao internos e refletem maturidade P0/P1, nao compromisso comercial externo final.

## 3) SLA no estado atual

## Posicao oficial

No ciclo atual, **nao ha SLA externo contratual fechado no repositorio**.

O que existe:
1. SLO interno para governanca de engenharia;
2. protocolos de release e rollback para reduzir indisponibilidade;
3. criterio objetivo para bloquear mudanca quando qualidade cai.

Diretriz:
- SLA externo so deve ser declarado apos consolidar observabilidade centralizada, retencao de metricas e rotina operacional estavel.

## 4) Error Budget

## 4.1 Regra geral

Error budget mensal = `100% - SLO alvo` por indicador.

Exemplos:
1. SLO 99.5% -> budget 0.5%
2. SLO 99.0% -> budget 1.0%

## 4.2 Politica de consumo

### Estado VERDE (consumo baixo)
Condicao:
- consumo <= 50% do budget na janela.

Acao:
1. pode acelerar melhorias e refino tecnico;
2. manter monitoramento normal.

### Estado AMARELO (pressao moderada)
Condicao:
- consumo > 50% e <= 100% do budget.

Acao:
1. reduzir mudancas de risco alto;
2. priorizar estabilizacao nos PRs;
3. reforcar checklist de release evidence.

### Estado VERMELHO (budget estourado)
Condicao:
- consumo > 100% do budget.

Acao obrigatoria:
1. congelar mudanca nao critica;
2. priorizar correcoes de confiabilidade;
3. liberar nova versao somente com evidencias de recuperacao.

## 4.3 Gatilhos de bloqueio automatico por processo

Mesmo sem automacao completa de budget, a governanca deve bloquear release quando ocorrer qualquer condicao:
1. `deploy-readiness` vermelho;
2. `test:ci` vermelho;
3. `verify:hardening` vermelho;
4. `smoke` local com FAIL;
5. checklist de evidencia de release incompleto nos itens bloqueantes.

## 5) Governanca operacional

## Cadencia

1. revisar SLI/SLO no fechamento de cada versao;
2. registrar status no relatorio final da versao;
3. atualizar QA-02 quando a cobertura de medicao evoluir.

## Ownership

1. engenharia de release: manter gates e evidencias;
2. engenharia de aplicacao: corrigir causas de consumo de budget;
3. responsavel de ciclo: decidir liberar/bloquear com base em evidencias.

## 6) Limites do modelo atual

1. medicao ainda parcialmente operacional/manual;
2. sem painel temporal centralizado para historico longo;
3. sem alerta proativo automatizado por threshold no repositorio.

Esses limites sao aceitos neste estagio e nao invalidam o uso de SLO interno para governanca.

## 7) Evolucao recomendada

## Fase 1 - Instrumentacao minima adicional
1. consolidar coleta recorrente de disponibilidade/latencia;
2. padronizar registro de incidentes vs consumo de budget.

## Fase 2 - Medicao automatizada
1. introduzir coleta temporal consolidada;
2. calcular consumo de budget automaticamente por janela.

## Fase 3 - SLA externo (quando pronto)
1. transformar SLO maduro em SLA formal apenas apos estabilidade comprovada;
2. publicar escopo, exclusoes e metodo de medicao do SLA.

## 8) Criterio de aceite deste documento

Este documento esta aprovado quando:
1. define SLI/SLO mensuraveis com o que ja existe hoje;
2. nao promete SLA externo ainda nao suportado;
3. estabelece politica clara de error budget e bloqueio de release;
4. permanece coerente com gates de QA/CI e runbooks do projeto.

## Conclusao tecnica

O `personal-site` ja possui base suficiente para operar com confiabilidade orientada por SLO interno e error budget, mesmo sem stack completa de observabilidade enterprise.

A disciplina correta neste estagio e:
1. medir com os sinais reais disponiveis;
2. bloquear release quando budget/gates degradarem;
3. evoluir gradualmente para automacao de medicao e, so depois, formalizacao de SLA externo.
