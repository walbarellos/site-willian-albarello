# 006 - Event Driven, Webhooks, Filas e Assincronismo

## Objetivo
Documentar o estado real do projeto em relacao a processamento assincrono, eventos, webhooks e filas, sem criar falso positivo de arquitetura que ainda nao existe.

## Escopo
Inclui:
1. modelo atual de execucao (sincrono/request-response);
2. pontos em que o sistema ja tem semantica de evento de dominio;
3. limites atuais por ausencia de fila/webhook;
4. trilha incremental para evolucao assincrona.

Nao inclui:
1. implementacao imediata de broker;
2. adocao prematura de arquitetura complexa;
3. promessa de SLA assincrono nao suportado no estado atual.

## Fontes soberanas usadas
1. `apps/api/src/routes/publications-admin.ts`
2. `apps/api/src/routes/publications-public.ts`
3. `apps/api/src/routes/auth.ts`
4. `apps/api/src/server.ts`
5. `apps/admin/src/lib/api/admin.ts`
6. `apps/web/src/lib/api/public.ts`
7. `infra/scripts/release-check.sh`
8. `infra/scripts/smoke.sh`
9. `.github/workflows/deploy-readiness.yml`

## Veredito tecnico do estado atual

### Estado oficial
O projeto opera hoje em **modelo sincrono HTTP request-response**, sem barramento de eventos e sem infraestrutura de filas.

### O que nao existe hoje (fisicamente)
1. nao existe broker (`RabbitMQ`, `Kafka`, `SQS`, etc.);
2. nao existe worker dedicado de consumo de fila;
3. nao existe endpoint de webhook de terceiros;
4. nao existe outbox/event-store no backend;
5. nao existe scheduler/cron de tarefas assincronas persistentes no repositorio.

### O que existe hoje
1. rotas administrativas e publicas com resposta imediata;
2. mutacoes editoriais processadas inline no request;
3. validacao e transicao de status no mesmo ciclo de requisicao;
4. testes e gates focados em contrato HTTP e hardening sincrono.

## Mapa de fluxos atuais

## F1 - Publicacao administrativa (create/update/transition)

Fluxo:
1. admin envia request HTTP (`POST/PATCH`);
2. API valida body/query/params;
3. API aplica regra de negocio e muta estado;
4. API retorna envelope de sucesso/erro no mesmo request.

Caracteristica:
- processamento acoplado ao tempo da requisicao.

## F2 - Leitura publica

Fluxo:
1. web solicita listagem/detalhe via API publica;
2. API resolve consulta e responde imediatamente;
3. pagina publica renderiza resultado.

Caracteristica:
- nenhum pre-processamento assincrono intermediario.

## F3 - Autenticacao e sessao admin

Fluxo:
1. login valida credenciais bootstrap;
2. sessao e criada e cookie e emitido;
3. leitura de sessao ocorre por request server-side.

Caracteristica:
- sem fila de auditoria ou eventos de seguranca assincronos.

## Semantica de eventos ja presente (dominio)

Mesmo sem arquitetura event-driven, o dominio ja possui eventos implicitos que podem ser promovidos no futuro:

1. `admin.auth.login.succeeded`
2. `admin.auth.login.failed`
3. `admin.publication.created`
4. `admin.publication.updated`
5. `admin.publication.status.transitioned`
6. `public.publication.published.visible`

Hoje esses eventos existem apenas como significado de negocio/logica, nao como mensagens assincronas persistidas.

## Impactos da ausencia de assicronismo

### Limites atuais
1. tarefas pesadas futuras (SEO enrichment, notificacao, indexacao externa) teriam que rodar inline;
2. retries ficam no nivel de cliente HTTP, nao de fila;
3. sem DLQ nao ha trilha formal de mensagem falha;
4. sem idempotency key de evento, reprocessamento controlado e limitado.

### Beneficio atual
1. arquitetura simples e auditavel;
2. menor custo operacional;
3. menor superficie de falha distribuida no estagio atual.

## Estrategia de evolucao incremental (quando necessario)

## Fase 1 - Event envelope interno (sem broker)

1. padronizar estrutura de evento de dominio (id, type, occurredAt, actor, resource, payload);
2. registrar eventos em log estruturado com `traceId`;
3. mapear quais eventos exigem entrega garantida.

Objetivo:
- preparar transicao sem quebrar rotas atuais.

## Fase 2 - Outbox transacional

1. persistir eventos em tabela/colecao de outbox junto da mutacao principal;
2. criar processo de dispatch com retry controlado;
3. marcar status de entrega (`pending`, `sent`, `failed`).

Objetivo:
- garantir consistencia entre estado de negocio e emissao de evento.

## Fase 3 - Fila/worker

1. introduzir broker conforme necessidade real de throughput;
2. implementar consumidor dedicado com idempotencia;
3. definir DLQ e politicas de retry/backoff.

Objetivo:
- desacoplar tarefas nao criticas do request principal.

## Fase 4 - Webhooks externos

1. expor endpoint de webhook com assinatura/verificacao;
2. implementar replay seguro e idempotente;
3. monitorar taxa de falha e latencia de entrega.

Objetivo:
- integrar servicos externos sem degradar API principal.

## Regras de seguranca e confiabilidade para evolucao

1. nenhum evento assincrono sem `traceId` e correlacao com acao origem;
2. todo consumidor deve ser idempotente;
3. retries precisam de limite e politica explicita;
4. eventos sensiveis devem respeitar politica de segredo/PII;
5. webhook externo so com assinatura valida e controle de replay.

## Criterios para abrir ciclo Event-Driven

Abrir implementacao assincrona somente quando houver pelo menos um caso concreto com ganho comprovado:

1. tarefa de custo alto degradando request sincrono;
2. necessidade de integracao externa orientada a evento;
3. necessidade de entrega eventual com retry garantido;
4. evidencia de gargalo operacional que justifique complexidade extra.

## Indicadores de aceite do modelo atual

Estado atual e considerado correto enquanto:
1. API responde dentro de latencia aceitavel sem fila;
2. fluxos editoriais funcionam integralmente no modelo sincrono;
3. gates de release/hardening seguem verdes;
4. nao ha requisito formal obrigando webhooks/fila.

## Criterio de aceite deste documento

Este documento esta aprovado quando:
1. declara explicitamente que hoje nao ha event-driven implementado;
2. descreve com precisao o modelo sincrono vigente;
3. evita promessa de fila/webhook inexistente;
4. define trilha clara de evolucao assincrona sem ruptura contratual.

## Conclusao tecnica

No estado atual do `personal-site`, a arquitetura sincrona e adequada ao escopo e ao porte do sistema.

Nao existe stack de eventos/webhooks/filas implementada, e isso esta correto neste estagio.

A evolucao para modelo assincrono deve acontecer apenas por necessidade comprovada, seguindo fases incrementais (event envelope -> outbox -> worker/fila -> webhooks), mantendo o contrato HTTP atual estavel durante toda a transicao.
