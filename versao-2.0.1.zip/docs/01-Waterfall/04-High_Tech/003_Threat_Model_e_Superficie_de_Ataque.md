# 003 — Threat Model e Superfície de Ataque

## Endereço

`/home/walbarellos/personal-site/personal-site(Graciliano)/docs/01-Waterfall/04-High_Tech/003_Threat_Model_e_Superficie_de_Ataque.md`

## Objetivo

Registrar o threat model técnico do estado atual do projeto, com foco em:

- API (`apps/api`) em Fastify
- Admin (`apps/admin`) em Next.js
- sessão administrativa por cookie assinado
- mutações administrativas protegidas por CSRF
- fronteiras de origem (CORS)
- rastreabilidade por `traceId`

Este documento descreve o que está materializado no código no ciclo atual. Não descreve arquitetura futura.

## Escopo analisado

### Fontes físicas auditadas

- `apps/api/src/server.ts`
- `apps/api/src/lib/admin-auth.ts`
- `apps/api/src/routes/auth.ts`
- `apps/api/src/routes/dashboard.ts`
- `apps/api/src/routes/publications-admin.ts`
- `apps/admin/src/lib/session.ts`
- `apps/admin/src/lib/api/admin.ts`
- `Waterfall/DOC-14-seguranca-p0.md`

### Fronteiras de sistema

1. Navegador do operador editorial
2. `apps/admin` (render e ações server-side)
3. `apps/api` (rotas públicas e administrativas)
4. Infra de execução (Vercel para web/admin, Render para API)

## Metodologia objetiva

Modelo aplicado: superfície de ataque + STRIDE prático por fluxo crítico.

A análise está organizada por:

1. Ativos críticos
2. Entradas e trust boundaries
3. Vetores de ataque prováveis
4. Controles existentes no código
5. Risco residual e priorização
6. Critérios de aceite para auditoria

## Ativos críticos

### A1 — Sessão administrativa

- cookie `wa_admin_session`
- token de sessão no backend
- identidade (`id`, `email`, `role`) do operador autenticado

Impacto se comprometido: acesso indevido ao painel e mutações editoriais.

### A2 — Integridade editorial

- CRUD de publicações administrativas
- transições de status (`draft`, `review`, `ready_to_publish`, `published`, `archived`)

Impacto se comprometido: publicação indevida, perda de governança e dano reputacional.

### A3 — Segredos e configuração

- `SESSION_SECRET`
- credenciais bootstrap (`ADMIN_BOOTSTRAP_EMAIL`, `ADMIN_BOOTSTRAP_PASSWORD`, `ADMIN_BOOTSTRAP_ROLE`)
- `CORS_ORIGINS`

Impacto se comprometido: bypass de autenticação, forja de sessão, exposição indevida.

### A4 — Disponibilidade de API

- rotas `/health`, `/ready`, `/v1/publications/*`, `/v1/admin/*`

Impacto se comprometido: indisponibilidade de painel e camada pública.

### A5 — Telemetria e rastreabilidade

- `x-trace-id` no request/response
- logs com metadados de requisição e status

Impacto se comprometido: perda de capacidade de investigação e resposta a incidente.

## Superfície de ataque atual

### Entradas HTTP públicas

- `GET /health`
- `GET /ready`
- `GET /v1/publications`
- `GET /v1/publications/:slug`

### Entradas HTTP administrativas

- `POST /v1/admin/auth/login`
- `GET /v1/admin/auth/session`
- `POST /v1/admin/auth/logout`
- `GET /v1/admin/dashboard`
- `GET /v1/admin/publications`
- `GET /v1/admin/publications/:id`
- `POST /v1/admin/publications`
- `PATCH /v1/admin/publications/:id`
- `POST /v1/admin/publications/:id/status`

### Headers relevantes

- `cookie`
- `x-csrf-token`
- `x-trace-id`
- `origin`

### Limites de confiança

1. Browser -> Admin App
2. Admin App -> API
3. API -> sessão/adapter em memória
4. Runtime -> variáveis de ambiente

## Ameaças por fluxo crítico

## F1 — Login administrativo

### Vetores

- brute force de credenciais
- credential stuffing
- enumeração indireta de usuários
- replay de login sem proteção contextual

### Controles existentes

- validação de payload com `zod`
- comparação de segredo com `timingSafeEqual`
- resposta unificada de falha (`401 UNAUTHENTICATED`)
- cookie de sessão `httpOnly`, `signed`, `sameSite=strict`
- `secure` em produção

### Risco residual

- médio: ainda sem MFA e sem anti-automation específico por endpoint

## F2 — Leitura de sessão admin

### Vetores

- uso de cookie adulterado
- sessão expirada reutilizada
- tentativa de elevação por papel

### Controles existentes

- leitura de cookie assinado
- retorno `401 SESSION_EXPIRED` para sessão ausente/inválida
- enforcement de role (`admin`, `editor`) no backend e no server-side do admin

### Risco residual

- baixo a médio: depende de higiene de segredo (`SESSION_SECRET`) e isolamento de ambiente

## F3 — Mutações administrativas (publicações)

### Vetores

- CSRF em `POST/PATCH`
- requisições cross-site com cookie válido
- transição editorial inválida via payload manipulado

### Controles existentes

- plugin `@fastify/csrf-protection`
- header `x-csrf-token` no client admin quando aplicável
- CORS com allowlist explícita e `credentials: true`
- validações de body/query/params com `zod`
- bloqueio de transição inválida (`INVALID_STATE_TRANSITION`)

### Risco residual

- médio: robustez depende da entrega consistente do token CSRF no runtime completo de sessão

## F4 — API abuse e indisponibilidade

### Vetores

- rajadas de requests (DoS de baixa escala)
- saturação por endpoints administrativos

### Controles existentes

- rate limit global `120 req/min`
- padronização de erro `429 RATE_LIMITED`
- separação de rotas e payload mínimo de health/ready

### Risco residual

- médio: sem WAF dedicado e sem rate-limit segmentado por rota crítica

## F5 — Injeção e payload malicioso

### Vetores

- query/path/body com formato inválido
- tentativa de inputs com campos extras

### Controles existentes

- schemas `zod` com `.strict()`
- limites de tamanho e regex para campos sensíveis (slug, password, etc.)
- normalização de erros de validação em envelope consistente

### Risco residual

- baixo: cobertura de schema é boa para o escopo atual

## F6 — Exposição de dados sensíveis em logs

### Vetores

- vazamento de `authorization`, `cookie`, `set-cookie`

### Controles existentes

- redaction no logger (`[REDACTED]`) para headers sensíveis
- logs com `traceId`, status e latência sem payload sensível bruto

### Risco residual

- baixo a médio: depende de disciplina futura em novos pontos de log

## F7 — Cache indevido de rotas administrativas

### Vetores

- cache intermediário de conteúdo administrativo/sessão

### Controles existentes

- `cache-control: no-store/no-cache` em `/v1/admin/*`, `/health`, `/ready`

### Risco residual

- baixo

## F8 — Header injection via `x-trace-id`

### Vetores

- envio de `traceId` malformado para corromper logs/tracing

### Controles existentes

- sanitização de `traceId` por regex
- limite de tamanho (`MAX_TRACE_ID_LENGTH`)
- fallback para UUID interno

### Risco residual

- baixo

## Mapeamento STRIDE resumido

- Spoofing: sessão/cookie/credencial -> mitigado por cookie assinado + validação + role checks
- Tampering: payload e status editorial -> mitigado por `zod` + regras de transição
- Repudiation: rastreio de ações -> mitigado parcialmente por `traceId` e logs; auditoria persistente ainda pendente
- Information Disclosure: headers/logs/cache -> mitigado por redaction, headers de segurança e no-store
- Denial of Service: rajada de requests -> mitigado parcialmente por rate limit global
- Elevation of Privilege: acesso admin/editor -> mitigado por enforcement server-side de papéis

## Matriz de risco (estado atual)

| ID | Ameaça | Probabilidade | Impacto | Nível | Situação |
|---|---|---|---|---|---|
| T-01 | Brute force em login | Média | Alta | Alta | Mitigado parcialmente |
| T-02 | CSRF em mutações admin | Média | Alta | Alta | Mitigado parcialmente |
| T-03 | Compromisso de segredo de sessão | Baixa-Média | Alta | Alta | Mitigado parcialmente |
| T-04 | DoS leve por burst | Média | Média | Média | Mitigado parcialmente |
| T-05 | Injeção via payload inválido | Baixa | Média | Baixa-Média | Bem mitigado |
| T-06 | Vazamento em logs | Baixa | Alta | Média | Mitigado parcialmente |
| T-07 | Cache de conteúdo admin | Baixa | Média | Baixa | Bem mitigado |
| T-08 | TraceId malicioso | Baixa | Baixa-Média | Baixa | Bem mitigado |

## Controles obrigatórios já presentes (baseline)

1. CORS por allowlist (`CORS_ORIGINS`)
2. Cookie administrativo assinado e `httpOnly`
3. `sameSite=strict` para sessão e CSRF
4. `secure` em produção
5. CSRF plugin ativo no backend
6. Rate limit global
7. Headers de segurança no `onRequest`
8. `traceId` em header e envelope
9. Erro contratual padronizado (`code`, `message`, `meta.traceId`)
10. No-cache em rotas administrativas

## Lacunas assumidas para próximos ciclos

1. MFA para autenticação administrativa
2. trilha persistente de auditoria por ação (quem/que/quando)
3. rate limit por rota sensível e por identidade
4. estratégia anti-automation no login
5. playbook de resposta a incidente com severidade e SLA

## Critérios de aceite para auditoria deste documento

1. O documento referencia arquivos reais do repositório e não desenho hipotético.
2. A superfície de ataque lista as rotas administrativas e públicas atuais.
3. O modelo identifica controles concretos já implementados no código.
4. O texto separa risco mitigado vs risco residual sem mascarar lacunas.
5. O conteúdo permanece coerente com `DOC-14-seguranca-p0.md` e com `apps/api/src/server.ts`.

## Conclusão técnica do ciclo

No estado atual, o projeto possui baseline de segurança P0 consistente para operação inicial:

- autenticação e sessão administrativas com controles mínimos sólidos
- mutações administrativas com proteção CSRF e validação estrita
- fronteira de origem controlada por allowlist
- rastreabilidade suficiente para diagnóstico operacional inicial

A exposição residual existe, mas está explícita e delimitada em backlog de segurança avançada, sem impedir a continuidade dos ciclos de documentação High-Tech.
