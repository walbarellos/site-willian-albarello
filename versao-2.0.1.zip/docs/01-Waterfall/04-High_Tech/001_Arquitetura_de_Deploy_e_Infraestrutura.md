# 001 - Arquitetura de Deploy e Infraestrutura

## Objetivo
Documentar a arquitetura real de deploy e infraestrutura do `personal-site`, com base no que esta materializado no repositorio e nos runbooks operacionais.

## Escopo
Inclui:
1. topologia de deploy (`web`, `admin`, `api`);
2. provedores e fronteiras (Vercel/Render);
3. rotas de trafego e dependencia entre servicos;
4. matriz de env e criterios de operacao;
5. riscos de infraestrutura e mitigacoes praticas.

Nao inclui:
1. arquiteturas hipoteticas nao implementadas;
2. plataformas nao usadas no estado atual;
3. automacao de infra inexistente no repositorio.

## Fontes soberanas usadas
1. `infra/README.md`
2. `infra/env/ENVIRONMENT-MATRIX.md`
3. `infra/vercel/web.project.md`
4. `infra/vercel/admin.project.md`
5. `infra/render/api.service.yaml`
6. `Diagrama/DGM-05-deploy-vercel-render.mmd`
7. `infra/scripts/dev-up.sh`
8. `infra/scripts/smoke.sh`
9. `infra/scripts/release-check.sh`
10. `.github/workflows/deploy-readiness.yml`

## Topologia de deploy vigente

### Camada de frontend publico
- App: `apps/web`
- Plataforma-alvo: Vercel
- Dominio alvo: `publico.exemplo.com` (modelo)
- Papel: interface institucional publica (`/`, `/publicacoes`, `/publicacoes/[slug]`)

### Camada de frontend administrativo
- App: `apps/admin`
- Plataforma-alvo: Vercel
- Dominio alvo: `admin.exemplo.com` (modelo)
- Papel: autenticacao e operacao editorial

### Camada de backend
- App: `apps/api`
- Plataforma-alvo: Render (web service)
- Dominio alvo: `api.exemplo.com` (modelo)
- Papel: contratos HTTP admin/publico, sessao, health/ready

## Fluxo de trafego entre servicos
1. navegador acessa `web` (Vercel) em HTTPS;
2. `web` consome API publica (`/v1/public/*`) via `NEXT_PUBLIC_API_URL`;
3. navegador acessa `admin` (Vercel) em HTTPS;
4. `admin` consome API administrativa (`/v1/admin/*`) via `NEXT_PUBLIC_API_URL`;
5. API (Render) aplica CORS por allowlist e politicas de sessao.

## Estrategia de build e start por plataforma

### Vercel - web
- Root: `apps/web`
- Build: `pnpm build`
- Install: `pnpm install --frozen-lockfile`
- Framework: Next.js

### Vercel - admin
- Root: `apps/admin`
- Build: `pnpm build` (internamente `next build --webpack`)
- Install: `pnpm install --frozen-lockfile`
- Framework: Next.js

### Render - api
Arquivo de referencia: `infra/render/api.service.yaml`
- Root: `apps/api`
- Build: `pnpm install --frozen-lockfile && pnpm --filter @william-albarello/api build`
- Start: `pnpm --filter @william-albarello/api start`
- Health check: `/ready`

## Matriz de ambiente (resumo operacional)

### API (Render)
Obrigatorias de producao:
1. `NODE_ENV=production`
2. `PORT`
3. `SESSION_SECRET`
4. `DATABASE_URL`
5. `PUBLIC_SITE_URL`
6. `ADMIN_SITE_URL`
7. `CORS_ORIGINS`
8. `ADMIN_BOOTSTRAP_EMAIL`
9. `ADMIN_BOOTSTRAP_PASSWORD`

### Web (Vercel)
Obrigatorias:
1. `NEXT_PUBLIC_SITE_URL`
2. `NEXT_PUBLIC_API_URL`

### Admin (Vercel)
Obrigatorias:
1. `NEXT_PUBLIC_ADMIN_URL`
2. `NEXT_PUBLIC_API_URL`

Observacao:
- variaveis de fallback (`PUBLIC_API_URL`, `ADMIN_API_URL`, `API_URL`) existem, mas nao devem substituir a configuracao principal em producao.

## Caminho de validacao de deploy
1. `pnpm test:ci`
2. `pnpm verify:hardening`
3. `bash infra/scripts/release-check.sh`
4. validacao de workflows (`deploy-readiness`, `api-contract`, `api-docs`, `api-breaking-change`)
5. smoke funcional pos-deploy

## Riscos de infraestrutura conhecidos
1. env incompleta em Vercel/Render quebrando runtime mesmo com build verde;
2. divergencia de dominio/CORS impactando sessao do admin;
3. drift de contrato API sem reflexo em consumidor;
4. release sem evidencia formal causando falso positivo.

## Mitigacoes aplicadas
1. matriz de env soberana (`infra/env/ENVIRONMENT-MATRIX.md`);
2. runbooks separados por plataforma (`infra/vercel/*`, `infra/render/*`);
3. playbooks e checklists de CI/release em `infra/ci/*`;
4. validacao rapida por `smoke.sh` e gate agregado por `release-check.sh`.

## Capacidade de rollback
Fluxo vigente:
1. identificar ultimo deploy saudavel na plataforma;
2. promover redeploy da revisao estavel;
3. executar smoke minimo;
4. registrar incidente e acao corretiva.

Referencia: `infra/ops/OPERACAO-E-ROLLBACK.md`.

## Limites do estado atual
1. nao ha IaC completa declarativa para infraestrutura;
2. configuracao depende de parametros nos provedores (Vercel/Render);
3. arquitetura multi-regiao/alta disponibilidade nao esta formalizada neste estagio.

## Direcao de evolucao (sem romper simplicidade)
1. manter separacao clara de servicos e contratos;
2. padronizar cada mudanca de deploy com evidencia de gate;
3. evoluir observabilidade tecnica e de negocio antes de ampliar complexidade de infra.

## Criterio de aceite
Este documento esta aprovado quando:
1. descreve somente a infraestrutura real do projeto;
2. permite reproduzir fluxo de deploy e validacao;
3. deixa explicitos riscos, limites e mitigacoes do estado atual.
