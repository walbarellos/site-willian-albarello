# 019 - Superprompt Tecnico de Geracao Lego

## Objetivo
Definir o superprompt soberano para evolucao do `personal-site` em ciclos disciplinados, com geracao modular "lego" e rastreabilidade auditavel.

Este documento padroniza como uma IA executora deve:
1. ler contexto tecnico antes de alterar qualquer arquivo;
2. produzir um arquivo por vez, em ordem de ciclo;
3. evitar resumo, corte de conteudo e falso positivo de conclusao;
4. validar e registrar evidencia por etapa.

## Escopo
Inclui:
1. contrato operacional do prompt mestre;
2. blocos obrigatorios de contexto e validacao;
3. template pronto para execucao no projeto;
4. regras de bloqueio para evitar sabotagem metodologica;
5. exemplos de uso por tipo de ciclo (codigo, docs, infra, QA).

Nao inclui:
1. substituicao da governanca humana da versao;
2. liberacao automatica sem evidencias;
3. instrucoes juridicas fora de escopo tecnico.

## Fontes soberanas de alinhamento
1. `README.md`
2. `Waterfall/DOC-10-arquitetura-tecnica.md`
3. `Waterfall/DOC-13-arquitetura-de-autenticacao-e-sessao.md`
4. `Waterfall/DOC-16-estrategia-editorial-e-governanca.md`
5. `Waterfall/DOC-21-observabilidade-logs-e-incidentes.md`
6. `QA/QA-02-matriz-de-gates-ci-e-deploy-readiness.md`
7. `infra/ci/RELEASE-EVIDENCE-CHECKLIST.md`
8. `infra/ci/ARTIFACTS-AND-RETENTION.md`

## Veredito tecnico
O projeto exige um superprompt com disciplina de execucao sequencial porque:
1. ciclos sao longos e interdependentes;
2. documentos soberanos precisam permanecer consistentes com estado fisico;
3. respostas genéricas, resumidas ou fora de ordem quebram o Metodo Caracol;
4. auditoria posterior depende de trilha objetiva de alteracoes e validacoes.

## 1) Principios do Superprompt
1. um arquivo por vez, sempre;
2. ordem exata do `Atualizacao de codigo`;
3. sem pular item e sem "adiantar" pendencias;
4. sem resumo de arquivo alvo (sempre arquivo completo quando for geracao/reforma);
5. sem inventar estado verde sem evidencia;
6. sem reabrir ciclos ja congelados, salvo comando explicito.

## 2) Contrato de entrada obrigatoria
Antes de iniciar qualquer item, a IA deve ler:
1. o `Atualizacao de codigo` da rodada atual;
2. os documentos soberanos impactados pelo item;
3. o arquivo alvo no estado atual (existente ou vazio);
4. os arquivos tecnicos diretamente relacionados (codigo/docs/workflow).

Se algum artefato essencial nao existir, a IA deve:
1. registrar a ausencia com precisao;
2. seguir com fallback realista;
3. nunca afirmar leitura de arquivo inexistente.

## 3) Contrato de execucao obrigatoria
Para cada item da lista:
1. identificar caminho absoluto do arquivo alvo;
2. classificar: `EXISTE` (reforma) ou `INEXISTENTE` (geracao);
3. produzir conteudo completo (nao parcial);
4. salvar arquivo no local correto;
5. validar integridade minima (ex.: `wc -l` + leitura inicial);
6. registrar status do item e apontar proximo item.

## 4) Contrato de qualidade textual e tecnica

## 4.1 Para arquivos de documentacao tecnica
1. descrever estado real do repositorio, nao estado imaginado;
2. separar explicitamente: implementado vs gap;
3. incluir criterio de aceite objetivo;
4. incluir riscos residuais e plano incremental;
5. manter coerencia com docs soberanos ja existentes.

## 4.2 Para arquivos de codigo
1. preservar comportamento existente quando nao for alvo de mudanca;
2. evitar simplificacao que reduza cobertura funcional;
3. manter compatibilidade com contracts/OpenAPI/UI/QA;
4. validar typecheck/teste da area impactada quando viavel;
5. nao introduzir acoplamento desnecessario.

## 5) Contrato de evidencias
Cada item concluido deve registrar no minimo:
1. arquivo alterado/criado;
2. confirmacao de integridade (linhas e leitura parcial);
3. comandos de validacao executados (quando aplicavel);
4. bloqueios encontrados e tratamento adotado.

No fechamento do ciclo:
1. gerar relatorio final de versao;
2. gerar zip da versao sem `node_modules` e caches;
3. atualizar memoria/handoff de continuidade.

## 6) Regras anti-falso-positivo
A IA executora esta proibida de:
1. declarar ciclo concluido com itens pendentes;
2. mascarar erro de comando como sucesso;
3. resumir arquivo grande quando a regra exigir arquivo completo;
4. afirmar "testado" sem comando/evidencia;
5. mudar ordem dos itens sem autorizacao explicita.

Se houver bloqueio real:
1. declarar bloqueio tecnico concreto;
2. registrar causa e impacto;
3. propor proximo passo objetivo;
4. nao fingir conclusao.

## 7) Template soberano de superprompt (copy/paste)
Usar o bloco abaixo como prompt mestre para execucao de ciclo:

```text
Vida Relacional, execute o ciclo atual do arquivo "Atualizacao de codigo" com rigor do Metodo Caracol.

Regras inegociaveis:
1) Um arquivo por vez, em ordem exata da lista.
2) Para cada item, ler primeiro os docs soberanos e o arquivo alvo atual.
3) Se o arquivo existe: reformar completo. Se nao existe: gerar completo.
4) Nao resumir, nao cortar conteudo, nao inventar "concluido" sem evidencia.
5) Validar integridade de cada arquivo salvo (linhas + leitura parcial).
6) Quando aplicavel, rodar validacao tecnica da area impactada.
7) So avancar ao proximo item apos concluir integralmente o item atual.
8) Manter consistencia com README, Waterfall, UI_UX, QA e infra/ci.

Formato de saida por item:
- Item N concluido
- Arquivo: <caminho>
- Tipo: EXISTE (reforma) ou INEXISTENTE (geracao)
- Validacao: <comandos/resultados>
- Proximo: item N+1

No fechamento do ciclo:
- gerar relatorio final de versao
- gerar zip da versao sem node_modules/caches
- registrar handoff de continuidade
```

## 8) Template complementar para ciclo documental

```text
Vida Relacional, para este item documental, descreva apenas o estado fisico real do repositorio.

Obrigatorio no arquivo:
1) objetivo
2) escopo (inclui / nao inclui)
3) fontes soberanas auditadas
4) veredito tecnico atual
5) controles implementados
6) gaps e riscos residuais
7) plano incremental
8) criterio de aceite
9) conclusao tecnica

Proibido:
- prometer feature que nao existe
- declarar maturidade maxima sem evidencia
- copiar texto generico sem aderencia ao projeto
```

## 9) Template complementar para ciclo de codigo

```text
Vida Relacional, reforme o arquivo alvo preservando comportamento existente e removendo apenas a compressao/fragilidade que o item descreve.

Obrigatorio:
1) manter contratos compartilhados e OpenAPI coerentes
2) nao quebrar fluxo admin/web/api
3) nao criar abstracao genérica sem repeticao comprovada
4) validar typecheck/teste do escopo alterado
5) entregar arquivo completo final
```

## 10) Protocolo de uso em auditoria
Quando o projeto entrar em auditoria:
1. usar este superprompt como contrato de execucao;
2. anexar relatorio final + zip + checklist de evidencia;
3. responder divergencias sempre com referencia a arquivo e evidencia tecnica;
4. evitar argumentacao opinativa sem base no estado fisico.

## 11) Criterios de aceite deste documento
Este documento e aceito quando:
1. permite repetir ciclos sem perda de consistencia;
2. bloqueia comportamento de resumo/sabotagem/falso positivo;
3. oferece templates reutilizaveis de execucao;
4. permanece aderente ao estado real do `personal-site`.

## Conclusao tecnica
O superprompt tecnico lego e a camada de governanca operacional que conecta metodo, disciplina e rastreabilidade no `personal-site`.

Sem ele, a execucao tende a desordenar ciclos e gerar retrabalho. Com ele, a equipe consegue evoluir arquivo por arquivo, congelar versoes com evidencia e manter continuidade auditavel entre chats e ciclos.
