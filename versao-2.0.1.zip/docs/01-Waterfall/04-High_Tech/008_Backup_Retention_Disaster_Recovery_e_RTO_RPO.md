# 008 - Backup, Retention, Disaster Recovery e RTO/RPO

## Objetivo
Documentar a estrategia real de continuidade operacional do `personal-site` para backup, retencao, recuperacao de desastre e metas de RTO/RPO, com base no estado tecnico atual do repositorio.

## Escopo
Inclui:
1. estado atual de persistencia de dados do sistema;
2. capacidade real de backup e restauracao no ciclo vigente;
3. procedimento de DR e rollback por plataforma;
4. metas operacionais pragmativas de RTO/RPO no estagio atual;
5. trilha de evolucao para maturidade de backup.

Nao inclui:
1. promessas de backup transacional nao implementado;
2. desenho de BCP enterprise completo;
3. automacao de DR inexistente no repositorio.

## Fontes soberanas usadas
1. `infra/ops/OPERACAO-E-ROLLBACK.md`
2. `infra/README.md`
3. `infra/render/api.service.yaml`
4. `infra/vercel/web.project.md`
5. `infra/vercel/admin.project.md`
6. `apps/api/src/routes/publications-admin.ts`
7. `apps/api/src/routes/publications-public.ts`
8. `apps/api/src/lib/admin-session-store.ts`
9. `apps/api/README.md`
10. `Waterfall/DOC-21-observabilidade-logs-e-incidentes.md`

## Veredito tecnico do estado atual

### Estado oficial
No ciclo atual, o projeto possui **continuidade operacional por redeploy/rollback**, mas **nao possui estrategia completa de backup de dados de negocio persistidos dentro do codigo ativo**, pois as rotas principais ainda operam com adapters in-memory.

### Implicacao pratica
1. recuperacao de aplicacao: viavel e documentada;
2. recuperacao de estado editorial/sessao em memoria: nao preservada apos restart;
3. backup de banco para dados de runtime atual: nao e o mecanismo efetivo do fluxo principal neste estagio.

## 1) Classificacao de ativos para DR

## A1 - Artefatos de codigo e configuracao versionada
Exemplos:
1. codigo fonte;
2. docs operacionais;
3. workflows CI;
4. scripts `infra/scripts/*`.

Estado:
- versionados em repositorio, recuperaveis por git e por release zip.

## A2 - Configuracao de ambiente/plataforma
Exemplos:
1. envs em Vercel/Render;
2. configuracao de servicos e dominio.

Estado:
- runbooks descrevem variaveis e fluxo, mas restauracao depende de disciplina operacional da plataforma.

## A3 - Estado de runtime em memoria (sessao/publicacoes scaffold)
Exemplos:
1. sessoes do admin em store in-memory;
2. dados de publicacao usados por adapters in-memory.

Estado:
- nao persistente por desenho atual; reinicio limpa estado.

## 2) Backup no estado atual

## 2.1 O que existe

1. backup funcional de codigo e documentacao via versionamento e pacotes de versao (`versao-*.zip`);
2. runbooks de deploy e rollback para restaurar servicos (`infra/vercel/*`, `infra/render/*`, `infra/ops/*`);
3. matriz de ambiente para reconstituir configuracao minima (`infra/env/ENVIRONMENT-MATRIX.md`).

## 2.2 O que nao existe (ainda)

1. politica formal de snapshot de banco operacional no fluxo real de dados da aplicacao;
2. retencao automatizada de backups com janelas definidas no repositorio;
3. restauracao automatica testada de ponta a ponta para dados editoriais persistentes;
4. runbook de restauracao de dados com checklist transacional.

## 3) Retention policy (estado atual)

### Artefatos de release
Politica aplicada no processo atual:
1. gerar zip por versao fechada;
2. manter relatorio final por versao;
3. preservar rastreabilidade de ciclo (documento + zip).

### Logs operacionais
1. observabilidade esta centrada em logs da API com `traceId`;
2. retention de log depende da plataforma de execucao (fora do repositorio).

### Dados de runtime em memoria
1. sem retention por definicao tecnica atual;
2. restart implica perda de estado em memoria.

## 4) Disaster Recovery (DR) no estagio atual

## 4.1 Cenarios de desastre cobertos

### D-01 - Regressao de deploy
Resposta:
1. identificar ultimo deploy saudavel na plataforma;
2. redeploy da revisao estavel;
3. executar smoke checks minimos;
4. registrar incidente.

### D-02 - API indisponivel
Resposta:
1. validar `/health` e `/ready`;
2. revisar env no Render;
3. rollback se indisponibilidade persistir.

### D-03 - Admin sem autenticacao funcional
Resposta:
1. validar URLs e CORS;
2. validar cookie/sessao;
3. rollback se bloquear operacao editorial.

## 4.2 Cenarios parcialmente cobertos

### D-04 - Perda de dados editoriais persistentes
No estado atual, cobertura e parcial porque fluxo principal ainda nao esta com persistencia de producao formalizada no codigo da feature.

### D-05 - Recuperacao automatica cross-platform
Nao ha automacao DR declarativa no repositorio para Vercel+Render.

## 5) RTO/RPO pragmativos (versao atual)

## Definicoes
- RTO: tempo alvo para restaurar servico.
- RPO: perda maxima de dados aceitavel.

## Metas por classe de ativo

### Classe C1 - Servico (web/admin/api)
- RTO alvo atual: ate 60 minutos em incidente padrao de deploy/plataforma.
- RPO alvo atual: proximo de zero para codigo/config versionada.

### Classe C2 - Estado de runtime in-memory
- RTO alvo atual: baixo (reinicio recupera servico rapidamente).
- RPO atual: alto para estado em memoria (pode perder 100% do estado nao persistido).

### Classe C3 - Dados de negocio persistidos (quando entrar no fluxo principal)
- RTO/RPO ainda **nao homologados** neste ciclo, pois dependem da camada de persistencia real e politica de backup/restaure que ainda nao estao materializadas ponta a ponta.

## 6) Controles operacionais existentes

1. release gate (`release-check.sh`) para reduzir deploy regressivo;
2. smoke script (`smoke.sh`) para detectar indisponibilidade basica;
3. runbook de rollback com passo a passo;
4. observabilidade minima por `traceId` para triagem de incidente.

## 7) Gaps criticos para proximos ciclos

1. substituir adapters in-memory por persistencia real nas features centrais;
2. definir politica de backup de banco (frequencia, retencao, criptografia, restore testado);
3. criar runbook especifico de restore de dados;
4. introduzir teste periodico de restauracao;
5. formalizar RTO/RPO finais apos persistencia entrar em producao real.

## 8) Plano incremental recomendado

## Fase 1 - Persistencia real
1. ativar camada persistente para publicacoes/sessao no fluxo principal;
2. validar integridade de leitura/escrita e transicoes editoriais.

## Fase 2 - Backup e retention
1. definir janela de backup (ex.: diario + incremental);
2. definir retencao (ex.: 7/30/90 dias conforme ambiente);
3. registrar owner e rotina de verificacao.

## Fase 3 - Restore drill
1. simular incidente e restore em staging;
2. medir RTO/RPO real observados;
3. ajustar meta e procedimento.

## Fase 4 - Governanca continua
1. publicar relatorio periodico de restauracao;
2. bloquear release se backup/restore estiver fora de conformidade.

## 9) Criterio de aceite deste documento

Este documento esta aprovado quando:
1. nao mascara o estado atual (in-memory + rollback operacional);
2. separa claramente o que ja existe do que ainda e gap;
3. define RTO/RPO compativeis com maturidade atual;
4. orienta evolucao sem gerar falso positivo de DR completo.

## Conclusao tecnica

No ciclo atual, o `personal-site` tem boa recuperacao de servico por deploy/rollback e rastreabilidade operacional minima, mas ainda nao possui maturidade completa de backup/retencao de dados de negocio no fluxo principal.

A continuidade esta adequada para o estagio atual do projeto, desde que a equipe trate como prioridade a migracao para persistencia real e a institucionalizacao de backup/restore testado antes de declarar DR maduro.
