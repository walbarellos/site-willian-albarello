# 015 - Plano de Testes de Carga, Stress e Chaos

## Objetivo
Estabelecer um plano soberano e realista de testes de carga, stress e chaos engineering para o `personal-site`, alinhado ao nivel atual de maturidade tecnica do projeto.

## Escopo
Inclui:
1. estrategia de validacao progressiva de resiliência;
2. prioridades por superficie (API, web, admin);
3. pre-condicoes operacionais para executar testes com valor;
4. criterios objetivos de aprovacao/bloqueio;
5. trilha incremental de evolucao sem complexidade prematura.

Nao inclui:
1. prometer plataforma de chaos enterprise inexistente;
2. assumir ferramenta de load test ainda nao adotada no repositorio;
3. declarar readiness de alta escala sem evidencias de rodada.

## Fontes soberanas usadas
1. `QA/QA-01-checklist-de-homologacao-funcional.md`
2. `QA/QA-02-matriz-de-gates-ci-e-deploy-readiness.md`
3. `infra/scripts/smoke.sh`
4. `package.json`
5. `.github/workflows/deploy-readiness.yml`
6. `docs/01-Waterfall/04-High_Tech/009_Monitoramento_Metrics_Tracing_e_Alertas.md`
7. `docs/01-Waterfall/04-High_Tech/011_Performance_Budget_Query_Playbook_e_Profiling.md`

## Veredito tecnico do estado atual

### Estado oficial
1. existem gates de qualidade e smoke funcional;
2. existem testes automatizados unitarios/integracao de escopo atual (`test:ci`);
3. nao existe ferramenta de carga/stress/chaos integrada no repositorio (k6/artillery/locust etc.).

### Implicacao
O plano deste ciclo e de **organizacao e sequenciamento operacional** para testes de resiliência, sem mascarar que a instrumentacao de carga/chaos ainda precisa ser introduzida em ciclo proprio.

## 1) Definicoes praticas

- Teste de carga: valida comportamento sob volume esperado de uso.
- Teste de stress: empurra o sistema alem do limite esperado para observar degradacao.
- Teste de chaos: injeta falhas controladas para validar recuperacao e robustez.

## 2) Principios do plano

1. primeiro garantir funcionalidade correta, depois escalar volume;
2. nao medir latencia sem baseline funcional verde;
3. toda rodada deve gerar evidencia rastreavel;
4. sem evidencias, teste nao conta como executado;
5. qualquer degradacao critica bloqueia release ate mitigacao.

## 3) Pre-condicoes obrigatorias da rodada

Antes de executar qualquer teste de carga/stress/chaos:

1. `pnpm install --frozen-lockfile` verde;
2. `pnpm test:ci` verde;
3. `pnpm verify:hardening` verde;
4. `bash infra/scripts/smoke.sh` com `FAIL=0`;
5. checklist funcional `QA-01` sem falhas abertas criticas;
6. matriz `QA-02` atualizada para o ciclo da rodada.

Se qualquer pre-condicao falhar, a rodada de carga/stress/chaos deve ser adiada.

## 4) Superficies prioritarias para teste

## P1 - API de infraestrutura

1. `GET /health`
2. `GET /ready`

Objetivo:
- confirmar estabilidade de disponibilidade sob repeticao.

## P2 - API publica

1. `GET /v1/public/publications`
2. `GET /v1/public/publications/:slug`

Objetivo:
- validar listagem/detalhe em volume de leitura.

## P3 - API admin critica

1. `POST /v1/admin/auth/login`
2. `GET /v1/admin/auth/session`
3. `GET /v1/admin/publications`
4. `PATCH /v1/admin/publications/:id/status`

Objetivo:
- avaliar robustez de autenticacao e mutacao editorial sob carga moderada.

## P4 - Experiencia ponta-a-ponta

1. home publica (`/`)
2. listagem publica (`/publicacoes`)
3. login admin (`/painel/login`)

Objetivo:
- detectar degradacao perceptivel do usuario em cenarios de pressao.

## 5) Fases de execucao recomendadas

## Fase A - Carga leve (baseline)

Objetivo:
- validar que sistema suporta volume esperado inicial sem erro relevante.

Escopo:
1. foco em endpoints de leitura;
2. baixa concorrencia;
3. curta duracao.

Saidas obrigatorias:
1. taxa de sucesso por rota;
2. latencia media e p95 observadas;
3. evidencias de `traceId` para amostras de erro.

## Fase B - Carga operacional (esperada)

Objetivo:
- validar comportamento no patamar de uso realista do ciclo.

Escopo:
1. mistura de leitura publica + operacao admin moderada;
2. duracao suficiente para observar estabilidade;
3. monitoramento de status/latencia por rota critica.

Saidas obrigatorias:
1. comparacao com budget do item 011;
2. identificacao de gargalos;
3. recomendacoes de ajuste de curto prazo.

## Fase C - Stress controlado

Objetivo:
- identificar ponto de degradacao e modo de falha.

Escopo:
1. aumentar volume alem do alvo operacional;
2. observar transicao para erro/timeout/rate-limit;
3. validar se sistema degrada de forma previsivel.

Saidas obrigatorias:
1. limiar aproximado de saturacao por superficie;
2. comportamento de erro (429/5xx/timeout);
3. acao recomendada para evitar regressao em producao.

## Fase D - Chaos basico

Objetivo:
- validar recuperacao em falhas controladas de ambiente.

Cenarios minimos:
1. indisponibilidade temporaria da API;
2. degradacao de dependencia de readiness (quando aplicavel);
3. reinicio de processo e validacao de retorno operacional.

Saidas obrigatorias:
1. tempo de recuperacao observado;
2. impacto no fluxo publico/admin;
3. aderencia ao runbook de rollback/operacao.

## 6) Criterios de aprovacao por tipo de teste

## Carga

Aprovado quando:
1. taxa de sucesso da rota critica dentro do alvo definido para rodada;
2. latencia nao ultrapassa budget sem justificativa aceita;
3. nao ha erro sistemico nao tratado.

## Stress

Aprovado quando:
1. limite de saturacao e identificado com evidencia;
2. degradacao ocorre de forma previsivel e auditavel;
3. existe plano de mitigacao para gargalo encontrado.

## Chaos

Aprovado quando:
1. equipe consegue recuperar servico dentro da janela definida;
2. runbook de operacao/rollback se mostra executavel;
3. incidente simulado produz aprendizado documentado.

## 7) Criterios de bloqueio de release

Bloquear release se qualquer condicao ocorrer:

1. regressao funcional critica durante carga;
2. instabilidade de `/health` ou `/ready` sem causa controlada;
3. aumento relevante de erro 5xx sem mitigacao;
4. incapacidade de recuperar ambiente em caos basico;
5. ausencia de evidencias minimas da rodada.

## 8) Evidencias obrigatorias por rodada

Para considerar rodada concluida, registrar:

1. data, ambiente, commit/versao;
2. escopo executado (rotas/paginas);
3. parametros de carga/stress aplicados;
4. resultados consolidados (sucesso, erro, latencia);
5. incidentes encontrados;
6. decisao final (`seguir`, `mitigar`, `bloquear`).

## 9) Ferramental - estado atual e proxima etapa

## Estado atual

1. `smoke.sh` cobre disponibilidade funcional minima;
2. `test:ci` e `verify:hardening` cobrem qualidade tecnica de base;
3. nao ha harness dedicado de carga/stress/chaos versionado no repo.

## Proxima etapa recomendada

1. escolher ferramenta unica de carga (ex.: k6 ou equivalente) em ciclo dedicado;
2. versionar cenarios de teste em `infra/`;
3. integrar rodada minima em pipeline nao-bloqueante inicialmente;
4. evoluir para gate bloqueante quando baseline estiver estavel.

## 10) Roteiro de maturidade

## Nivel 0 (atual)
- sem harness de carga/chaos no repo, apenas plano + gates base.

## Nivel 1
- harness de carga basica versionado e executavel localmente.

## Nivel 2
- stress controlado recorrente com relatorio de tendencia.

## Nivel 3
- chaos basico recorrente com treino de resposta operacional.

## Nivel 4
- integracao parcial em CI com alerta de degradacao relevante.

## 11) Criterio de aceite deste documento

Este documento esta aprovado quando:
1. delimita escopo realista sem fingir maturidade inexistente;
2. define prioridades, pre-condicoes e fases executaveis;
3. estabelece bloqueios objetivos de release por resiliência;
4. exige evidencias auditaveis para cada rodada.

## Conclusao tecnica

O `personal-site` ja tem base tecnica para iniciar validacao de resiliência de forma disciplinada (gates, smoke, observabilidade P0), mas ainda precisa materializar ferramenta e cenarios versionados para carga/stress/chaos.

A estrategia correta deste ciclo e consolidar plano soberano e executar a evolucao incremental: primeiro carga basica com evidencia, depois stress controlado e, por fim, chaos recorrente com aprendizado operacional mensuravel.
