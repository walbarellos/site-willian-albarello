# 018 - Quality Gates, Automacao e Pipeline Tecnico

## Objetivo
Consolidar a arquitetura de gates tecnicos do `personal-site`, descrevendo:
1. quais gates existem no estado atual;
2. como os workflows automatizam validacoes de qualidade;
3. quais criterios bloqueiam ou liberam versao;
4. como evoluir o pipeline sem perder rastreabilidade.

Este documento e soberano para decisao operacional de release no ciclo atual.

## Escopo
Inclui:
1. mapa de gates locais e de CI;
2. cobertura dos workflows versionados em `.github/workflows`;
3. relacao entre scripts locais e gates de pipeline;
4. protocolo de bloqueio/liberacao de versao;
5. backlog de maturidade da automacao.

Nao inclui:
1. substituicao de CI por plataforma externa;
2. definicao de governanca corporativa fora do repositorio;
3. promessas de quality gate que nao possuem script/workflow real.

## Fontes soberanas auditadas
1. `QA/QA-02-matriz-de-gates-ci-e-deploy-readiness.md`
2. `infra/ci/CI-MATRIX.md`
3. `infra/ci/CI-BOOTSTRAP-CHECKLIST.md`
4. `infra/ci/RELEASE-EVIDENCE-CHECKLIST.md`
5. `infra/ci/WORKFLOW-OWNERSHIP-AND-GATES.md`
6. `.github/workflows/scaffold-bootstrap.yml`
7. `.github/workflows/api-contract.yml`
8. `.github/workflows/api-docs.yml`
9. `.github/workflows/api-breaking-change.yml`
10. `.github/workflows/deploy-readiness.yml`
11. `infra/scripts/release-check.sh`
12. `infra/scripts/smoke.sh`
13. `package.json`

## Veredito tecnico do estado atual
O projeto possui um pipeline tecnico funcional com gates automatizados para:
1. bootstrap de qualidade (`scaffold-bootstrap`);
2. contrato/documentacao OpenAPI (`api-contract`, `api-docs`);
3. protecao contra breaking removals (`api-breaking-change`);
4. gate agregado de readiness (`deploy-readiness`).

Tambem possui scripts locais para validacao operacional:
1. `pnpm test:ci`;
2. `pnpm verify:hardening`;
3. `bash infra/scripts/release-check.sh`;
4. `bash infra/scripts/smoke.sh`.

Limitacao atual:
- parte dos gates funcionais ainda depende de disciplina de execucao/evidencia por rodada, conforme matriz QA.

## 1) Principios de quality gate no projeto
1. gate sem evidencia nao vale como aprovado;
2. automacao deve bloquear regressao antes de congelar versao;
3. release depende de cadeia completa (local + CI + QA);
4. rastreabilidade e obrigatoria (checklist + relatorio + zip).

## 2) Camadas de validacao

## 2.1 Camada local (pre-CI)
Validacoes obrigatorias no ambiente do executor:
1. `pnpm test:ci`;
2. `pnpm verify:hardening`;
3. `bash infra/scripts/release-check.sh`;
4. `bash infra/scripts/smoke.sh` (quando houver runtime alterado).

Funcoes:
1. detectar erro rapido antes de abrir PR/congelar versao;
2. reduzir custo de falha tardia no workflow remoto.

## 2.2 Camada CI por escopo
Workflows especializados:
1. `scaffold-bootstrap.yml` -> install + hardening agregados;
2. `api-contract.yml` -> presenca/chaves OpenAPI + build/typecheck do pacote contracts;
3. `api-docs.yml` -> coerencia documental OpenAPI e referencias no README;
4. `api-breaking-change.yml` -> comparacao com branch base para detectar remocao de superficie;
5. `deploy-readiness.yml` -> gate agregado final (`test:ci` + `verify:hardening` + release-check em modo CI).

## 2.3 Camada QA/homologacao
Documentos de controle:
1. `QA-01` (homologacao funcional);
2. `QA-02` (matriz de gates e status por versao);
3. `infra/ci/RELEASE-EVIDENCE-CHECKLIST.md`.

Funcao:
1. garantir que validação tecnica e validação funcional convergem antes do release.

## 3) Matriz de workflows e gates cobertos

| Workflow | Validacoes centrais | Gates principais cobertos |
|---|---|---|
| `scaffold-bootstrap.yml` | `pnpm install --frozen-lockfile`; `pnpm run verify:hardening` | G-01, G-10 |
| `api-contract.yml` | presenca/chaves OpenAPI; build/typecheck de contracts | G-11 (e suporte de contrato) |
| `api-docs.yml` | integridade de docs OpenAPI + refs + README | G-12 |
| `api-breaking-change.yml` | bloqueio de remocoes de operationId/path+method/schemas/responses em PR | G-13 |
| `deploy-readiness.yml` | `pnpm test:ci`; `pnpm verify:hardening`; `release-check` CI | G-01, G-10, G-16 e gate agregado |

Observacao:
- a decisao final de readiness continua condicionada ao conjunto de gates obrigatorios definido em `QA-02`.

## 4) Gatilhos e concorrencia da pipeline

## 4.1 Escopo de disparo
1. `deploy-readiness` observa mudancas em apps/packages/infra/QA/workflows/config base;
2. `api-contract` e `api-docs` disparam por alteracoes em APIs/contracts/README/workflow;
3. `api-breaking-change` faz diff efetivo em contexto de `pull_request`.

## 4.2 Controle de concorrencia
Todos os workflows principais usam `concurrency` com `cancel-in-progress: true`, reduzindo fila redundante e evitando leitura de status obsoleto.

## 5) Regra soberana de bloqueio/liberacao

## 5.1 Bloquear release quando
1. qualquer gate obrigatorio em `QA-02` estiver `AMARELO` ou `VERMELHO`;
2. `RELEASE-EVIDENCE-CHECKLIST` tiver item bloqueante pendente;
3. workflow critico falhar (`scaffold-bootstrap`, `deploy-readiness`, `api-contract`, `api-docs`, `api-breaking-change`);
4. nao houver relatorio final coerente com o estado fisico.

## 5.2 Liberar release quando
1. validacoes locais obrigatorias estiverem verdes;
2. workflows criticos estiverem verdes na rodada alvo;
3. evidencias estiverem registradas no checklist e no relatorio da versao;
4. pacote de versao (`versao-*.zip`) estiver gerado conforme politica de retencao.

## 6) Protocolo de operacao por falha de gate

## 6.1 Classificacao rapida
1. falha de dependencia/instalacao;
2. falha de build/typecheck;
3. falha contratual/documental OpenAPI;
4. falha de teste/hardening;
5. falha de smoke/readiness.

## 6.2 Sequencia de resposta
1. reproduzir localmente o gate falho;
2. corrigir no menor escopo possivel;
3. reexecutar comandos locais do bloco afetado;
4. atualizar evidencia no checklist;
5. rerodar pipeline CI;
6. registrar no relatorio final da versao.

Referencia operacional detalhada:
- `infra/ci/PIPELINE-FAILURE-PLAYBOOK.md`.

## 7) Evidencias obrigatorias de cada rodada
No fechamento da versao, anexar no minimo:
1. saida de `pnpm test:ci`;
2. saida de `pnpm verify:hardening`;
3. resultado de `release-check` e `smoke` (quando aplicavel);
4. status dos workflows criticos;
5. checklist de release preenchido;
6. relatorio final + zip da versao.

Sem esse conjunto, a qualidade nao e auditavel.

## 8) Gaps atuais de maturidade
1. parte dos gates funcionais em QA ainda depende de evidencia manual por rodada;
2. ausencia de agregador unico de historico de execucao dentro do repo (hoje disperso em relatorios/workflows);
3. ausencia de quality gate semanticamente voltado a regressao de UX/UI (hoje validado por auditoria manual e docs).

## 9) Plano incremental de evolucao

## Fase 1 - Consolidacao de evidencia
1. padronizar preenchimento do `RELEASE-EVIDENCE-CHECKLIST` em toda versao;
2. sincronizar status de `QA-02` com evidencias reais da rodada;
3. garantir referencia cruzada entre relatorio final e workflows.

## Fase 2 - Endurecimento funcional
1. ampliar cobertura de testes para reduzir dependencia de homologacao manual;
2. associar gates funcionais criticos a execucao automatizada quando viavel;
3. manter criterio de bloqueio estrito em regressao contratual.

## Fase 3 - Governanca de pipeline
1. revisar ownership por workflow (`infra/ci/WORKFLOW-OWNERSHIP-AND-GATES.md`);
2. definir SLA de resposta para falha em gate critico;
3. institucionalizar postmortem tecnico para falhas repetidas.

## 10) Criterios de aceite deste documento
Este documento e aceito quando:
1. reflete fielmente os workflows e scripts existentes;
2. separa com clareza gate automatizado de gate ainda manual;
3. define regra objetiva de `BLOQUEAR` e `LIBERAR` release;
4. orienta evolucao sem reabrir etapas ja estabilizadas.

## Conclusao tecnica
O `personal-site` possui pipeline tecnico real e funcional para controle de qualidade e readiness, com automacao relevante ja materializada em CI e disciplina de evidencia via `infra/ci` + QA.

A maturidade ainda pode crescer, mas o estado atual ja suporta congelamento de versao com criterio tecnico auditavel, desde que os gates obrigatorios e as evidencias da rodada sejam tratados como bloqueantes de verdade.
