# 013 - Politica de Migracoes, Banco e Dados

## Objetivo
Definir a politica soberana de migracoes de banco e dados do `personal-site`, alinhada ao estado real do projeto e preparada para a transicao de adapters in-memory para persistencia de producao.

## Escopo
Inclui:
1. estado atual de persistencia no backend;
2. regras para introduzir migracoes de schema com seguranca;
3. estrategia de rollout/rollback de mudancas de dados;
4. governanca de integridade e compatibilidade de dados;
5. criterios de aceite para futuros ciclos de persistencia.

Nao inclui:
1. implementacao de ORM/ferramenta especifica nesta rodada;
2. scripts de migration ainda inexistentes no repositorio;
3. promessa de DR transacional completo neste estagio.

## Fontes soberanas usadas
1. `apps/api/src/lib/env.ts`
2. `apps/api/README.md`
3. `apps/api/src/routes/publications-admin.ts`
4. `apps/api/src/routes/publications-public.ts`
5. `apps/api/src/lib/admin-session-store.ts`
6. `infra/render/api.service.yaml`
7. `docs/01-Waterfall/04-High_Tech/008_Backup_Retention_Disaster_Recovery_e_RTO_RPO.md`

## Veredito tecnico do estado atual

### Estado oficial
1. a API exige `DATABASE_URL` por contrato de ambiente;
2. o fluxo principal de publicacoes/sessao ainda opera com adapters in-memory;
3. nao ha framework de migration materializado (prisma/drizzle/typeorm etc.) no repositorio atual.

### Implicacao
Existe **preparacao de ambiente para banco**, mas ainda nao existe **pipeline formal de migracao de schema de producao** no codigo ativo.

## 1) Principios da politica de migracao

1. **Zero falsos positivos**: nao declarar migration madura sem artefato fisico no repositorio.
2. **Backward compatibility por fase**: primeiro expandir schema, depois migrar leitura/escrita, depois remover legado.
3. **Migracao reversivel**: toda mudanca deve ter estrategia de rollback e criterio de parada.
4. **Contrato primeiro**: mudanca de dado precisa refletir em contratos (`packages/contracts` + OpenAPI + consumers).
5. **Evidencia obrigatoria**: nenhuma migracao e considerada concluida sem teste e registro de execucao.

## 2) Modelo de maturidade de dados

## Nivel atual (N0/N1)

- N0: scaffold com estado in-memory para publicacoes/sessoes.
- N1: `DATABASE_URL` e variavel obrigatoria no backend, preparando caminho para persistencia.

## Nivel alvo (N2)

- N2: persistencia real no fluxo principal + migrations versionadas + rollback operacional validado.

## 3) Estrategia de migracao recomendada

## Fase A - Baseline de persistencia

1. escolher stack de persistencia e migration tool (decisao de ciclo futuro);
2. versionar schema inicial de forma declarativa;
3. manter adapters de compatibilidade enquanto transicao nao fecha.

## Fase B - Expand migration (nao destrutiva)

1. adicionar novas tabelas/colunas sem remover campos antigos;
2. manter leitura e escrita dual quando necessario;
3. nao quebrar consumers durante rollout.

## Fase C - Data backfill

1. executar preenchimento de dados historicos/derivados;
2. validar consistencia por amostragem e contagem;
3. registrar evidencias de concluido/falhas.

## Fase D - Switch de leitura/escrita

1. ativar leitura principal no novo schema;
2. manter fallback de contingencia por janela controlada;
3. monitorar erro/latencia apos switch.

## Fase E - Contract/legacy cleanup

1. remover campos/paths legados somente apos janela estavel;
2. proteger breaking changes via gates de contrato;
3. atualizar docs e runbooks finais.

## 4) Regras de versionamento de migration

Quando a camada de migration for introduzida:

1. arquivos de migration devem ser imutaveis apos aplicados;
2. naming deve refletir ordem temporal e intencao (`YYYYMMDDHHMM_desc`);
3. cada migration deve ter descricao de:
   - objetivo
   - impacto
   - risco
   - rollback plan
4. migrations destrutivas exigem justificativa explicita e janela de execucao.

## 5) Regras de rollback de dados

## 5.1 Rollback tecnico

1. deploy rollback (codigo) nao e suficiente para recuperar dados se schema mudou;
2. cada mudanca de schema deve definir estrategia de retorno:
   - down migration segura, ou
   - restauracao por backup/snapshot.

## 5.2 Rollback operacional

1. se erro critico pos-migration, pausar novas mudancas de schema;
2. restaurar servico para estado estavel;
3. aplicar plano de restauracao de dados conforme runbook;
4. registrar incidente com causa raiz e acao preventiva.

## 6) Gates obrigatorios para mudanca de dados

Toda mudanca de schema/dados deve passar em:

1. `pnpm test:ci`
2. `pnpm verify:hardening`
3. validacao de contratos (OpenAPI + contracts + CI gates)
4. checklist de release evidence preenchido
5. validacao funcional de fluxos criticos:
   - login/sessao admin
   - listagem/edicao admin
   - listagem/detalhe publico

## 7) Integridade e qualidade de dados

## 7.1 Controles minimos

1. constraints de chave e nulidade coerentes com contrato de dominio;
2. validacoes de entrada permanecem no backend (`zod`) mesmo com banco;
3. transicoes editoriais invalidas devem continuar bloqueadas por regra de dominio.

## 7.2 Auditoria de consistencia

1. reconciliar contagem de registros por status apos migracao;
2. validar amostras de dados criticos (slug unico, SEO, datas);
3. conferir que API continua retornando envelopes e metas corretas.

## 8) Anti-padroes proibidos

1. migracao destrutiva direta sem fase de compatibilidade;
2. alterar schema em producao sem evidencias de teste em staging;
3. mudar contrato de API sem sincronizar `packages/contracts` e OpenAPI;
4. confiar em rollback de codigo para corrigir perda de dado sem plano de restore.

## 9) Mapa de responsabilidade

1. engenharia backend: definir e revisar migrations e data backfill;
2. engenharia de plataforma/ops: executar janela e monitorar rollout;
3. responsavel de ciclo: validar evidencias e aprovar congelamento de versao;
4. QA/release: confirmar gates e fluxos funcionais pos-migracao.

## 10) Criterio de aceite deste documento

Este documento esta aprovado quando:
1. reflete o estado atual (sem engine de migration ativa no repo);
2. define politica clara para introduzir migracoes com seguranca;
3. amarra migracao de dados a gates de contrato e release;
4. evita prometer maturidade de banco nao materializada.

## Conclusao tecnica

No estado atual, o `personal-site` ainda nao possui pipeline de migracao de banco materializado, apesar de ja exigir `DATABASE_URL` no contrato de ambiente.

A politica correta neste ciclo e preparar a transicao com disciplina:
1. introduzir persistencia real por fases;
2. executar migracoes com compatibilidade e rollback planejado;
3. consolidar evidencias tecnicas e funcionais antes de declarar maturidade de dados.
