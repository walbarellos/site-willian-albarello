# 002 - CI/CD, Estrategia de Release e Gates

## Objetivo
Consolidar a estrategia real de CI/CD e release do `personal-site`, baseada exclusivamente nos workflows e scripts existentes no repositorio.

## Escopo
Inclui:
1. pipelines ativas em `.github/workflows`;
2. relacao entre validacao local e CI;
3. gates bloqueantes e gates de alerta;
4. criterio formal de liberacao de versao;
5. fluxo de resposta a falhas.

Nao inclui:
1. pipeline hipotetica nao materializada;
2. fluxo multi-ambiente automatizado inexistente;
3. regras de aprovacao fora da governanca atual.

## Fontes soberanas
1. `.github/workflows/scaffold-bootstrap.yml`
2. `.github/workflows/api-contract.yml`
3. `.github/workflows/api-docs.yml`
4. `.github/workflows/api-breaking-change.yml`
5. `.github/workflows/deploy-readiness.yml`
6. `infra/ci/CI-MATRIX.md`
7. `infra/ci/LOCAL-TO-CI-MAP.md`
8. `infra/ci/WORKFLOW-OWNERSHIP-AND-GATES.md`
9. `infra/ci/RELEASE-EVIDENCE-CHECKLIST.md`
10. `QA/QA-02-matriz-de-gates-ci-e-deploy-readiness.md`
11. `infra/scripts/release-check.sh`

## Arquitetura de CI/CD vigente

### Pipeline 1 - Scaffold Bootstrap
Workflow: `scaffold-bootstrap.yml`

Objetivo:
- garantir bootstrap tecnico minimo do monorepo.

Checks:
1. `pnpm install --frozen-lockfile`
2. `pnpm run verify:hardening`

Uso:
- baseline de qualidade de build/typecheck agregado.

### Pipeline 2 - API Contract
Workflow: `api-contract.yml`

Objetivo:
- proteger contrato minimo OpenAPI e integridade do pacote `contracts`.

Checks:
1. presenca de arquivos OpenAPI/components;
2. validacao de chaves basicas (`openapi`, `schemas`, `responses`);
3. build e typecheck de `@william-albarello/contracts`.

### Pipeline 3 - API Docs
Workflow: `api-docs.yml`

Objetivo:
- validar coerencia documental minima de OpenAPI.

Checks:
1. presenca de specs e components;
2. chaves core (`openapi/info/paths`);
3. referencias para components compartilhados;
4. mencoes no `README.md`.

### Pipeline 4 - API Breaking Change
Workflow: `api-breaking-change.yml`

Objetivo:
- bloquear remocoes de superficie contratual em `pull_request`.

Checks:
1. diff contra branch base;
2. remocao de `operationId`;
3. remocao de `path+method`;
4. remocao de `schemas` e `responses`.

Observacao:
- em `push`, atua como validacao de presenca; o diff de breaking e foco de `pull_request`.

### Pipeline 5 - Deploy Readiness
Workflow: `deploy-readiness.yml`

Objetivo:
- gate agregado de readiness de release.

Checks:
1. `pnpm install --frozen-lockfile`
2. `pnpm test:ci`
3. `pnpm verify:hardening`
4. `SKIP_SMOKE=1 bash infra/scripts/release-check.sh`

## Estrategia de release (estado atual)

### Fase local obrigatoria
1. `pnpm test:ci`
2. `pnpm verify:hardening`
3. `bash infra/scripts/release-check.sh`
4. `bash infra/scripts/smoke.sh` (readiness operacional)

### Fase CI obrigatoria
1. pipelines relevantes verdes na PR/branch alvo;
2. ausencia de falha em gates bloqueantes;
3. evidencias registradas no relatorio da versao.

### Fase de fechamento
1. gerar `RELATORIO-FINAL-V*.md`;
2. gerar `versao-*.zip`;
3. registrar decisao final (`LIBERAR`/`BLOQUEAR`).

## Gates bloqueantes
Release deve ser bloqueado se falhar qualquer item:
1. install deterministico;
2. `pnpm test:ci`;
3. `pnpm verify:hardening`;
4. guardas OpenAPI (`api-contract`, `api-docs`, `api-breaking-change`);
5. `deploy-readiness.yml`;
6. checklist de evidencia de release.

## Gates de alerta
Podem existir como aviso, mas escalam para bloqueio se houver risco real:
1. lacuna documental sem impacto contratual imediato;
2. evidencia complementar incompleta com gates tecnicos verdes;
3. melhoria operacional pendente sem impacto imediato de release.

## Mapa local x CI (resumo)
1. local: `pnpm test:ci` -> CI: `deploy-readiness`;
2. local: `pnpm verify:hardening` -> CI: `scaffold-bootstrap` e `deploy-readiness`;
3. local: checks OpenAPI -> CI: `api-contract` e `api-docs`;
4. local: analise de surface -> CI: `api-breaking-change` em PR.

## Falha de pipeline - protocolo
Ao falhar pipeline:
1. identificar workflow e etapa;
2. classificar categoria de falha;
3. reproduzir com comando local equivalente;
4. aplicar correcao minima;
5. rerodar check local;
6. rerodar gate CI;
7. registrar evidencias da recuperacao.

Referencia: `infra/ci/PIPELINE-FAILURE-PLAYBOOK.md`.

## Limites do estado atual
1. smoke HTTP completo ainda e primariamente local (CI usa `SKIP_SMOKE=1` no release-check);
2. gates funcionais de QA ainda exigem evolucao de preenchimento continuo em `QA-01`/`QA-02`;
3. pipeline esta orientada a confiabilidade pragmatica, nao a cobertura enterprise total.

## Direcao de evolucao recomendada
1. manter paridade entre check local e check CI;
2. amadurecer evidencia funcional em QA por versao;
3. ampliar automacao apenas quando houver ganho claro de reducao de risco.

## Criterio de aceite
Este documento esta aprovado quando:
1. descreve fielmente pipelines e gates existentes;
2. define decisao de release com criterio objetivo;
3. reduz ambiguidade entre validacao local e CI.
