# 009 - Monitoramento, Metrics, Tracing e Alertas

## Objetivo
Consolidar o baseline real de monitoramento, metricas, tracing e alertas do `personal-site`, descrevendo o que ja esta implementado e o que ainda e backlog de maturidade.

## Escopo
Inclui:
1. sinais atuais de saude e disponibilidade;
2. tracing por `traceId` na API e nos clients;
3. metricas operacionais disponiveis hoje;
4. estrategia de alerta viavel no estagio atual;
5. trilha incremental para evolucao.

Nao inclui:
1. APM externo nao implementado;
2. stack completa de metricas (Prometheus/Grafana) ainda nao materializada;
3. nocao de observabilidade enterprise fora do estado atual.

## Fontes soberanas usadas
1. `apps/api/src/server.ts`
2. `apps/api/src/routes/health.ts`
3. `apps/admin/src/lib/api/admin.ts`
4. `apps/web/src/lib/api/public.ts`
5. `infra/scripts/smoke.sh`
6. `.github/workflows/deploy-readiness.yml`
7. `infra/ci/CI-MATRIX.md`
8. `Waterfall/DOC-21-observabilidade-logs-e-incidentes.md`

## Veredito tecnico do estado atual

### Estado oficial
O projeto possui observabilidade **P0 funcional**, centrada em:
1. health/readiness checks;
2. correlation id (`traceId`);
3. logs estruturados da API;
4. gates de CI/release readiness.

### Limite atual
Nao existe stack dedicada de metricas e alertas automatizados de SLO/SLA no repositorio.

## 1) Monitoramento de saude e prontidao

## 1.1 Endpoints de monitoramento

Na API:
1. `GET /health`
2. `GET /ready`

Comportamento:
1. retornam envelope com `meta.traceId`;
2. `/ready` pode retornar `503 SERVICE_UNAVAILABLE` em falha bloqueante de dependencia.

## 1.2 Uso operacional

1. `infra/scripts/smoke.sh` valida health/ready e checa presenca de `traceId`;
2. smoke integra o gate local de release (`release-check.sh`), e no CI o release-check roda em modo `SKIP_SMOKE=1`.

## 2) Tracing e correlacao

## 2.1 Correlation ID na API

No `apps/api/src/server.ts`:
1. `requestIdHeader` usa `x-trace-id`;
2. entrada e validada por regex e limite de tamanho;
3. fallback para UUID interno se header invalido/ausente;
4. resposta devolve `x-trace-id`.

## 2.2 Propagacao para clientes

### Admin (`apps/admin/src/lib/api/admin.ts`)
1. encaminha `x-trace-id` em runtime server-side quando disponivel;
2. erros tipados preservam `traceId` (`AdminApiError`).

### Web (`apps/web/src/lib/api/public.ts`)
1. erros tipados preservam `traceId` (`PublicApiError`) quando fornecido pela API;
2. facilita correlacao entre falha de tela e log de backend.

## 3) Logging e metricas disponiveis hoje

## 3.1 Logs estruturados da API

Por request (`onResponse`):
1. `traceId`
2. `method`
3. `route`
4. `statusCode`
5. `responseTimeMs`

No `setErrorHandler`:
1. separa erro esperado (`4xx`) de erro inesperado (`5xx`);
2. redige campos sensiveis (`authorization`, `cookie`, `set-cookie`).

## 3.2 Metricas operacionais derivadas (estado atual)

Sem coletor dedicado, as metricas atuais sao extraidas de logs e checks:
1. disponibilidade de API via `/health` e `/ready`;
2. taxa de erro por classe de status (`4xx`/`5xx`);
3. latencia por rota (`responseTimeMs`);
4. falhas de gate no CI (`test:ci`, `verify:hardening`, `deploy-readiness`).

## 3.3 O que ainda nao existe

1. endpoint `/metrics` padronizado;
2. serie temporal centralizada no repositorio;
3. painel de dashboard tecnico automatizado;
4. alerta baseado em thresholds de erro/latencia dentro do codigo.

## 4) Alertas no estagio atual

## 4.1 Alertas existentes (indiretos)

1. falha de workflow CI atua como alerta de qualidade/deploy;
2. smoke local falhando atua como alerta operacional imediato;
3. `ready=503` atua como alerta de indisponibilidade de dependencia bloqueante.

## 4.2 Alertas ausentes

1. alerta automatizado por latencia acima de threshold;
2. alerta automatizado por taxa de erro;
3. escalonamento por severidade com canal integrado.

## 5) Protocolo de triagem monitoravel

Quando houver incidente:
1. identificar rota e horario da falha;
2. capturar `traceId` no client/response;
3. localizar log correlato na API;
4. classificar erro (`4xx`, `5xx`, `NETWORK_ERROR`, `INVALID_RESPONSE_SHAPE`, etc.);
5. executar correcao de menor escopo;
6. rerodar validacao (`smoke`, `test:ci`, `verify:hardening`) conforme impacto.

## 6) Matriz de maturidade (estado atual)

| Pilar | Estado atual | Nivel |
|---|---|---|
| Health checks | `/health` e `/ready` implementados | Bom P0 |
| Tracing | `traceId` ponta a ponta (API + clients) | Bom P0 |
| Logs estruturados | API com latencia/status/rota + redaction | Bom P0 |
| Metricas temporais | derivadas manualmente de logs/checks | Basico |
| Alertas automatizados | CI/gates e readiness indiretos | Basico |
| Observabilidade centralizada | nao implementada | Gap conhecido |

## 7) Gaps e riscos residuais

### G-01 - Sem alertas proativos de runtime
Risco:
- deteccao tardia de degradacao fora da janela de release.

### G-02 - Sem serie temporal consolidada
Risco:
- dificuldade para analise de tendencia (erro/latencia).

### G-03 - Dependencia de triagem manual
Risco:
- resposta a incidente depende de disciplina operacional da equipe.

## 8) Evolucao incremental recomendada

## Fase 1 - Alertas operacionais minimos
1. padronizar checklist de monitoramento diario com health/ready;
2. formalizar thresholds manuais iniciais (erro e latencia) por rota critica;
3. registrar evidencias no runbook operacional.

## Fase 2 - Metrics estruturadas
1. adicionar endpoint de metricas (ou exportador) sem romper contrato HTTP principal;
2. coletar contadores de erro e histogramas de latencia;
3. manter `traceId` como chave de correlacao com logs.

## Fase 3 - Alertas automatizados
1. criar regras de alerta para indisponibilidade e taxa de erro;
2. definir severidade e responsavel por resposta;
3. integrar com playbook de incidente e rollback.

## 9) Criterio de aceite deste documento

Este documento esta aprovado quando:
1. descreve o baseline real (sem prometer APM inexistente);
2. mapeia como monitorar hoje com o que ja existe;
3. deixa claro o gap entre P0 funcional e observabilidade avancada;
4. define evolucao viavel e incremental.

## Conclusao tecnica

No estado atual, o `personal-site` possui monitoramento e tracing suficientes para operacao disciplinada de ciclo (health/ready + traceId + logs estruturados + gates CI).

A maturidade de metricas e alertas ainda e basica, com dependencia de triagem manual e ausencia de stack centralizada.

A linha correta e evoluir por fases, sem reabrir o que ja funciona: preservar baseline P0 e adicionar metricas/alertas automatizados somente com ganho operacional comprovado.
