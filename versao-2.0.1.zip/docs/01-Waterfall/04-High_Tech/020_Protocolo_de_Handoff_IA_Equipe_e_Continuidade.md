# 020 - Protocolo de Handoff IA, Equipe e Continuidade

## Objetivo
Definir o protocolo soberano de handoff entre IA e equipe humana no `personal-site`, garantindo continuidade sem perda de contexto, sem falso positivo de conclusao e com rastreabilidade auditavel entre ciclos.

Este documento encerra a camada de governanca High-Tech para passagem de bastao entre:
1. execucao tecnica (codigo/docs/infra/QA);
2. validacao humana de ciclo;
3. auditoria de versao.

## Escopo
Inclui:
1. padrao de handoff por item e por ciclo;
2. pacote minimo obrigatorio de evidencias;
3. responsabilidades de IA e equipe;
4. criterio de bloqueio/liberacao de continuidade;
5. template oficial de handoff para proximo chat.

Nao inclui:
1. substituicao da decisao final humana de release;
2. bypass de gates tecnicos obrigatorios;
3. aprovacao automatica sem checklist preenchido.

## Fontes soberanas auditadas
1. `docs/01-Waterfall/04-High_Tech/019_Superprompt_Tecnico_de_Geracao_Lego.md`
2. `infra/ci/ARTIFACTS-AND-RETENTION.md`
3. `infra/ci/RELEASE-EVIDENCE-CHECKLIST.md`
4. `infra/ci/CI-MATRIX.md`
5. `QA/QA-02-matriz-de-gates-ci-e-deploy-readiness.md`
6. `README.md`
7. `Waterfall/DOC-10-arquitetura-tecnica.md`
8. `Waterfall/DOC-21-observabilidade-logs-e-incidentes.md`

## Veredito tecnico do estado atual
O projeto ja possui base forte para continuidade (metodo caracol, ciclo sequencial, checklist de release, politica de retencao, workflows de gate).

O risco residual de continuidade nao esta na falta de ferramenta, e sim na disciplina de handoff:
1. perda de contexto entre chats;
2. declaracao prematura de conclusao;
3. ausencia de evidencia consolidada no fechamento.

Este protocolo resolve esse risco ao transformar handoff em processo tecnico com bloqueios objetivos.

## 1) Principios soberanos de handoff
1. continuidade e parte do produto, nao etapa opcional;
2. handoff sem evidencia e handoff invalido;
3. um ciclo so existe como "concluido" quando codigo, docs e evidencias convergem;
4. o proximo chat deve iniciar com estado congelado claro (feito, pendente, bloqueado);
5. todo handoff precisa apontar proximo passo executavel.

## 2) Responsabilidades por ator

## 2.1 Responsabilidades da IA executora
1. seguir a ordem do `Atualizacao de codigo` sem pular itens;
2. alterar um arquivo por vez, com confirmacao de integridade;
3. reportar apenas fatos verificaveis (sem inflar status);
4. registrar evidencias tecnicas por item e por ciclo;
5. gerar handoff final com estado real da versao.

## 2.2 Responsabilidades da equipe humana
1. validar aderencia do item entregue ao escopo da lista;
2. confirmar evidencias de gates e checklist de release;
3. decidir `LIBERAR` ou `BLOQUEAR` com base no protocolo;
4. manter arquivo `Atualizacao de codigo` como fonte de ordem do ciclo;
5. acionar proximo ciclo apenas apos congelamento explicito da versao atual.

## 3) Pacote minimo obrigatorio de handoff
Nenhum handoff e valido sem o pacote abaixo:
1. status do ciclo (itens concluidos, pendentes, bloqueados);
2. lista de arquivos alterados/criados com caminho completo;
3. evidencias de validacao tecnica aplicavel (`test`, `typecheck`, `hardening`, `smoke`, workflows);
4. relatorio final de versao;
5. zip da versao sem `node_modules` e caches;
6. riscos residuais assumidos no fechamento.

## 4) Handoff por item (micro-handoff)
A cada item concluido, registrar:
1. `Item N`;
2. arquivo alvo;
3. tipo de acao (`EXISTE` reforma ou `INEXISTENTE` geracao);
4. validacao de integridade (ex.: `wc -l` + leitura parcial);
5. impacto em docs relacionados;
6. proximo item em ordem.

Regra:
- sem micro-handoff valido, nao avancar para o proximo item.

## 5) Handoff de ciclo (macro-handoff)
No fechamento do ciclo, o relatorio de continuidade deve conter:
1. resumo factual do escopo do ciclo;
2. lista objetiva de entregas por bloco;
3. o que ficou fora do escopo por decisao tecnica;
4. bloqueios encontrados e como foram tratados;
5. veredito de prontidao do ciclo (`CONCLUIDO` ou `PARCIAL`), com justificativa;
6. proximo ciclo recomendado em ordem operacional.

## 6) Criticos de bloqueio de continuidade
Bloquear continuidade quando houver qualquer condicao abaixo:
1. item da lista marcado como concluido sem arquivo materializado;
2. teste/gate declarado verde sem evidencia;
3. divergencia entre relatorio final e estado fisico do repositorio;
4. ausencia de zip ou relatorio final no congelamento da versao;
5. ausencia de referencia ao risco residual relevante.

## 7) Regra de liberacao de continuidade
Liberar continuidade para proximo chat somente quando:
1. pacote minimo obrigatorio estiver completo;
2. `RELEASE-EVIDENCE-CHECKLIST` estiver coerente com a rodada;
3. gates obrigatorios da versao estiverem explicitamente classificados;
4. proximo ciclo estiver descrito com ordem executavel arquivo por arquivo.

## 8) Template oficial de handoff para proximo chat (copy/paste)

```text
Memoria atualizada.

# RELATORIO DE CONTINUIDADE — <versao>

## 1. Veredito do ciclo
- Estado: <CONCLUIDO|PARCIAL|BLOQUEADO>
- Escopo executado: <resumo objetivo>
- Aderencia ao estado fisico: <sim/nao + justificativa>

## 2. Entregas materializadas
1. <arquivo 1>
2. <arquivo 2>
...

## 3. Evidencias tecnicas
- Local: <comandos + resultado>
- CI: <workflows + status>
- QA/checklists: <arquivos atualizados>

## 4. Pendencias e bloqueios
1. <pendencia/bloqueio>
2. <impacto>
3. <acao recomendada>

## 5. Riscos residuais
1. <risco>
2. <mitigacao atual>

## 6. Proximo ciclo recomendado
- Nome: <nome do ciclo>
- Ordem soberana: <itens em sequencia>
- Regra: um arquivo por vez

## 7. Artefatos de congelamento
- Relatorio: <arquivo>
- ZIP: <arquivo>
- Checklist: <arquivo>
```

## 9) Template de handoff rapido por incidente

```text
INCIDENTE: <id>
Impacto: <servico/fluxo>
Janela: <inicio/fim>
TraceId(s): <ids>
Causa raiz: <resumo tecnico>
Correcao aplicada: <arquivo/comando>
Validacao pos-correcao: <evidencia>
Risco residual: <sim/nao + detalhe>
Proximo passo: <acao objetiva>
```

## 10) Integracao com Metodo Caracol
Este protocolo e compativel com o Metodo Caracol porque:
1. preserva execucao sequencial;
2. exige consolidacao antes de avancar;
3. congela versoes com evidencias;
4. reduz perda de memoria entre chats;
5. transforma continuidade em processo tecnico auditavel.

## 11) Criterios de aceite deste documento
Este documento e aceito quando:
1. define handoff como processo com entradas, saidas e bloqueios claros;
2. impede continuidade sem evidencia tecnica;
3. permite retomada precisa por outro executor/chat;
4. permanece aderente ao estado real de governanca do projeto.

## Conclusao tecnica
No `personal-site`, continuidade sem protocolo gera retrabalho e risco de auditoria negativa.

Com este protocolo, cada ciclo fecha com contexto preservado, evidencias verificaveis e proximo passo executavel. Isso reduz ruido operacional, protege a memoria do projeto e sustenta evolucao disciplinada entre IA e equipe humana.
