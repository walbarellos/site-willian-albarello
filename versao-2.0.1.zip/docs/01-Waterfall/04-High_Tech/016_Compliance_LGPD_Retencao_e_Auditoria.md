# 016 - Compliance, LGPD, Retencao e Auditoria

## Objetivo
Estabelecer o baseline real de compliance do `personal-site` para protecao de dados, retencao de artefatos e trilha de auditoria, com foco em:
1. aderencia pragmatica a LGPD no estagio atual;
2. separacao clara entre controles implementados e gaps residuais;
3. regras objetivas de retencao para auditoria de ciclos;
4. protocolo operacional para resposta a incidente de dados.

Este documento registra o estado tecnico atual do repositorio. Nao descreve conformidade "idealizada".

## Escopo
Inclui:
1. dados pessoais tratados no fluxo atual;
2. controles tecnicos existentes (API/admin/infra);
3. politicas de retencao ja materializadas no projeto;
4. evidencias minimas exigidas por ciclo para rastreabilidade;
5. lacunas de maturidade e backlog de conformidade.

Nao inclui:
1. parecer juridico formal;
2. certificacao de compliance regulatorio externo;
3. controles enterprise que nao estao materializados no codigo/documentacao atual.

## Fontes soberanas auditadas
1. `Waterfall/DOC-14-seguranca-p0.md`
2. `infra/ci/ARTIFACTS-AND-RETENTION.md`
3. `docs/01-Waterfall/04-High_Tech/008_Backup_Retention_Disaster_Recovery_e_RTO_RPO.md`
4. `docs/01-Waterfall/04-High_Tech/009_Monitoramento_Metrics_Tracing_e_Alertas.md`
5. `QA/QA-02-matriz-de-gates-ci-e-deploy-readiness.md`
6. `.env.example`
7. `apps/api/src/server.ts`
8. `apps/api/src/lib/admin-auth.ts`
9. `apps/api/src/routes/auth.ts`
10. `apps/admin/src/lib/api/admin.ts`
11. `apps/admin/src/lib/session.ts`

## Veredito tecnico do estado atual
No estagio atual, o projeto possui um **baseline P0 de protecao de dados e rastreabilidade operacional** adequado para ambiente controlado e ciclos auditaveis.

Esse baseline e sustentado por:
1. sessao administrativa por cookie assinado e `httpOnly`;
2. protecao CSRF para mutacoes;
3. CORS com allowlist;
4. headers de seguranca;
5. `traceId` propagado no backend e nos clients;
6. politica soberana de retencao de artefatos de ciclo.

Ao mesmo tempo, ainda existem lacunas relevantes para um nivel de compliance mais avancado:
1. ausencia de trilha persistente de auditoria por usuario/acao em banco;
2. ausencia de MFA para acesso administrativo;
3. ausencia de automacao completa de alertas e governanca de incidente em runtime continuo;
4. dependencia de disciplina operacional para consolidacao de evidencias.

## 1) Mapa de dados pessoais no estado atual

## 1.1 Dados tratados diretamente
1. email administrativo (`ADMIN_BOOTSTRAP_EMAIL` ou credencial equivalente de login);
2. identificador de sessao administrativa (token em cookie assinado);
3. metadados de requisicao para observabilidade (`traceId`, rota, status, tempo de resposta).

## 1.2 Dados sensiveis por configuracao/segredo
1. segredo de sessao (`SESSION_SECRET`);
2. senha bootstrap administrativa (`ADMIN_BOOTSTRAP_PASSWORD`);
3. string de conexao de banco (`DATABASE_URL`) quando persistencia externa e utilizada.

## 1.3 Dados de conteudo editorial
Publicacoes e metadados editoriais (titulo, resumo, slug, tags, status) sao dados de produto, mas podem conter informacao pessoal dependendo do conteudo redacional. A governanca de conteudo deve mitigar esse risco no fluxo editorial.

## 2) Base legal e principio de minimizacao (visao tecnica)
No estagio atual, o tratamento tecnico de dados administrativos e orientado por necessidade operacional do sistema:
1. autenticar e autorizar acesso ao painel;
2. proteger mutacoes administrativas;
3. garantir rastreabilidade de incidente e operacao.

Principio aplicado no codigo:
1. minimizacao de superficie de sessao (cookie assinado, `httpOnly`, TTL);
2. minimizacao de exposicao de segredo (uso por env, nao em codigo hardcoded de producao);
3. minimizacao de cache em rotas administrativas (`no-store`).

## 3) Controles tecnicos implementados e seu valor para compliance

## 3.1 Autenticacao e sessao
Implementado:
1. validacao de credenciais e comparacao segura (`timingSafeEqual`);
2. sessao com cookie assinado;
3. expiracao de sessao e limpeza no logout;
4. verificacao de papeis (`admin`, `editor`) nas rotas protegidas.

Valor de compliance:
1. reduz risco de acesso indevido;
2. limita exposicao de dados administrativos;
3. melhora trilha de responsabilizacao de acesso (ainda sem trilha persistente completa).

## 3.2 Protecao de mutacao (CSRF)
Implementado:
1. plugin CSRF no backend;
2. tentativa de propagacao de token no client admin;
3. normalizacao de erro para `CSRF_INVALID_TOKEN`.

Valor de compliance:
1. mitiga submissao maliciosa em contexto autenticado;
2. protege integridade de dados administrativos.

## 3.3 Transporte e superficie HTTP
Implementado:
1. CORS por allowlist;
2. headers de seguranca (`nosniff`, `DENY`, `referrer-policy`, `permissions-policy`);
3. `traceId` em request/response para correlacao.

Valor de compliance:
1. reduz superficie de exposicao cross-origin;
2. melhora capacidade de investigacao em incidente.

## 3.4 Logging e redacao
Implementado:
1. logs estruturados por request;
2. redacao de campos sensiveis (`authorization`, `cookie`, `set-cookie`).

Valor de compliance:
1. evita vazamento acidental de credenciais nos logs;
2. preserva rastreabilidade sem comprometer segredos.

## 4) Politica de retencao soberana (estado materializado)
Fonte principal: `infra/ci/ARTIFACTS-AND-RETENTION.md`.

## 4.1 Artefatos obrigatorios por ciclo
Cada ciclo fechado deve preservar:
1. ZIP da versao;
2. relatorio final da versao;
3. evidencias de validacao tecnica (`test:ci`, `verify:hardening`, `smoke` quando aplicavel);
4. referencia ao checklist de release com decisao explicita.

## 4.2 Retencao minima definida
1. manter ultimas 3 versoes ZIP;
2. manter historico completo de relatorios finais;
3. manter evidencias locais de comando por ao menos 2 ciclos subsequentes, com consolidacao em relatorio quando estavel;
4. descartar logs temporarios sem valor de auditoria apos consolidacao.

## 4.3 O que nao pode ser descartado
1. documentos soberanos atualizados;
2. evidencia que sustenta `LIBERAR` ou `BLOQUEAR` release;
3. relatorios finais de versoes fechadas.

## 5) Trilha de auditoria do projeto

## 5.1 Nivel atual de trilha
A trilha existe em nivel de ciclo e operacao:
1. relatorio final por versao;
2. zip de versao;
3. gates de qualidade documentados;
4. `traceId` para correlacao de incidentes HTTP.

## 5.2 Limitacao atual
Nao existe, no estado atual, trilha persistente detalhada de "quem fez o que" no nivel transacional de negocio (ex.: registro imutavel por acao editorial em storage dedicado).

## 6) Direitos do titular (visao tecnica no estagio atual)
Este documento nao substitui politica juridica formal, mas define requisitos tecnicos minimos para viabilizar atendimento futuro de direitos LGPD:
1. identificar rapidamente onde dados administrativos residem (env, sessao, logs redigidos);
2. evitar dispersao de dado pessoal em artefatos nao controlados;
3. manter trilha de release e evidencias para provar mudanca/mitigacao;
4. preparar backlog para persistencia e trilha auditavel por entidade/acao.

## 7) Matriz de maturidade de compliance (estado atual)

| Pilar | Estado atual | Nivel |
|---|---|---|
| Seguranca de sessao/admin | Implementado (P0) | Bom P0 |
| Protecao CSRF/CORS/headers | Implementado (P0) | Bom P0 |
| Redacao de segredo em log | Implementado (P0) | Bom P0 |
| Retencao de artefatos de ciclo | Definida e aplicada | Bom P0 |
| Trilho de auditoria transacional persistente | Nao implementado | Gap |
| MFA/controle forte de identidade | Nao implementado | Gap |
| Programa formal de privacidade (DPIA/ROPA juridico) | Nao materializado no repo | Gap |

## 8) Riscos residuais aceitos neste ciclo
1. comprometimento de conta administrativa por ausencia de MFA;
2. investigacao limitada de autoria transacional por ausencia de trilha persistente detalhada;
3. dependencia de processo manual para consolidar evidencias de auditoria fora dos gates automaticos;
4. risco de conteudo editorial conter dado pessoal sem classificacao automatica.

## 9) Controles obrigatorios para liberar nova versao
Para evitar falso positivo de conformidade, a liberacao de versao deve manter:
1. gates tecnicos verdes (`test:ci`, `verify:hardening`, `deploy-readiness` quando aplicavel);
2. `smoke` operacional aprovado quando houver alteracao de runtime;
3. relatorio final versionado com resumo de mudancas e riscos residuais;
4. atualizacao de documentos soberanos impactados.

Se algum item acima falhar, a decisao deve ser `BLOQUEAR` ate correcao.

## 10) Backlog de evolucao recomendado

## Fase 1 - Fortalecimento de identidade
1. introduzir MFA para acesso administrativo;
2. separar credenciais bootstrap de operacao cotidiana;
3. revisar politica de rotacao de segredos.

## Fase 2 - Auditoria persistente
1. registrar eventos administrativos criticos em storage persistente;
2. incluir identificador de ator, acao, alvo, timestamp e traceId;
3. padronizar exportacao de trilha para auditoria.

## Fase 3 - Privacidade operacional
1. formalizar classificacao de dados por categoria;
2. definir procedimentos de atendimento a solicitacoes de titular;
3. adicionar checklist de privacidade por release com evidencias.

## Fase 4 - Governanca continua
1. revisar trimestralmente riscos residuais;
2. atualizar documento de compliance junto com mudancas arquiteturais;
3. bloquear release quando houver regressao de controles P0.

## 11) Criterio de aceite deste documento
Este documento e considerado aceito quando:
1. representa o estado real do repositorio sem inflar maturidade;
2. conecta seguranca, retencao e auditoria em regras operacionais objetivas;
3. registra riscos residuais de forma explicita;
4. orienta evolucao incremental sem reabrir o que ja esta estavel.

## Conclusao tecnica
No estado atual, o `personal-site` atende um baseline P0 consistente para compliance tecnico orientado a LGPD em ambiente controlado: possui controles de sessao, protecao de mutacao, redacao de segredos, rastreabilidade por `traceId` e politica de retencao de artefatos de ciclo.

A maturidade ainda nao e plena para auditoria transacional avancada e identidade forte. O caminho correto nao e declarar conformidade maxima prematura, e sim evoluir por fases com evidencias verificaveis em cada ciclo.
