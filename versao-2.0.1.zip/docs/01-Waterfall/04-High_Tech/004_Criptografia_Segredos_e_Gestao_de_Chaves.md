# 004 - Criptografia, Segredos e Gestao de Chaves

## Objetivo
Definir o baseline tecnico de criptografia aplicada, segredos e gestao de chaves do `personal-site`, estritamente aderente ao estado atual do codigo e da operacao.

## Escopo
Inclui:
1. uso real de segredo de sessao e protecao de cookie;
2. modelo atual de autenticacao bootstrap admin;
3. exigencias de variaveis sensiveis por ambiente;
4. armazenamento, distribuicao e rotacao operacional de segredos;
5. riscos de exposicao e mitigacoes praticas no estagio atual.

Nao inclui:
1. KMS/HSM nao implementado;
2. criptografia de dados em repouso fora da plataforma;
3. modelo de identidade avancado (MFA, SSO corporativo, IAM complexo).

## Fontes soberanas usadas
1. `apps/api/src/lib/env.ts`
2. `apps/api/src/lib/admin-auth.ts`
3. `apps/api/src/server.ts`
4. `.env.example`
5. `infra/env/ENVIRONMENT-MATRIX.md`
6. `infra/env/.env.staging.example`
7. `infra/env/.env.production.example`
8. `infra/ops/OPERACAO-E-ROLLBACK.md`
9. `Waterfall/DOC-14-seguranca-p0.md`

## Modelo de criptografia aplicado no estado atual

### 1) Segredo de sessao (chave aplicacional)
- Variavel: `SESSION_SECRET`
- Uso: assinatura de cookie e integridade de sessao via `@fastify/cookie`
- Regra tecnica em `env.ts`:
  1. minimo 16 chars fora de producao;
  2. minimo 32 chars em producao;
  3. proibido usar default de desenvolvimento em producao.

Conclusao:
- a "chave mestre" atual da camada web/app e o `SESSION_SECRET`.
- sem ela valida, a API nao sobe corretamente em ambiente restrito.

### 2) Credenciais bootstrap admin (segredo de acesso)
- Variaveis:
  1. `ADMIN_BOOTSTRAP_EMAIL`
  2. `ADMIN_BOOTSTRAP_PASSWORD`
  3. `ADMIN_BOOTSTRAP_ROLE`
  4. `ADMIN_BOOTSTRAP_DISPLAY_NAME` (nao sensivel critica)
- Uso: autenticacao inicial administrativa em `admin-auth.ts`.

Comportamento:
1. em producao, ausencia de email/senha bootstrap causa erro de boot (fail-closed);
2. comparacao de senha usa `timingSafeEqual`;
3. role e validada (`admin` ou `editor`).

### 3) CSRF token por sessao
- Geracao: `reply.generateCsrf()` quando plugin CSRF esta ativo.
- Transporte: payload de sessao pode incluir `csrfToken`.
- Consumo: mutacoes admin enviam `x-csrf-token` quando aplicavel.

Observacao:
- token e efemero de sessao e nao substitui a politica de segredo de ambiente.

## Segredos e dados sensiveis por camada

### API (`apps/api`)
Sensivel obrigatorio:
1. `SESSION_SECRET`
2. `DATABASE_URL`
3. `ADMIN_BOOTSTRAP_PASSWORD`

Sensivel de controle de fronteira:
1. `CORS_ORIGINS`
2. `PUBLIC_SITE_URL`
3. `ADMIN_SITE_URL`

### Web/Admin (`apps/web`, `apps/admin`)
Nao devem armazenar segredo privado de backend no bundle.

Variaveis publicas (`NEXT_PUBLIC_*`) sao de configuracao de endpoint/canonical, nao de segredo.

## Politica de armazenamento de segredos

### Repositorio
1. permitido versionar apenas exemplos (`.env.example`, `infra/env/.env.*.example`);
2. proibido versionar `.env` real com segredo;
3. proibido commitar token/chave em markdown, script ou workflow.

### Plataformas
1. Vercel: segredos setados no projeto (`web` e `admin`) por ambiente;
2. Render: segredos setados no service da API por ambiente;
3. valores de producao nao devem aparecer em logs nem em artefatos de build.

## Politica de distribuicao por ambiente

### Development
- aceita defaults locais controlados para acelerar bootstrap.
- ainda assim, `SESSION_SECRET` deve respeitar minimo tecnico.

### Staging
- deve usar valores proprios de staging (nao copiar dev).
- bootstrap admin deve ser explicito para evitar ambiguidade de acesso.

### Production
Obrigatorio:
1. `SESSION_SECRET` forte e exclusivo;
2. bootstrap admin explicito;
3. `CORS_ORIGINS` explicito e restrito;
4. segregacao de segredos por plataforma/servico.

## Rotacao de chaves e segredos (runbook minimo)

### Quando rotacionar
1. suspeita de vazamento;
2. troca de responsavel operacional;
3. incidente de seguranca confirmado;
4. politica periodica definida pela operacao.

### Ordem recomendada de rotacao
1. preparar novo segredo no ambiente alvo (sem remover o antigo prematuramente);
2. aplicar em staging e validar (`test:ci`, `verify:hardening`, smoke);
3. aplicar em producao em janela controlada;
4. forcar novo ciclo de login admin se necessario;
5. registrar evidencia no relatorio de versao/incidente.

### Impactos esperados
1. rotacao de `SESSION_SECRET` invalida sessoes existentes;
2. rotacao de bootstrap password altera ponto de entrada administrativa;
3. erros de env devem ser detectados no boot por validacao estrita.

## Controles ativos de protecao

1. validacao de env com `zod` e fail-fast;
2. fail-closed para credenciais bootstrap em producao;
3. cookie de sessao `httpOnly`, `signed`, `sameSite=strict`, `secure` em prod;
4. redaction de headers sensiveis no logger (`authorization`, `cookie`, `set-cookie`);
5. CSRF token para mutacoes administrativas;
6. CORS por allowlist com credenciais.

## Riscos atuais e mitigacoes

### R-01: segredo fraco ou reutilizado em producao
Mitigacao:
1. regra minima de tamanho em `env.ts`;
2. bloqueio de default de dev em producao;
3. checklist de release/env em `infra/ci`.

### R-02: exposicao acidental de segredo em commit
Mitigacao:
1. versionar apenas arquivos `*.example`;
2. revisao de diff antes de release;
3. auditoria de pipeline e ownership dos gates.

### R-03: inconsistencia de env entre plataformas
Mitigacao:
1. `infra/env/ENVIRONMENT-MATRIX.md` como fonte soberana;
2. runbooks separados para Vercel/Render;
3. smoke e release-check antes de deploy.

### R-04: dependencia de bootstrap admin simples
Mitigacao:
1. restringir uso operacional e controlar segredo com disciplina;
2. manter backlog para evolucao de identidade (MFA/IAM) sem quebrar P0.

## Anti-padroes proibidos

1. usar `SESSION_SECRET` curto ou previsivel em producao;
2. reutilizar senha bootstrap entre ambientes;
3. copiar `.env` de desenvolvimento para producao;
4. registrar segredo em texto plano em relatorio publico;
5. expor segredo em variavel `NEXT_PUBLIC_*`.

## Checklist operacional de seguranca de segredos

Antes de qualquer release:
1. confirmar variaveis obrigatorias de backend presentes e validas;
2. confirmar `CORS_ORIGINS` com dominios corretos;
3. confirmar que nenhum segredo real entrou em arquivo versionado;
4. executar `pnpm verify:hardening`;
5. executar `bash infra/scripts/release-check.sh`;
6. registrar resultado no relatorio da versao.

## Limites do estado atual

1. nao ha KMS central declarada no repositorio;
2. nao ha rotacao automatica de segredos;
3. trilha criptografica de auditoria de segredo ainda e operacional/manual.

Esses limites sao conhecidos e aceitos no estagio atual, com compensacao por disciplina de env + gates + runbook.

## Direcao de evolucao

1. consolidar processo de rotacao com janela e evidencia padrao;
2. separar segredo por servico e por ambiente sem sobrecarga desnecessaria;
3. avaliar evolucao de identidade admin (MFA/contas gerenciadas) apos fechar backlog High-Tech.

## Criterio de aceite
Este documento esta aprovado quando:
1. mapeia segredos reais usados hoje no codigo;
2. descreve politica de armazenamento/distribuicao sem teoria generica;
3. define rotina minima de rotacao e resposta a incidente;
4. permanece coerente com `ENVIRONMENT-MATRIX`, `DOC-14` e runbooks de `infra/`.
