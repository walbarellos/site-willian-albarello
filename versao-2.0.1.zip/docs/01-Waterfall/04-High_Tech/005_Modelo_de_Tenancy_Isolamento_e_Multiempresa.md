# 005 - Modelo de Tenancy, Isolamento e Multiempresa

## Objetivo
Documentar o modelo de tenancy real do `personal-site` no estado atual, explicando:

1. como o sistema esta segmentado hoje;
2. quais limites de isolamento existem de fato;
3. o que ainda nao existe para multiempresa;
4. como evoluir para multi-tenant sem quebrar contratos vigentes.

## Escopo
Inclui:
1. arquitetura atual de identidade/sessao e dados editoriais;
2. isolamento pratico entre camada publica e administrativa;
3. riscos de crescimento para cenario multiempresa;
4. direcao de evolucao incremental.

Nao inclui:
1. implementacao imediata de multi-tenant;
2. redesign completo de schema de dados;
3. IAM corporativo avancado.

## Fontes soberanas usadas
1. `apps/api/src/routes/publications-admin.ts`
2. `apps/api/src/routes/publications-public.ts`
3. `apps/api/src/lib/admin-session-store.ts`
4. `apps/api/src/lib/admin-auth.ts`
5. `apps/admin/src/lib/session.ts`
6. `packages/contracts/src/session.ts`
7. `packages/contracts/src/publications.ts`
8. `packages/contracts/src/routes.ts`
9. `apps/api/src/lib/env.ts`

## Veredito de tenancy no estado atual

### Estado real
O projeto opera hoje em **single-tenant institucional**.

Caracteristicas observadas no codigo:
1. nao existe `tenantId`, `organizationId`, `workspaceId` ou equivalente nos contratos;
2. sessao admin nao carrega contexto de tenant;
3. rotas admin/publicas nao recebem cabecalho ou path de tenant;
4. dados editoriais sao tratados como acervo unico da instancia.

### Consequencia
- o isolamento atual e de **fronteira de acesso** (publico vs admin + role), nao de multiempresa.

## Modelo de isolamento vigente

### 1) Isolamento de superficie

- superficie publica:
  1. `/v1/public/publications`
  2. `/v1/public/publications/:slug`

- superficie administrativa:
  1. `/v1/admin/auth/*`
  2. `/v1/admin/dashboard`
  3. `/v1/admin/publications*`

Isolamento aplicado:
- rotas admin exigem sessao valida e role permitida (`admin`, `editor`).

### 2) Isolamento de autenticacao e sessao

- sessao por cookie assinado (`wa_admin_session`);
- sessao valida usuario administrativo unico da instancia;
- sem particionamento de sessao por tenant.

### 3) Isolamento de dados editoriais

- contratos de publicacao (`AdminPublication`, `PublicPublication*`) nao incluem coluna/campo de tenant;
- filtros disponiveis hoje: busca textual, status, pagina, categoria, tag;
- nenhum filtro por tenant.

### 4) Isolamento por ambiente

- separacao por ambiente (`development`, `staging`, `production`) via variaveis;
- isso isola implantacao, mas nao cria multiempresa dentro da mesma implantacao.

## O que o modelo atual protege bem

1. separacao clara entre acesso publico e administrativo;
2. enforcement de papeis administrativos;
3. controle de mutacao editorial por autenticacao/sessao;
4. fronteira de origem por CORS;
5. rastreabilidade basica por `traceId`.

## O que o modelo atual nao resolve (ainda)

1. coexistencia de multiplas organizacoes no mesmo backend;
2. isolamento logico/fisico de dados por tenant;
3. politicas de permissao por tenant;
4. scoping de sessao por tenant ativo;
5. quotas, limites e observabilidade segmentadas por tenant.

## Riscos ao escalar sem modelo de tenancy

### R-01 - Vazamento cruzado de dados no futuro
Se multiempresa for adicionada sem chave de tenant em toda cadeia, risco alto de leitura/edicao cruzada.

### R-02 - Regras de autorizacao ambiguas
Roles globais (`admin`/`editor`) deixam de ser suficientes quando houver empresas distintas.

### R-03 - Contratos instaveis
Adicionar `tenantId` tardiamente sem estrategia de compatibilidade pode quebrar admin/web/api.

### R-04 - Operacao e suporte sem recorte
Sem tenant, incidentes e metricas por cliente ficam dificeis de investigar e auditar.

## Decisao arquitetural do ciclo

### Decisao
Manter **single-tenant institucional** como estado oficial desta versao.

### Justificativa
1. aderencia ao escopo atual do produto (presenca institucional unica);
2. simplicidade operacional e menor superficie de risco no curto prazo;
3. evita complexidade prematura enquanto backlog High-Tech e completado.

### Condicao de revisao
Revisar esta decisao quando houver requisito formal de multiempresa real.

## Estrategia de evolucao para multiempresa (sem ruptura)

## Fase 1 - Preparacao de contrato (compatibilidade)

1. introduzir `tenantId` opcional em contratos internos de admin/sessao;
2. manter respostas atuais compativeis por periodo de transicao;
3. adicionar testes de serializacao para campos novos opcionais.

## Fase 2 - Persistencia e scoping

1. adicionar chave de tenant em sessoes e entidades editoriais;
2. aplicar filtro de tenant em todas as queries admin/publicas;
3. negar acesso quando tenant de sessao nao bater com recurso.

## Fase 3 - Autorizacao e operacao

1. evoluir role para contexto por tenant (ex.: `admin_tenant`, `editor_tenant`);
2. incluir `tenantId` em logs e metadados de observabilidade;
3. introduzir runbooks de incidente por tenant.

## Fase 4 - Hardening multiempresa

1. testes de isolamento cruzado obrigatorios na CI;
2. gates de regressao para evitar leak cross-tenant;
3. checklist de deploy com validacao de tenancy.

## Diretrizes de implementacao futura

1. evitar branch paralela de contrato; evoluir incrementalmente no pacote `contracts`;
2. qualquer campo novo de tenancy deve nascer com testes API + admin + web;
3. nao introduzir multiempresa apenas por UI; regra deve nascer no backend;
4. manter fallback de compatibilidade ate todos consumidores migrarem.

## Indicadores de prontidao para abrir ciclo multiempresa

Abrir ciclo de implementacao de multi-tenant somente quando todos os itens abaixo estiverem verdadeiros:

1. requisito de negocio formalizado e aprovado;
2. backlog de impactos em API/admin/web mapeado;
3. estrategia de migracao de dados definida;
4. criterio de aceite de isolamento descrito em QA;
5. plano de rollback especifico para regressao de tenancy.

## Criterio de aceite deste documento

Este documento esta aprovado quando:
1. declara explicitamente o estado atual como single-tenant;
2. evita falso positivo de multiempresa inexistente;
3. descreve isolamento real hoje e lacunas reais;
4. apresenta trilha evolutiva incremental sem quebrar contratos atuais.

## Conclusao tecnica

No estado atual, o `personal-site` tem isolamento suficiente para operacao institucional unica, com fronteiras claras de acesso e sessao.

Nao ha multiempresa implementada.

A estrategia correta neste momento e manter o modelo single-tenant oficial, documentado e auditavel, preparando evolucao para tenancy somente quando o requisito de negocio surgir e puder ser entregue com contrato, persistencia, autorizacao e testes alinhados.
