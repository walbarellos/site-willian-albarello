# 007 - Cache, Idempotencia, Consistencia e Retry

## Objetivo
Documentar o comportamento real do `personal-site` para cache HTTP, idempotencia de operacoes, consistencia de dados e estrategia de retry, refletindo somente o que esta implementado hoje.

## Escopo
Inclui:
1. politica atual de cache em API, admin e web;
2. estado atual de idempotencia em endpoints criticos;
3. modelo de consistencia vigente no backend;
4. comportamento de retry no cliente e no servidor;
5. direcao de evolucao sem quebrar contratos.

Nao inclui:
1. mecanismos nao implementados (ETag, cache distribuido, idempotency key ativa);
2. promessa de consistencia transacional distribuida;
3. estrategia de retry automatica inexistente no estado atual.

## Fontes soberanas usadas
1. `apps/api/src/server.ts`
2. `apps/api/src/routes/publications-admin.ts`
3. `apps/api/src/routes/publications-public.ts`
4. `apps/admin/src/lib/api/admin.ts`
5. `apps/web/src/lib/api/public.ts`
6. `infra/scripts/smoke.sh`
7. `infra/scripts/release-check.sh`

## Veredito tecnico do estado atual

### Estado oficial
O sistema opera hoje com **cache conservador (no-store)**, **processamento sincrono por request**, **consistencia imediata no escopo da requisicao** e **retry predominantemente manual/orquestrado pelo chamador**.

### Resumo objetivo
1. cache de API:
   - `/health`, `/ready` e `/v1/admin/*` recebem `cache-control: no-store`;
2. clientes `web` e `admin` usam `fetch` com `cache: 'no-store'`;
3. nao existe cabecalho `Idempotency-Key` nem deduplicacao de mutacao;
4. nao existe retry automatico com backoff nas bibliotecas de client;
5. rate limit existe (429), mas sem policy automatica de retry no client.

## 1) Politica de Cache

## 1.1 Cache na API

No `apps/api/src/server.ts`:
1. hook `onSend` aplica `no-store/no-cache` para:
   - `/health`
   - `/ready`
   - qualquer rota iniciando com `/v1/admin`
2. headers aplicados:
   - `cache-control: no-store, no-cache, must-revalidate, proxy-revalidate`
   - `pragma: no-cache`
   - `expires: 0`

Interpretacao:
- endpoints administrativos e de prontidao nao sao cacheados por desenho.

## 1.2 Cache no client admin

No `apps/admin/src/lib/api/admin.ts`:
1. toda requisicao usa `fetch(..., { cache: 'no-store' })`;
2. isso evita reuse indevido de resposta em contexto de sessao e CSRF.

## 1.3 Cache no client publico

No `apps/web/src/lib/api/public.ts`:
1. requisicoes publicas tambem usam `cache: 'no-store'`;
2. privilegia coerencia de leitura sobre ganho de latencia por cache HTTP.

## 1.4 Consequencia pratica

Beneficio:
- reduz risco de dado stale em fluxo editorial/admin.

Custo:
- perde oportunidade de cache de leitura para conteudo publico estavel.

## 2) Idempotencia

## 2.1 Estado atual

Nao ha implementacao de idempotencia por chave de requisicao.

Nao existe hoje:
1. `Idempotency-Key` em contrato;
2. persistencia de request fingerprint;
3. replay protegido de mutacoes.

## 2.2 Semantica por tipo de operacao

### Leitura (`GET`)
- naturalmente idempotente (sem efeito colateral), conforme contrato HTTP.

### Mutacao (`POST/PATCH`)
- `POST /v1/admin/publications` pode criar mais de um rascunho em retries duplicados;
- `PATCH /v1/admin/publications/:id` depende do payload e do estado atual;
- `PATCH /v1/admin/publications/:id/status` protege transicao invalida por regra de dominio, mas nao implementa deduplicacao por chave externa.

## 2.3 Risco residual

Risco principal:
- reenvio de mutacao por erro de rede pode repetir efeito.

Mitigacao parcial atual:
- validacoes de schema + regras de transicao editorial.

## 3) Consistencia

## 3.1 Modelo vigente

Consistencia atual e **sincrona no escopo da requisicao**.

Fluxo:
1. request entra;
2. validacao ocorre;
3. estado e alterado (ou leitura e feita);
4. resposta retorna no mesmo ciclo.

## 3.2 Persistencia no estado atual

No estado atual de scaffold:
1. publicacoes/admin usam adapter em memoria;
2. sessoes admin usam store em memoria.

Implicacoes:
1. consistencia e imediata dentro da instancia ativa;
2. nao ha garantia multi-instancia/distribuida neste estagio;
3. restart limpa estado em memoria.

## 3.3 Consistencia contratual

Mesmo com armazenamento simples, contratos HTTP estao padronizados:
1. envelopes de sucesso/erro consistentes;
2. `meta.traceId` presente para correlacao;
3. codigos de erro previsiveis.

## 4) Retry

## 4.1 Servidor

O servidor nao executa retry de mutacao de negocio.

Controles existentes:
1. rate limit global com resposta `429 RATE_LIMITED`;
2. detalhe de `retry after` no payload de erro de rate-limit.

## 4.2 Cliente admin

`apps/admin/src/lib/api/admin.ts`:
1. nao ha loop automatico de retry com backoff;
2. falha de rede gera `AdminApiError` (`NETWORK_ERROR`);
3. retry e decidido por camada superior (UI/acao do usuario).

## 4.3 Cliente web publico

`apps/web/src/lib/api/public.ts`:
1. nao ha retry automatico;
2. falha de rede gera `PublicApiError` (`NETWORK_ERROR`);
3. tela decide experiencia de nova tentativa.

## 4.4 Operacao

No plano operacional:
1. `smoke.sh` e `release-check.sh` sao gates de validacao, nao mecanismo de retry de runtime;
2. reexecucao e manual/orquestrada no processo de release.

## 5) Matriz de estado atual

| Dimensao | Estado atual | Nivel |
|---|---|---|
| Cache admin API | no-store/no-cache | Conservador |
| Cache public API client | no-store | Conservador |
| Idempotency key | Ausente | Lacuna conhecida |
| Consistencia intra-request | Presente | Adequado ao estagio |
| Consistencia distribuida | Nao implementada | Fora de escopo atual |
| Retry automatico client | Ausente | Lacuna controlada |
| Retry server de negocio | Ausente | Intencional no estagio |

## 6) Riscos e mitigacoes

### R-01 - Duplicacao de mutacao por reenvio
Mitigacao atual:
1. validacoes de payload;
2. regras de transicao editorial.

Melhoria futura:
1. idempotency key em operacoes de criacao/transicao.

### R-02 - Leitura publica sem cache
Mitigacao atual:
1. simplicidade e consistencia total de leitura.

Melhoria futura:
1. cache seletivo apenas para GET publico estavel.

### R-03 - Retry manual insuficiente em instabilidade
Mitigacao atual:
1. erro tipado e feedback de UI.

Melhoria futura:
1. retry controlado com backoff para falhas transientes de leitura.

## 7) Estrategia de evolucao incremental

## Fase 1 - Idempotencia minima

1. introduzir `Idempotency-Key` opcional em mutacoes criticas (`POST` de criacao);
2. armazenar chave+resultado por janela curta;
3. responder replay com mesmo envelope da primeira execucao valida.

## Fase 2 - Retry seguro de leitura

1. retry automatico somente para `GET` com erro transiente (`5xx`/network);
2. backoff exponencial curto e limite baixo de tentativas;
3. manter mutacoes sem retry automatico por padrao.

## Fase 3 - Cache seletivo publico

1. aplicar cache-control especifico para endpoints publicos estaveis;
2. manter admin e sessao em no-store;
3. monitorar latencia e acerto de cache antes de ampliar.

## 8) Criterio de aceite deste documento

Este documento esta aprovado quando:
1. descreve exatamente o estado atual sem superestimar maturidade;
2. deixa explicito que idempotencia dedicada ainda nao foi implementada;
3. explica por que cache esta conservador no estagio atual;
4. define trilha de evolucao sem romper contratos existentes.

## Conclusao tecnica

No estado atual do `personal-site`, a estrategia prioriza confiabilidade operacional e previsibilidade contratual sobre otimizacoes agressivas de cache/retry.

A arquitetura esta correta para o estagio atual, com lacunas conhecidas e controladas:
1. ausencia de idempotency key aplicada em mutacoes;
2. ausencia de retry automatico inteligente nos clients;
3. cache publico ainda conservador.

A evolucao recomendada e incremental, com foco em idempotencia minima para mutacoes criticas e retry/cache seletivos em leitura publica, mantendo admin e seguranca em modo restritivo.
