# 014 - Feature Flags, Remote Config e Ambientes

## Objetivo
Definir a politica tecnica de feature flags, remote config e segregacao de ambientes do `personal-site`, refletindo o estado real atual e a trilha de evolucao segura.

## Escopo
Inclui:
1. modelo atual de configuracao por ambiente;
2. estado atual de feature flags/remote config no codigo;
3. riscos de rollout sem controle granular;
4. estrategia incremental para introduzir flags com governanca.

Nao inclui:
1. implementacao imediata de plataforma externa de feature flag;
2. experimentacao A/B ativa (nao materializada no estado atual);
3. politicas de produto fora do escopo tecnico-operacional.

## Fontes soberanas usadas
1. `infra/env/ENVIRONMENT-MATRIX.md`
2. `.env.example`
3. `apps/api/src/lib/env.ts`
4. `infra/vercel/web.project.md`
5. `infra/vercel/admin.project.md`
6. `infra/render/api.service.yaml`
7. `QA/QA-02-matriz-de-gates-ci-e-deploy-readiness.md`

## Veredito tecnico do estado atual

### Estado oficial
1. o projeto possui segregacao de ambientes clara por variaveis (`development`, `staging`, `production`, `test`);
2. o projeto **nao possui sistema de feature flags runtime** materializado no codigo;
3. o projeto **nao possui remote config dinamico** implementado.

### Implicacao
O controle de rollout hoje e feito por:
1. branch/release process;
2. env por plataforma;
3. gates de CI e verificacao local.

Nao ha chave de toggle em runtime para ligar/desligar funcionalidade sem redeploy.

## 1) Ambientes - baseline atual

## 1.1 API

Em `apps/api/src/lib/env.ts`:
1. valida `NODE_ENV` (`development|test|production`);
2. exige variaveis criticas (`SESSION_SECRET`, `DATABASE_URL`, URLs, CORS);
3. aplica regras mais estritas fora de dev;
4. falha rapido em configuracao invalida.

## 1.2 Web/Admin

Em `infra/env/ENVIRONMENT-MATRIX.md` e runbooks Vercel:
1. web e admin usam resolucao de API por ordem (`NEXT_PUBLIC_API_URL` e fallbacks);
2. cada app possui URL canonica propria por ambiente;
3. configuracao e orientada por env, nao por remote config central.

## 1.3 Plataforma

1. Vercel (`web`, `admin`) e Render (`api`) com env segregada por ambiente;
2. segredos sensiveis marcados como `sync: false` no blueprint da API;
3. processo operacional de deploy/rollback documentado em `infra/`.

## 2) Feature Flags - estado atual

## 2.1 O que existe

No estado atual, **nao existem**:
1. modulo de flags em `apps/*/src/lib`;
2. schema de flags em `packages/contracts`;
3. envs `FEATURE_*` oficiais no contrato soberano;
4. avaliador de flag por usuario/tenant/percentual.

## 2.2 O que isso significa

1. mudancas funcionais seguem rollout por release completo;
2. rollback de feature depende de rollback de versao;
3. nao ha canary funcional por flag no runtime atual.

## 3) Remote Config - estado atual

## 3.1 O que existe

- configuracao por ambiente via `.env` e settings de plataforma.

## 3.2 O que nao existe

1. endpoint/config service para alteracao dinamica em runtime;
2. cache local de remote config com TTL;
3. trilha de auditoria de alteracao de toggle em producao.

## 3.3 Risco operacional atual

Sem flags/config dinamico:
1. mitigacao de regressao depende de rollback de deploy;
2. reducao de blast radius e menos granular;
3. experimentacao controlada fica limitada.

## 4) Politica de introducao de flags (futuro)

## 4.1 Principios obrigatorios

1. toda flag deve ter nome, owner, objetivo e data de expiracao;
2. toda flag deve nascer com default explicito por ambiente;
3. toda flag deve ter criterio de remocao (nao virar lixo permanente);
4. flags nao substituem validacao contratual nem gates de CI.

## 4.2 Tipos de flag permitidos

1. Release flag: controla exposicao gradual de funcionalidade pronta;
2. Ops flag: permite degradacao controlada de recurso nao critico;
3. Kill switch: desliga rapidamente fluxo problematico sem rollback completo.

## 4.3 Tipos de flag proibidos

1. flag sem owner;
2. flag sem expiracao;
3. flag para esconder bug estrutural permanente;
4. flag que muda contrato publico sem sincronizar OpenAPI/contracts.

## 5) Estrategia incremental recomendada

## Fase 1 - Feature flags por env (simples)

1. introduzir modulo local de flags no backend (`FEATURE_*`); 
2. validar flags no loader de env com schema estrito;
3. manter avaliacao deterministica por ambiente (sem remote config externo).

## Fase 2 - Contrato de flags

1. definir schema versionado de flags em `packages/contracts`;
2. documentar flags em Waterfall/High-Tech + runbooks;
3. cobrir com teste de integridade de config.

## Fase 3 - Remote config controlado

1. introduzir fonte externa de config somente quando houver ganho comprovado;
2. manter fallback seguro local;
3. registrar auditoria de alteracoes e trilha de incidente.

## Fase 4 - Rollout progressivo

1. habilitar rollout por percentual/segmento quando telemetria permitir;
2. integrar com error budget e criterio de bloqueio de release.

## 6) Integracao com processo de release

Mesmo sem flags hoje, qualquer mudanca de config/ambiente deve seguir:
1. `pnpm test:ci`
2. `pnpm verify:hardening`
3. `deploy-readiness` verde
4. checklist de evidencias de release preenchido

Quando flags forem introduzidas:
1. mudar valor de flag deve gerar evidencia auditavel;
2. alteracao critica deve exigir validacao funcional minima.

## 7) Anti-padroes de ambiente

1. usar defaults de development em production;
2. compartilhar segredo entre ambientes sem rotacao;
3. alterar env de producao sem registro de evidencias;
4. criar fallback silencioso para mascarar configuracao invalida.

## 8) Criterio de aceite deste documento

Este documento esta aprovado quando:
1. representa fielmente que hoje nao ha feature flags/remote config runtime;
2. descreve corretamente a maturidade de ambientes ja implementada;
3. estabelece politica clara para adocao futura sem gerar complexidade prematura;
4. preserva coerencia com a matriz de env e runbooks de deploy.

## Conclusao tecnica

No estado atual, o `personal-site` ja tem maturidade suficiente de ambientes para operacao disciplinada, mas ainda sem controle granular de rollout via feature flags/remote config.

A decisao correta deste ciclo e manter simplicidade operacional e preparar adocao incremental de flags somente quando houver necessidade concreta de reduzir blast radius sem aumentar risco sistêmico.
