# 017 - Observabilidade de Negocio e Eventos de Produto

## Objetivo
Definir o baseline soberano de observabilidade de negocio do `personal-site`, conectando:
1. eventos de produto relevantes para governanca editorial;
2. metricas de negocio viaveis no estagio atual;
3. rastreabilidade operacional por `traceId`;
4. protocolo incremental de evolucao sem falso positivo de maturidade.

Este documento descreve o estado real do repositorio e os proximos passos tecnicos para elevar observabilidade de negocio.

## Escopo
Inclui:
1. eventos-chave do ciclo editorial e da experiencia publica;
2. sinais de negocio que ja podem ser derivados com a estrutura atual;
3. lacunas entre observabilidade tecnica P0 e observabilidade de produto madura;
4. plano incremental para instrumentacao e governanca.

Nao inclui:
1. implantacao de ferramenta externa de analytics nao materializada no codigo;
2. promessas de dashboard executivo pronto sem pipeline de evento persistente;
3. definicao juridica/comercial fora do escopo tecnico.

## Fontes soberanas auditadas
1. `Waterfall/DOC-21-observabilidade-logs-e-incidentes.md`
2. `Waterfall/DOC-16-estrategia-editorial-e-governanca.md`
3. `docs/01-Waterfall/04-High_Tech/009_Monitoramento_Metrics_Tracing_e_Alertas.md`
4. `QA/QA-02-matriz-de-gates-ci-e-deploy-readiness.md`
5. `apps/api/src/server.ts`
6. `apps/api/src/routes/publications-admin.ts`
7. `apps/api/src/routes/publications-public.ts`
8. `apps/admin/src/lib/api/admin.ts`
9. `apps/web/src/lib/api/public.ts`

## Veredito tecnico do estado atual
No estagio atual, o projeto possui observabilidade tecnica P0 consistente (health/ready, logs estruturados, `traceId`, taxonomia de erro), mas ainda nao materializou uma trilha persistente e dedicada de eventos de negocio.

Em termos praticos:
1. ja e possivel correlacionar falha tecnica por `traceId`;
2. ja e possivel inferir parte dos eventos de produto a partir de rotas/status;
3. ainda nao existe camada formal de event store ou telemetria de produto separada dos logs de API.

## 1) Modelo de observabilidade de negocio

## 1.1 Entidades centrais observaveis
1. sessao administrativa;
2. publicacao editorial;
3. fluxo publico de descoberta e leitura;
4. operacao de release e readiness.

## 1.2 Perguntas de negocio que a observabilidade deve responder
1. quantas publicacoes foram promovidas de `draft` para `published` por ciclo?
2. quantas tentativas de transicao editorial falharam por regra (`INVALID_STATE_TRANSITION`)?
3. qual o volume de acesso publico por rota de listagem e detalhe?
4. qual a taxa de falha funcional por fluxo critico (login, listagem, leitura)?
5. qual o tempo medio de recuperacao operacional entre incidente e estabilizacao?

## 2) Taxonomia de eventos de produto (estado-alvo incremental)

## 2.1 Familia AUTH (acesso administrativo)
1. `auth.login_attempted`
2. `auth.login_succeeded`
3. `auth.login_failed`
4. `auth.session_checked`
5. `auth.logout_executed`

Atributos minimos:
1. `traceId`
2. `actorRole`
3. `status` (success/failure)
4. `reasonCode` (quando falha)
5. `timestamp`

## 2.2 Familia EDITORIAL (governanca de publicacoes)
1. `editorial.publication_list_viewed`
2. `editorial.publication_opened`
3. `editorial.publication_saved`
4. `editorial.publication_status_transition_requested`
5. `editorial.publication_status_transition_succeeded`
6. `editorial.publication_status_transition_failed`

Atributos minimos:
1. `traceId`
2. `publicationId`
3. `previousStatus`
4. `nextStatus`
5. `actorRole`
6. `resultCode`
7. `timestamp`

## 2.3 Familia PUBLIC (camada publica)
1. `public.home_viewed`
2. `public.publications_list_viewed`
3. `public.publications_search_applied`
4. `public.publication_detail_viewed`
5. `public.publication_not_found`

Atributos minimos:
1. `traceId` (quando houver request correlacionado)
2. `slug` (para detalhe)
3. `queryFingerprint` (busca/filtro, sem dado sensivel)
4. `resultCount` (quando aplicavel)
5. `timestamp`

## 2.4 Familia RELEASE/QUALITY
1. `quality.verify_hardening_passed`
2. `quality.test_ci_passed`
3. `quality.smoke_passed`
4. `quality.release_blocked`
5. `quality.release_approved`

Atributos minimos:
1. `versionTag`
2. `gateId`
3. `result`
4. `timestamp`
5. `evidenceRef`

## 3) O que ja existe hoje (sem inventar)

## 3.1 Sinais tecnicos que ja sustentam observabilidade de negocio
1. `traceId` ponta a ponta entre API e clients;
2. logs por request com rota/status/latencia;
3. erros contratuais normalizados (`UNAUTHENTICATED`, `FORBIDDEN`, `INVALID_STATE_TRANSITION`, etc.);
4. gates de qualidade e readiness na esteira de CI/deploy.

## 3.2 O que ainda nao existe
1. schema formal de evento de negocio versionado no repositorio;
2. emissao explicita de eventos de produto no backend/frontend;
3. persistencia historica orientada a analise de tendencia;
4. dashboard consolidado de indicadores editoriais/publicos.

## 4) Indicadores de negocio recomendados para o estagio atual

## 4.1 Indicadores editoriais
1. taxa de promocao editorial por status (`draft->review->ready_to_publish->published`);
2. taxa de erro de transicao editorial;
3. tempo medio entre criacao e publicacao;
4. volume de publicacoes ativas por periodo.

## 4.2 Indicadores de experiencia publica
1. visualizacoes de listagem publica;
2. visualizacoes de detalhe por slug;
3. taxa de `notFound` em detalhe;
4. eficiencia de descoberta (resultado encontrado por busca/filtro).

## 4.3 Indicadores de operacao
1. disponibilidade de `/health` e `/ready`;
2. taxa de erro HTTP por classe;
3. latencia media das rotas criticas;
4. estabilidade dos gates de release por ciclo.

## 5) Estrutura minima de payload de evento
Quando a instrumentacao de eventos for materializada, o payload minimo deve seguir:
1. `eventName`
2. `eventVersion`
3. `occurredAt`
4. `traceId` (quando aplicavel)
5. `context` (ambiente, app, rota)
6. `actor` (anon/public/admin/editor quando aplicavel)
7. `entity` (publication/session/release)
8. `result` (success/failure)
9. `reasonCode` (quando failure)

Regra de privacidade:
- nao incluir dado sensivel em texto livre;
- usar identificadores tecnicos e classificacao de resultado.

## 6) Matriz de maturidade atual

| Pilar | Estado atual | Nivel |
|---|---|---|
| Observabilidade tecnica basica | Implementada | Bom P0 |
| Correlacao por traceId | Implementada | Bom P0 |
| Taxonomia de erro contratual | Implementada | Bom P0 |
| Eventos de negocio explicitamente emitidos | Nao implementado | Gap |
| Indicadores de produto automatizados | Parcial (inferidos) | Basico |
| Dashboard de negocio consolidado | Nao implementado | Gap |

## 7) Riscos residuais aceitos neste ciclo
1. decisoes de produto dependem de leitura manual de logs e evidencias de ciclo;
2. dificuldade de comparacao historica fina sem trilha persistente de eventos;
3. risco de confundir incidente tecnico com problema de negocio por falta de camada dedicada de evento.

## 8) Plano incremental de evolucao

## Fase 1 - Padronizacao sem ruptura
1. publicar schema versionado de evento (arquivo soberano em docs/infra);
2. mapear eventos obrigatorios por rota critica (auth/editorial/public);
3. manter compatibilidade com `traceId` ja existente.

## Fase 2 - Emissao de eventos no backend
1. emitir eventos de AUTH e EDITORIAL nos pontos de mutacao critica;
2. registrar eventos com `resultCode` e `traceId`;
3. validar que emissores nao vazam segredo/dado sensivel.

## Fase 3 - Emissao de eventos no web/admin
1. instrumentar eventos de descoberta publica e fluxo de login/listagem;
2. manter separacao entre evento tecnico e evento de negocio;
3. adicionar testes de contrato de payload minimo.

## Fase 4 - Consolidacao de indicadores
1. consolidar relatorio por ciclo com tendencias basicas;
2. definir thresholds de alerta de negocio (ex.: alta taxa de `publication_not_found`);
3. integrar trilha de evento aos gates de release quando maduro.

## 9) Criterios de aceite deste documento
Este documento e aceito quando:
1. reconhece corretamente o baseline P0 ja existente;
2. separa inferencia de negocio atual de observabilidade de evento madura;
3. define taxonomia e payload minimo objetivos;
4. orienta evolucao incremental sem reabrir arquitetura estabilizada.

## Conclusao tecnica
O `personal-site` ja possui base tecnica solida para observabilidade operacional, mas ainda nao possui camada soberana de eventos de negocio persistidos.

A linha correta e evoluir com disciplina: primeiro padronizar taxonomia e payload, depois instrumentar emissores criticos e, por fim, consolidar indicadores de produto com rastreabilidade confiavel.
