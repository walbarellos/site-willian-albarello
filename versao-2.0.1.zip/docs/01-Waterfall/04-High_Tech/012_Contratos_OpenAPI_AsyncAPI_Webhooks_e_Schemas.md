# 012 - Contratos OpenAPI, AsyncAPI, Webhooks e Schemas

## Objetivo
Consolidar o estado soberano dos contratos tecnicos do `personal-site`, cobrindo:

1. contratos HTTP em OpenAPI;
2. schemas compartilhados;
3. relacao entre OpenAPI e `packages/contracts`;
4. posicao atual de AsyncAPI e Webhooks;
5. gates de governanca para evitar regressao contratual.

## Escopo
Inclui:
1. contrato publico (`API-06`) e administrativo (`API-07`);
2. componentes compartilhados (`schemas.common`, `responses.common`);
3. automacao de validacao contratual em CI;
4. estrategia incremental para async/webhook no futuro.

Nao inclui:
1. implementacao imediata de AsyncAPI;
2. endpoints de webhook inexistentes no estado atual;
3. versionamento semantico externo formal de API (fora do processo atual de ciclo).

## Fontes soberanas usadas
1. `APIs/API-06-openapi-public.yaml`
2. `APIs/API-07-openapi-admin.yaml`
3. `APIs/openapi/components/schemas.common.yaml`
4. `APIs/openapi/components/responses.common.yaml`
5. `packages/contracts/src/index.ts`
6. `packages/contracts/src/session.ts`
7. `packages/contracts/src/publications.ts`
8. `.github/workflows/api-contract.yml`
9. `.github/workflows/api-docs.yml`
10. `.github/workflows/api-breaking-change.yml`

## Veredito tecnico do estado atual

### Estado oficial
O projeto possui contratos HTTP soberanos e materializados com:
1. duas specs OpenAPI completas (publica e admin);
2. componentes compartilhados para schemas/responses;
3. pacote `contracts` alinhado como contrato de tipos do monorepo;
4. gates de CI para presenca, consistencia e breaking removals.

### Limite atual
1. **nao existe AsyncAPI** materializada no repositorio;
2. **nao existem webhooks** como superficie oficial de contrato no estado atual.

## 1) OpenAPI soberano

## 1.1 Contrato publico

Arquivo:
- `APIs/API-06-openapi-public.yaml`

Cobertura:
1. `/health`
2. `/ready`
3. `/v1/public/publications`
4. `/v1/public/publications/:slug`

Caracteristicas:
1. `openapi: 3.1.0`;
2. envelope padrao com `meta.traceId`;
3. paginação e filtros de listagem;
4. exemplos operacionais de sucesso e erro.

## 1.2 Contrato administrativo

Arquivo:
- `APIs/API-07-openapi-admin.yaml`

Cobertura:
1. auth (`login`, `session`, `logout`);
2. dashboard;
3. CRUD/operacao editorial administrativa de publicacoes.

Caracteristicas:
1. `openapi: 3.1.0`;
2. modelagem de sessao admin e fluxo com cookie;
3. codigos de erro contratuais (`401`, `403`, `422`, `429`, etc.);
4. exemplos para casos principais de operacao.

## 2) Componentes compartilhados

## 2.1 Schemas comuns

Arquivo:
- `APIs/openapi/components/schemas.common.yaml`

Estado atual:
1. contem `TraceMeta`, `ApiMeta`, `PaginationMeta`;
2. define `ApiError*`;
3. define base de sessao admin (`AdminSessionUser`, `AdminSessionPayload`, etc.);
4. define refs comuns (`CategoryRef`, `TagRef`, `SeoFields`).

## 2.2 Responses comuns

Arquivo:
- `APIs/openapi/components/responses.common.yaml`

Estado atual:
1. `SessionExpiredResponse`;
2. `ForbiddenResponse` (incluindo CSRF invalid token);
3. `RateLimitedResponse`;
4. `InternalServerErrorResponse`.

Valor:
- reduz duplicacao e melhora consistencia entre `API-06` e `API-07`.

## 3) Alinhamento com `packages/contracts`

## 3.1 Papel do pacote

`packages/contracts` e a camada tipada consumida por:
1. `apps/api`
2. `apps/admin`
3. `apps/web`

## 3.2 Estado atual de alinhamento

1. `session.ts` concentra tipos de sessao/erro/meta;
2. `publications.ts` concentra tipos de publicacoes/paginacao;
3. `routes.ts` concentra paths e helpers de rota;
4. `index.ts` atua como barrel com compat layer para nao quebrar imports legados.

## 3.3 Regra de coerencia

Qualquer mudanca de contrato deve manter sincronia minima entre:
1. implementacao de rota em `apps/api`;
2. OpenAPI correspondente em `APIs/`;
3. tipos em `packages/contracts`;
4. consumidores em `apps/web` e `apps/admin`.

## 4) Governanca contratual em CI

## 4.1 `api-contract.yml`

Garante:
1. presenca dos arquivos OpenAPI/components;
2. chaves raiz minimas (`openapi`, `schemas`, `responses`);
3. build e typecheck do pacote `contracts`.

## 4.2 `api-docs.yml`

Garante:
1. presenca e chaves centrais de docs OpenAPI (`openapi/info/paths`);
2. referencias para components compartilhados;
3. mencoes de contrato no `README.md`.

## 4.3 `api-breaking-change.yml`

No contexto de PR:
1. compara com branch base;
2. bloqueia remocao de `operationId`;
3. bloqueia remocao de `path+method`;
4. bloqueia remocao de `schemas` e `responses` dos componentes.

Resultado:
- previne regressao silenciosa de superficie contratual.

## 5) AsyncAPI e Webhooks (estado atual)

## 5.1 AsyncAPI

Estado:
- nao ha arquivo AsyncAPI no repositorio;
- nao ha canal/event schema assinado como contrato oficial.

Conclusao:
- arquitetura assincrona ainda nao entrou no nivel de contrato formal.

## 5.2 Webhooks

Estado:
- nao ha endpoints de webhook publicados no OpenAPI atual;
- nao ha assinatura/verificacao de webhook no backend como superficie contratual.

Conclusao:
- webhooks estao fora do escopo materializado desta versao.

## 6) Schema governance playbook

## 6.1 Regras de mudanca

1. nao remover campos/paths sem avaliacao de breaking;
2. preferir adicao backward-compatible;
3. documentar exemplos de erro e sucesso para novas operacoes;
4. manter `traceId` no envelope como regra fixa.

## 6.2 Processo recomendado por mudanca de contrato

1. ajustar tipo em `packages/contracts`;
2. ajustar rota/validador em `apps/api`;
3. ajustar OpenAPI (`API-06` ou `API-07` + components quando necessario);
4. ajustar consumers web/admin;
5. validar gates locais e CI;
6. registrar evidencia no relatorio da versao.

## 6.3 Anti-padroes proibidos

1. alterar contrato somente no código sem atualizar OpenAPI;
2. atualizar OpenAPI sem refletir nos tipos compartilhados;
3. remover schema/resposta comum sem migracao;
4. mudar shape de erro quebrando parser dos clients.

## 7) Trilha de evolucao (async/webhook)

## Fase 1 - Preparacao de dominio
1. mapear eventos de dominio candidatos (auth/publication/status);
2. padronizar envelope de evento interno.

## Fase 2 - Contrato assincrono inicial
1. introduzir especificacao AsyncAPI para canais priorizados;
2. versionar schemas de evento com compatibilidade.

## Fase 3 - Webhooks externos
1. definir endpoints de entrega;
2. definir assinatura/idempotencia/replay;
3. documentar em contrato e integrar gates.

## Fase 4 - Protecao de breaking assincrono
1. criar gate equivalente ao `api-breaking-change` para AsyncAPI/webhook schemas.

## 8) Criterio de aceite deste documento

Este documento esta aprovado quando:
1. representa fielmente OpenAPI/components existentes;
2. deixa explicito que AsyncAPI/Webhooks ainda nao estao materializados;
3. descreve governanca real de contrato com gates CI;
4. define trilha de evolucao sem falso positivo.

## Conclusao tecnica

O `personal-site` ja possui uma base contratual HTTP solida e auditavel:
1. OpenAPI publico/admin preenchidos;
2. componentes compartilhados ativos;
3. `packages/contracts` como espelho tipado do monorepo;
4. protecoes de CI contra regressao contratual.

Neste estagio, AsyncAPI e Webhooks permanecem backlog estruturado. A decisao correta e manter o contrato HTTP robusto, e introduzir contrato assincrono apenas quando houver necessidade operacional comprovada e implementacao real correspondente.
