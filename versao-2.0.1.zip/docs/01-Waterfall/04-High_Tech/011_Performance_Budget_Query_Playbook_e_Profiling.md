# 011 - Performance Budget, Query Playbook e Profiling

## Objetivo
Estabelecer um baseline pragmativo de performance para o `personal-site`, com:

1. budgets operacionais por superficie;
2. playbook de query para API publica e administrativa;
3. fluxo de profiling reproduzivel no estado atual do projeto.

## Escopo
Inclui:
1. latencia e carga por endpoints/paginas criticas;
2. limites de pagina e filtros ja implementados;
3. estrategia de diagnostico de degradacao;
4. backlog de evolucao de performance.

Nao inclui:
1. benchmark sintético enterprise completo;
2. tuning de banco em producao (fluxo principal ainda em adapters in-memory);
3. promessa de resultados sem medicao de rodada.

## Fontes soberanas usadas
1. `apps/api/src/server.ts`
2. `apps/api/src/routes/publications-public.ts`
3. `apps/api/src/routes/publications-admin.ts`
4. `apps/web/src/lib/api/public.ts`
5. `apps/admin/src/lib/api/admin.ts`
6. `apps/web/app/page.tsx`
7. `apps/web/app/publicacoes/page.tsx`
8. `apps/web/app/publicacoes/[slug]/page.tsx`
9. `apps/admin/app/painel/publicacoes/page.tsx`
10. `apps/admin/app/painel/publicacoes/[id]/editar/page.tsx`
11. `infra/scripts/smoke.sh`
12. `docs/01-Waterfall/04-High_Tech/009_Monitoramento_Metrics_Tracing_e_Alertas.md`

## Veredito tecnico do estado atual

### Estado oficial
O projeto ja possui controles de performance P0 relevantes:
1. paginação com limites maximos (`pageSize <= 50`);
2. cache conservador para admin e API clients (`no-store` onde sensivel);
3. cache seletivo na home publica (`force-cache` + `revalidate=300`);
4. metrica de latencia por request no backend (`responseTimeMs` em log).

### Limite atual
1. nao ha coletor central de p95/p99;
2. profiling de query de banco ainda nao e foco principal porque fluxo ativo usa adapters in-memory.

## 1) Performance Budget - baseline do ciclo

## 1.1 API - budget por rota critica

### Classe A (infra)
- `GET /health`
- `GET /ready`

Budget alvo:
1. disponibilidade: >= 99.5% na janela
2. latencia alvo p95 operacional: <= 200ms
3. payload: pequeno e estavel

### Classe B (publico)
- `GET /v1/public/publications`
- `GET /v1/public/publications/:slug`

Budget alvo:
1. p95 alvo inicial: <= 400ms
2. paginação obrigatoria:
   - default `pageSize=12`
   - max `pageSize=50`
3. resposta consistente com envelope e `traceId`

### Classe C (admin)
- auth/session/dashboard/publicacoes

Budget alvo:
1. p95 alvo inicial: <= 500ms em leitura
2. mutacoes (`POST/PATCH`) com resposta previsivel <= 800ms em estagio atual
3. sem cache de resposta em superficie admin

Observacao:
- valores sao metas internas de ciclo, para controle de regressao; nao sao SLA externo.

## 1.2 Web publico - budget de render e dados

### Home (`/`)
Estado atual:
1. usa `listPublications({ page:1, pageSize:3 })`;
2. fetch com `force-cache` + `next.revalidate=300`.

Budget:
1. manter payload de destaque enxuto (3 itens);
2. evitar ampliar bloco de spotlight sem necessidade editorial;
3. manter revalidate coerente com estrategia de publicacao.

### Listagem (`/publicacoes`)
Estado atual:
1. query normalizada (`page`, `pageSize`, `q`, `category`, `tag`);
2. redireciona pagina invalida para ultimo page valido.

Budget:
1. `pageSize` max 50 (ja aplicado);
2. evitar filtros livres sem normalizacao;
3. preservar shell com loading/error sem render duplicado.

### Detalhe (`/publicacoes/[slug]`)
Estado atual:
1. revalidate `300`;
2. fallback `notFound` para 404/422;
3. metadata dinamica com SEO/canonical.

Budget:
1. nao adicionar chamadas API redundantes por request;
2. manter caminho de erro leve (`PublicationDetailErrorState`);
3. preservar custo de metadata previsivel.

## 1.3 Admin - budget de operacao editorial

### Listagem admin
1. `pageSize` fixo de trabalho: 12;
2. busca/filtro normalizados;
3. `dynamic='force-dynamic'` e `revalidate=0` por natureza do painel.

Budget:
1. manter paginação pequena para operacao responsiva;
2. evitar cargas massivas em uma unica tela;
3. manter erro de sessao/forbidden com redirect rapido.

### Edicao admin
1. mutacoes de conteudo, SEO e status em server actions;
2. revalidate de rotas publicas afetadas apos salvar.

Budget:
1. manter mutacoes atomicas por acao (conteudo, SEO, status separados);
2. evitar cadeia de revalidacao excessiva sem necessidade;
3. priorizar feedback imediato ao operador.

## 2) Query Playbook (estado atual)

## 2.1 Regras de ouro

1. toda listagem deve ter paginação e limite maximo;
2. todo filtro textual deve ser normalizado (`trim`) antes de consulta;
3. rejeitar parametros invalidos com erro contratual (`422`) em vez de processar lixo;
4. manter shape de resposta paginada estavel (`page`, `pageSize`, `totalItems`, `totalPages`).

## 2.2 API publica

Implementado hoje:
1. `page >= 1`
2. `pageSize <= 50`
3. filtros opcionais `category`, `tag`, `q`
4. slug validado por regex URL-safe

Playbook:
1. manter `q` curto e sanitizado;
2. nao expandir payload de listagem com campos pesados de detalhe;
3. quando precisar novo filtro, introduzir com default seguro e cobertura de teste.

## 2.3 API admin

Implementado hoje:
1. `page >= 1`
2. `pageSize <= 50`
3. filtro por `status` + `q`
4. validacoes de payload com `zod.strict()`.

Playbook:
1. manter queries administrativas orientadas a pagina atual;
2. evitar endpoint de listagem sem paginação;
3. validar transicao editorial antes de mutar para reduzir retrabalho de processamento.

## 2.4 Query anti-patterns proibidos

1. aumentar `pageSize` acima de 50 sem justificativa de negocio + medicao;
2. inserir filtros sem validacao/schema;
3. retornar detalhe completo em endpoint de listagem quando nao necessario;
4. bypass de normalizacao de query no frontend.

## 3) Profiling Playbook (operacional)

## 3.1 Sinais primarios

1. `responseTimeMs` nos logs da API;
2. status code por rota;
3. resultado de smoke e gates.

## 3.2 Fluxo de profiling por incidente

1. reproduzir rota lenta com `traceId` capturado;
2. localizar log correspondente e confirmar latencia;
3. classificar: gargalo de validacao, transformacao, chamada externa, render ou rede;
4. aplicar correcao minima no ponto de maior custo;
5. rerodar verificacoes:
   - smoke
   - `pnpm test:ci`
   - `pnpm verify:hardening`
6. registrar antes/depois no relatorio da versao.

## 3.3 Profiling local minimo por superficie

### API
1. executar ambiente local;
2. disparar requests repetidos para endpoints criticos;
3. observar `responseTimeMs` e status por rota.

### Web/Admin
1. navegar fluxos criticos (home, listagem, detalhe, login, listagem admin, edicao);
2. observar tempo de resposta percebido + erros de rede/API;
3. confirmar ausencia de chamadas redundantes obvias.

## 3.4 Limites atuais de profiling

1. sem flamegraphs padronizados no repositorio;
2. sem coleta automatica de percentis em serie temporal;
3. analise ainda centrada em log + reproducoes dirigidas.

## 4) Gates de performance do ciclo

Um ciclo deve ser bloqueado por performance quando ocorrer ao menos um:
1. `/health` ou `/ready` instaveis em smoke;
2. regressao clara de latencia em rota critica observada em logs;
3. quebra de paginação/limite (`pageSize`) em contratos;
4. erro de runtime por carga invalida de query.

## 5) Evolucao incremental recomendada

## Fase 1 - Baseline numerico recorrente
1. registrar latencia observada por rota critica em cada release;
2. versionar tabela comparativa simples (antes/depois).

## Fase 2 - Instrumentacao de percentis
1. consolidar p50/p95/p99 por rota;
2. ligar thresholds de alerta a degradacao repetida.

## Fase 3 - Profiling aprofundado
1. introduzir perfil de CPU/memoria em cenarios selecionados;
2. integrar diagnostico de query quando persistencia real estiver no fluxo principal.

## 6) Criterio de aceite deste documento

Este documento esta aprovado quando:
1. define budgets coerentes com o estado atual do sistema;
2. descreve playbook de query aderente aos limites implementados;
3. fornece fluxo de profiling executavel pela equipe no ciclo atual;
4. evita promessas de performance nao mensuraveis hoje.

## Conclusao tecnica

O `personal-site` ja possui base suficiente para governar performance no estagio atual: limites de query, logs de latencia por rota e disciplina de cache por contexto.

O proximo ganho de maturidade vem de consolidar medicao recorrente (percentis e historico), sem romper a simplicidade operacional que hoje sustenta a estabilidade do projeto.
