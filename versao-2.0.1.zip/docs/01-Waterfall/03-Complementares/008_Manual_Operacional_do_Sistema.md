# 008 - Manual Operacional do Sistema

## Objetivo
Consolidar rotina diaria de operacao do `personal-site` para execucao previsivel e auditavel.

## Topologia operacional
1. Web: `http://localhost:3000`
2. Admin: `http://localhost:3001`
3. API: `http://localhost:3002`

## Rotina padrao (inicio de dia)
1. validar `.env` local;
2. executar `pnpm install --frozen-lockfile` (se houve alteracao de deps);
3. subir ambiente com `bash infra/scripts/dev-up.sh`;
4. executar `bash infra/scripts/smoke.sh`.

## Rotina de validacao antes de fechamento de item
1. executar testes impactados;
2. quando aplicavel, executar `pnpm test:ci`;
3. confirmar ausencia de regressao funcional visivel nas rotas centrais.

## Rotina de fechamento de ciclo
1. `pnpm test:ci`
2. `pnpm verify:hardening`
3. `bash infra/scripts/release-check.sh`
4. gerar `RELATORIO-FINAL-V*.md`
5. gerar `versao-*.zip`

## Procedimentos de contingencia

### API indisponivel
1. testar `/health` e `/ready`;
2. revisar variaveis de ambiente;
3. revisar logs de inicializacao;
4. decidir bloqueio de release.

### Web/Admin com 500 local
1. verificar processos em `3000/3001`;
2. reiniciar servidores dev;
3. repetir smoke;
4. registrar incidente no relatorio.

### Pipeline CI falhou
1. identificar workflow e etapa;
2. classificar categoria da falha;
3. aplicar `infra/ci/PIPELINE-FAILURE-PLAYBOOK.md`;
4. rerodar checks locais equivalentes.

## Checklist operacional diario
- [ ] Ambiente subiu sem erro
- [ ] Smoke verde
- [ ] Admin login funcional
- [ ] Rotas publicas centrais funcionais
- [ ] Nenhum gate bloqueante aberto

## Evidencias minimas por rodada
1. data/hora;
2. comandos executados;
3. status obtido;
4. anomalias e correcao aplicada.

## Referencias cruzadas
1. `infra/ops/OPERACAO-E-ROLLBACK.md`
2. `infra/ci/CI-BOOTSTRAP-CHECKLIST.md`
3. `infra/ci/RELEASE-EVIDENCE-CHECKLIST.md`
4. `QA/QA-01-checklist-de-homologacao-funcional.md`

## Criterio de aceite
Documento aprovado quando:
1. orienta operacao diaria sem ambiguidade;
2. reduz tempo de resposta a falhas comuns;
3. permanece aderente aos scripts reais do repositorio.
