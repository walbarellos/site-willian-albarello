# 005 - FAQ Produto, Negocio, Operacao e Suporte

## Objetivo
Responder duvidas recorrentes para reduzir retrabalho operacional e desalinhamento de expectativa.

## Produto

### O que e o `personal-site`?
Monorepo com tres apps (`api`, `web`, `admin`) e dois pacotes compartilhados (`contracts`, `ui`) orientado por ciclos Caracol.

### Qual problema ele resolve?
Organizar presenca institucional publica com publicacao editorial consistente e operacao rastreavel.

### Quais rotas publicas sao essenciais?
1. `/`
2. `/publicacoes`
3. `/publicacoes/[slug]`

### Quais rotas admin sao essenciais?
1. `/painel/login`
2. `/painel/publicacoes`
3. `/painel/publicacoes/[id]/editar`

## Operacao tecnica

### Como subir ambiente completo?
`bash infra/scripts/dev-up.sh`

### Como validar disponibilidade minima?
`bash infra/scripts/smoke.sh`

### Como validar release local?
`bash infra/scripts/release-check.sh`

### Quais checks bloqueiam release?
1. `pnpm test:ci`
2. `pnpm verify:hardening`
3. workflows de contrato/docs/breaking-change/readiness

## Suporte

### O que fazer se API cair?
Verificar `/health` e `/ready`, revisar env/log e seguir `infra/ops/OPERACAO-E-ROLLBACK.md`.

### O que fazer se web/admin retornarem 500 local?
Reiniciar runtime dev e repetir `smoke`; validar se `clean` removeu cache/estado de servidor em execucao.

### O que fazer se pipeline quebrar?
Aplicar `infra/ci/PIPELINE-FAILURE-PLAYBOOK.md` por categoria de falha.

## Negocio e continuidade

### Como evitar falso positivo de "concluido"?
Sempre fechar ciclo com relatorio + zip + evidencias de comando.

### Onde fica a fonte de prioridade do ciclo?
No arquivo `Atualizacao de codigo` vigente.

### O OpenClaw substitui o metodo?
Nao. Ele apoia rastreio; o metodo de execucao continua sendo o Caracol sequencial.

## Auditoria

### O que precisa existir para auditoria objetiva?
1. relatorio final de versao;
2. zip de versao;
3. evidencias de checks;
4. documentos soberanos atualizados.

### O que nao pode ser removido como "lixo"?
Artefatos de ciclo ativo vinculados a fechamento/auditoria.

## Criterio de aceite
Documento aprovado quando:
1. responde as duvidas reais do projeto;
2. aponta para fontes internas corretas;
3. reduz ruido entre execucao e auditoria.
