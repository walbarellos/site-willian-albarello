# 002 - Analise de Concorrentes e Reposicionamento

## Objetivo
Posicionar o `personal-site` frente a referencias de mercado sem cair em dois erros comuns:
1. portfolio estetico sem governanca;
2. blog volumoso sem criterio editorial.

## Fontes soberanas usadas
1. `README.md`
2. `Waterfall/DOC-16-estrategia-editorial-e-governanca.md`
3. `UI_UX/UIUX-11-contratos-de-tela-por-rota.md`
4. `apps/web/app/page.tsx`
5. `apps/web/app/publicacoes/page.tsx`
6. `apps/admin/app/painel/publicacoes/page.tsx`

## Mapa de concorrencia por classe

### Classe 1 - Portfolio pessoal visual-first
Forca:
- impacto rapido de primeira impressao.

Fraqueza:
- baixo lastro operacional;
- pouca profundidade editorial;
- alta dependência de atualizacao manual sem processo.

### Classe 2 - Blog pessoal classico
Forca:
- autenticidade de voz.

Fraqueza:
- inconsistencia de formato;
- dificuldade de evoluir sem refatoracao de estrutura.

### Classe 3 - Hub institucional B2B
Forca:
- consistencia e previsibilidade.

Fraqueza:
- linguagem fria e excesso de jargao;
- UX burocratica.

## Tese de reposicionamento do projeto
"Presenca institucional com disciplina publica: conteudo com criterio, sistema com rastreabilidade e UX com legibilidade."

## Diferenciais competitivos reais
1. separacao clara entre publico e operacao (web/admin);
2. contrato tecnico explicito (OpenAPI + contracts);
3. gates de qualidade objetivos (`test:ci`, `verify:hardening`, `smoke`);
4. governanca documental por ciclo;
5. historico de release com evidencias.

## O que o projeto faz melhor que o padrao de mercado
1. combina narrativa institucional e operacao tecnica auditavel;
2. evita home inflada e prioriza leitura;
3. trata publicacao como fluxo, nao como upload isolado;
4. reduz risco de divergencia entre codigo e docs.

## O que ainda pode melhorar
1. consolidar bloco `04-High_Tech` para maturidade arquitetural de longo prazo;
2. fortalecer indicadores editoriais com cadencia formal;
3. ampliar mapa de prova social sem ruido visual.

## Regras de reposicionamento por superficie

### Home
Meta:
- comunicar tese e direcionar descoberta sem excesso visual.

### Listagem publica
Meta:
- dar contexto editorial e facilitar busca de conteudo relevante.

### Detalhe publico
Meta:
- maximizar legibilidade e continuidade de leitura.

### Admin
Meta:
- reduzir friccao de operacao e manter criterio de publicacao.

## Matriz de decisao de reposicionamento

| Pergunta | Resposta atual | Acao |
|---|---|---|
| Mensagem inicial e clara? | Sim | manter coerencia de copy |
| Publicacao parece governada? | Sim | reforcar politica formal (doc 007) |
| Operacao transmite confianca? | Sim | manter checklist de release e historico |
| Diferencial e defensavel? | Sim | documentar evidencias por versao |

## Riscos de reposicionamento mal executado
1. virar discurso sem acao tecnica;
2. adotar linguagem "premium" sem melhorar clareza;
3. copiar concorrente e perder identidade metodologica.

## Mitigacoes
1. toda mudanca de posicionamento precisa refletir em docs de copy/rotas;
2. toda promessa precisa de evidencia operacional;
3. toda evolucao publica precisa passar por fluxo editorial do admin.

## Criterio de aceite
Documento aprovado quando:
1. diferencia o projeto por capacidade real, nao por retorica;
2. conecta posicionamento a arquitetura e operacao existentes;
3. sustenta decisoes de produto para proximos ciclos.
