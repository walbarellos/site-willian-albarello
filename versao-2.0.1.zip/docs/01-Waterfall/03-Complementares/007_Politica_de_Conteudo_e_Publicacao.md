# 007 - Politica de Conteudo e Publicacao

## Objetivo
Definir politica editorial para manter padrao publico de qualidade no `personal-site`.

## Principios editoriais
1. publicar com criterio, nao por volume;
2. preservar legibilidade publica;
3. manter coerencia entre tese institucional e conteudo;
4. registrar mudanca relevante com rastreabilidade.

## Escopo
Aplica-se a:
1. home institucional;
2. listagem publica;
3. detalhe por slug;
4. fluxo de criacao/edicao no admin.

## Tipos de conteudo permitidos
1. analise institucional;
2. explicacao tecnica em linguagem publica;
3. atualizacao de posicionamento;
4. conteudo de continuidade editorial.

## Tipos de conteudo restritos
1. texto sem revisao minima;
2. claims sem evidencias;
3. conteudo fora da tese central do projeto;
4. copy inflada para gerar impressao falsa de autoridade.

## Fluxo de publicacao (obrigatorio)
1. redacao inicial;
2. revisao de clareza;
3. revisao de aderencia de tom (`004`);
4. revisao de metadata;
5. publicacao no admin;
6. verificacao em rota publica;
7. registro de mudanca quando aplicavel.

## Regras de qualidade minima
1. titulo objetivo;
2. resumo util;
3. estrutura interna com seções claras;
4. ausencia de ambiguidade de mensagem;
5. aderencia ao tom institucional.

## Regras de manutencao
1. erro factual confirmado deve ser corrigido no proximo ciclo;
2. atualizacao de sentido deve deixar rastro no historico;
3. retirada de conteudo deve ter justificativa documentada.

## Governanca e papeis
1. Operador editorial: cria e revisa conteudo;
2. Operador tecnico: garante integridade de plataforma;
3. Responsavel de ciclo: valida evidencia e fechamento.

## Indicadores editoriais basicos
1. tempo medio redacao -> publicacao;
2. taxa de retrabalho editorial;
3. taxa de correcao pos-publicacao;
4. regularidade de cadencia por ciclo.

## Criticidade e bloqueio
Bloquear publicacao quando:
1. conteudo conflita com tese institucional;
2. metadata essencial estiver ausente;
3. texto tiver erro factual sem resolucao;
4. houver risco juridico/reputacional nao mitigado.

## Integracao com outros docs
1. `Waterfall/DOC-16-estrategia-editorial-e-governanca.md`
2. `UI_UX/UIUX-11-contratos-de-tela-por-rota.md`
3. `005_FAQ_Produto_Negocio_Operacao_e_Suporte.md`

## Criterio de aceite
Documento aprovado quando:
1. reduz improviso de publicacao;
2. torna criterios editoriais verificaveis;
3. protege qualidade publica no tempo.
