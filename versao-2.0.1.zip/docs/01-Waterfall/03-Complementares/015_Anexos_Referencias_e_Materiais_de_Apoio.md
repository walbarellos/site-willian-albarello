# 015 - Anexos, Referencias e Materiais de Apoio

## Objetivo
Servir como indice operacional do bloco `03-Complementares`, conectando referencias essenciais para execucao e auditoria.

## Como usar este documento
1. localizar rapidamente fonte soberana por tema;
2. reduzir busca manual durante ciclo;
3. manter continuidade entre versoes.

## Indice de documentos do bloco 03-Complementares
1. `001_Benchmark_e_Referencias_de_Mercado.md`
2. `002_Analise_de_Concorrentes_e_Reposicionamento.md`
3. `003_Mapa_de_Prova_Social_e_Autoridade.md`
4. `004_Copy_Strategy_Tom_de_Voz_e_Mensagem.md`
5. `005_FAQ_Produto_Negocio_Operacao_e_Suporte.md`
6. `006_Plano_de_Treinamento_Adocao_e_Onboarding.md`
7. `007_Politica_de_Conteudo_e_Publicacao.md`
8. `008_Manual_Operacional_do_Sistema.md`
9. `009_Runbook_de_Suporte_e_Atendimento.md`
10. `010_Planejamento_de_Relatorios_e_Indicadores.md`
11. `011_Modelo_de_Monetizacao_Captacao_Receita_ou_Expansao.md`
12. `012_Historico_de_Versoes_e_Mudancas.md`
13. `013_Registro_de_Descobertas_Pesquisas_e_Insights.md`
14. `014_Roadmap_Expandido_Pos_MVP.md`

## Referencias tecnicas principais
1. `README.md`
2. `apps/api/README.md`
3. `apps/web/README.md`
4. `apps/admin/README.md`
5. `Waterfall/DOC-10-arquitetura-tecnica.md`
6. `Waterfall/DOC-14-seguranca-p0.md`
7. `Waterfall/DOC-15-seo-tecnico.md`
8. `Waterfall/DOC-16-estrategia-editorial-e-governanca.md`
9. `Waterfall/DOC-21-observabilidade-logs-e-incidentes.md`

## Referencias de UX e contrato de tela
1. `UI_UX/UIUX-02-design-system-base.md`
2. `UI_UX/UIUX-04-guia-de-componentes.md`
3. `UI_UX/UIUX-09-estados-de-interface-e-feedback.md`
4. `UI_UX/UIUX-10-criterios-de-aceite-por-tela.md`
5. `UI_UX/UIUX-11-contratos-de-tela-por-rota.md`

## Referencias de QA e CI
1. `QA/QA-01-checklist-de-homologacao-funcional.md`
2. `QA/QA-02-matriz-de-gates-ci-e-deploy-readiness.md`
3. `infra/ci/README.md`
4. `infra/ci/CI-MATRIX.md`
5. `infra/ci/LOCAL-TO-CI-MAP.md`
6. `infra/ci/PIPELINE-FAILURE-PLAYBOOK.md`
7. `infra/ci/RELEASE-EVIDENCE-CHECKLIST.md`
8. `infra/ci/WORKFLOW-OWNERSHIP-AND-GATES.md`
9. `infra/ci/ARTIFACTS-AND-RETENTION.md`
10. `infra/ci/CI-BOOTSTRAP-CHECKLIST.md`

## Diagramas e apoio visual
1. `docs/02-Diagramas/*`
2. `Diagrama/*.mmd`

## Artefatos de versao para auditoria
1. `RELATORIO-FINAL-V1.6.md`
2. `RELATORIO-FINAL-V1.7.md`
3. `RELATORIO-FINAL-V1.8.md`
4. `versao-1.6.zip`
5. `versao-1.7.zip`
6. `versao-1.8.zip`

## Regra de manutencao
1. atualizar este indice ao fechar ciclo documental relevante;
2. remover referencia apenas quando houver substituicao formal;
3. manter coerencia com estado fisico do repositorio.

## Criterio de aceite
Documento aprovado quando:
1. reduz tempo de localizacao de material;
2. melhora consistencia de continuidade;
3. suporta auditoria sem dependencia de memoria informal.
