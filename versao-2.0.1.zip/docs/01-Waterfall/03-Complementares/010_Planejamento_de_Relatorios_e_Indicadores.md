# 010 - Planejamento de Relatorios e Indicadores

## Objetivo
Definir plano de relatorios e indicadores para decisao de produto, operacao e release no `personal-site`.

## Principio
Indicador sem acao associada nao entra no plano.

## Fontes soberanas
1. `QA/QA-02-matriz-de-gates-ci-e-deploy-readiness.md`
2. `infra/ci/CI-MATRIX.md`
3. `infra/ci/RELEASE-EVIDENCE-CHECKLIST.md`
4. `Waterfall/DOC-21-observabilidade-logs-e-incidentes.md`

## Camadas de indicadores

### A. Qualidade tecnica
1. sucesso de `test:ci` por ciclo;
2. sucesso de `verify:hardening` por ciclo;
3. taxa de smoke verde no fechamento;
4. tempo medio de resolucao de falha bloqueante.

### B. Qualidade de release
1. ciclos fechados sem reabertura de bug critico;
2. percentual de gates bloqueantes em verde;
3. percentual de ciclos com checklist de evidencia completo;
4. taxa de divergencia relatorio x estado fisico.

### C. Qualidade editorial
1. cadencia de publicacoes;
2. consistencia de metadados;
3. taxa de retrabalho editorial;
4. taxa de continuidade de leitura (`/publicacoes` -> detalhe).

### D. Maturidade de governanca
1. cumprimento de ordem do `Atualizacao de codigo`;
2. tempo de fechamento por ciclo;
3. backlog documental residual por bloco.

## Relatorios operacionais

### R-01 Fechamento de versao (obrigatorio)
Conteudo:
1. escopo executado;
2. arquivos alterados;
3. validacoes executadas;
4. pendencias remanescentes.

Artefatos:
- `RELATORIO-FINAL-V*.md`
- `versao-*.zip`

### R-02 Painel de gates (obrigatorio)
Conteudo:
1. status de cada gate bloqueante;
2. causa de falha quando aplicavel;
3. acao para recuperar verde.

### R-03 Incidentes operacionais (recomendado)
Conteudo:
1. incidente;
2. impacto;
3. causa raiz;
4. acao preventiva.

### R-04 Evolucao editorial (recomendado)
Conteudo:
1. publicacoes novas;
2. revisoes relevantes;
3. sinais de qualidade de leitura.

## Cadencia recomendada
1. por ciclo: R-01 e R-02;
2. semanal: R-03;
3. mensal: R-04.

## Matriz de ownership

| Relatorio | Owner primario | Apoio |
|---|---|---|
| R-01 | responsavel de ciclo | operador tecnico |
| R-02 | responsavel de qualidade | operador tecnico |
| R-03 | operacao/suporte | engenharia |
| R-04 | editorial | produto |

## Anti-padroes
1. relatorio sem evidencia;
2. status verde por percepcao;
3. indicador sem criterio de coleta;
4. metrica de vaidade sem impacto em decisao.

## Checklist de qualidade do relatorio
- [ ] evidencia objetiva anexada
- [ ] decisao explicita (`LIBERAR`/`BLOQUEAR`)
- [ ] proxima acao definida
- [ ] coerencia com estado fisico do repo

## Criterio de aceite
Documento aprovado quando:
1. cria rotina de leitura gerencial util;
2. reduz decisao por intuicao;
3. melhora previsibilidade de ciclo e release.
