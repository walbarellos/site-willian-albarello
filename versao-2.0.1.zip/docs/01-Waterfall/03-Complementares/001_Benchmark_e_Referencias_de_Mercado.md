# 001 - Benchmark e Referencias de Mercado

## Objetivo
Definir um benchmark util para evolucao do `personal-site` sem copiar visual de concorrente e sem perder a disciplina institucional do projeto.

## Escopo
Este documento organiza referencias por criterio de decisao:
1. estrategia de presenca institucional;
2. UX editorial publica;
3. confiabilidade tecnica percebida;
4. governanca de operacao e release.

## Fontes soberanas usadas
1. `README.md`
2. `Waterfall/DOC-10-arquitetura-tecnica.md`
3. `Waterfall/DOC-16-estrategia-editorial-e-governanca.md`
4. `UI_UX/UIUX-11-contratos-de-tela-por-rota.md`
5. `infra/ci/CI-MATRIX.md`
6. `QA/QA-02-matriz-de-gates-ci-e-deploy-readiness.md`

## Estado real atual do projeto (baseline)
1. arquitetura web/admin/api estabilizada;
2. contratos OpenAPI e `packages/contracts` ativos;
3. trilha de qualidade com `test:ci`, `verify:hardening` e `smoke`;
4. camada `infra` e `infra/ci` preenchidas;
5. backlog tecnico concentrado em docs `04-High_Tech`.

## Modelo de benchmark adotado
Benchmark por criterio, nao por marca.

Cada referencia e avaliada por:
1. utilidade para legibilidade publica;
2. utilidade para continuidade editorial;
3. utilidade para reduzir risco operacional;
4. custo de manutencao no tempo.

## Eixo A - Presenca institucional
Pergunta de controle:
- "A home comunica proposta sem ruido e sem performance visual vazia?"

Criterios:
1. tese explicita em ate 2 blocos;
2. CTA principal sem ambiguidade;
3. bloco lateral de contexto compacto (sem card gigante desnecessario);
4. contraste de texto consistente.

Aplicacao no projeto:
- manter o padrao visual limpo ja validado no ciclo de refino da home.

## Eixo B - Descoberta editorial
Pergunta de controle:
- "A navegacao de descoberta (home -> listagem -> detalhe) e natural?"

Criterios:
1. listagem com busca e paginação previsiveis;
2. cards com resumo informativo e sem clickbait;
3. detalhe por slug com leitura limpa;
4. retorno contextual para continuidade.

Aplicacao no projeto:
- preservar contratos de rota descritos em `UIUX-11`.

## Eixo C - Confianca tecnica percebida
Pergunta de controle:
- "O usuario percebe estabilidade ao navegar?"

Criterios:
1. erros com mensagem clara;
2. indisponibilidade rara nas rotas principais;
3. consistencia de resposta API para camadas consumidoras;
4. ausencia de regressao visual grave apos release.

Aplicacao no projeto:
- manter gate pre-release com evidencias obrigatorias.

## Eixo D - Governanca operacional
Pergunta de controle:
- "O projeto evolui sem perder rastreabilidade?"

Criterios:
1. relatorio final por versao;
2. zip de versao por ciclo;
3. checklist de evidencia preenchido;
4. fluxo do `Atualizacao de codigo` respeitado.

Aplicacao no projeto:
- `infra/ci/RELEASE-EVIDENCE-CHECKLIST.md` como bloqueante de release.

## Matriz de referencia (criterio x nivel atual)

| Criterio | Nivel atual | Evidencia no repo | Acao recomendada |
|---|---|---|---|
| Clareza institucional | Alto | home + docs de copy e rota | manter padrao e evitar inflacao visual |
| Descoberta editorial | Alto | `/publicacoes` e detalhe estabilizados | ampliar links de continuidade entre temas |
| Robustez operacional | Alto | scripts + workflows + QA | manter disciplina de evidencia por release |
| Prova de autoridade | Medio | narrativa forte, mas sem mapa formal completo | consolidar sinais por rota (doc 003) |
| Estrategia de expansao | Medio | base pronta, sem trilha comercial formal | amadurecer doc 011 + roadmap 014 |

## Anti-benchmark (o que rejeitar)
1. copiar interfaces de portfolio "hero + efeito" sem substancia;
2. inserir componente novo sem criterio de negocio;
3. usar metrica de vaidade como sucesso de projeto;
4. trocar estabilidade por novidade visual a cada ciclo.

## Indicadores de benchmark para acompanhamento
1. taxa de continuidade home -> publicacoes;
2. taxa de retorno em detalhes publicados;
3. ciclos sem reabertura de regressao visual;
4. releases sem bloqueio por falta de evidencia;
5. tempo medio de fechamento de ciclo sem retrabalho.

## Cadencia de revisao
1. revisar este benchmark a cada 2 ciclos;
2. atualizar matriz quando houver mudanca de arquitetura, UX ou processo de release;
3. registrar diferenca entre "antes" e "depois" no historico de versoes.

## Criterio de aceite
Este documento e valido quando:
1. orienta decisao pratica de produto e operacao;
2. usa referencias internas do projeto como verdade primaria;
3. evita benchmarking generico sem aderencia ao estado real.
