# 009 - Runbook de Suporte e Atendimento

## Objetivo
Padronizar suporte para incidentes funcionais do `personal-site`, com triagem rapida e encaminhamento tecnico claro.

## Niveis de atendimento

### N1 - Triagem
1. coletar sintoma e rota afetada;
2. identificar impacto (baixo, medio, alto);
3. reproduzir em ambiente controlado.

### N2 - Correcao operacional
1. aplicar procedimento conhecido;
2. validar com comando objetivo;
3. registrar resultado.

### N3 - Escalonamento
1. incidente sem resolucao em N2;
2. risco de release;
3. necessidade de rollback.

## Classificacao de impacto

| Nivel | Definicao | Exemplo |
|---|---|---|
| Baixo | impacto localizado | inconsistência textual sem quebra funcional |
| Medio | fluxo parcial comprometido | falha intermitente em listagem |
| Alto | fluxo critico indisponivel | login admin ou API fora |

## Fluxo de atendimento
1. receber incidente;
2. classificar impacto;
3. executar check basico;
4. aplicar acao por categoria;
5. confirmar recuperacao;
6. registrar evidencia e causa.

## Playbooks por categoria

### Categoria API
1. testar `/health` e `/ready`;
2. validar env;
3. analisar logs;
4. decidir bloqueio/rollback se necessario.

### Categoria Web publico
1. testar `/` e `/publicacoes`;
2. validar conectividade com API;
3. reiniciar runtime se necessario;
4. repetir smoke.

### Categoria Admin
1. testar `/painel/login`;
2. validar sessao/autenticacao;
3. checar origem/cookies no backend.

### Categoria CI/Release
1. identificar workflow falho;
2. mapear para comando local equivalente;
3. aplicar correcao minima;
4. rerodar gate.

## SLA interno recomendado
1. triagem inicial: ate 30 min;
2. resposta em incidente medio: ate 2h;
3. incidente alto: acao imediata com decisao de bloqueio.

## Evidencia minima por incidente
1. data/hora;
2. categoria;
3. impacto;
4. acao aplicada;
5. resultado apos acao;
6. proxima acao.

## Integracao com governanca
1. `infra/ops/OPERACAO-E-ROLLBACK.md`
2. `infra/ci/PIPELINE-FAILURE-PLAYBOOK.md`
3. `QA/QA-01-checklist-de-homologacao-funcional.md`

## Criterio de aceite
Documento aprovado quando:
1. reduz improviso no suporte;
2. acelera triagem e resolucao;
3. define claramente quando escalar ou bloquear release.
