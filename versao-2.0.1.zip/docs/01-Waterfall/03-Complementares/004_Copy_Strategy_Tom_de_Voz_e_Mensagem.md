# 004 - Copy Strategy, Tom de Voz e Mensagem

## Objetivo
Padronizar linguagem do `personal-site` para manter consistencia entre:
1. home;
2. listagem e detalhe publico;
3. painel admin;
4. documentacao de apoio.

## Tese de linguagem
"Clareza publica com disciplina editorial e confianca operacional."

## Fontes soberanas usadas
1. `UI_UX/UIUX-11-contratos-de-tela-por-rota.md`
2. `Waterfall/DOC-16-estrategia-editorial-e-governanca.md`
3. `README.md`
4. `apps/web/app/page.tsx`
5. `apps/admin/app/painel/login/page.tsx`

## Tom de voz oficial

### Deve ser
1. claro;
2. objetivo;
3. institucional;
4. tecnicamente responsavel;
5. humano sem informalidade excessiva.

### Nao deve ser
1. promocional hiperbolico;
2. vago;
3. agressivo;
4. jargao por jargao.

## Regras de escrita por contexto

### Home
1. frase de tese curta e forte;
2. explicacao em linguagem acessivel;
3. CTA com acao explicita.

### Listagem publica
1. introducao contextual sem exagero;
2. cards com resumo informativo;
3. termos consistentes com detalhe.

### Detalhe publico
1. abertura orientada a leitura;
2. paragrafos com ritmo;
3. fechamento com continuidade.

### Admin
1. labels operacionais diretas;
2. erros acionaveis;
3. sucesso com confirmacao objetiva.

## Glossario recomendado
1. presenca institucional;
2. legibilidade publica;
3. governanca editorial;
4. continuidade;
5. rastreabilidade;
6. evidencia de release.

## Termos restritos (evitar)
1. "revolucionario";
2. "disruptivo";
3. "garantia absoluta";
4. qualquer superlativo sem base.

## Padrao de mensagens de erro
Formato:
1. o que falhou;
2. impacto para usuario;
3. proximo passo.

Exemplo:
"Nao foi possivel concluir a operacao agora. Tente novamente em instantes."

## Padrao de CTA
1. CTA principal unico por bloco;
2. CTA secundario apenas com funcao diferente;
3. evitar acao redundante com labels diferentes.

## Revisao de copy por ciclo
- [ ] alinhada com `UIUX-11`?
- [ ] alinhada com estado real das rotas?
- [ ] sem claims sem evidencia?
- [ ] sem regressao de tom?

## Criterio de aceite
Documento aprovado quando:
1. reduz variacao indevida de linguagem;
2. melhora previsibilidade de comunicacao;
3. sustenta posicionamento institucional em todas as telas.
