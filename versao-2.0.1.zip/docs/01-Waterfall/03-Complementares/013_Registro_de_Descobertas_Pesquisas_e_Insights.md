# 013 - Registro de Descobertas, Pesquisas e Insights

## Objetivo
Consolidar aprendizados que alteraram decisoes reais de produto, UX, operacao e governanca no `personal-site`.

## Descobertas de UX
1. contraste e hierarquia visual impactam mais a confianca percebida do que efeitos visuais;
2. cards superdimensionados na home aumentam percepcao de "layout brega";
3. melhorias de legibilidade com pequenos ajustes estruturais geram alto ganho.

## Descobertas de produto/editorial
1. rota publica precisa servir descoberta real, nao apenas vitrine;
2. consistencia de metadados melhora leitura e percepcao de organizacao;
3. copy institucional funciona melhor quando evita promessa vaga.

## Descobertas tecnicas
1. `clean` pode derrubar estado de runtime dev e gerar falso alarme de regressao;
2. smoke rapido detecta falhas de disponibilidade antes do release;
3. contracts + OpenAPI evitam quebra silenciosa entre camadas.

## Descobertas operacionais
1. checklist de evidencia reduz conflito em auditoria;
2. playbook de falha reduz tempo de resposta;
3. relatorio+zip por ciclo facilita continuidade sem perda de contexto.

## Descobertas metodologicas
1. ordem sequencial do `Atualizacao de codigo` reduz retrabalho;
2. docs sem aderencia ao estado fisico viram passivo;
3. qualidade documental precisa ser medida por utilidade operacional.

## Insights acionaveis para proximos ciclos
1. antes de abrir novo bloco, validar se o bloco atual esta util na pratica;
2. priorizar documentos que ajudam decisao e execucao;
3. bloquear texto "bonito" sem criterio verificavel.

## Sinais de risco observados
1. pressa em fechar volume sem profundidade;
2. reaproveito de estrutura generica sem evidencia;
3. pouca ligacao entre documento e comando real do projeto.

## Contramedidas adotadas neste ciclo
1. reescrita por criterio e fonte soberana;
2. foco em checklist, matriz e protocolo aplicavel;
3. registro de falhas percebidas no historico de versao.

## Criterio de aceite
Documento aprovado quando:
1. registra aprendizado aplicavel;
2. distingue fato de opiniao;
3. orienta melhoria concreta no proximo ciclo.
