# 011 - Modelo de Monetizacao, Captacao, Receita ou Expansao

## Objetivo
Mapear modelos de monetizacao/captacao coerentes com a natureza institucional do `personal-site`.

## Premissas
1. reputacao vem antes de conversao;
2. monetizacao nao pode quebrar legibilidade publica;
3. escala deve respeitar capacidade operacional.

## Modelos candidatos

### Modelo 1 - Servico premium derivado de autoridade
Como funciona:
1. publicacoes sustentam posicionamento;
2. interesse qualificado entra via canais institucionais;
3. conversao ocorre por proposta fora do site.

Vantagens:
- alto alinhamento com o estado atual.

Risco:
- dependencia de cadencia editorial.

### Modelo 2 - Parcerias institucionais
Como funciona:
1. conteudo demonstra capacidade metodologica;
2. abre colaboracoes com organizacoes;
3. gera receita indireta por parceria.

Vantagens:
- preserva perfil institucional.

Risco:
- ciclo comercial mais longo.

### Modelo 3 - Produto editorial estruturado (futuro)
Como funciona:
1. curadoria de series/relatorios;
2. oferta premium em etapa posterior;
3. operacao apoiada por indicadores de leitura.

Vantagens:
- escalabilidade de longo prazo.

Risco:
- maturidade editorial ainda em consolidacao.

## Modelos nao recomendados agora
1. publicidade intrusiva;
2. paywall precoce;
3. microprodutos sem governanca de conteudo.

## Matriz de priorizacao

| Criterio | Peso | M1 | M2 | M3 |
|---|---|---|---|---|
| Aderencia institucional | Alto | Alto | Alto | Medio |
| Simplicidade operacional | Alto | Alto | Medio | Baixo |
| Potencial curto prazo | Medio | Medio/Alto | Medio | Baixo |
| Escala longo prazo | Medio | Medio | Medio | Alto |
| Risco de ruido na UX | Alto | Baixo | Baixo | Medio |

## Recomendacao por fase
1. Curto prazo: Modelo 1;
2. Medio prazo: Modelo 2 em paralelo seletivo;
3. Longo prazo: Modelo 3 apos consolidacao de dados editoriais.

## Requisitos de prontidao
- [ ] cadencia minima de publicacao estabilizada
- [ ] gates de qualidade verdes em ciclos consecutivos
- [ ] historico de evidencias de release consistente
- [ ] politica editorial aplicada sem excecao recorrente

## Indicadores de tracao
1. contatos qualificados originados por publicacoes;
2. taxa de retorno ao site;
3. profundidade de leitura em conteudos-chave;
4. continuidade de fluxo de leitura para contato institucional.

## Riscos de execucao
1. pressionar conversao e degradar tom institucional;
2. prometer oferta sem capacidade de entrega;
3. desviar foco da base editorial para experimentos dispersos.

## Mitigacoes
1. adotar rollout por fase;
2. revisar copy comercial com base no doc 004;
3. bloquear oferta fora de escopo sem evidencia de capacidade.

## Criterio de aceite
Documento aprovado quando:
1. apresenta caminho de monetizacao realista;
2. preserva integridade editorial e operacional;
3. evita desvio oportunista de curto prazo.
