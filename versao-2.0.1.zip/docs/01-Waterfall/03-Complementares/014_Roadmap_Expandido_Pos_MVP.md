# 014 - Roadmap Expandido Pos-MVP

## Objetivo
Planejar evolucao do `personal-site` apos fechamento do bloco complementar, preservando estabilidade e sequencia metodologica.

## Estado atual de partida
1. arquitetura principal consolidada;
2. qualidade tecnica com gates ativos;
3. `03-Complementares` preenchido;
4. proximo backlog concentrado em `04-High_Tech`.

## Diretriz de priorizacao
1. priorizar impacto operacional verificavel;
2. evitar abrir frente nova sem fechar frente atual;
3. manter trilha de evidencia por versao.

## Horizonte 1 - Proximo ciclo (curto prazo)

### H1.1
Iniciar `docs/01-Waterfall/04-High_Tech` item 001 em ordem.

### H1.2
Fechar cada item com criterio de utilidade pratica para arquitetura, seguranca, deploy e operacao.

### H1.3
Manter relatorio e zip por versao sem excecao.

## Horizonte 2 - Consolidacao tecnica (medio prazo)
1. completar bloco `04-High_Tech`;
2. revisar integracao entre docs high-tech e scripts/workflows reais;
3. ajustar QA e infraestrutura conforme descobertas tecnicas.

## Horizonte 3 - Maturidade operacional (longo prazo)
1. evoluir observabilidade de negocio;
2. amadurecer estrategia de expansao com base em dados;
3. reforcar protocolo de handoff IA-equipe.

## Backlog priorizado

| Ordem | Entrega | Valor | Dependencia |
|---|---|---|---|
| 1 | Abrir `04-High_Tech/001` | Alto | `03-Complementares` fechado |
| 2 | Seguir `04-High_Tech` em ordem | Alto | item 1 |
| 3 | Revisar QA/gates apos bloco high-tech | Medio | itens high-tech centrais |
| 4 | Consolidar indicadores de evolucao | Medio | historico atualizado |

## Regras de execucao
1. um arquivo por vez;
2. sem pular ordem;
3. sem reabrir ciclo fechado sem causa tecnica;
4. com evidencia de validacao ao final.

## Riscos de roadmap
1. inflacao de escopo sem fechamento;
2. foco excessivo em teoria sem reflexo no repo;
3. perda de rastreabilidade entre versoes.

## Mitigacoes
1. gates de fechamento por ciclo;
2. checklist de evidencia obrigatorio;
3. auditoria cruzada relatorio x estado fisico.

## Marco de sucesso
1. backlog reduzido com qualidade;
2. menor retrabalho entre ciclos;
3. auditoria com baixa divergencia.

## Criterio de aceite
Documento aprovado quando:
1. orienta claramente o proximo bloco de trabalho;
2. protege contra dispersao de prioridade;
3. conecta plano a capacidade real da equipe/projeto.
