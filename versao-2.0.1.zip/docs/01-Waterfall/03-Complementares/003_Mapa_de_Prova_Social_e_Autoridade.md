# 003 - Mapa de Prova Social e Autoridade

## Objetivo
Definir onde e como sinais de autoridade entram no `personal-site` sem comprometer sobriedade visual e sem criar claims nao verificaveis.

## Premissa
Autoridade publica deve ser resultado de consistencia.
Nao de adorno.

## Fontes soberanas usadas
1. `apps/web/app/page.tsx`
2. `apps/web/app/publicacoes/[slug]/page.tsx`
3. `Waterfall/DOC-16-estrategia-editorial-e-governanca.md`
4. `RELATORIO-FINAL-V1.6.md`
5. `RELATORIO-FINAL-V1.7.md`

## Taxonomia de prova social

### Tipo A - Prova de consistencia
Exemplos:
1. regularidade de publicacao;
2. padrao de estrutura entre textos;
3. historico de versoes e continuidade.

### Tipo B - Prova tecnica
Exemplos:
1. rastreabilidade de release;
2. gates de qualidade documentados;
3. runbooks de operacao e rollback.

### Tipo C - Prova de autoridade de conteudo
Exemplos:
1. profundidade argumentativa em artigos;
2. coerencia entre tese e execucao;
3. linguagem institucional verificavel.

## Distribuicao de prova por rota

### Rota `/`
Objetivo:
- estabelecer confianca inicial.

Sinais recomendados:
1. tese clara;
2. bloco de direcao de presenca com promessas limitadas e verificaveis;
3. CTA para publicacoes como evidencia de continuidade.

### Rota `/publicacoes`
Objetivo:
- mostrar disciplina editorial.

Sinais recomendados:
1. metadados consistentes;
2. cards com contexto e clareza;
3. ausencia de ruido visual e clickbait.

### Rota `/publicacoes/[slug]`
Objetivo:
- provar profundidade e confiabilidade.

Sinais recomendados:
1. estrutura de leitura limpa;
2. fechamento com continuidade;
3. coerencia de tom e argumento.

## Distribuicao de prova fora da UI
1. `RELATORIO-FINAL-*` para evidencias de ciclo;
2. `infra/ci/*` para prova de governanca de pipeline;
3. `QA/*` para prova de criterio funcional.

## Matriz de uso de prova

| Sinal | Onde aparece | Quem valida | Risco se ausente |
|---|---|---|---|
| Continuidade editorial | listagem e detalhe | operador editorial | percepcao de abandono |
| Rastreabilidade de release | docs e relatorios | responsavel de ciclo | perda de confianca tecnica |
| Coerencia de tese | home e artigos | revisao editorial | mensagem fragmentada |
| Disciplina de operacao | runbooks e QA | operador tecnico | regressao e retrabalho |

## Limites de prova social
1. nao exibir metricas sem contexto;
2. nao usar testemunho sem fonte;
3. nao usar selo de autoridade sem criterio;
4. nao prometer escala sem processo.

## Checklist de revisao por ciclo
- [ ] sinais da home continuam verdadeiros?
- [ ] publicacoes sustentam a tese institucional?
- [ ] evidencias tecnicas estao atualizadas?
- [ ] houve claim novo sem lastro?

## Criterio de aceite
Documento aprovado quando:
1. transforma autoridade em protocolo verificavel;
2. evita inflacao estetica;
3. melhora confianca publica com evidencia concreta.
