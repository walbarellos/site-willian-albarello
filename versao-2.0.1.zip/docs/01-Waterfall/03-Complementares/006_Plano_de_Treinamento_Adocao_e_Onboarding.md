# 006 - Plano de Treinamento, Adocao e Onboarding

## Objetivo
Garantir onboarding reproduzivel para operadores tecnicos, editoriais e de release do `personal-site`.

## Perfis de entrada
1. Operador tecnico (infra, scripts, gates)
2. Operador editorial (painel e publicacao)
3. Responsavel de ciclo (fechamento e auditoria)

## Resultado minimo esperado
Ao final do onboarding, a pessoa deve:
1. subir ambiente local sem ajuda externa;
2. executar `test:ci`, `verify:hardening` e `smoke`;
3. operar fluxo basico de publicacao no admin;
4. preparar relatorio de fechamento com evidencia.

## Trilha oficial de onboarding

### Fase 1 - Contexto do sistema (1h)
Leitura obrigatoria:
1. `README.md`
2. `apps/api/README.md`
3. `apps/web/README.md`
4. `apps/admin/README.md`
5. `Waterfall/DOC-10-arquitetura-tecnica.md`

Criterio de saida:
- explicar fronteiras web/admin/api/contracts.

### Fase 2 - Ambiente local (1h30)
Execucao:
1. `pnpm install --frozen-lockfile`
2. `bash infra/scripts/dev-up.sh`
3. `bash infra/scripts/smoke.sh`

Criterio de saida:
- smoke com `PASS` integral.

### Fase 3 - Fluxo editorial (1h30)
Execucao:
1. login em `/painel/login`;
2. navegar listagem de publicacoes;
3. abrir edicao de uma publicacao;
4. salvar mudanca simples e conferir reflexo publico.

Criterio de saida:
- fluxo fim a fim sem erro bloqueante.

### Fase 4 - Qualidade e release (2h)
Execucao:
1. `pnpm test:ci`
2. `pnpm verify:hardening`
3. `bash infra/scripts/release-check.sh`
4. leitura de `infra/ci/*`

Criterio de saida:
- identificar gates bloqueantes e explicar decisao de release.

### Fase 5 - Governanca de ciclo (1h)
Execucao:
1. ler `Atualizacao de codigo` vigente;
2. seguir um item real em ordem;
3. registrar evidencia no padrao do projeto.

Criterio de saida:
- produzir mini handoff coerente com estado fisico.

## Matriz de competencia

| Competencia | Nivel alvo | Evidencia objetiva |
|---|---|---|
| Setup tecnico | Basico | ambiente ativo + smoke verde |
| Diagnostico de falha | Basico | uso de playbook de pipeline |
| Operacao editorial | Intermediario | edicao e validacao em rota publica |
| Gate de release | Intermediario | test:ci + verify:hardening + release-check |
| Continuidade documental | Intermediario | relatorio e zip de ciclo |

## Checklist de certificacao interna
- [ ] Consegue subir ambiente sem suporte
- [ ] Consegue restaurar ambiente apos falha de runtime
- [ ] Consegue explicar gate bloqueante vs alerta
- [ ] Consegue fechar um item documental em ordem
- [ ] Consegue gerar evidencia para auditoria

## Riscos de onboarding mal feito
1. dependencia de memoria oral;
2. release sem evidencia;
3. retrabalho por desconhecimento de fonte soberana.

## Mitigacoes
1. trilha obrigatoria com check de saida;
2. avaliacao pratica por fase;
3. bloqueio de autonomia sem checklist concluido.

## Criterio de aceite
Documento aprovado quando:
1. onboarding pode ser executado por terceiro sem perda de contexto;
2. reduz risco operacional de rotacao de pessoa;
3. fica aderente aos comandos e fluxos reais do repositorio.
