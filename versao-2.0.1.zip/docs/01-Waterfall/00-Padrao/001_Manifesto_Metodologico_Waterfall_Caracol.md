# 001_Manifesto_Metodologico_Waterfall_Caracol

## Identificação do Documento

- **Projeto:** William Albarello
- **Camada:** 01-Waterfall
- **Subpasta:** 00-Padrao
- **Documento:** 001_Manifesto_Metodologico_Waterfall_Caracol.md
- **Função:** Constituição metodológica do projeto, definindo a lógica oficial de documentação, congelamento de decisões, tradução para geração e prevenção de retrabalho
- **Status:** ATIVO
- **Versão:** v1.0
- **Autoridade:** Máxima dentro da metodologia documental
- **Natureza:** Documento constitucional do método
- **Dependência superior:** 000_Indice_Mestre.md
- **Dependências relacionadas:**
  - 002_Regra_de_Nomenclatura_e_Versionamento.md
  - 024_Politica_de_Governanca_Documental.md

---

## 1. Finalidade

Este manifesto define o método oficial de construção do projeto.

Ele existe para impedir que o software seja conduzido por improviso, dispersão, retrabalho, modismos técnicos ou documentação ornamental sem consequência prática.

Sua função é estabelecer uma disciplina de engenharia documental suficientemente precisa para que:

1. o projeto tenha uma verdade soberana;
2. as decisões sejam registradas com clareza;
3. os módulos sejam definidos com rigor;
4. a arquitetura nasça como consequência dos requisitos;
5. a camada gerativa futura possa produzir código com encaixe previsível;
6. a evolução do sistema aconteça sem perda de coerência.

Este documento não é apenas uma explicação do método.  
Ele é a regra-mãe de operação intelectual do projeto.

---

## 2. Tese Central do Método

O projeto será conduzido por uma combinação de:

- **Waterfall** como mecanismo de soberania documental, congelamento de decisões e sequenciamento lógico;
- **Método Caracol** como mecanismo de aprofundamento progressivo, precisão cirúrgica, redução de ambiguidade e continuidade evolutiva;
- **Vida Relacional / Relational Life** como futura camada de tradução operacional da documentação em blocos geráveis, contratos encaixáveis e superprompts modulares.

A síntese oficial é esta:

> primeiro se pensa com ordem,  
> depois se documenta com rigor,  
> depois se congela com critério,  
> depois se traduz com precisão,  
> depois se gera com encaixe,  
> depois se valida com evidência.

---

## 3. Princípios Estruturais do Método

### 3.1 Fonte única de verdade

Toda decisão relevante do projeto deve possuir um local documental soberano.

Nada importante deve depender de memória informal, conversa solta, interpretação oral ou “intenção implícita”.

Aquilo que não está corretamente documentado não pode ser considerado estável.

### 3.2 Ordem antes de velocidade

Velocidade sem ordem produz acúmulo de retrabalho.

A prioridade do projeto não é gerar muito rapidamente.  
A prioridade é gerar corretamente, com estabilidade e progressão acumulativa.

### 3.3 Arquitetura como consequência, não como enfeite

A arquitetura não nasce da vontade abstrata de “usar tecnologias modernas”.

Ela nasce de:

- problema definido;
- objetivo declarado;
- escopo delimitado;
- requisitos claros;
- regras de negócio consistentes;
- restrições explícitas;
- contexto operacional real.

### 3.4 Documentação com consequência prática

Todo documento deve existir para produzir efeito real sobre:

- decisões;
- modelagem;
- geração;
- validação;
- operação;
- manutenção;
- continuidade.

Documento sem efeito concreto é ruído metodológico.

### 3.5 Redução máxima de ambiguidade

Cada ciclo documental deve reduzir interpretações concorrentes.

A documentação correta é aquela que fecha lacunas, explicita fronteiras, nomeia contratos e diminui a quantidade de decisões arbitrárias futuras.

### 3.6 Sem retrabalho como princípio de honra

Retrabalho não é tratado como normalidade inevitável.

Ele é entendido como sinal de:

- documentação insuficiente;
- ordem incorreta de execução;
- fronteiras mal definidas;
- contratos mal escritos;
- governança documental fraca.

O método existe para reduzir drasticamente esse tipo de perda.

---

## 4. Camadas Oficiais do Projeto

### 4.1 Camada 01-Waterfall

É a camada institucional e soberana.

Aqui ficam:

- visão;
- escopo;
- requisitos;
- regras;
- arquitetura;
- modelo de dados;
- integrações;
- segurança;
- qualidade;
- operação;
- governança;
- critérios de aceite;
- rastreabilidade.

Esta camada responde à pergunta:

**o que o sistema é, por que existe, como deve funcionar e quais são seus limites oficiais.**

### 4.2 Camada 02-Relational-Life

É a camada de tradução gerativa.

Aqui ficarão:

- superprompts por bloco;
- contratos modulares;
- mapas de encaixe;
- dependências de geração;
- regras de composição;
- protocolos de integração;
- instruções anti-conflito;
- ordem de montagem do código;
- critérios de consistência entre módulos.

Esta camada responderá à pergunta:

**como transformar a verdade documental em construção modular de software com precisão e mínimo retrabalho.**

### 4.3 Regra de precedência entre camadas

A camada `01-Waterfall` precede a camada `02-Relational-Life`.

Portanto:

- `02-Relational-Life` não cria verdade institucional;
- `02-Relational-Life` traduz a verdade institucional;
- se houver conflito, prevalece `01-Waterfall`;
- só pode ser gerado aquilo que já estiver suficientemente congelado.

---

## 5. Ordem Oficial de Construção Intelectual

A ordem oficial do método é:

1. Constituição documental do repositório;
2. Visão geral do projeto;
3. Problema, oportunidade e tese central;
4. Objetivos estratégicos;
5. Escopo e fora de escopo;
6. Atores, perfis e stakeholders;
7. Requisitos funcionais;
8. Requisitos não funcionais;
9. Regras de negócio;
10. Jornadas, fluxos e casos de uso;
11. Arquitetura geral;
12. Domínios, módulos e limites;
13. Modelo de dados;
14. Integrações;
15. Segurança, permissões, privacidade e auditoria;
16. Contratos de API e contratos de interface;
17. Critérios de aceite e qualidade;
18. Testes e rastreabilidade;
19. Tradução para a camada gerativa;
20. Geração modular do código;
21. Validação integrada;
22. Evolução controlada.

Qualquer inversão dessa ordem só é aceitável quando expressamente registrada e justificada.

---

## 6. Regra Oficial de Congelamento

Congelar não significa impedir evolução.  
Congelar significa impedir mutação caótica.

Uma decisão é considerada congelada quando:

1. foi registrada no documento correto;
2. está coerente com os documentos de nível superior;
3. não entra em conflito com arquitetura, escopo ou regras de negócio;
4. pode orientar implementação sem ambiguidades graves.

Após o congelamento:

- mudanças precisam ser justificadas;
- impactos precisam ser avaliados;
- documentos afetados precisam ser atualizados;
- a mudança não pode ser feita de modo silencioso.

---

## 7. O que é proibido neste método

É proibido:

- programar em cima de lacuna conceitual séria;
- abrir várias frentes sem soberania documental;
- duplicar a mesma decisão em documentos concorrentes;
- usar documentação apenas como vitrine;
- definir arquitetura sem base em requisitos;
- detalhar soluções técnicas antes de travar o problema;
- gerar código sem ordem de dependência;
- alterar conceitos centrais sem atualizar a camada soberana;
- tratar retrabalho como comportamento normal;
- deixar contratos implícitos.

---

## 8. O que é obrigatório neste método

É obrigatório:

- documentar antes de modularizar;
- modularizar antes de gerar;
- nomear corretamente arquivos, pastas, entidades e contratos;
- explicitar dependências entre blocos;
- declarar limites de cada módulo;
- indicar entradas, saídas, regras e falhas;
- definir critérios de aceite;
- preservar continuidade entre ciclos;
- manter rastreabilidade entre decisão, documento e implementação;
- separar claramente o que está estável do que ainda está em elaboração.

---

## 9. Critério de Qualidade 12/10

Este projeto adota a lógica 12/10 como ideal metodológico.

Isso significa que o objetivo não é apenas “funcionar”.

O objetivo é produzir material que reúna:

- **Sabedoria** — clareza de pensamento, ordem lógica, inteligência estrutural;
- **Força** — firmeza de contrato, resistência a ambiguidades, capacidade de sustentar execução real;
- **Beleza** — organização elegante, escrita limpa, arquitetura compreensível, forma digna do conteúdo.

A nota alta não será atribuída à complexidade aparente, mas à combinação de:

- precisão;
- coerência;
- utilidade;
- encaixe;
- continuidade;
- ausência de ruído.

---

## 10. Relação entre Documento e Código

Neste método, o código não deve ser o lugar onde o projeto “se descobre”.

O código deve ser o lugar onde o projeto **se materializa**.

Portanto:

- documentação define;
- arquitetura organiza;
- contratos limitam;
- geração implementa;
- testes confirmam;
- operação observa.

Quando o código precisar decidir aquilo que a documentação deveria ter resolvido, há falha metodológica.

---

## 11. Relação entre Superprompt e Sistema

O superprompt não deve ser tratado como mágica.

Ele será entendido como instrumento de tradução da inteligência documental em instrução gerativa de alta precisão.

Um superprompt bom:

- não inventa requisitos;
- não contradiz a camada soberana;
- não tenta “adivinhar” arquitetura;
- não amplia escopo sem autorização;
- não mistura responsabilidades;
- não gera blocos fora da ordem correta.

Em outras palavras:

> superprompt não substitui método;  
> superprompt executa método.

---

## 12. Continuidade e Memória do Projeto

Cada ciclo relevante do projeto deve deixar rastros suficientes para que o próximo ciclo não recomece do zero.

Isso exige:

- documentos com função clara;
- nomenclatura consistente;
- handoffs de continuidade;
- índice mestre atualizado;
- registro das decisões importantes;
- separação entre estável, provisório e futuro.

A continuidade é parte da engenharia.  
Perder contexto é forma de desperdício.

---

## 13. Definição oficial de progresso

Neste projeto, progresso não será medido apenas por:

- número de arquivos;
- quantidade de linhas;
- volume de código;
- quantidade de telas;
- sensação subjetiva de avanço.

O verdadeiro progresso é a soma de:

- redução de ambiguidade;
- aumento de estabilidade;
- aumento de capacidade gerativa;
- melhoria de encaixe entre partes;
- diminuição de retrabalho futuro;
- maturidade de decisão.

---

## 14. Cláusula de Sobriedade Técnica

Nem toda tecnologia interessante deve entrar no projeto.

Nem toda abstração sofisticada melhora a solução.

Nem toda complexidade é maturidade.

A escolha técnica correta será sempre a que melhor respeitar:

- o problema real;
- a capacidade de execução;
- a clareza dos contratos;
- a previsibilidade operacional;
- a facilidade de manutenção;
- a coerência com a arquitetura já congelada.

---

## 15. Cláusula de Evolução Controlada

O método não é rígido por vaidade.  
Ele é firme para permitir evolução segura.

Quando o projeto amadurecer, a mudança será aceita, desde que:

1. a necessidade esteja clara;
2. o ganho seja real;
3. o impacto seja rastreável;
4. a documentação seja atualizada;
5. a camada gerativa seja realinhada;
6. a mudança não destrua a coerência acumulada.

---

## 16. Declaração Final

Este manifesto institui a forma oficial de pensar, documentar, organizar, congelar, traduzir e gerar o software deste projeto.

A partir dele, fica estabelecido que:

- não haverá crescimento caótico;
- não haverá documentação ornamental como substituta de engenharia;
- não haverá geração de código desconectada da verdade documental;
- não haverá avanço legítimo sem coerência entre método, documento, arquitetura e execução.

Este projeto será conduzido com ordem, precisão, continuidade e vocação de encaixe.

---

## 17. Status deste Documento

Este documento entra em vigor imediatamente como referência metodológica oficial da pasta `01-Waterfall`.

Toda evolução posterior da documentação deve respeitar sua lógica, salvo revisão formal explícita.
