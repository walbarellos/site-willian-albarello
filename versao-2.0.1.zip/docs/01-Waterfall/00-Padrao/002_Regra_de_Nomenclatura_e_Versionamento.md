# 002_Regra_de_Nomenclatura_e_Versionamento

## Identificação do Documento

- **Projeto:** William Albarello
- **Camada:** 01-Waterfall
- **Subpasta:** 00-Padrao
- **Documento:** 002_Regra_de_Nomenclatura_e_Versionamento.md
- **Função:** Definir o padrão oficial de nomenclatura, ordenação, identificação, classificação e versionamento dos artefatos do projeto
- **Status:** ATIVO
- **Versão:** v1.0
- **Autoridade:** Alta
- **Natureza:** Documento normativo de padronização estrutural
- **Dependência superior:**
  - 000_Indice_Mestre.md
  - 001_Manifesto_Metodologico_Waterfall_Caracol.md
- **Dependências relacionadas:**
  - 024_Politica_de_Governanca_Documental.md

---

## 1. Finalidade

Este documento define as regras oficiais de nomenclatura e versionamento do projeto.

Sua finalidade é impedir:

- caos estrutural;
- nomes arbitrários;
- duplicidade semântica;
- quebra de ordem de leitura;
- arquivos difíceis de localizar;
- diretórios ambíguos;
- conflitos entre documentos, módulos e artefatos;
- perda de continuidade entre ciclos.

Neste projeto, nomear corretamente não é detalhe cosmético.

Nomear corretamente é parte da engenharia.

---

## 2. Princípios Gerais

## 2.1 Clareza antes de criatividade

Nomes devem ser claros, diretos, descritivos e rastreáveis.

É proibido usar nomes “bonitos” porém vagos.

Exemplos inadequados:

- `coisas_importantes.md`
- `estrutura_nova.md`
- `teste_final_agora.md`
- `versao_certa_mesmo.md`

Exemplos adequados:

- `013_Modelo_de_Dados_Conceitual.md`
- `016_API_Contract_Mestre.md`
- `019_Superprompt_Tecnico_de_Geracao_Lego.md`

## 2.2 Ordem visível no nome

Sempre que a ordem de leitura ou execução for importante, ela deve aparecer no nome.

A ordenação não pode depender apenas de memória humana.

## 2.3 Um nome deve indicar função

Todo nome deve comunicar, com o máximo de precisão possível, a função do artefato.

Quem lê o nome deve entender rapidamente:

- o que é;
- para que serve;
- em que camada está;
- qual sua posição relativa dentro da estrutura.

## 2.4 Estabilidade sem rigidez cega

Os nomes devem ser estáveis, mas podem evoluir quando houver ganho real de clareza, rastreabilidade ou coerência metodológica.

Toda mudança de nome deve ser rara, justificada e controlada.

---

## 3. Padrão Oficial de Pastas

## 3.1 Convenção geral

As pastas devem usar o padrão:

`NN-Nome_Canonico`

Onde:

- `NN` = índice numérico de ordenação;
- `Nome_Canonico` = nome descritivo, sem ambiguidade, com palavras separadas por underscore quando necessário.

Exemplos:

- `00-Padrao`
- `01-Obrigatorios`
- `02-Altamente_Relevantes`
- `03-Complementares`
- `04-High_Tech`

## 3.2 Regras para nomes de pastas

Pastas devem:

- usar numeração quando houver ordem estrutural;
- evitar acentos quando a finalidade for compatibilidade técnica ampla;
- evitar caracteres especiais desnecessários;
- evitar espaços quando houver risco operacional em terminal, scripts ou automações;
- refletir exatamente sua função.

## 3.3 É proibido em pastas

É proibido usar:

- nomes genéricos demais;
- variações semânticas equivalentes em pastas diferentes;
- siglas obscuras sem glossário;
- nomes temporários permanentes;
- sufixos improvisados como `novo`, `novo2`, `agora`, `definitivo`, `final_final`.

---

## 4. Padrão Oficial de Arquivos Documentais

## 4.1 Convenção geral

Arquivos documentais devem usar o padrão:

`NNN_Titulo_Descritivo.md`

Onde:

- `NNN` = índice numérico com três dígitos;
- `Titulo_Descritivo` = nome canônico do documento;
- `.md` = extensão padrão para documentação textual principal.

Exemplos:

- `000_Indice_Mestre.md`
- `001_Manifesto_Metodologico_Waterfall_Caracol.md`
- `002_Regra_de_Nomenclatura_e_Versionamento.md`
- `016_API_Contract_Mestre.md`

## 4.2 Regra de capitalização

Em nomes de arquivos documentais, cada palavra principal deve começar com letra maiúscula.

Exemplo:

- correto: `010_Template_Arquitetura_Geral.md`
- incorreto: `010_template_arquitetura_geral.md`

## 4.3 Uso de underscore

O underscore `_` é o separador oficial entre palavras em nomes de arquivos documentais.

Não usar hífen no corpo do nome do arquivo documental, salvo quando houver necessidade técnica ou nomenclatura previamente consagrada.

## 4.4 Títulos devem ser funcionais

O título do arquivo deve indicar o tipo real do documento.

Exemplos de tipos aceitos:

- `Indice`
- `Manifesto`
- `Template`
- `Plano`
- `Matriz`
- `Arquitetura`
- `Contrato`
- `Politica`
- `Protocolo`
- `Checklist`
- `Runbook`
- `Glossario`
- `Roadmap`

---

## 5. Padrão Oficial de Numeração

## 5.1 Três dígitos para documentos

Todo documento principal deve ser numerado com três dígitos:

- `000`
- `001`
- `002`
- `003`
- ...
- `024`
- `105`

Isso garante:

- ordenação estável;
- previsibilidade;
- escalabilidade;
- leitura visual limpa.

## 5.2 Dois dígitos para grandes grupos de pastas

Pastas de primeiro nível podem usar dois dígitos:

- `00-Padrao`
- `01-Obrigatorios`
- `02-Altamente_Relevantes`

## 5.3 Numeração é semântica, não decorativa

A numeração deve refletir ordem de precedência, leitura, execução ou agrupamento metodológico.

Não usar números aleatórios apenas para “organizar visualmente”.

## 5.4 Uma vez congelado, não renumerar levianamente

Depois que uma sequência estiver consolidada, a renumeração ampla deve ser evitada.

Se um novo documento precisar entrar entre dois existentes, há três caminhos preferenciais:

1. alocá-lo em posição futura mais adequada;
2. inseri-lo em subestrutura coerente;
3. só renumerar tudo se o ganho estrutural for realmente superior ao custo de ruptura.

---

## 6. Padrão Oficial para Versões

## 6.1 Convenção canônica

As versões devem usar o padrão:

`vMAJOR.MINOR`

Opcionalmente, em casos específicos:

`vMAJOR.MINOR.PATCH`

Exemplos:

- `v1.0`
- `v1.1`
- `v2.0`
- `v2.1.3`

## 6.2 Significado das partes

### MAJOR
Mudança estrutural importante.

Usar quando houver:

- revisão forte de arquitetura;
- alteração relevante de método;
- redefinição de escopo central;
- quebra de compatibilidade conceitual.

### MINOR
Evolução incremental compatível.

Usar quando houver:

- ampliação de conteúdo;
- melhora de precisão;
- inclusão de seções;
- refinamento sem ruptura estrutural.

### PATCH
Ajuste fino sem impacto estrutural.

Usar quando houver:

- correções textuais;
- ajustes pequenos de clareza;
- correção de inconsistência local;
- normalização semântica de baixo impacto.

## 6.3 Regra prática para documentos

Como regra geral deste projeto:

- documentos nascem em `v1.0`;
- refinamentos normais sobem para `v1.1`, `v1.2`, etc.;
- grandes reformulações sobem para `v2.0`;
- PATCH só será usado quando houver real necessidade de rastreio fino.

---

## 7. Versionamento de Documentos

## 7.1 A versão deve aparecer no conteúdo do documento

A versão oficial do documento deve estar registrada dentro do próprio arquivo, no bloco de identificação.

## 7.2 Evitar versões no nome do arquivo

Salvo exceção muito justificada, não inserir versão no nome do arquivo.

Exemplos proibidos como padrão:

- `001_Manifesto_v2.md`
- `016_API_Contract_Mestre_FINAL.md`
- `013_Modelo_de_Dados_Conceitual_novo.md`

O nome do arquivo deve permanecer estável.

A evolução deve ser controlada pelo conteúdo, histórico, governança e, quando aplicável, versionamento do repositório.

## 7.3 Exceções raras

Versão no nome do arquivo só será aceitável quando houver coexistência legítima entre artefatos diferentes, e não mera revisão do mesmo artefato.

Exemplo aceitável:

- `Contrato_OpenAPI_Publica_v1.yaml`
- `Contrato_OpenAPI_Publica_v2.yaml`

Neste caso há duas versões operacionais distintas coexistindo.

---

## 8. Padrão Oficial para Nomes Técnicos de Código

## 8.1 Pastas técnicas

Para código, os nomes devem seguir a convenção mais adequada à linguagem e ao ecossistema adotado, mas sempre respeitando clareza e estabilidade.

Exemplos possíveis:

- `components`
- `services`
- `repositories`
- `use-cases`
- `entities`
- `shared`
- `contracts`

## 8.2 Componentes, módulos e entidades

A convenção exata será definida mais adiante por stack, mas já ficam princípios obrigatórios:

- um nome = uma responsabilidade principal;
- evitar abreviações obscuras;
- evitar plural/singular inconsistentes;
- evitar nomes que escondam fronteiras.

## 8.3 Proibição de nomes fracos em código

São proibidos nomes como:

- `utils2`
- `helperNovo`
- `coisa`
- `dadosTemp`
- `testeReal`
- `controllerNovoFinal`

Nome técnico ruim é dívida técnica semântica.

---

## 9. Padrão Oficial para ADRs e Decisões

## 9.1 Estrutura recomendada

ADRs devem seguir padrão estável, como por exemplo:

`ADR_001_Titulo_Descritivo.md`

ou, caso o projeto mantenha a convenção unificada:

`001_ADR_Titulo_Descritivo.md`

A convenção escolhida deve ser única e coerente em todo o repositório.

## 9.2 Regra de decisão

Toda decisão importante deve ter:

- nome claro;
- status;
- contexto;
- decisão tomada;
- consequências.

---

## 10. Padrão Oficial para Templates

Templates devem conter explicitamente a palavra `Template` no nome.

Exemplos:

- `003_Template_Documento_Padrao.md`
- `010_Template_Arquitetura_Geral.md`
- `020_Template_Superprompt_de_Geracao.md`

Isso evita confundir:

- documento-base real;
- documento-modelo reutilizável.

---

## 11. Padrão Oficial para Matrizes, Planos e Protocolos

## 11.1 Matrizes

Usar `Matriz` quando o documento organizar relações entre elementos.

Exemplos:

- requisitos x módulos;
- papéis x permissões;
- testes x critérios de aceite.

## 11.2 Planos

Usar `Plano` quando o documento definir intenção estruturada de execução.

Exemplos:

- plano de implantação;
- plano de testes;
- plano de evolução.

## 11.3 Protocolos

Usar `Protocolo` quando o documento definir procedimento formal, regra processual ou rito operacional.

---

## 12. Idioma Oficial dos Nomes

## 12.1 Regra geral

A documentação interna principal deste projeto usa português do Brasil como idioma base.

## 12.2 Exceções permitidas

Termos em inglês podem ser usados quando:

- forem padrão técnico consolidado;
- trouxerem mais precisão que a tradução;
- já fizerem parte do vocabulário do projeto.

Exemplos aceitáveis:

- `High_Tech`
- `API_Contract`
- `Definition_of_Done`
- `Runbook`
- `Roadmap`

## 12.3 Proibição de mistura caótica

Não misturar português e inglês de forma arbitrária no mesmo nome quando isso gerar estranheza ou ambiguidade.

---

## 13. Caracteres Permitidos e Restrições

## 13.1 Permitidos em nomes documentais

Preferência por:

- letras;
- números;
- underscore `_`;
- hífen `-` apenas em contextos estruturais adequados;
- ponto `.` para extensão.

## 13.2 Evitar

Evitar, salvo necessidade extrema:

- espaços em nomes técnicos;
- acentos em estruturas altamente automatizadas;
- parênteses;
- símbolos especiais;
- caracteres ambíguos.

## 13.3 Regra de compatibilidade

Sempre que houver dúvida entre beleza visual e robustez operacional, prevalece a robustez operacional.

---

## 14. Regras de Renomeação

## 14.1 Quando renomear

Renomear somente quando houver:

- aumento real de clareza;
- correção de erro estrutural;
- alinhamento metodológico necessário;
- eliminação de ambiguidade relevante.

## 14.2 Quando não renomear

Não renomear por:

- capricho momentâneo;
- gosto pessoal isolado;
- sensação de “ficaria mais bonito” sem ganho real;
- impulso de reorganização infinita.

## 14.3 Toda renomeação relevante exige

- verificação de impacto em referências internas;
- atualização do índice mestre, se necessário;
- atualização dos documentos relacionados;
- preservação da rastreabilidade.

---

## 15. Regras de Continuidade

A nomenclatura deve favorecer a continuidade entre ciclos, chats, equipes e fases do projeto.

Um bom nome deve permitir que, meses depois, ainda seja possível compreender:

- a função do artefato;
- seu papel no sistema;
- sua posição dentro da estrutura;
- sua relação com outros documentos e módulos.

Nome ruim destrói continuidade.

---

## 16. Checklist de Conformidade de Nomeação

Antes de criar ou renomear qualquer artefato, verificar:

1. o nome indica claramente a função?
2. o nome respeita a convenção da camada?
3. a numeração está correta?
4. há conflito com nomes existentes?
5. o nome favorece ordenação e busca?
6. o nome evita ambiguidade?
7. a convenção escolhida é consistente com o restante do projeto?
8. o nome ajuda a continuidade futura?

Se a resposta for “não” em qualquer ponto relevante, o nome ainda não está bom.

---

## 17. Declaração Final

A partir deste documento, fica estabelecido que o projeto adotará nomenclatura disciplinada, semântica, ordenável, rastreável e metodologicamente coerente.

Nomes não serão tratados como detalhe secundário.

Eles serão tratados como parte da arquitetura da informação, da governança documental e da engenharia do próprio sistema.

---

## 18. Status deste Documento

Este documento entra em vigor imediatamente como norma oficial de nomenclatura e versionamento do projeto.

Toda criação futura de pastas, documentos, módulos e artefatos deverá respeitar suas regras, salvo revisão formal explícita.
