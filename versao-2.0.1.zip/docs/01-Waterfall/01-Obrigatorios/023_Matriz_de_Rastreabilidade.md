# 023_Matriz_de_Rastreabilidade

## Identificação do Documento

- **Projeto:** William Albarello
- **Camada:** 01-Waterfall
- **Subpasta:** 01-Obrigatorios
- **Documento:** 023_Matriz_de_Rastreabilidade.md
- **Função:** Definir a matriz soberana de rastreabilidade do projeto, conectando visão, requisitos, regras de negócio, fluxos, arquitetura, contratos, testes, aceite, implantação e evolução, para impedir perda de contexto, cobertura órfã, entrega sem fundamento e validação sem lastro
- **Status:** ATIVO
- **Versão:** v1.0
- **Autoridade:** Alta
- **Natureza:** Documento soberano de rastreabilidade estrutural, funcional, contratual e operacional
- **Dependência superior:**
  - 000_Indice_Mestre.md
  - 001_Manifesto_Metodologico_Waterfall_Caracol.md
  - 002_Regra_de_Nomenclatura_e_Versionamento.md
  - 024_Politica_de_Governanca_Documental.md
  - 001_Visao_Geral_do_Projeto.md
  - 002_Problema_Oportunidade_e_Tese_Central.md
  - 003_Objetivos_Estrategicos_e_Resultados_Esperados.md
  - 004_Escopo_e_Fora_de_Escopo.md
  - 005_Stakeholders_Perfis_e_Atores_do_Sistema.md
  - 006_Requisitos_Funcionais.md
  - 007_Requisitos_Nao_Funcionais.md
  - 008_Regras_de_Negocio.md
  - 009_Casos_de_Uso_Macro.md
  - 010_Jornadas_do_Usuario_e_Fluxos_Principais.md
  - 011_Arquitetura_Geral_do_Sistema.md
  - 012_Modulos_Dominios_e_Limites_do_Software.md
  - 013_Modelo_de_Dados_Conceitual.md
  - 014_Integracoes_e_Sistemas_Externos.md
  - 015_Seguranca_Privacidade_Auditoria_e_Permissoes.md
  - 016_API_Contract_Mestre.md
  - 017_UI_UX_Arquitetura_da_Informacao.md
  - 018_Plano_de_Testes_Homologacao_e_Qualidade.md
  - 019_Riscos_Premissas_Restricoes_e_Mitigacoes.md
  - 020_Cronograma_Fases_Marcos_e_Sequenciamento.md
  - 021_Criterios_de_Aceite_Gerais.md
  - 022_Plano_de_Implantacao_Rollback_e_Suporte.md
- **Dependências relacionadas:**
  - 024_Registro_de_Decisoes_Arquiteturais.md

---

## 1. Finalidade

Este documento existe para impedir que o projeto **William Albarello** produza muito material e, ainda assim, perca a capacidade de responder com precisão a perguntas fundamentais como:

- de onde veio este requisito;
- qual regra de negócio sustenta esta funcionalidade;
- qual fluxo operacionaliza esta decisão;
- qual contrato de API implementa este comportamento;
- qual tela consome este recurso;
- qual teste valida este item;
- qual critério de aceite decide sua aprovação;
- qual implantação colocou isso em operação;
- qual decisão arquitetural explica a forma final adotada.

Em outras palavras:

> este documento existe para garantir que nada importante no projeto exista solto.

A matriz de rastreabilidade transforma a obra em sistema coerente de relações.
Ela impede:

- requisito órfão;
- teste sem alvo;
- API sem fundamento;
- tela sem contrato;
- aceite sem lastro;
- publicação sem origem;
- evolução sem memória.

---

## 2. Tese Central do Documento

A tese central deste documento é a seguinte:

> o projeto William Albarello só poderá evoluir com maturidade se cada artefato relevante puder ser rastreado para trás, até sua razão de existir, e para frente, até sua forma de validação, aceite, implantação e sustentação.

Isso significa que a rastreabilidade neste projeto não é burocracia.

Ela é:

1. **proteção contra perda de contexto**;
2. **proteção contra contradição entre camadas**;
3. **proteção contra retrabalho cego**;
4. **proteção contra aceite ilusório**;
5. **proteção contra evolução sem fundamento**.

Sem rastreabilidade, o projeto pode até parecer avançado.
Mas ficará estruturalmente vulnerável a uma pergunta fatal:

> “isso existe por quê, para quê, onde, como e com que prova?”

---

## 3. Papel Estrutural Deste Documento

Este documento ocupa a camada que costura todo o corpo soberano do projeto.

Ele liga:

- visão;
- tese;
- objetivos;
- escopo;
- perfis;
- requisitos;
- regras de negócio;
- casos de uso;
- jornadas;
- arquitetura;
- dados;
- integrações;
- segurança;
- contratos de API;
- arquitetura da informação;
- testes;
- riscos;
- cronograma;
- critérios de aceite;
- implantação;
- decisões arquiteturais.

Ele responde às seguintes perguntas soberanas:

### 3.1 O que justifica este item?

Seu vínculo com visão, objetivo, requisito, regra ou fluxo.

### 3.2 Onde este item se materializa?

Em módulos, APIs, telas, dados, componentes ou operações.

### 3.3 Como este item é validado?

Por teste, homologação, checklist, evidência ou critério de aceite.

### 3.4 Como este item evolui sem perder o sentido?

Por decisão registrada, impacto conhecido e relação explícita com a estrutura da obra.

---

## 4. Escopo do Documento

Este documento cobre rastreabilidade entre:

- documentos obrigatórios;
- requisitos funcionais;
- requisitos não funcionais;
- regras de negócio;
- fluxos críticos;
- módulos do sistema;
- entidades centrais;
- rotas de API;
- superfícies pública e administrativa;
- testes e homologação;
- critérios de aceite;
- riscos relevantes;
- implantação e suporte;
- ADRs.

Este documento **não substitui**:

- catálogo técnico detalhado de cada endpoint;
- suite de testes completa;
- backlog operacional;
- runbooks específicos;
- documentação de código.

Ele define a **estrutura soberana da rastreabilidade**.

---

## 5. Definições Soberanas

Para evitar ambiguidade, o projeto adotará as definições abaixo.

### 5.1 Rastreabilidade

Capacidade de seguir um item para trás, até sua origem lógica, e para frente, até sua implementação, validação, aceite e operação.

### 5.2 Item fonte

Artefato ou decisão que justifica a existência de outro item.

### 5.3 Item derivado

Artefato que nasce da necessidade expressa em um item fonte.

### 5.4 Cobertura

Estado em que um item possui relação explícita com artefatos que o implementam, validam ou governam.

### 5.5 Lacuna de rastreabilidade

Situação em que um item relevante não consegue ser relacionado de forma clara ao restante do sistema.

### 5.6 Órfão

Item sem origem justificável ou sem downstream verificável.

### 5.7 Vínculo de rastreabilidade

Ligação formal entre dois ou mais artefatos.

### 5.8 Cadeia de rastreabilidade

Sequência lógica que conecta origem, materialização, validação e aceite de um item.

---

## 6. Princípios Soberanos de Rastreabilidade

Os princípios abaixo tornam-se obrigatórios.

### 6.1 Nada central deve existir órfão

Se é importante, precisa estar ligado a algo que o justifique e algo que o valide.

### 6.2 A matriz não é decorativa

Ela deve servir para decisão real, auditoria real e continuidade real.

### 6.3 Quanto maior o impacto, maior a exigência de rastreio

Itens críticos precisam de vínculo explícito mais forte.

### 6.4 Rastreabilidade serve tanto para construção quanto para correção

Ela ajuda a construir certo e ajuda a corrigir sem destruir o restante.

### 6.5 Mudança sem impacto conhecido é risco

Se não sabemos o que uma alteração afeta, a alteração é estruturalmente perigosa.

### 6.6 Teste sem origem é ruído

Todo teste relevante deve poder apontar para requisito, fluxo, contrato ou risco.

### 6.7 API sem lastro é improviso

Toda rota relevante deve ter fundamento claro no domínio do projeto.

### 6.8 Aceite sem rastreio é frágil

A decisão de aceite deve poder ser defendida com vínculos explícitos.

---

## 7. Objetivos da Matriz de Rastreabilidade

Os objetivos soberanos desta matriz são:

1. conectar visão e execução;
2. impedir perda de sentido ao longo dos ciclos;
3. mostrar cobertura entre requisito e validação;
4. mostrar cobertura entre contrato e tela;
5. mostrar relação entre risco e mitigação;
6. mostrar relação entre aceite e evidência;
7. preparar o projeto para evolução disciplinada;
8. permitir auditoria interna da coerência do corpus.

---

## 8. Dimensões Oficiais de Rastreabilidade do Projeto

O projeto reconhecerá as seguintes dimensões de rastreabilidade.

### 8.1 Rastreabilidade estratégica

Visão, tese, objetivos e escopo.

### 8.2 Rastreabilidade funcional

Requisitos, regras de negócio, casos de uso e jornadas.

### 8.3 Rastreabilidade arquitetural

Arquitetura, módulos, domínios, dados, integrações e segurança.

### 8.4 Rastreabilidade contratual

APIs, payloads, rotas, status, envelopes, fluxos entre camadas.

### 8.5 Rastreabilidade experiencial

Rotas, telas, componentes, estados de interface, fluxos UX.

### 8.6 Rastreabilidade de qualidade

Testes, homologação, evidências e defeitos.

### 8.7 Rastreabilidade decisória

Critérios de aceite, implantação, rollback, ADRs e mudanças de fase.

---

## 9. Estrutura Oficial da Matriz

A matriz deste projeto deve ser lida em duas direções.

### 9.1 Rastreabilidade para trás

Pergunta:

> “de onde veio isso?”

Exemplos:

- esta API veio de qual requisito?
- esta tela veio de qual fluxo?
- esta regra veio de qual necessidade estratégica?

### 9.2 Rastreabilidade para frente

Pergunta:

> “isso impacta o quê?”

Exemplos:

- este requisito impacta quais APIs?
- esta regra impacta quais testes?
- esta decisão arquitetural altera quais módulos?

---

## 10. Classes de Vínculo Reconhecidas

A matriz reconhecerá, no mínimo, os seguintes tipos de vínculo.

### 10.1 Justifica

Um item dá razão de existência a outro.

### 10.2 Deriva em

Um item é desdobrado em outro.

### 10.3 Materializa em

Um item ganha forma concreta em outro.

### 10.4 Valida por

Um item é verificado por outro.

### 10.5 Aceita por

Um item é formalmente decidido por outro.

### 10.6 Mitiga por

Um item reduz o risco de outro.

### 10.7 Restringe

Um item limita ou condiciona outro.

### 10.8 É impactado por

Um item sofre efeito de mudança em outro.

---

## 11. Nomenclatura de Referência para Itens Rastreáveis

Para facilitar a leitura operacional, o projeto adota os seguintes prefixos conceituais.

- **OBJ** = Objetivo estratégico
- **RF** = Requisito funcional
- **RNF** = Requisito não funcional
- **RN** = Regra de negócio
- **UC** = Caso de uso macro
- **FUX** = Fluxo/Jornada UX crítica
- **MOD** = Módulo ou domínio arquitetural
- **ENT** = Entidade conceitual
- **API-PUB** = Rota/contrato de API pública
- **API-ADM** = Rota/contrato de API administrativa
- **UI-PUB** = Tela/área pública
- **UI-ADM** = Tela/área administrativa
- **TST** = Teste/checklist/homologação
- **ACE** = Critério ou decisão de aceite
- **RISK** = Risco relevante
- **DEP** = Ato de implantação/deploy/rollback
- **ADR** = Decisão arquitetural registrada

Essa nomenclatura é lógica e operacional.
Não precisa substituir a documentação superior, mas deve ajudá-la.

---

## 12. Fontes de Autoridade da Matriz

A matriz deverá ser sempre derivada, prioritariamente, de:

1. `003_Objetivos_Estrategicos_e_Resultados_Esperados.md`
2. `006_Requisitos_Funcionais.md`
3. `007_Requisitos_Nao_Funcionais.md`
4. `008_Regras_de_Negocio.md`
5. `009_Casos_de_Uso_Macro.md`
6. `010_Jornadas_do_Usuario_e_Fluxos_Principais.md`
7. `011_Arquitetura_Geral_do_Sistema.md`
8. `012_Modulos_Dominios_e_Limites_do_Software.md`
9. `013_Modelo_de_Dados_Conceitual.md`
10. `015_Seguranca_Privacidade_Auditoria_e_Permissoes.md`
11. `016_API_Contract_Mestre.md`
12. `017_UI_UX_Arquitetura_da_Informacao.md`
13. `018_Plano_de_Testes_Homologacao_e_Qualidade.md`
14. `019_Riscos_Premissas_Restricoes_e_Mitigacoes.md`
15. `020_Cronograma_Fases_Marcos_e_Sequenciamento.md`
16. `021_Criterios_de_Aceite_Gerais.md`
17. `022_Plano_de_Implantacao_Rollback_e_Suporte.md`

---

## 13. Critérios Gerais de Boa Rastreabilidade

Um item será considerado bem rastreado quando, no mínimo, for possível identificar:

1. sua origem;
2. sua função;
3. sua materialização;
4. seu método de validação;
5. seu critério de aceite;
6. seus riscos relevantes;
7. seu impacto de mudança.

---

## 14. Lacunas de Rastreabilidade Expressamente Rejeitadas

Ficam rejeitadas, desde já, as seguintes situações:

- requisito sem fluxo correspondente;
- fluxo sem interface ou contrato correspondente;
- API sem requisito ou regra de negócio;
- tela sem fundamento funcional;
- teste sem item-alvo claro;
- aceite sem evidência ou referência;
- implantação sem escopo vinculado;
- decisão arquitetural sem contexto de problema;
- item central sem qualquer downstream conhecido.

---

## 15. Matriz Mestra — Objetivos Estratégicos até Entregas

Abaixo está a primeira camada soberana da matriz: da estratégia até a materialização.

### 15.1 OBJ-01 — Construir base digital soberana de presença, autoridade e organização

- **Deriva em:** RF ligados à camada pública institucional, editorial e relacional
- **Materializa em:** Home, Sobre, Projetos, Conteúdos/Publicações, Contato
- **Conecta com módulos:** MOD-Publico, MOD-Conteudo, MOD-Contato
- **Conecta com APIs:** API-PUB Pages, Publications, Contact
- **Valida por:** TST navegação pública, TST leitura editorial, TST contato
- **Aceita por:** ACE camada pública + ACE fluxos F01, F02, F03

### 15.2 OBJ-02 — Organizar operação interna com clareza e governança

- **Deriva em:** RF ligados a login, dashboard, publicações, taxonomia e auditoria
- **Materializa em:** UI-ADM Login, Dashboard, Publicações, Categorias, Tags, Auditoria
- **Conecta com módulos:** MOD-Admin, MOD-Auth, MOD-Conteudo, MOD-Auditoria
- **Conecta com APIs:** API-ADM Auth, Dashboard, Publications, Categories, Tags, Audit Logs
- **Valida por:** TST login, TST gestão editorial, TST taxonomia, TST auditoria
- **Aceita por:** ACE camada administrativa + ACE fluxos F04, F05, F06, F07

### 15.3 OBJ-03 — Permitir evolução disciplinada com mínimo retrabalho

- **Deriva em:** RNF de modularidade, rastreabilidade, versionamento, segurança e qualidade
- **Materializa em:** arquitetura modular, matriz de rastreabilidade, ADRs, plano de testes, critérios de aceite
- **Conecta com módulos:** MOD-Core, MOD-API, MOD-UI, MOD-Governanca
- **Valida por:** TST documental, TST estrutural, revisão de coerência
- **Aceita por:** ACE bloco obrigatório, ACE governança de execução

---

## 16. Matriz Mestra — Requisitos Funcionais até Fluxos, APIs e Telas

A seguir, a matriz funcional central.

---

## 17. RF-01 a RF-05 — Presença Pública Institucional

### RF-PUB-01 — Exibir Home institucional coerente com a tese do projeto
- **Justificado por:** OBJ-01
- **Regras associadas:** RN de posicionamento, clareza institucional e conteúdo primeiro
- **Fluxo associado:** FUX-01 navegação institucional pública
- **API associada:** API-PUB-01 `GET /v1/public/pages/{key}` com `key=home`
- **Tela associada:** UI-PUB-01 Home
- **Testes associados:** TST-PUB-01 Home acessível; TST-UX-01 hero e hierarquia; TST-E2E-01 navegação inicial
- **Aceite associado:** ACE-PUB-01 Home comunica identidade com clareza

### RF-PUB-02 — Exibir página Sobre com identidade e direção
- **Justificado por:** OBJ-01
- **Fluxo associado:** FUX-01
- **API associada:** API-PUB-01 `GET /v1/public/pages/{key}` com `key=sobre`
- **Tela associada:** UI-PUB-02 Sobre
- **Testes associados:** TST-PUB-02 acesso à Sobre; TST-UX-02 leitura e hierarquia
- **Aceite associado:** ACE-PUB-02 página Sobre inteligível e não autobiográfica dispersa

### RF-PUB-03 — Exibir Projetos / frentes do ecossistema
- **Justificado por:** OBJ-01
- **Fluxo associado:** FUX-01
- **API associada:** API-PUB-01 `GET /v1/public/pages/{key}` com `key=projetos` ou recurso equivalente futuro
- **Tela associada:** UI-PUB-03 Projetos
- **Testes associados:** TST-PUB-03 listagem de projetos; TST-UX-03 cards compreensíveis
- **Aceite associado:** ACE-PUB-03 cada item explica o que é e por que existe

### RF-PUB-04 — Listar publicações públicas
- **Justificado por:** OBJ-01
- **Fluxo associado:** FUX-02 descoberta editorial
- **API associada:** API-PUB-02 `GET /v1/public/publications`
- **Tela associada:** UI-PUB-04 Lista de Publicações
- **Testes associados:** TST-API-PUB-02; TST-E2E-02 listagem; TST-UX-04 descoberta editorial
- **Aceite associado:** ACE-FUX-02

### RF-PUB-05 — Exibir publicação individual
- **Justificado por:** OBJ-01
- **Fluxo associado:** FUX-02
- **API associada:** API-PUB-03 `GET /v1/public/publications/{slug}`
- **Tela associada:** UI-PUB-05 Publicação Individual
- **Testes associados:** TST-API-PUB-03; TST-E2E-03 detalhe editorial; TST-UX-05 leitura longa
- **Aceite associado:** ACE-FUX-02

---

## 18. RF-06 a RF-09 — Continuidade Relacional Pública

### RF-PUB-06 — Exibir relacionados em publicação
- **Justificado por:** OBJ-01
- **Fluxo associado:** FUX-02
- **API associada:** API-PUB-04 `GET /v1/public/publications/{slug}/related`
- **Tela associada:** UI-PUB-05 bloco RelatedPublications
- **Testes associados:** TST-API-PUB-04; TST-UX-06 continuidade editorial
- **Aceite associado:** ACE-FUX-02 continuidade legítima

### RF-PUB-07 — Exibir Contato institucional
- **Justificado por:** OBJ-01
- **Fluxo associado:** FUX-03 contato público
- **API associada:** API-PUB-01 `GET /v1/public/pages/{key}` com `key=contato`
- **Tela associada:** UI-PUB-06 Contato
- **Testes associados:** TST-PUB-04 acesso a Contato
- **Aceite associado:** ACE-PUB-04 contato visível e compreensível

### RF-PUB-08 — Receber submissão de contato
- **Justificado por:** OBJ-01
- **Regra associada:** consentimento mínimo e validação de entrada
- **Fluxo associado:** FUX-03
- **API associada:** API-PUB-05 `POST /v1/public/contact`
- **Tela associada:** UI-PUB-06 ContactForm
- **Testes associados:** TST-API-PUB-05; TST-E2E-04 envio válido/inválido; TST-SEC-01 proteção básica da rota
- **Aceite associado:** ACE-FUX-03

### RF-PUB-09 — Fornecer feedback de sucesso e erro no contato
- **Justificado por:** OBJ-01 + RNF de UX
- **Fluxo associado:** FUX-03
- **Tela associada:** UI-PUB-06 estados `validation_error`, `error`, `success`
- **Testes associados:** TST-UX-07 estados do formulário; TST-E2E-04
- **Aceite associado:** ACE-FUX-03 + ACE-UX-01 estados explícitos

---

## 19. RF-10 a RF-16 — Operação Administrativa Básica

### RF-ADM-01 — Autenticar operador autorizado
- **Justificado por:** OBJ-02
- **Regra associada:** segurança, sessão e papéis
- **Fluxo associado:** FUX-04 login administrativo
- **API associada:** API-ADM-01 `POST /v1/admin/auth/login`
- **Tela associada:** UI-ADM-01 Login
- **Testes associados:** TST-API-ADM-01; TST-E2E-05 login; TST-SEC-02 autenticação
- **Aceite associado:** ACE-FUX-04

### RF-ADM-02 — Encerrar sessão administrativa
- **Justificado por:** OBJ-02
- **Fluxo associado:** FUX-04
- **API associada:** API-ADM-02 `POST /v1/admin/auth/logout`
- **Tela associada:** UI-ADM shell / ação Logout
- **Testes associados:** TST-API-ADM-02 logout; TST-SEC-03 encerramento de sessão
- **Aceite associado:** ACE-ADM-01 sessão íntegra

### RF-ADM-03 — Validar sessão administrativa corrente
- **Justificado por:** OBJ-02
- **Fluxo associado:** FUX-04
- **API associada:** API-ADM-03 `GET /v1/admin/auth/session`
- **Tela associada:** UI-ADM shell
- **Testes associados:** TST-API-ADM-03; TST-SEC-04 proteção de rota
- **Aceite associado:** ACE-ADM-01

### RF-ADM-04 — Exibir dashboard administrativo
- **Justificado por:** OBJ-02
- **Fluxo associado:** FUX-04 e FUX-05
- **API associada:** API-ADM-04 `GET /v1/admin/dashboard`
- **Tela associada:** UI-ADM-02 Dashboard
- **Testes associados:** TST-API-ADM-04; TST-UX-ADM-01 leitura do dashboard
- **Aceite associado:** ACE-ADM-02 dashboard legível e funcional

### RF-ADM-05 — Listar publicações no painel
- **Justificado por:** OBJ-02
- **Fluxo associado:** FUX-05 gestão editorial
- **API associada:** API-ADM-05 `GET /v1/admin/publications`
- **Tela associada:** UI-ADM-03 Lista de Publicações
- **Testes associados:** TST-API-ADM-05; TST-E2E-06 listagem admin
- **Aceite associado:** ACE-FUX-05

### RF-ADM-06 — Criar publicação
- **Justificado por:** OBJ-02
- **Fluxo associado:** FUX-05
- **API associada:** API-ADM-06 `POST /v1/admin/publications`
- **Tela associada:** UI-ADM-04 Editor de Publicação
- **Testes associados:** TST-API-ADM-06; TST-E2E-07 criação
- **Aceite associado:** ACE-FUX-05

### RF-ADM-07 — Editar publicação existente
- **Justificado por:** OBJ-02
- **Fluxo associado:** FUX-05
- **API associada:** API-ADM-07 `GET /v1/admin/publications/{id}` e API-ADM-08 `PUT /v1/admin/publications/{id}`
- **Tela associada:** UI-ADM-04 Editor de Publicação
- **Testes associados:** TST-API-ADM-07/08; TST-E2E-08 edição
- **Aceite associado:** ACE-FUX-05

### RF-ADM-08 — Alterar status editorial
- **Justificado por:** OBJ-02
- **Regra associada:** transições de status
- **Fluxo associado:** FUX-05
- **API associada:** API-ADM-09 `PATCH /v1/admin/publications/{id}/status`
- **Tela associada:** UI-ADM-04 e UI-ADM-03
- **Testes associados:** TST-API-ADM-09; TST-E2E-09 mudança de status
- **Aceite associado:** ACE-FUX-05 + ACE-RN-Status

### RF-ADM-09 — Governar categorias
- **Justificado por:** OBJ-02
- **Fluxo associado:** FUX-06 taxonomia
- **API associada:** API-ADM-10 a API-ADM-13
- **Tela associada:** UI-ADM-05 Categorias
- **Testes associados:** TST-API-ADM-CAT; TST-E2E-10 categorias
- **Aceite associado:** ACE-FUX-06

### RF-ADM-10 — Governar tags
- **Justificado por:** OBJ-02
- **Fluxo associado:** FUX-06 taxonomia
- **API associada:** API-ADM-14 a API-ADM-17
- **Tela associada:** UI-ADM-06 Tags
- **Testes associados:** TST-API-ADM-TAG; TST-E2E-11 tags
- **Aceite associado:** ACE-FUX-06

### RF-ADM-11 — Ler auditoria mínima
- **Justificado por:** OBJ-02
- **Fluxo associado:** FUX-07 auditoria
- **API associada:** API-ADM-18 `GET /v1/admin/audit-logs`
- **Tela associada:** UI-ADM-07 Auditoria
- **Testes associados:** TST-API-ADM-18; TST-E2E-12 auditoria
- **Aceite associado:** ACE-FUX-07

---

## 20. Matriz Mestra — Requisitos Não Funcionais até Evidência

Abaixo, o eixo RNF do projeto.

### RNF-01 — Clareza, legibilidade e coerência institucional
- **Materializa em:** UI pública, arquitetura da informação, copy funcional
- **Valida por:** TST-UX público, homologação visual e leitura
- **Aceita por:** ACE-UX-PUB

### RNF-02 — Separação nítida entre público e admin
- **Materializa em:** arquitetura, rotas, APIs, autenticação, payloads
- **Valida por:** TST-API, TST-SEC, revisão arquitetural
- **Aceita por:** ACE-ARCH-SEP + ACE-SEC-ADM

### RNF-03 — Segurança administrativa mínima
- **Materializa em:** sessão, autenticação, autorização, logout, proteção de rota
- **Valida por:** TST-SEC-02, 03, 04
- **Aceita por:** ACE-SEC-ADM

### RNF-04 — Rastreabilidade e continuidade
- **Materializa em:** este documento + ADRs + critérios de aceite + handoffs
- **Valida por:** revisão documental e coerência do corpus
- **Aceita por:** ACE-GOV-RASTREIO

### RNF-05 — Qualidade por evidência
- **Materializa em:** plano de testes, homologação, smoke, registros
- **Valida por:** existência e suficiência das evidências
- **Aceita por:** ACE-QUAL-01

### RNF-06 — Responsividade mínima
- **Materializa em:** layouts públicos e admin
- **Valida por:** TST-RESP-mobile/tablet/desktop
- **Aceita por:** ACE-UX-RESP

### RNF-07 — Acessibilidade base
- **Materializa em:** foco, contraste, labels, headings, navegação por teclado
- **Valida por:** TST-A11Y-base
- **Aceita por:** ACE-A11Y-01

### RNF-08 — Implantação controlada e reversível
- **Materializa em:** plano de implantação, smoke, rollback, suporte inicial
- **Valida por:** checklist de implantação e evidência de publicação
- **Aceita por:** ACE-DEP-01

---

## 21. Matriz Mestra — Regras de Negócio até Contratos e Testes

A seguir, o eixo das regras de negócio centrais.

### RN-01 — Apenas conteúdo publicável deve aparecer na superfície pública
- **Materializa em:** status editorial, filtros de API pública, renderização pública
- **APIs impactadas:** API-PUB-02, API-PUB-03
- **Telas impactadas:** UI-PUB-04, UI-PUB-05
- **Testes:** TST-RN-01 publicações não públicas invisíveis
- **Aceite:** ACE-RN-01

### RN-02 — Transição de status deve ser explícita e controlada
- **Materializa em:** API-ADM-09, editor admin, badges, listagem
- **Fluxo:** FUX-05
- **Testes:** TST-RN-02 mudança de status válida/inválida
- **Aceite:** ACE-RN-Status

### RN-03 — Slug deve ser semanticamente estável e tecnicamente único
- **Materializa em:** criação/edição de publicação e leitura pública
- **APIs impactadas:** API-ADM-06, 08; API-PUB-03
- **Testes:** TST-RN-03 slug único
- **Aceite:** ACE-RN-Slug

### RN-04 — Contato exige dados mínimos e consentimento proporcional
- **Materializa em:** ContactForm, API-PUB-05
- **Testes:** TST-RN-04 validação de campos e consentimento
- **Aceite:** ACE-FUX-03

### RN-05 — Taxonomia não deve degradar o acervo em caos semântico
- **Materializa em:** categorias, tags, filtros e associação editorial
- **Testes:** TST-RN-05 duplicidade e governança taxonômica
- **Aceite:** ACE-FUX-06

### RN-06 — Ação administrativa relevante deve ser auditável no mínimo necessário
- **Materializa em:** API-ADM-18, UI-ADM-07, módulo auditoria
- **Testes:** TST-RN-06 trilha mínima
- **Aceite:** ACE-FUX-07

---

## 22. Matriz Mestra — Fluxos Críticos até APIs, Telas e Aceite

---

## 23. FUX-01 — Navegação Institucional Pública

- **Origem:** OBJ-01 + RF públicos institucionais
- **Telas centrais:** UI-PUB-01 Home, UI-PUB-02 Sobre, UI-PUB-03 Projetos, UI-PUB-06 Contato
- **APIs centrais:** API-PUB-01
- **Testes centrais:** TST-E2E-01 navegação pública; TST-UX-01/02/03
- **Riscos associados:** RISK-R06 UX semanticamente fraca
- **Aceite:** ACE-FUX-01

### Critério de cobertura
Se qualquer uma das telas centrais ou sua navegação quebrar, FUX-01 fica parcialmente descoberto.

---

## 24. FUX-02 — Descoberta e Leitura Editorial

- **Origem:** OBJ-01 + RF-PUB-04/05/06
- **Telas centrais:** UI-PUB-04, UI-PUB-05
- **APIs centrais:** API-PUB-02, 03, 04
- **Testes centrais:** TST-E2E-02, 03; TST-API-PUB-02/03/04; TST-UX-04/05/06
- **Riscos associados:** RISK-R06, RISK-R10
- **Aceite:** ACE-FUX-02

---

## 25. FUX-03 — Contato Público

- **Origem:** OBJ-01 + RF-PUB-07/08/09 + RN-04
- **Tela central:** UI-PUB-06
- **API central:** API-PUB-05
- **Testes centrais:** TST-E2E-04; TST-API-PUB-05; TST-SEC-01
- **Riscos associados:** RISK-R08
- **Aceite:** ACE-FUX-03

---

## 26. FUX-04 — Login Administrativo

- **Origem:** OBJ-02 + RF-ADM-01/02/03 + RNF de segurança
- **Telas centrais:** UI-ADM-01 + shell admin
- **APIs centrais:** API-ADM-01, 02, 03
- **Testes centrais:** TST-E2E-05; TST-SEC-02/03/04
- **Riscos associados:** RISK-R07
- **Aceite:** ACE-FUX-04

---

## 27. FUX-05 — Gestão Editorial Administrativa

- **Origem:** OBJ-02 + RF-ADM-05/06/07/08 + RN-01/02/03
- **Telas centrais:** UI-ADM-03, UI-ADM-04
- **APIs centrais:** API-ADM-05, 06, 07, 08, 09
- **Testes centrais:** TST-E2E-06, 07, 08, 09; TST-RN-01/02/03
- **Riscos associados:** RISK-R04, RISK-R10
- **Aceite:** ACE-FUX-05

---

## 28. FUX-06 — Governança de Taxonomia

- **Origem:** OBJ-02 + RF-ADM-09/10 + RN-05
- **Telas centrais:** UI-ADM-05, UI-ADM-06
- **APIs centrais:** API-ADM-10 a 17
- **Testes centrais:** TST-E2E-10, 11; TST-RN-05
- **Riscos associados:** RISK-R09
- **Aceite:** ACE-FUX-06

---

## 29. FUX-07 — Auditoria Operacional

- **Origem:** OBJ-02 + RF-ADM-11 + RN-06
- **Tela central:** UI-ADM-07
- **API central:** API-ADM-18
- **Testes centrais:** TST-E2E-12; TST-RN-06
- **Riscos associados:** RISK-R10
- **Aceite:** ACE-FUX-07

---

## 30. Matriz Mestra — Módulos até Entidades, APIs e Telas

### MOD-01 — Público Institucional
- **Entidades relevantes:** ENT-Page, ENT-Project, ENT-IdentityBlock
- **APIs:** API-PUB-01
- **Telas:** UI-PUB-01, 02, 03
- **Fluxos:** FUX-01
- **Testes:** TST-PUB institucionais
- **Aceite:** ACE-PUB

### MOD-02 — Conteúdo Editorial
- **Entidades relevantes:** ENT-Publication, ENT-Category, ENT-Tag
- **APIs:** API-PUB-02/03/04; API-ADM-05 a 17
- **Telas:** UI-PUB-04/05; UI-ADM-03/04/05/06
- **Fluxos:** FUX-02, FUX-05, FUX-06
- **Testes:** TST-API, TST-E2E, TST-RN editoriais
- **Aceite:** ACE-EDITORIAL

### MOD-03 — Contato Relacional
- **Entidades relevantes:** ENT-ContactEntry
- **APIs:** API-PUB-05
- **Telas:** UI-PUB-06
- **Fluxos:** FUX-03
- **Testes:** TST contato
- **Aceite:** ACE-CONTACT

### MOD-04 — Autenticação e Sessão
- **Entidades relevantes:** ENT-AdminUser, ENT-Session
- **APIs:** API-ADM-01/02/03
- **Telas:** UI-ADM-01 + shell
- **Fluxos:** FUX-04
- **Testes:** TST-SEC + E2E login
- **Aceite:** ACE-SEC-ADM

### MOD-05 — Auditoria
- **Entidades relevantes:** ENT-AuditLog
- **APIs:** API-ADM-18
- **Telas:** UI-ADM-07
- **Fluxos:** FUX-07
- **Testes:** TST auditoria
- **Aceite:** ACE-AUDIT

---

## 31. Matriz Mestra — Entidades até Regras, APIs e Riscos

### ENT-01 — Publication
- **Requisitos associados:** RF-PUB-04/05/06, RF-ADM-05/06/07/08
- **Regras associadas:** RN-01, RN-02, RN-03
- **APIs associadas:** API-PUB-02/03/04; API-ADM-05/06/07/08/09
- **Telas associadas:** UI-PUB-04/05; UI-ADM-03/04
- **Riscos associados:** RISK-R03, R04, R10
- **Testes associados:** TST editoriais
- **Aceite associado:** ACE-EDITORIAL

### ENT-02 — Category
- **Requisitos associados:** RF-ADM-09
- **Regras associadas:** RN-05
- **APIs associadas:** API-ADM-10 a 13
- **Telas associadas:** UI-ADM-05
- **Riscos associados:** RISK-R09
- **Testes associados:** TST taxonomia
- **Aceite associado:** ACE-FUX-06

### ENT-03 — Tag
- **Requisitos associados:** RF-ADM-10
- **Regras associadas:** RN-05
- **APIs associadas:** API-ADM-14 a 17
- **Telas associadas:** UI-ADM-06
- **Riscos associados:** RISK-R09
- **Testes associados:** TST taxonomia
- **Aceite associado:** ACE-FUX-06

### ENT-04 — ContactEntry
- **Requisitos associados:** RF-PUB-08/09
- **Regras associadas:** RN-04
- **APIs associadas:** API-PUB-05
- **Telas associadas:** UI-PUB-06
- **Riscos associados:** RISK-R08
- **Testes associados:** TST contato
- **Aceite associado:** ACE-FUX-03

### ENT-05 — AdminUser / Session
- **Requisitos associados:** RF-ADM-01/02/03
- **Regras associadas:** segurança, menor privilégio
- **APIs associadas:** API-ADM-01/02/03
- **Telas associadas:** UI-ADM-01 + shell
- **Riscos associados:** RISK-R07
- **Testes associados:** TST-SEC
- **Aceite associado:** ACE-FUX-04

### ENT-06 — AuditLog
- **Requisitos associados:** RF-ADM-11
- **Regras associadas:** RN-06
- **APIs associadas:** API-ADM-18
- **Telas associadas:** UI-ADM-07
- **Riscos associados:** RISK-R10
- **Testes associados:** TST auditoria
- **Aceite associado:** ACE-FUX-07

---

## 32. Matriz Mestra — APIs até Telas, Testes e Aceite

### API-PUB-01 — `GET /v1/public/pages/{key}`
- **Origem:** RF-PUB-01/02/03/07
- **Telas consumidoras:** Home, Sobre, Projetos, Contato
- **Testes:** TST-API-PUB-01 + TST-E2E-01
- **Aceite:** ACE-PUB estruturais

### API-PUB-02 — `GET /v1/public/publications`
- **Origem:** RF-PUB-04
- **Telas consumidoras:** Lista de Publicações
- **Testes:** TST-API-PUB-02 + TST-E2E-02
- **Aceite:** ACE-FUX-02

### API-PUB-03 — `GET /v1/public/publications/{slug}`
- **Origem:** RF-PUB-05 + RN-03
- **Telas consumidoras:** Publicação individual
- **Testes:** TST-API-PUB-03 + TST-E2E-03
- **Aceite:** ACE-FUX-02

### API-PUB-04 — `GET /v1/public/publications/{slug}/related`
- **Origem:** RF-PUB-06
- **Telas consumidoras:** Publicação individual
- **Testes:** TST-API-PUB-04
- **Aceite:** ACE-FUX-02

### API-PUB-05 — `POST /v1/public/contact`
- **Origem:** RF-PUB-08/09 + RN-04
- **Telas consumidoras:** ContactForm
- **Testes:** TST-API-PUB-05 + TST-E2E-04 + TST-SEC-01
- **Aceite:** ACE-FUX-03

### API-ADM-01/02/03 — auth admin
- **Origem:** RF-ADM-01/02/03
- **Telas consumidoras:** Login + shell
- **Testes:** TST-SEC-02/03/04 + TST-E2E-05
- **Aceite:** ACE-FUX-04

### API-ADM-04 — dashboard
- **Origem:** RF-ADM-04
- **Telas consumidoras:** Dashboard
- **Testes:** TST-API-ADM-04
- **Aceite:** ACE-ADM-02

### API-ADM-05 a 09 — publicações admin
- **Origem:** RF-ADM-05/06/07/08 + RN editoriais
- **Telas consumidoras:** Lista e Editor de Publicação
- **Testes:** TST-API-ADM-PUB + TST-E2E-06 a 09
- **Aceite:** ACE-FUX-05

### API-ADM-10 a 17 — taxonomia admin
- **Origem:** RF-ADM-09/10 + RN-05
- **Telas consumidoras:** Categorias e Tags
- **Testes:** TST-API-ADM-CAT/TAG + TST-E2E-10/11
- **Aceite:** ACE-FUX-06

### API-ADM-18 — auditoria
- **Origem:** RF-ADM-11 + RN-06
- **Telas consumidoras:** Auditoria
- **Testes:** TST-API-ADM-18 + TST-E2E-12
- **Aceite:** ACE-FUX-07

---

## 33. Matriz Mestra — Telas até APIs, Fluxos e Critérios de Aceite

### UI-PUB-01 — Home
- **Depende de:** API-PUB-01
- **Fluxo:** FUX-01
- **RNF:** clareza institucional, legibilidade, conteúdo primeiro
- **Testes:** TST-PUB-01, TST-UX-01, TST-RESP-01
- **Aceite:** ACE-PUB-01

### UI-PUB-04 — Lista de Publicações
- **Depende de:** API-PUB-02
- **Fluxo:** FUX-02
- **RNF:** descoberta, filtros legíveis, paginação usável
- **Testes:** TST-UX-04, TST-E2E-02
- **Aceite:** ACE-FUX-02

### UI-PUB-05 — Publicação Individual
- **Depende de:** API-PUB-03/04
- **Fluxo:** FUX-02
- **RNF:** leitura longa, relateds coerentes
- **Testes:** TST-UX-05/06, TST-E2E-03
- **Aceite:** ACE-FUX-02

### UI-PUB-06 — Contato
- **Depende de:** API-PUB-05
- **Fluxo:** FUX-03
- **RNF:** feedback explícito, validação por campo
- **Testes:** TST-E2E-04, TST-UX-07
- **Aceite:** ACE-FUX-03

### UI-ADM-01 — Login
- **Depende de:** API-ADM-01/02/03
- **Fluxo:** FUX-04
- **RNF:** segurança, clareza, erro seguro
- **Testes:** TST-E2E-05, TST-SEC
- **Aceite:** ACE-FUX-04

### UI-ADM-03 — Lista de Publicações
- **Depende de:** API-ADM-05
- **Fluxo:** FUX-05
- **RNF:** eficiência operacional
- **Testes:** TST-E2E-06
- **Aceite:** ACE-FUX-05

### UI-ADM-04 — Editor de Publicação
- **Depende de:** API-ADM-06/07/08/09
- **Fluxo:** FUX-05
- **RNF:** validação, segurança de edição, clareza de estado
- **Testes:** TST-E2E-07/08/09
- **Aceite:** ACE-FUX-05

### UI-ADM-05 / 06 — Categorias / Tags
- **Depende de:** APIs taxonômicas
- **Fluxo:** FUX-06
- **RNF:** governança semântica
- **Testes:** TST-E2E-10/11
- **Aceite:** ACE-FUX-06

### UI-ADM-07 — Auditoria
- **Depende de:** API-ADM-18
- **Fluxo:** FUX-07
- **RNF:** confiança operacional
- **Testes:** TST-E2E-12
- **Aceite:** ACE-FUX-07

---

## 34. Matriz Mestra — Testes até Requisitos e Aceite

Abaixo, a leitura inversa: do teste até sua razão.

### TST-E2E-01 — Navegação institucional pública
- **Valida:** RF-PUB-01/02/03/07
- **Fluxo:** FUX-01
- **Aceite habilitado:** ACE-FUX-01
- **Riscos mitigados:** RISK-R06, R15

### TST-E2E-02/03 — Descoberta e leitura editorial
- **Valida:** RF-PUB-04/05/06
- **Fluxo:** FUX-02
- **Aceite habilitado:** ACE-FUX-02
- **Riscos mitigados:** RISK-R06, R10

### TST-E2E-04 — Contato público
- **Valida:** RF-PUB-08/09 + RN-04
- **Fluxo:** FUX-03
- **Aceite habilitado:** ACE-FUX-03
- **Riscos mitigados:** RISK-R08

### TST-E2E-05 — Login administrativo
- **Valida:** RF-ADM-01/02/03
- **Fluxo:** FUX-04
- **Aceite habilitado:** ACE-FUX-04
- **Riscos mitigados:** RISK-R07

### TST-E2E-06 a 09 — Gestão editorial
- **Valida:** RF-ADM-05/06/07/08 + RN-01/02/03
- **Fluxo:** FUX-05
- **Aceite habilitado:** ACE-FUX-05
- **Riscos mitigados:** RISK-R04, R10

### TST-E2E-10/11 — Taxonomia
- **Valida:** RF-ADM-09/10 + RN-05
- **Fluxo:** FUX-06
- **Aceite habilitado:** ACE-FUX-06
- **Riscos mitigados:** RISK-R09

### TST-E2E-12 — Auditoria
- **Valida:** RF-ADM-11 + RN-06
- **Fluxo:** FUX-07
- **Aceite habilitado:** ACE-FUX-07
- **Riscos mitigados:** RISK-R10

---

## 35. Matriz Mestra — Riscos até Mitigação, Teste e Gate

### RISK-R01 — Divergência entre documento e estado real do acervo
- **Mitigado por:** revisão documental, checagem material de arquivos, continuidade controlada
- **Testes/checagens associadas:** TST-DOC-01 integridade do acervo
- **Critério de aceite associado:** ACE-DOC-REALIDADE
- **Gate associado:** Gate de fechamento do obrigatório

### RISK-R02 — Crescimento de escopo sem fechamento do núcleo
- **Mitigado por:** cronograma soberano, gates e precedência
- **Critério associado:** ACE-FASE-01 só após fechamento real
- **Documento controlador:** 020

### RISK-R03 — Dependência excessiva do legado
- **Mitigado por:** harmonização curada
- **Critério associado:** ACE-GOV-LEGADO
- **Documento controlador:** 019 + 024

### RISK-R04 — Implementação mais rápida que arquitetura
- **Mitigado por:** fechamento de 016, 017, 018, 021, 023, 024 antes da explosão de código
- **Critério associado:** ACE-EXEC-CONTROL
- **Gate associado:** Gate de execução controlada

### RISK-R07 — Falha na proteção do fluxo administrativo
- **Mitigado por:** TST-SEC, homologação admin, ACE-SEC-ADM
- **Gate associado:** publicação bloqueada sem segurança mínima

### RISK-R08 — Falha do fluxo de contato
- **Mitigado por:** TST-E2E-04, API contract, ACE-FUX-03
- **Gate associado:** implantação pública bloqueada

### RISK-R10 — Falha de rastreabilidade
- **Mitigado por:** este documento + ACE-GOV-RASTREIO
- **Gate associado:** fechamento do obrigatório e governança de execução

---

## 36. Matriz Mestra — Aceite até Evidência e Gate

### ACE-FUX-01
- **Exige evidência de:** navegação pública funcional
- **Depende de:** TST-E2E-01, TST-UX público
- **Habilita:** aceite da camada pública institucional

### ACE-FUX-03
- **Exige evidência de:** envio válido/inválido de contato
- **Depende de:** TST-API-PUB-05, TST-E2E-04
- **Habilita:** publicação segura do contato público

### ACE-FUX-04
- **Exige evidência de:** autenticação, sessão e proteção de rota
- **Depende de:** TST-SEC + E2E login
- **Habilita:** abertura legítima da camada administrativa

### ACE-FUX-05
- **Exige evidência de:** criação, edição e mudança de status
- **Depende de:** TST-E2E-06 a 09
- **Habilita:** aceite do núcleo editorial admin

### ACE-GOV-RASTREIO
- **Exige evidência de:** ausência de órfãos críticos e coerência da matriz
- **Depende de:** este documento consolidado
- **Habilita:** avanço seguro de governança de execução

### ACE-DEP-01
- **Exige evidência de:** checklist de implantação, smoke e rollback definidos
- **Depende de:** 022
- **Habilita:** publicação controlada

---

## 37. Matriz Mestra — Implantação até Escopo, Smoke e Rollback

### DEP-01 — Implantação da camada pública
- **Escopo provável:** Home, Sobre, Projetos, Publicações, Contato
- **Depende de:** ACE-PUB + ACE-FUX-01/02/03
- **Smoke associado:** Home, navegação, conteúdo, contato
- **Rollback associado:** reversão do frontend público e/ou API pública

### DEP-02 — Implantação da camada administrativa
- **Escopo provável:** login, dashboard, publicações, taxonomia, auditoria
- **Depende de:** ACE-FUX-04/05/06/07 + ACE-SEC-ADM
- **Smoke associado:** login, rota protegida, dashboard, lista, logout
- **Rollback associado:** reversão admin e/ou bloqueio temporário de acesso

### DEP-03 — Implantação da API central
- **Escopo provável:** rotas públicas e admin
- **Depende de:** ACE contratual + testes de API
- **Smoke associado:** endpoints centrais
- **Rollback associado:** retorno ao último contrato estável

---

## 38. Matriz Mestra — Fases até Entregáveis e Gates

### Fase 0
- **Entregáveis:** 000, 001, 002, 024 de 00-Padrao
- **Gate:** G01 Constitucional
- **Estado:** concluída

### Fase 1
- **Entregáveis:** todos os documentos de 01-Obrigatorios
- **Gate:** G05 fechamento do obrigatório
- **Estado atual:** em fechamento

### Fase 2
- **Entregáveis:** 021, 022, 023, 024
- **Gate:** G06 execução controlada
- **Estado atual:** em consolidação

### Fase 3 em diante
- **Dependem de:** fechamento real da Fase 1 e 2
- **Gate:** entrada só após núcleo reconciliado

---

## 39. Procedimento Soberano de Uso da Matriz

A matriz deverá ser usada sempre que ocorrer uma das situações abaixo.

### 39.1 Geração de novo documento relevante
Pergunta:
- ele se conecta a quê?
- o que ele passa a governar?

### 39.2 Criação de endpoint ou tela
Pergunta:
- qual requisito/fluxo/objetivo justifica isso?
- qual teste validará isso?
- qual aceite permitirá isso?

### 39.3 Mudança em item já consolidado
Pergunta:
- o que essa mudança impacta para trás e para frente?

### 39.4 Falha encontrada
Pergunta:
- qual fluxo, requisito, aceite e risco foram afetados?

### 39.5 Implantação
Pergunta:
- qual escopo entra;
- qual aceite autorizou;
- qual smoke valida;
- qual rollback cobre.

---

## 40. Regras para Atualização da Matriz

A matriz deve ser atualizada quando ocorrer:

- criação de novo requisito relevante;
- criação de novo fluxo crítico;
- inclusão de nova rota de API obrigatória;
- inclusão de nova tela central;
- surgimento de novo risco estrutural;
- alteração relevante de aceite;
- mudança relevante em implantação;
- registro de ADR com impacto estrutural.

### Regra soberana

A matriz não deve ser reescrita por capricho.
Ela deve ser atualizada por mudança real de estrutura.

---

## 41. Critérios de Qualidade da Própria Matriz

Esta matriz será considerada boa quando:

1. for legível;
2. for útil para decisão;
3. permitir enxergar cobertura e lacuna;
4. reduzir ambiguidade de impacto;
5. impedir órfãos críticos;
6. ajudar a explicar o projeto a um próximo ciclo;
7. sustentar homologação, aceite e implantação;
8. ser suficientemente rica sem virar ruído burocrático.

---

## 42. Materiais Herdados Úteis para Reforço

Como reforço estrutural, podem ser observados no legado:

- `personal-site (1)/personal-site/Waterfall/`
- `personal-site (1)/personal-site/APIs/`
- `personal-site (1)/personal-site/UI_UX/`
- `personal-site (1)/personal-site/Execucao/`
- `personal-site (1)/personal-site/Implementacao/`
- `personal-site (1)/personal-site/Scaffold/`
- `personal-site (1)/personal-site/Monorepo/`

### Regra de precedência

Esses materiais podem ajudar a identificar futuras cadeias de derivação, mas não têm autoridade para redefinir a matriz soberana do ciclo atual.

---

## 43. Anti-padrões de Rastreabilidade Expressamente Rejeitados

Ficam rejeitados, desde já:

- requisito sem downstream;
- teste sem upstream;
- tela sem contrato;
- API sem fluxo;
- aceite sem evidência;
- implantação sem escopo rastreável;
- decisão estrutural sem contexto;
- mudança sem análise de impacto;
- documentação que não conversa com o restante do corpus;
- evolução que obriga reconstruir a linha de sentido do projeto.

---

## 44. Critérios de Aceite Deste Documento

Este documento será considerado corretamente consolidado quando:

1. definir o que é rastreabilidade no projeto;
2. estabelecer as dimensões oficiais de rastreio;
3. formalizar os tipos de vínculo entre itens;
4. conectar objetivos, requisitos, regras, fluxos, módulos, APIs, telas, testes, aceite e implantação;
5. permitir leitura para trás e para frente;
6. tornar visíveis lacunas e coberturas;
7. preparar o projeto para ADRs e evolução disciplinada;
8. transformar a continuidade do projeto em estrutura verificável, e não apenas narrativa.

---

## 45. Declaração Final

Com este documento, o projeto **William Albarello** passa a possuir uma **matriz soberana de rastreabilidade**, capaz de responder com rigor a uma pergunta decisiva para qualquer obra complexa:

> “como tudo isso se conecta?”

A partir daqui:

- requisito deixa de ficar solto;
- fluxo deixa de ser intuído;
- API deixa de parecer arbitrária;
- teste deixa de ser ruído;
- aceite deixa de ser impressão;
- implantação deixa de ser ato isolado;
- evolução deixa de ser salto no escuro.

A obra passa a possuir memória estrutural.

---

## 46. Status do Documento

**Documento consolidado como base soberana de rastreabilidade do projeto William Albarello, apto a conectar estratégia, requisitos, fluxos, arquitetura, APIs, telas, testes, aceite, implantação e evolução disciplinada da obra.**
