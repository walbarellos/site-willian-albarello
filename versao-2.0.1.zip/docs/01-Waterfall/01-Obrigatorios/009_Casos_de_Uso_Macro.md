# 009_Casos_de_Uso_Macro

## Identificação do Documento

- **Projeto:** William Albarello
- **Camada:** 01-Waterfall
- **Subpasta:** 01-Obrigatorios
- **Documento:** 009_Casos_de_Uso_Macro.md
- **Função:** Definir os principais casos de uso do sistema em nível macro, traduzindo stakeholders, perfis, requisitos e regras de negócio em interações estruturantes entre atores e solução
- **Status:** ATIVO
- **Versão:** v1.0
- **Autoridade:** Alta
- **Natureza:** Documento soberano de modelagem macro de interações do sistema
- **Dependência superior:**
  - 000_Indice_Mestre.md
  - 001_Manifesto_Metodologico_Waterfall_Caracol.md
  - 002_Regra_de_Nomenclatura_e_Versionamento.md
  - 024_Politica_de_Governanca_Documental.md
  - 001_Visao_Geral_do_Projeto.md
  - 002_Problema_Oportunidade_e_Tese_Central.md
  - 003_Objetivos_Estrategicos_e_Resultados_Esperados.md
  - 004_Escopo_e_Fora_de_Escopo.md
  - 005_Stakeholders_Perfis_e_Atores_do_Sistema.md
  - 006_Requisitos_Funcionais.md
  - 007_Requisitos_Nao_Funcionais.md
  - 008_Regras_de_Negocio.md
- **Dependências relacionadas:**
  - 010_Jornadas_do_Usuario_e_Fluxos_Principais.md
  - 011_Arquitetura_Geral_do_Sistema.md
  - 015_Seguranca_Privacidade_Auditoria_e_Permissoes.md
  - 016_API_Contract_Mestre.md
  - 017_UI_UX_Arquitetura_da_Informacao.md
  - 021_Criterios_de_Aceite_Gerais.md

---

## 1. Finalidade

Este documento existe para transformar a modelagem de atores, requisitos e regras do projeto em **interações macro compreensíveis**.

Sua função é responder à pergunta:

> como os principais atores se relacionam, em alto nível, com a solução?

Sem este documento, o projeto corre o risco de possuir visão, requisitos e regras corretos, mas ainda sem uma imagem operacional suficientemente clara dos usos centrais do sistema.

Este documento não entra ainda em detalhamento minucioso de fluxos de tela, mensagens de erro, estados internos ou regras técnicas de API.

Sua função é estabelecer os **grandes casos de uso estruturantes** que justificam a forma futura da solução.

---

## 2. Princípio Geral dos Casos de Uso

Os casos de uso deste projeto devem ser entendidos como **unidades macro de interação significativa** entre atores e sistema.

Eles não são meras ações isoladas como “clicar em botão” ou “abrir página”.

Cada caso de uso macro deve representar uma intenção real, relevante e coerente com:

- a visão do projeto;
- o problema central;
- os objetivos estratégicos;
- os perfis e atores mapeados;
- os requisitos funcionais e não funcionais;
- as regras de negócio já estabelecidas.

A regra central é esta:

> caso de uso bom não descreve movimento mecânico;  
> caso de uso bom descreve relação significativa entre ator e sistema.

---

## 3. Macrogrupos de Casos de Uso

Para manter ordem metodológica, os casos de uso serão organizados em grupos.

### 3.1 Grupo A — Compreensão institucional

Casos de uso relacionados ao entendimento inicial do projeto, sua identidade, propósito e estrutura.

### 3.2 Grupo B — Exploração de áreas, conteúdos e contextos

Casos de uso relacionados à navegação e ao aprofundamento progressivo.

### 3.3 Grupo C — Aproximação e relação

Casos de uso relacionados a contato, interesse qualificado e conexão com o projeto.

### 3.4 Grupo D — Administração e manutenção

Casos de uso relacionados à operação interna, publicação, edição e governança futura.

### 3.5 Grupo E — Evolução controlada da solução

Casos de uso relacionados à sustentação do crescimento futuro da estrutura.

---

## 4. Atores Principais Considerados neste Documento

Para fins de modelagem macro, este documento considera os seguintes atores principais:

- **A1 — Visitante Público**
- **A2 — Interessado Qualificado**
- **A3 — Leitor de Conteúdo**
- **A4 — Administrador Principal**
- **A5 — Editor ou Operador de Conteúdo**
- **A6 — Mantenedor Técnico**
- **A7 — Titular Institucional (William Albarello)**

Observação importante:

O ator **William Albarello** possui, neste projeto, natureza singular.

Ele não é apenas usuário final de uma interface. Ele também é sujeito central de representação, validação identitária e autoridade estratégica do sistema.

---

## 5. Casos de Uso Macro — Grupo A: Compreensão Institucional

### CU-001 — Compreender quem é William Albarello e o que representa o projeto

**Atores principais:**
- A1 — Visitante Público
- A2 — Interessado Qualificado

**Descrição:**
O ator acessa a solução para entender, em nível inicial, quem é William Albarello, qual é a natureza do projeto e por que a presença digital existe.

**Objetivo do ator:**
Obter compreensão institucional inicial com clareza e confiança.

**Resultado esperado:**
O ator consegue formar imagem coerente da identidade e do propósito do projeto sem depender de inferência excessiva.

**Implicações estruturais:**
- apresentação inicial precisa ser clara;
- o sistema precisa comunicar proposta e direção;
- a arquitetura pública precisa reduzir ambiguidade.

---

### CU-002 — Compreender a proposta, visão e posicionamento do sistema

**Atores principais:**
- A1 — Visitante Público
- A2 — Interessado Qualificado

**Descrição:**
O ator busca compreender não apenas quem está representado, mas qual é a visão por trás da estrutura digital, sua lógica e seu posicionamento.

**Objetivo do ator:**
Entender a proposta superior do projeto e seu caráter institucional, autoral ou estratégico.

**Resultado esperado:**
O sistema consegue comunicar direção, coerência e intencionalidade.

---

### CU-003 — Reconhecer as áreas centrais da solução

**Atores principais:**
- A1 — Visitante Público
- A2 — Interessado Qualificado
- A3 — Leitor de Conteúdo

**Descrição:**
O ator identifica as áreas principais do sistema e compreende, em alto nível, como elas se organizam.

**Objetivo do ator:**
Orientar-se dentro da estrutura sem perder contexto.

**Resultado esperado:**
O sistema apresenta uma topologia institucional compreensível.

---

## 6. Casos de Uso Macro — Grupo B: Exploração de Áreas, Conteúdos e Contextos

### CU-004 — Navegar entre áreas públicas do projeto

**Atores principais:**
- A1 — Visitante Público
- A2 — Interessado Qualificado
- A3 — Leitor de Conteúdo

**Descrição:**
O ator percorre as áreas públicas principais da solução, transitando entre apresentação institucional, conteúdos, projetos ou seções relacionadas.

**Objetivo do ator:**
Explorar a estrutura com continuidade semântica.

**Resultado esperado:**
O sistema sustenta navegação organizada, contextual e coerente.

---

### CU-005 — Aprofundar entendimento sobre uma área específica

**Atores principais:**
- A2 — Interessado Qualificado
- A3 — Leitor de Conteúdo

**Descrição:**
Após uma compreensão inicial, o ator escolhe uma área específica e aprofunda seu entendimento sobre ela.

**Objetivo do ator:**
Encontrar mais densidade informacional sem perder relação com o todo.

**Resultado esperado:**
A solução oferece leitura progressiva, não apenas blocos isolados de informação.

---

### CU-006 — Explorar conteúdos, projetos ou materiais relacionados

**Atores principais:**
- A2 — Interessado Qualificado
- A3 — Leitor de Conteúdo

**Descrição:**
O ator acessa materiais, conteúdos ou projetos e explora relações entre eles.

**Objetivo do ator:**
Compreender não só um item isolado, mas sua inserção no ecossistema do projeto.

**Resultado esperado:**
Conteúdos e materiais aparecem contextualizados e conectáveis.

---

### CU-007 — Percorrer o sistema por trilha de interesse progressivo

**Atores principais:**
- A2 — Interessado Qualificado
- A3 — Leitor de Conteúdo

**Descrição:**
O ator inicia com interesse geral e vai sendo conduzido para níveis mais profundos de compreensão, conforme sua intenção aumenta.

**Objetivo do ator:**
Ser acompanhado por uma estrutura que não o perca nem o sufoque com excesso de informação inicial.

**Resultado esperado:**
A solução sustenta jornadas de progressão semântica.

---

## 7. Casos de Uso Macro — Grupo C: Aproximação e Relação

### CU-008 — Encontrar meios adequados de contato ou aproximação

**Atores principais:**
- A2 — Interessado Qualificado
- A1 — Visitante Público

**Descrição:**
O ator deseja localizar meios adequados de contato, aproximação institucional ou manifestação de interesse.

**Objetivo do ator:**
Identificar o canal correto de aproximação sem confusão.

**Resultado esperado:**
O sistema oferece caminhos claros de relação, coerentes com a dignidade institucional do projeto.

---

### CU-009 — Avaliar seriedade, consistência e valor antes de se aproximar

**Atores principais:**
- A2 — Interessado Qualificado
- potenciais parceiros ou interlocutores estratégicos

**Descrição:**
O ator usa a navegação e a leitura do sistema como meio de avaliar se vale a pena estabelecer aproximação mais qualificada.

**Objetivo do ator:**
Julgar credibilidade, coerência e maturidade do projeto.

**Resultado esperado:**
A solução serve como filtro de confiança institucional.

---

### CU-010 — Identificar rotas de aprofundamento relacional

**Atores principais:**
- A2 — Interessado Qualificado

**Descrição:**
O ator deseja avançar da simples visita para uma relação mais concreta com o projeto.

**Objetivo do ator:**
Descobrir como sair da camada pública geral e ingressar em uma camada de interlocução mais específica.

**Resultado esperado:**
A solução distingue apresentação de aproximação e oferece transições coerentes.

---

## 8. Casos de Uso Macro — Grupo D: Administração e Manutenção

### CU-011 — Acessar área administrativa autorizada

**Atores principais:**
- A4 — Administrador Principal
- A5 — Editor ou Operador de Conteúdo

**Descrição:**
O ator interno autorizado acessa a camada restrita do sistema para operar funções de manutenção, publicação ou gestão.

**Objetivo do ator:**
Entrar em ambiente controlado de operação.

**Resultado esperado:**
A solução diferencia claramente acesso público de acesso interno.

---

### CU-012 — Atualizar conteúdos ou estruturas institucionais autorizadas

**Atores principais:**
- A4 — Administrador Principal
- A5 — Editor ou Operador de Conteúdo

**Descrição:**
O ator interno realiza alterações em conteúdos, seções ou blocos sob sua responsabilidade.

**Objetivo do ator:**
Manter a presença digital atualizada e coerente.

**Resultado esperado:**
A solução permite manutenção sem destruir identidade, contexto ou organização.

---

### CU-013 — Governar publicação ou revisão de materiais relevantes

**Atores principais:**
- A4 — Administrador Principal
- A5 — Editor ou Operador de Conteúdo
- A7 — Titular Institucional, quando aplicável

**Descrição:**
O ator interno cria, revisa, aprova ou ajusta materiais antes de sua consolidação pública, conforme a governança definida.

**Objetivo do ator:**
Preservar qualidade, coerência e responsabilidade sobre o que aparece publicamente.

**Resultado esperado:**
A solução sustenta processos internos compatíveis com a seriedade do projeto.

---

### CU-014 — Preservar integridade e coerência da estrutura durante manutenção

**Atores principais:**
- A4 — Administrador Principal
- A5 — Editor ou Operador de Conteúdo
- A6 — Mantenedor Técnico

**Descrição:**
Durante atividades de manutenção, o ator precisa alterar partes do sistema sem provocar ruptura na experiência pública ou na coerência institucional.

**Objetivo do ator:**
Executar manutenção com segurança estrutural.

**Resultado esperado:**
O sistema é operável sem fragilizar sua dignidade institucional.

---

## 9. Casos de Uso Macro — Grupo E: Evolução Controlada da Solução

### CU-015 — Evoluir a estrutura pública sem perder unidade

**Atores principais:**
- A7 — Titular Institucional
- A4 — Administrador Principal
- A6 — Mantenedor Técnico

**Descrição:**
Os atores responsáveis desejam ampliar ou refinar a estrutura do sistema sem destruir a coerência já consolidada.

**Objetivo do ator:**
Fazer o projeto crescer com ordem.

**Resultado esperado:**
A solução admite expansão por encaixe, não por colagem improvisada.

---

### CU-016 — Incorporar novas áreas, módulos ou capacidades em conformidade com o projeto

**Atores principais:**
- A7 — Titular Institucional
- A4 — Administrador Principal
- A6 — Mantenedor Técnico

**Descrição:**
Uma nova necessidade legítima surge e precisa ser incorporada à solução de forma compatível com a visão, o escopo e a arquitetura.

**Objetivo do ator:**
Expandir sem trair a fundação documental do sistema.

**Resultado esperado:**
O crescimento é governado, rastreável e compatível com o ecossistema existente.

---

### CU-017 — Traduzir progressivamente a estrutura documental em componentes e módulos implementáveis

**Atores principais:**
- A6 — Mantenedor Técnico
- A4 — Administrador Principal
- atores de construção técnica futura

**Descrição:**
A base documental e arquitetural do projeto é utilizada para decompor a solução em unidades mais implementáveis e, futuramente, geráveis.

**Objetivo do ator:**
Converter a inteligência documental em construção modular sem improviso.

**Resultado esperado:**
A solução caminha para geração e implementação com melhor encaixe previsível.

---

## 10. Caso de Uso Macro Singular do Titular Institucional

### CU-018 — Validar fidelidade entre sistema e identidade representada

**Atores principais:**
- A7 — Titular Institucional (William Albarello)

**Descrição:**
O titular institucional utiliza o sistema, sua documentação e sua evolução para verificar se a solução permanece fiel à identidade, à proposta e à direção estratégica do projeto.

**Objetivo do ator:**
Assegurar que a estrutura digital não se descole do sujeito central que ela representa.

**Resultado esperado:**
A presença digital permanece alinhada ao seu eixo de legitimidade.

**Observação importante:**
Este caso de uso é singular porque não se reduz a ação operacional de interface. Ele possui natureza estratégica e identitária.

---

## 11. Relação entre Casos de Uso Macro e Requisitos Funcionais

Os casos de uso macro aqui definidos existem para dar forma relacional aos requisitos funcionais já estabelecidos.

Em termos práticos:

- RFs de apresentação institucional se materializam em CU-001, CU-002 e CU-003;
- RFs de navegação e aprofundamento se materializam em CU-004, CU-005, CU-006 e CU-007;
- RFs de contato e relação se materializam em CU-008, CU-009 e CU-010;
- RFs de administração se materializam em CU-011, CU-012, CU-013 e CU-014;
- RFs de expansão e geração futura se materializam em CU-015, CU-016 e CU-017.

Assim, os casos de uso funcionam como ponte entre requisitos e jornadas.

---

## 12. Relação entre Casos de Uso Macro e Jornadas Futuras

O próximo documento de jornadas e fluxos deverá detalhar percursos reais derivados dos casos de uso aqui definidos.

Este documento ainda não detalha:

- etapas finas de navegação;
- entradas e saídas por tela;
- mensagens de sistema;
- tratamentos excepcionais detalhados;
- ramificações UX minuciosas.

Ele apenas fixa quais relações centrais deverão existir.

---

## 13. Relação entre Casos de Uso Macro e Arquitetura

A arquitetura geral do sistema deverá ser capaz de sustentar estes casos de uso sem contradição.

Isso implica que a arquitetura precisará prever, em nível apropriado:

- camada pública institucional;
- organização semântica de áreas e conteúdos;
- mecanismos de navegação relacional;
- pontos de aproximação;
- camada interna administrativa, quando aplicável;
- capacidade de expansão e modularização futura.

Arquitetura que não suporte esses casos de uso será insuficiente para a natureza do projeto.

---

## 14. O que Este Documento Não Faz

Este documento não:

- desenha wireframes;
- detalha fluxos completos de UX;
- define entidades de banco;
- fixa contrato técnico de API;
- determina mensagens de erro;
- especifica regras finas de permissão por tela ou operação.

Sua função é modelar os **grandes usos legítimos** do sistema.

---

## 15. Riscos de Desvio em Relação a Este Documento

### 15.1 Risco de reduzir casos de uso a navegação superficial

Isso empobreceria a inteligência operacional do projeto.

### 15.2 Risco de inflar casos de uso artificiais

Isso criaria burocracia documental sem ganho estrutural.

### 15.3 Risco de ignorar a singularidade do titular institucional

Isso fragilizaria a dimensão identitária do sistema.

### 15.4 Risco de modelar apenas o público e esquecer operação e evolução

Isso produziria solução aparente, porém curta e pouco governável.

### 15.5 Risco de misturar caso de uso com detalhe de interface

Isso reduziria a utilidade deste documento para arquitetura e jornadas.

---

## 16. Declaração Final

O projeto **William Albarello** não pode ser reduzido a um conjunto de páginas estáticas acessadas por um visitante genérico.

Ele envolve relações reais de compreensão, aprofundamento, avaliação, aproximação, administração, manutenção e evolução.

Os casos de uso macro aqui definidos dão forma operacional a essas relações e estabelecem o mapa de interações estruturantes do sistema.

Eles deverão orientar jornadas, arquitetura, contratos e implementação futura, preservando a coerência entre identidade, uso, governança e expansão.

---

## 17. Status deste Documento

Este documento entra em vigor imediatamente como referência soberana para os casos de uso macro do projeto.

Os documentos seguintes da pasta `01-Obrigatorios` deverão ser compatíveis com ele, salvo revisão formal explícita.
