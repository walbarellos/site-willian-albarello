# 013_Modelo_de_Dados_Conceitual

## Identificação do Documento

- **Projeto:** William Albarello
- **Camada:** 01-Waterfall
- **Subpasta:** 01-Obrigatorios
- **Documento:** 013_Modelo_de_Dados_Conceitual.md
- **Função:** Definir o modelo de dados conceitual do projeto, suas entidades centrais, relações estruturais, responsabilidades semânticas e limites de persistência, preparando a solução para implementação coerente e expansão controlada
- **Status:** ATIVO
- **Versão:** v1.0
- **Autoridade:** Alta
- **Natureza:** Documento soberano de modelagem conceitual de dados
- **Dependência superior:**
  - 000_Indice_Mestre.md
  - 001_Manifesto_Metodologico_Waterfall_Caracol.md
  - 002_Regra_de_Nomenclatura_e_Versionamento.md
  - 024_Politica_de_Governanca_Documental.md
  - 001_Visao_Geral_do_Projeto.md
  - 002_Problema_Oportunidade_e_Tese_Central.md
  - 003_Objetivos_Estrategicos_e_Resultados_Esperados.md
  - 004_Escopo_e_Fora_de_Escopo.md
  - 005_Stakeholders_Perfis_e_Atores_do_Sistema.md
  - 006_Requisitos_Funcionais.md
  - 007_Requisitos_Nao_Funcionais.md
  - 008_Regras_de_Negocio.md
  - 009_Casos_de_Uso_Macro.md
  - 010_Jornadas_do_Usuario_e_Fluxos_Principais.md
  - 011_Arquitetura_Geral_do_Sistema.md
  - 012_Modulos_Dominios_e_Limites_do_Software.md
- **Dependências relacionadas:**
  - 014_Integracoes_e_Sistemas_Externos.md
  - 015_Seguranca_Privacidade_Auditoria_e_Permissoes.md
  - 016_API_Contract_Mestre.md
  - 017_UI_UX_Arquitetura_da_Informacao.md
  - 018_Plano_de_Testes_Homologacao_e_Qualidade.md
  - 021_Criterios_de_Aceite_Gerais.md
  - 023_Matriz_de_Rastreabilidade.md

---

## 1. Finalidade

Este documento existe para definir a forma conceitual dos dados do projeto **William Albarello**.

Sua função é responder, de modo soberano, às seguintes perguntas:

1. quais entidades o sistema precisa reconhecer para existir com coerência;
2. como essas entidades se relacionam entre si;
3. quais responsabilidades semânticas pertencem a cada entidade;
4. quais dados pertencem à camada pública, à camada operacional interna e à sustentação estrutural do sistema;
5. como modelar o crescimento futuro sem destruir a inteligibilidade da base.

Este documento não descreve ainda o banco final, os tipos exatos de colunas, a engine de persistência ou a implementação detalhada de ORM.

Ele define o **modelo conceitual de dados**, isto é, a anatomia semântica do sistema.

---

## 2. Princípio Geral do Modelo Conceitual

Neste projeto, modelagem de dados não será tratada como exercício técnico isolado.

Ela deverá refletir:

- a visão do projeto;
- sua identidade institucional;
- a organização de áreas e conteúdos;
- os fluxos de relação e contato;
- a operação interna futura;
- a governança da evolução.

A regra central é esta:

> o dado deve servir ao sentido do sistema,  
> e não o sistema tornar-se refém de um armazenamento mal pensado.

---

## 3. Tese do Modelo de Dados

A tese conceitual deste modelo é a seguinte:

> o projeto William Albarello precisa de um modelo de dados centrado em identidade institucional, organização contextual de áreas e conteúdos, governança editorial e operação interna controlada, distinguindo claramente o que pertence à representação pública, à administração futura e à sustentação estrutural do sistema.

Isso implica que o modelo de dados não deverá nascer como:

- simples tabela de páginas soltas;
- blog genérico sem contexto institucional;
- painel administrativo desconectado da camada pública;
- estrutura rígida demais para crescimento;
- estrutura frouxa demais para governança.

---

## 4. Macrogrupos de Entidades

Para organizar a modelagem conceitual, as entidades do sistema serão agrupadas em sete macrogrupos.

1. **Entidades de Identidade e Presença Institucional**
2. **Entidades de Estrutura Pública e Navegação**
3. **Entidades de Conteúdo, Projeto e Contextualização**
4. **Entidades de Relação e Aproximação**
5. **Entidades de Usuários Internos, Perfis e Permissões**
6. **Entidades de Operação, Publicação e Auditoria**
7. **Entidades de Suporte Estrutural e Evolução**

Esses grupos não são ainda tabelas finais. Eles são agrupamentos conceituais para preservar ordem semântica.

---

## 5. Entidades do Grupo 1 — Identidade e Presença Institucional

### E-01 — IdentidadeInstitucional

#### Finalidade
Representar o núcleo institucional do projeto na camada de dados.

#### Papel conceitual
Esta entidade concentra a definição semântica da identidade central representada pelo sistema.

#### Exemplos de informações conceituais associadas
- nome principal de representação;
- descrição institucional resumida;
- posicionamento central;
- mensagem de apresentação;
- estado de ativação institucional;
- parâmetros centrais de exibição pública.

#### Observação
Esta entidade não deve ser confundida com usuário interno, conta administrativa ou configuração técnica. Ela representa a identidade pública soberana do projeto.

---

### E-02 — BlocoInstitucional

#### Finalidade
Representar blocos públicos de apresentação institucional vinculados à identidade central.

#### Papel conceitual
Permitir que a presença pública seja composta por blocos estruturados e governáveis, em vez de depender de conteúdo solto ou acoplado diretamente à interface.

#### Exemplos de informações conceituais associadas
- tipo de bloco institucional;
- título;
- subtítulo;
- corpo de texto;
- ordem de exibição;
- status de publicação;
- relação com a identidade institucional.

#### Observação
Esta entidade favorece modularidade na apresentação pública.

---

## 6. Entidades do Grupo 2 — Estrutura Pública e Navegação

### E-03 — AreaPublica

#### Finalidade
Representar grandes áreas públicas do sistema.

#### Papel conceitual
Servir como eixo organizador da arquitetura de informação pública.

#### Exemplos de informações conceituais associadas
- nome da área;
- slug ou identificador público;
- descrição resumida;
- ordem de navegação;
- visibilidade;
- estado de publicação.

#### Relações conceituais principais
- uma ÁreaPublica pode possuir vários Conteudos;
- uma ÁreaPublica pode possuir vários BlocosInstitucionais ou blocos de contextualização;
- uma ÁreaPublica pode vincular-se a itens de navegação.

---

### E-04 — ItemNavegacao

#### Finalidade
Representar elementos de navegação que conectam o usuário às áreas e percursos do sistema.

#### Papel conceitual
Permitir que a navegação seja governável como estrutura, e não apenas como detalhe de frontend.

#### Exemplos de informações conceituais associadas
- rótulo do item;
- destino lógico;
- hierarquia;
- ordem;
- visibilidade;
- tipo de item.

#### Observação
ItemNavegacao não substitui AreaPublica. Ele organiza acesso; não define sozinho a estrutura semântica das áreas.

---

### E-05 — RotaContextual

#### Finalidade
Representar vínculos de percurso ou caminhos contextuais entre áreas, conteúdos ou blocos relacionados.

#### Papel conceitual
Sustentar a navegação relacional e a continuidade semântica das jornadas.

#### Exemplos de informações conceituais associadas
- origem;
- destino;
- tipo de relação;
- prioridade de exibição;
- contexto de uso.

#### Observação
Esta entidade é importante para não reduzir a navegação a menus rígidos.

---

## 7. Entidades do Grupo 3 — Conteúdo, Projeto e Contextualização

### E-06 — Conteudo

#### Finalidade
Representar itens de conteúdo, materiais, textos, projetos apresentados, publicações ou blocos informacionais relevantes do sistema.

#### Papel conceitual
Servir como entidade central de profundidade informacional do projeto.

#### Exemplos de informações conceituais associadas
- título;
- resumo;
- corpo;
- tipo de conteúdo;
- estado de publicação;
- data de criação;
- data de publicação;
- autor ou responsável;
- área pública vinculada.

#### Observação
Conteudo é entidade ampla, mas não ilimitada. Seu uso deverá respeitar classificação e contexto.

---

### E-07 — CategoriaConteudo

#### Finalidade
Representar categorias, agrupamentos ou taxonomias conceituais dos conteúdos.

#### Papel conceitual
Permitir classificação consistente e recuperação contextual de conteúdos.

#### Exemplos de informações conceituais associadas
- nome;
- descrição;
- slug;
- ordem;
- estado.

#### Relações conceituais principais
- uma CategoriaConteudo pode agrupar vários Conteudos;
- um Conteudo pode pertencer a uma ou mais categorias, conforme a modelagem final escolhida.

---

### E-08 — ProjetoApresentado

#### Finalidade
Representar projetos, iniciativas ou frentes que precisem ser exibidos como unidades próprias de valor dentro do sistema.

#### Papel conceitual
Distinguir, quando necessário, um projeto estruturado de um conteúdo genérico.

#### Exemplos de informações conceituais associadas
- nome do projeto;
- descrição;
- status;
- área ou eixo institucional;
- materiais associados;
- posição pública.

#### Observação
Esta entidade é válida se o sistema assumir explicitamente a apresentação de projetos como parte da presença institucional.

---

### E-09 — ContextoEditorial

#### Finalidade
Representar o enquadramento conceitual ou institucional de conteúdos e materiais.

#### Papel conceitual
Evitar que itens apareçam como objetos órfãos sem contexto de leitura.

#### Exemplos de informações conceituais associadas
- texto de contexto;
- tipo de enquadramento;
- ordem de aplicação;
- vínculo com conteúdo, área ou projeto.

#### Observação
Esta entidade reforça a regra de negócio de que o conteúdo deve aparecer contextualizado.

---

## 8. Entidades do Grupo 4 — Relação e Aproximação

### E-10 — CanalContato

#### Finalidade
Representar meios formais de contato ou aproximação oferecidos pelo projeto.

#### Papel conceitual
Separar canais e rotas de relação da lógica geral de apresentação pública.

#### Exemplos de informações conceituais associadas
- tipo de canal;
- rótulo público;
- destino;
- instrução de uso;
- estado de ativação;
- ordem de exibição.

---

### E-11 — ManifestacaoInteresse

#### Finalidade
Representar registros de interesse, contato ou aproximação iniciados por atores externos, quando essa funcionalidade for validada.

#### Papel conceitual
Servir como entidade relacional entre o público interessado e a camada interna de acompanhamento.

#### Exemplos de informações conceituais associadas
- identificador;
- origem;
- nome ou referência do interessado;
- canal utilizado;
- assunto;
- conteúdo da manifestação;
- status de tratamento;
- datas relevantes.

#### Observação
Esta entidade deve existir apenas quando o fluxo de aproximação exigir persistência e governança interna.

---

### E-12 — TipoAproximacao

#### Finalidade
Representar classificações possíveis das relações iniciadas a partir do sistema.

#### Papel conceitual
Permitir distinguir tipos de contato ou interesse qualificado sem inflar a entidade principal de manifestação.

#### Exemplos de informações conceituais associadas
- nome do tipo;
- descrição;
- prioridade;
- critérios de enquadramento.

---

## 9. Entidades do Grupo 5 — Usuários Internos, Perfis e Permissões

### E-13 — UsuarioInterno

#### Finalidade
Representar atores autorizados a operar a camada interna da solução.

#### Papel conceitual
Sustentar autenticação, rastreabilidade e separação entre público e operação interna.

#### Exemplos de informações conceituais associadas
- nome;
- identificador de acesso;
- e-mail ou credencial equivalente;
- status;
- data de criação;
- última atividade relevante.

#### Observação
UsuarioInterno não representa o titular institucional enquanto identidade pública, a menos que este também assuma papel operacional autenticado no sistema.

---

### E-14 — PerfilInterno

#### Finalidade
Representar perfis operacionais internos, como administrador, editor ou operador.

#### Papel conceitual
Organizar responsabilidades e permissões por papel.

#### Exemplos de informações conceituais associadas
- nome do perfil;
- descrição;
- escopo de atuação;
- nível de responsabilidade.

---

### E-15 — PermissaoInterna

#### Finalidade
Representar capacidades autorizadas para perfis ou usuários internos.

#### Papel conceitual
Permitir governança sobre ações sensíveis, preservando proporcionalidade entre responsabilidade e acesso.

#### Exemplos de informações conceituais associadas
- nome da permissão;
- descrição;
- recurso afetado;
- tipo de ação.

#### Observação
A modelagem final pode optar por relação direta PerfilInterno ↔ PermissaoInterna ou estrutura equivalente.

---

## 10. Entidades do Grupo 6 — Operação, Publicação e Auditoria

### E-16 — Publicacao

#### Finalidade
Representar o estado público de disponibilização de conteúdos, blocos ou estruturas publicáveis.

#### Papel conceitual
Separar o objeto de conteúdo de seu ciclo de exposição pública.

#### Exemplos de informações conceituais associadas
- status;
- data de publicação;
- data de retirada;
- responsável pela publicação;
- observações operacionais.

#### Observação
Dependendo da implementação final, esta entidade pode ser lógica explícita ou comportamento distribuído entre conteúdos e estruturas publicáveis. Conceitualmente, porém, a ideia de governança de publicação deve existir.

---

### E-17 — RevisaoConteudo

#### Finalidade
Representar ciclos de revisão de conteúdo relevante, quando aplicável.

#### Papel conceitual
Permitir que alterações importantes tenham histórico mínimo e governança editorial.

#### Exemplos de informações conceituais associadas
- referência ao conteúdo;
- versão ou marcador de revisão;
- autor da revisão;
- data;
- observação de mudança;
- status da revisão.

---

### E-18 — LogAuditoria

#### Finalidade
Representar registros de ações internas relevantes para rastreabilidade e governança.

#### Papel conceitual
Sustentar memória operacional e possibilidade futura de auditoria.

#### Exemplos de informações conceituais associadas
- usuário interno responsável;
- ação realizada;
- entidade afetada;
- referência afetada;
- data e hora;
- contexto resumido.

#### Observação
LogAuditoria deve ser proporcional ao risco e ao escopo real do sistema.

---

## 11. Entidades do Grupo 7 — Suporte Estrutural e Evolução

### E-19 — ConfiguracaoEstrutural

#### Finalidade
Representar parâmetros estruturais do sistema que não pertencem diretamente à identidade pública nem à operação editorial cotidiana.

#### Papel conceitual
Permitir configuração controlada de elementos estruturais sem confundir esse papel com conteúdo institucional.

#### Exemplos de informações conceituais associadas
- chave;
- valor;
- escopo de aplicação;
- estado;
- data de atualização.

---

### E-20 — ModuloAtivo

#### Finalidade
Representar, conceitualmente, módulos ou capacidades ativadas da solução, quando o crescimento futuro exigir governança modular mais explícita.

#### Papel conceitual
Preparar o sistema para evolução controlada sem inflar desde já sua complexidade.

#### Exemplos de informações conceituais associadas
- nome do módulo;
- status;
- escopo;
- data de ativação;
- observações estruturais.

#### Observação
Esta entidade possui caráter prospectivo. Ela existe como preparação conceitual para expansão futura, não como obrigação imediata de implementação.

---

## 12. Relações Conceituais Principais

Em nível macro, o sistema deverá reconhecer relações como:

- **IdentidadeInstitucional** 1:N **BlocoInstitucional**
- **AreaPublica** 1:N **Conteudo**
- **AreaPublica** 1:N **ItemNavegacao**
- **AreaPublica** 1:N **ProjetoApresentado**
- **Conteudo** N:N **CategoriaConteudo** ou modelagem equivalente
- **Conteudo** 1:N **ContextoEditorial**
- **ProjetoApresentado** 1:N **ContextoEditorial** ou associação equivalente
- **CanalContato** 1:N **ManifestacaoInteresse**, quando aplicável
- **TipoAproximacao** 1:N **ManifestacaoInteresse**
- **UsuarioInterno** N:N **PerfilInterno** ou associação equivalente
- **PerfilInterno** N:N **PermissaoInterna** ou associação equivalente
- **UsuarioInterno** 1:N **LogAuditoria**
- **Conteudo** 1:N **RevisaoConteudo**
- **UsuarioInterno** 1:N **Publicacao** ou relação equivalente com publicação governada

Essas relações serão refinadas futuramente, mas sua lógica conceitual já está fixada aqui.

---

## 13. Entidades Centrais versus Entidades de Apoio

### 13.1 Entidades centrais

São consideradas centrais neste estágio:

- IdentidadeInstitucional
- AreaPublica
- Conteudo
- CanalContato
- UsuarioInterno
- PerfilInterno
- Domínios de contexto e governança associados

### 13.2 Entidades de apoio

São consideradas de apoio ou aprofundamento:

- ItemNavegacao
- RotaContextual
- CategoriaConteudo
- ProjetoApresentado
- ContextoEditorial
- ManifestacaoInteresse
- PermissaoInterna
- RevisaoConteudo
- LogAuditoria
- ConfiguracaoEstrutural
- ModuloAtivo

Essa distinção ajuda a preservar foco no que é realmente fundacional.

---

## 14. Regras Conceituais de Integridade

O modelo conceitual deverá preservar, no mínimo, as seguintes regras de integridade:

### RC-01
Todo conteúdo público relevante deve possuir contexto institucional ou temático reconhecível.

### RC-02
Nenhuma área pública legítima deve existir sem função clara na arquitetura de informação do sistema.

### RC-03
A camada de operação interna deve ser separável da camada de identidade pública.

### RC-04
Permissões internas devem ser proporcionais aos papéis assumidos pelos usuários internos.

### RC-05
A publicação de elementos relevantes deve poder ser governada.

### RC-06
O crescimento futuro do sistema não deve exigir ruptura do núcleo conceitual dos dados.

---

## 15. Limites do Modelo Conceitual

Este modelo deve evitar dois erros.

### 15.1 Inflar o presente com entidades apenas hipotéticas

Nem toda possibilidade futura deve virar entidade agora.

### 15.2 Empobrecer demais a base

Também não se deve reduzir o sistema a páginas e textos soltos, sacrificando governança e expansão futura.

A modelagem correta é a que protege o essencial do presente e deixa portas razoáveis para o futuro.

---

## 16. Relação com a Arquitetura Modular

A decomposição modular definida em `012_Modulos_Dominios_e_Limites_do_Software.md` deverá ser refletida neste modelo.

Em alto nível:

- M-01 Presença Pública Institucional se apoia em **IdentidadeInstitucional** e **BlocoInstitucional**;
- M-02 Conteúdo e Contextualização se apoia em **Conteudo**, **CategoriaConteudo**, **ProjetoApresentado** e **ContextoEditorial**;
- M-03 Navegação Relacional se apoia em **ItemNavegacao** e **RotaContextual**;
- M-04 Contato e Aproximação se apoia em **CanalContato**, **ManifestacaoInteresse** e **TipoAproximacao**;
- M-05 Operação Interna se apoia em **UsuarioInterno**, **PerfilInterno**, **PermissaoInterna**, **Publicacao**, **RevisaoConteudo** e **LogAuditoria**;
- M-06 Domínio Estrutural atravessa conceitualmente quase todas as entidades centrais;
- M-07 Persistência materializa essas estruturas;
- M-08 Sustentação Técnica pode apoiar **ConfiguracaoEstrutural** e estruturas equivalentes.

---

## 17. Relação com Segurança e Permissões

O documento de segurança e permissões deverá aprofundar, a partir deste modelo, temas como:

- papéis internos;
- níveis de acesso;
- rastreabilidade de ações;
- separação entre áreas públicas e internas;
- proteção de estruturas sensíveis.

Este documento não detalha toda a matriz de permissão, mas já a torna inevitável do ponto de vista conceitual.

---

## 18. Relação com API e Contratos Futuros

O contrato mestre de API deverá refletir este modelo conceitual sem violar suas fronteiras.

Isso significa que futuras rotas, recursos ou contratos não deverão:

- misturar identidade institucional com operação administrativa;
- tratar conteúdo sem contexto;
- ignorar governança de publicação;
- expor indevidamente estruturas internas.

---

## 19. O que Este Documento Não Faz

Este documento não:

- define nomes finais de tabelas ou coleções;
- fixa tipos de campos em nível físico;
- escolhe banco relacional, documento ou outro mecanismo;
- define migrations;
- especifica índices;
- substitui contratos de API;
- detalha eventos técnicos;
- resolve infraestrutura.

Sua função é declarar o **modelo conceitual soberano dos dados**.

---

## 20. Riscos de Desvio em Relação a Este Modelo

### 20.1 Risco de reduzir o sistema a páginas sem entidades estruturais

Isso empobreceria governança e crescimento futuro.

### 20.2 Risco de modelar demais cedo demais

Isso criaria complexidade sem aderência ao escopo atual.

### 20.3 Risco de misturar entidades públicas e operacionais sem fronteira clara

Isso comprometeria segurança, coerência e manutenção.

### 20.4 Risco de ignorar contexto editorial e relacional

Isso faria conteúdos e áreas perderem sentido institucional.

### 20.5 Risco de permitir que persistência governe o domínio

Isso inverteria a ordem metodológica correta do projeto.

---

## 21. Declaração Final

O projeto **William Albarello** deverá possuir um modelo de dados conceitual centrado em identidade institucional, organização de áreas e conteúdos, governança relacional e operação interna controlada.

As entidades aqui definidas fornecem a base semântica sobre a qual banco, API, UI/UX, permissões, auditoria e futura camada gerativa poderão ser construídos com maior coerência.

Este modelo não existe para inflar o projeto, mas para impedir que ele cresça sem anatomia.

---

## 22. Status deste Documento

Este documento entra em vigor imediatamente como referência soberana para o modelo de dados conceitual do projeto.

Os documentos seguintes da pasta `01-Obrigatorios` deverão ser compatíveis com ele, salvo revisão formal explícita.
