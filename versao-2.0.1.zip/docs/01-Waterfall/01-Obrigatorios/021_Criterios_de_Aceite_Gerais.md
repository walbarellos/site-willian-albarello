# 021_Criterios_de_Aceite_Gerais

## Identificação do Documento

- **Projeto:** William Albarello
- **Camada:** 01-Waterfall
- **Subpasta:** 01-Obrigatorios
- **Documento:** 021_Criterios_de_Aceite_Gerais.md
- **Função:** Definir os critérios soberanos de aceite do projeto, seus artefatos, fases, fluxos, módulos e entregas, estabelecendo quando algo pode ser considerado efetivamente aceito, reprovado, pendente ou aceito com ressalvas formais
- **Status:** ATIVO
- **Versão:** v1.0
- **Autoridade:** Alta
- **Natureza:** Documento soberano de aceite, validação final e decisão de avanço
- **Dependência superior:**
  - 000_Indice_Mestre.md
  - 001_Manifesto_Metodologico_Waterfall_Caracol.md
  - 002_Regra_de_Nomenclatura_e_Versionamento.md
  - 024_Politica_de_Governanca_Documental.md
  - 001_Visao_Geral_do_Projeto.md
  - 002_Problema_Oportunidade_e_Tese_Central.md
  - 003_Objetivos_Estrategicos_e_Resultados_Esperados.md
  - 004_Escopo_e_Fora_de_Escopo.md
  - 005_Stakeholders_Perfis_e_Atores_do_Sistema.md
  - 006_Requisitos_Funcionais.md
  - 007_Requisitos_Nao_Funcionais.md
  - 008_Regras_de_Negocio.md
  - 009_Casos_de_Uso_Macro.md
  - 010_Jornadas_do_Usuario_e_Fluxos_Principais.md
  - 011_Arquitetura_Geral_do_Sistema.md
  - 012_Modulos_Dominios_e_Limites_do_Software.md
  - 013_Modelo_de_Dados_Conceitual.md
  - 014_Integracoes_e_Sistemas_Externos.md
  - 015_Seguranca_Privacidade_Auditoria_e_Permissoes.md
  - 016_API_Contract_Mestre.md
  - 017_UI_UX_Arquitetura_da_Informacao.md
  - 018_Plano_de_Testes_Homologacao_e_Qualidade.md
  - 019_Riscos_Premissas_Restricoes_e_Mitigacoes.md
  - 020_Cronograma_Fases_Marcos_e_Sequenciamento.md
- **Dependências relacionadas:**
  - 022_Plano_de_Implantacao_Rollback_e_Suporte.md
  - 023_Matriz_de_Rastreabilidade.md
  - 024_Registro_de_Decisoes_Arquiteturais.md

---

## 1. Finalidade

Este documento existe para declarar, de forma soberana, **o que significa “estar pronto”** no projeto **William Albarello**.

Sua função é impedir que o projeto avance por impressão subjetiva, entusiasmo momentâneo, aparência superficial de funcionamento ou interpretação benevolente do que foi entregue.

Este documento fixa:

- o que pode ser aceito;
- em que condições pode ser aceito;
- quem pode considerar algo aceito;
- o que bloqueia aceite;
- o que exige correção antes de avanço;
- quando algo pode ser aceito com ressalva;
- como transformar qualidade e conformidade em decisão objetiva.

Em outras palavras:

> este documento transforma conclusão aparente em aceite soberano.

---

## 2. Tese Central do Documento

A tese central deste documento é a seguinte:

> no projeto William Albarello, nada será considerado concluído apenas porque foi escrito, desenhado, implementado, exibido ou demonstrado; algo só será considerado aceito quando atender, de forma verificável, aos contratos documentais, funcionais, arquiteturais, experienciais, de segurança e de qualidade já formalizados.

Isso significa que o aceite não se resume a:

- “está bonito”;
- “está funcionando aqui”;
- “parece pronto”;
- “dá para seguir depois”;
- “está quase igual ao esperado”.

O aceite exige, simultaneamente:

1. **aderência ao escopo**;
2. **conformidade com o contrato documental**;
3. **funcionamento verificável**;
4. **qualidade mínima coerente com o risco**;
5. **evidência suficiente**;
6. **ausência de falha bloqueadora**;
7. **capacidade real de sustentar a próxima fase**.

---

## 3. Papel Estrutural Deste Documento

Este documento ocupa a camada decisória entre:

- o que foi concebido;
- o que foi documentado;
- o que foi implementado;
- o que foi testado;
- o que foi homologado;
- o que pode avançar de fase;
- o que pode ser publicado.

Ele responde às seguintes perguntas soberanas:

### 3.1 Quando um documento é aceito?

Quando estiver completo, coerente, útil, alinhado à precedência do projeto e apto a orientar a fase seguinte sem lacuna estrutural material.

### 3.2 Quando uma funcionalidade é aceita?

Quando cumprir seu contrato, seus fluxos críticos, seus critérios de qualidade e sua integração mínima com as demais partes do sistema.

### 3.3 Quando uma fase é aceita?

Quando seus entregáveis essenciais estiverem efetivamente produzidos, validados e aprovados contra critérios explícitos.

### 3.4 Quando algo não pode ser aceito?

Quando houver risco crítico não tratado, falha bloqueadora, divergência material entre documento e realidade, ausência de evidência ou quebra de contrato relevante.

---

## 4. Escopo do Documento

Este documento cobre critérios de aceite para:

- documentos do ciclo Waterfall;
- blocos do repositório soberano;
- artefatos de contrato;
- rotas e APIs;
- superfície pública;
- superfície administrativa;
- fluxos críticos;
- segurança básica;
- qualidade e homologação;
- fases e marcos;
- decisão de avanço;
- publicação controlada.

Este documento **não substitui**:

- plano detalhado de testes;
- plano detalhado de implantação;
- matriz detalhada de rastreabilidade;
- ADRs específicos;
- checklist operacional de produção.

Ele define a **régua soberana do aceite**.

---

## 5. Definições Soberanas

Para evitar ambiguidade, o projeto adotará as definições abaixo.

### 5.1 Aceite

Decisão formal de que determinado item atende, no nível exigido, aos critérios necessários para avançar ou ser considerado concluído no contexto do projeto.

### 5.2 Aceite pleno

Aceite sem ressalvas estruturais relevantes.

### 5.3 Aceite com ressalva

Aceite condicionado, permitido apenas quando o desvio remanescente for baixo ou administrável, não comprometer o núcleo do item e estiver explicitamente registrado.

### 5.4 Não aceite

Estado em que o item não está apto a avançar ou ser tratado como concluído.

### 5.5 Evidência de aceite

Registro verificável que sustenta a decisão de aceite.

### 5.6 Critério de aceite

Condição objetiva ou suficientemente verificável que precisa ser atendida para o item ser considerado aceito.

### 5.7 Bloqueador

Falha ou lacuna que impede aceite.

### 5.8 Ressalva

Pendência conhecida que não destrói a aceitação do item, mas que precisa ser registrada e acompanhada.

---

## 6. Princípios Soberanos de Aceite

Os princípios abaixo tornam-se obrigatórios.

### 6.1 Aceite por contrato, não por simpatia

A decisão deve ser orientada pelo corpus soberano do projeto, não por indulgência subjetiva.

### 6.2 Aceite por evidência

Sem evidência suficiente, não há aceite robusto.

### 6.3 Aceite proporcional ao impacto

Quanto maior o impacto do item, maior a exigência de conformidade e validação.

### 6.4 Aceite não apaga risco

Algo pode ser aceito, mas ainda carregar risco residual explicitamente registrado.

### 6.5 Aceite não substitui aprendizado

Aceitar algo não significa que ele não possa ser refinado em fase posterior, desde que o refinamento não desfaça a coerência já estabelecida.

### 6.6 Aceite exige integridade semântica

Se o item contradiz a arquitetura, os requisitos, a UX ou a segurança, ele não deve ser aceito.

### 6.7 Aceite de fase exige fechamento real

Não se deve aceitar fase com lacunas estruturais escondidas por narrativa otimista.

### 6.8 Aceite com ressalva é exceção, não hábito

O projeto não deve normalizar aceitar itens estruturalmente incompletos.

---

## 7. Fontes de Autoridade para o Aceite

Em caso de dúvida sobre a aceitação de um item, a precedência correta será:

1. documentos soberanos do `01-Waterfall`;
2. regras de negócio;
3. contratos de API;
4. arquitetura da informação e UX;
5. plano de testes e homologação;
6. mapa de riscos e restrições;
7. evidências de validação;
8. implementação.

Ou seja:

> a implementação sozinha não define se algo está aceito.

---

## 8. Classes Oficiais de Itens Passíveis de Aceite

O projeto reconhecerá as seguintes classes de aceite:

1. aceite documental;
2. aceite arquitetural;
3. aceite contratual;
4. aceite funcional;
5. aceite experiencial;
6. aceite de segurança;
7. aceite de qualidade;
8. aceite de fase;
9. aceite de implantação/publicação.

---

## 9. Estados Oficiais de Aceite

Todo item relevante deverá ser enquadrado em um dos estados abaixo.

### 9.1 Aceito

O item atende aos critérios exigidos para o seu contexto.

### 9.2 Aceito com ressalva

O item atende ao núcleo dos critérios, mas possui pendência remanescente formalmente registrada e não bloqueadora.

### 9.3 Pendente de validação

O item foi produzido, mas ainda não foi suficientemente validado.

### 9.4 Reprovado

O item foi validado e falhou em critérios relevantes.

### 9.5 Bloqueado

O item não pode sequer seguir para aceite por dependência ausente, risco crítico, falha estrutural ou lacuna de contexto.

---

## 10. Regras Gerais para Decisão de Aceite

Um item só poderá ser aceito quando, cumulativamente, estiverem presentes os elementos abaixo, conforme o seu tipo.

### 10.1 Clareza de escopo

O que está sendo aceito precisa estar claramente definido.

### 10.2 Critério explícito

É necessário existir régua objetiva ou suficientemente verificável.

### 10.3 Evidência mínima

Deve haver base para a decisão, seja documental, técnica, funcional ou experiencial.

### 10.4 Ausência de bloqueador

Não pode existir falha crítica incompatível com o aceite daquele item.

### 10.5 Coerência com a fase

O item precisa estar maduro o bastante para a fase em que se encontra.

### 10.6 Aderência ao corpus soberano

O item não pode contradizer os documentos superiores.

---

## 11. Bloqueadores Gerais de Aceite

Os seguintes elementos bloqueiam aceite de qualquer item relevante.

### 11.1 Divergência material entre documento e realidade

Exemplo: item tratado como concluído, mas arquivo vazio ou implementação inexistente.

### 11.2 Falha crítica em fluxo essencial

Exemplo: contato quebrado, login quebrado, publicação pública inacessível.

### 11.3 Contradição com arquitetura soberana

Exemplo: mistura indevida entre público e admin.

### 11.4 Ausência de evidência mínima

Exemplo: “foi testado” sem qualquer registro verificável.

### 11.5 Dependência superior não concluída

Exemplo: aceitar painel antes do contrato administrativo estar claro.

### 11.6 Risco crítico não mitigado

Exemplo: publicação cogitada com falha séria de autenticação.

### 11.7 Quebra relevante de nomenclatura, contrato ou UX

Exemplo: API entregando semântica incompatível com o frontend.

---

## 12. Critérios Gerais de Aceite Documental

Um documento do ciclo Waterfall será considerado aceito quando atender, no mínimo, aos seguintes critérios.

### 12.1 Existência material

O arquivo realmente existe e contém conteúdo compatível com seu propósito.

### 12.2 Integridade estrutural

O documento possui:

- identificação;
- finalidade;
- tese ou princípio central quando cabível;
- corpo lógico consistente;
- declaração final;
- status claro.

### 12.3 Coerência com a sequência do projeto

O documento não contradiz precedência, nomenclatura ou decisões já consolidadas.

### 12.4 Utilidade real

O documento é apto a orientar a próxima camada do projeto.

### 12.5 Não ornamentalidade

O documento não é apenas retórico; ele cria critério, direção, contrato ou governança útil.

### 12.6 Aderência ao corpus

O documento conversa corretamente com os demais documentos do bloco obrigatório.

### 12.7 Ausência de contradição material conhecida

Se contradizer o estado do acervo, não pode ser aceito sem reconciliação.

---

## 13. Critérios Gerais de Aceite do Bloco `01-Obrigatorios`

O bloco `01-Obrigatorios` só será considerado aceito como núcleo soberano quando:

1. todos os arquivos obrigatórios estiverem efetivamente preenchidos;
2. não houver documento obrigatório vazio tratado como pronto;
3. visão, requisitos, arquitetura, API, UX, testes, riscos, cronograma, aceite, implantação, rastreabilidade e ADRs formarem um todo coerente;
4. a sequência do projeto puder avançar sem reconstruir o tronco;
5. o bloco estiver apto a sustentar detalhamento superior e futura implementação.

---

## 14. Critérios Gerais de Aceite Arquitetural

A arquitetura será considerada aceita quando:

- refletir corretamente o escopo e a tese do projeto;
- separar com clareza superfície pública e administrativa;
- possuir modularidade compreensível;
- não depender de improviso fundamental para funcionar;
- estar coerente com dados, API, segurança e UX;
- ser suficientemente específica para orientar implementação sem rigidez destrutiva.

### Bloqueadores específicos

- fronteiras confusas;
- entidades centrais indefinidas;
- dependências mal resolvidas;
- mistura de preocupações;
- arquitetura contraditória com os requisitos.

---

## 15. Critérios Gerais de Aceite Contratual de API

A camada de API será considerada aceita quando:

1. as rotas obrigatórias existirem no nível documental e, no momento adequado, no nível executável;
2. a separação `/v1/public` e `/v1/admin` estiver preservada;
3. envelopes, status e semântica de erro estiverem coerentes;
4. payloads atenderem ao `016_API_Contract_Mestre.md`;
5. autenticação e autorização administrativa estiverem compatíveis com o contrato;
6. a API sustentar os fluxos públicos e administrativos previstos.

### Bloqueadores específicos

- rotas ausentes sem justificativa;
- mistura entre público e admin;
- vazamento de dados internos em payload público;
- status HTTP incoerente;
- autenticação administrativa inconsistente;
- contrato documental contradito pela implementação.

---

## 16. Critérios Gerais de Aceite da Superfície Pública

A camada pública será considerada aceita quando:

- a navegação principal estiver clara;
- as páginas obrigatórias existirem e fizerem sentido;
- a Home comunicar identidade e direção;
- Sobre, Projetos, Conteúdos/Publicações e Contato forem utilizáveis;
- a leitura for confortável;
- a proposta do projeto estiver inteligível;
- a experiência não parecer improvisada ou semanticamente vazia.

### Bloqueadores específicos

- hero genérico e vazio;
- navegação confusa;
- páginas sem densidade mínima;
- CTA importante quebrado;
- conteúdo principal inacessível;
- quebra grave de responsividade.

---

## 17. Critérios Gerais de Aceite da Superfície Administrativa

A camada administrativa será considerada aceita quando:

- o login funcionar;
- a sessão estiver íntegra;
- o dashboard for legível e operacional;
- publicações puderem ser criadas, editadas e geridas;
- categorias e tags puderem ser governadas;
- a auditoria mínima estiver acessível;
- o painel não depender de adivinhação para operar.

### Bloqueadores específicos

- login falho;
- sessão instável;
- rota administrativa sem proteção;
- publicação não persiste;
- listagem administrativa inutilizável;
- fluxo editorial quebrado;
- ausência total de rastreabilidade mínima.

---

## 18. Critérios Gerais de Aceite de UX e Arquitetura da Informação

A UX será considerada aceita quando:

1. o usuário conseguir entender onde está e para onde pode ir;
2. a hierarquia visual estiver nítida;
3. os estados de loading, erro, vazio e sucesso forem tratados;
4. a navegação pública e administrativa for previsível;
5. a interface reforçar a tese institucional do projeto;
6. a estética não sacrificar legibilidade, conteúdo e clareza.

### Bloqueadores específicos

- hierarquia fraca;
- excesso de ruído visual;
- tela bonita, porém semanticamente vazia;
- ausência de estado de erro;
- fluxo crítico confuso;
- experiência incoerente entre rotas.

---

## 19. Critérios Gerais de Aceite de Segurança Básica

A segurança básica será considerada aceita quando:

- rotas administrativas exigirem autenticação coerente;
- sessão e logout funcionarem;
- não houver vazamento óbvio de dados sensíveis;
- os erros não expuserem internals desnecessários;
- a separação entre papéis fizer sentido;
- o fluxo de contato e o fluxo de login possuírem proteção proporcional ao risco.

### Bloqueadores específicos

- rota administrativa pública por engano;
- autenticação quebrada;
- autorização inexistente ou meramente decorativa;
- erro com vazamento de detalhes sensíveis;
- falha grave de sessão;
- ausência total de contenção em rotas sensíveis.

---

## 20. Critérios Gerais de Aceite Funcional

Uma funcionalidade será considerada aceita quando:

- fizer o que promete;
- respeitar as regras de negócio;
- tratar erros de forma coerente;
- possuir integração suficiente com o restante do sistema;
- não quebrar fluxo central relacionado;
- puder ser usada sem interpretação benevolente.

### Exigência adicional

Quanto mais central a funcionalidade, mais forte o rigor do aceite.

---

## 21. Critérios Gerais de Aceite de Fluxos Críticos

Os fluxos críticos do projeto só serão aceitos quando forem executáveis de ponta a ponta.

---

## 22. Fluxo Crítico F01 — Navegação Institucional Pública

### Será aceito quando:

1. o usuário entrar na Home;
2. compreender a proposta central;
3. conseguir navegar para Sobre, Projetos, Conteúdos/Publicações e Contato;
4. encontrar consistência entre essas áreas;
5. não enfrentar quebra estrutural de navegação.

### Bloqueadores

- links quebrados;
- desorientação grave;
- páginas centrais inexistentes;
- UX incompatível com a proposta do projeto.

---

## 23. Fluxo Crítico F02 — Descoberta e Leitura Editorial

### Será aceito quando:

1. a listagem de publicações funcionar;
2. a abertura de uma publicação individual funcionar;
3. a leitura for legível;
4. houver mecanismo coerente de continuidade, como relacionados;
5. o conteúdo não estiver estruturalmente quebrado.

### Bloqueadores

- listagem vazia sem tratamento;
- slug quebrado;
- publicação inacessível;
- conteúdo mal renderizado;
- navegação editorial interrompida.

---

## 24. Fluxo Crítico F03 — Contato Público

### Será aceito quando:

1. o usuário preencher o formulário;
2. erros de validação forem corretamente tratados;
3. o envio válido funcionar de fato;
4. o backend receber corretamente a submissão;
5. o usuário perceber feedback confiável.

### Bloqueadores

- sucesso falso;
- envio quebrado;
- ausência de validação;
- erro sem orientação;
- perda silenciosa da submissão.

---

## 25. Fluxo Crítico F04 — Login Administrativo

### Será aceito quando:

1. a tela de login estiver clara;
2. credenciais inválidas gerarem erro seguro;
3. credenciais válidas criarem sessão íntegra;
4. o operador autorizado entrar no painel;
5. rotas protegidas respeitarem essa sessão.

### Bloqueadores

- login não autentica;
- erro confuso;
- sessão não persiste;
- rota protegida acessível sem autenticação;
- sessão expira de modo incoerente sem tratamento.

---

## 26. Fluxo Crítico F05 — Gestão Editorial Administrativa

### Será aceito quando:

1. o operador criar publicação;
2. salvar rascunho funcionar;
3. editar funcionar;
4. mudança de status funcionar;
5. a publicação aparecer conforme o estado definido;
6. a superfície pública refletir corretamente o que deve ser público.

### Bloqueadores

- persistência falha;
- slug conflitante sem tratamento;
- status sem efeito real;
- item público/admin incoerente;
- edição destrutiva ou instável.

---

## 27. Fluxo Crítico F06 — Governança de Taxonomia

### Será aceito quando:

1. categorias e tags puderem ser criadas/ajustadas;
2. duplicidades óbvias forem tratadas;
3. associação com publicação fizer sentido;
4. a navegação e o conteúdo não entrarem em caos semântico.

### Bloqueadores

- taxonomia inutilizável;
- duplicidade sem qualquer controle;
- quebra de associação;
- filtro ou categorização incoerente.

---

## 28. Fluxo Crítico F07 — Auditoria Operacional

### Será aceito quando:

1. ações administrativas relevantes produzirem registro coerente;
2. o operador puder ler a trilha mínima;
3. o log não estiver vazio por falha estrutural;
4. a auditoria reforçar confiança operacional.

### Bloqueadores

- inexistência total de rastreabilidade mínima;
- trilha inconsistente;
- evento administrativo sem qualquer reflexo auditável quando deveria existir.

---

## 29. Critérios Gerais de Aceite de Qualidade e Testes

A camada de qualidade será considerada aceita quando:

- os níveis mínimos de validação previstos em `018_Plano_de_Testes_Homologacao_e_Qualidade.md` tiverem sido respeitados;
- os fluxos críticos tiverem sido validados;
- defeitos críticos tiverem sido tratados;
- evidências mínimas estiverem registradas;
- houver base real para homologação.

### Bloqueadores específicos

- ausência de validação mínima;
- homologação improvisada;
- defeito crítico aberto;
- inexistência de evidência para item central.

---

## 30. Critérios Gerais de Aceite por Severidade de Defeito

A decisão de aceite deverá considerar severidade remanescente dos defeitos.

### 30.1 Com defeito crítico aberto

**Não pode haver aceite.**

### 30.2 Com defeito alto aberto

O aceite só poderá ocorrer em caráter excepcional, com justificativa formal, desde que o defeito não comprometa o núcleo do item avaliado.

### 30.3 Com defeito médio aberto

Pode haver aceite com ressalva, dependendo do contexto.

### 30.4 Com defeito baixo aberto

Pode haver aceite pleno ou com ressalva, conforme o impacto agregado.

---

## 31. Critérios de Aceite com Ressalva

Um item só pode ser aceito com ressalva quando, cumulativamente:

1. o núcleo funcional e contratual estiver íntegro;
2. o problema remanescente não for crítico;
3. a pendência estiver explicitamente registrada;
4. o risco residual for conhecido e aceitável;
5. a ressalva não comprometer a próxima fase de forma estrutural.

### Casos típicos aceitáveis com ressalva

- refinamento estético não central;
- microajuste de copy não bloqueador;
- melhoria incremental de responsividade em faixa não crítica;
- otimização futura já registrada, sem comprometer o núcleo da função.

### Casos inaceitáveis com ressalva

- autenticação frágil;
- fluxo de contato incerto;
- divergência documental grave;
- API central quebrada;
- UX central confusa;
- publicação sem rastreabilidade mínima quando exigida.

---

## 32. Critérios de Não Aceite

Um item deverá ser formalmente não aceito quando:

- faltar conteúdo material;
- contradizer documentos superiores;
- falhar em fluxo crítico;
- não possuir evidência mínima;
- depender de correções centrais ainda não realizadas;
- expor risco crítico não mitigado;
- criar falsa percepção de prontidão.

---

## 33. Critérios Gerais de Aceite por Fase

As fases do projeto só podem ser aceitas quando seus marcos e gates estiverem respeitados.

### 33.1 Fase 0 — Constituição documental

Aceita quando índice, manifesto, nomenclatura e governança estiverem consolidados.

### 33.2 Fase 1 — Núcleo obrigatório

Aceita quando `01-Obrigatorios` estiver completo, coerente e reconciliado com a materialidade do acervo.

### 33.3 Fase 2 — Governança de execução

Aceita quando aceite, implantação, rastreabilidade e ADRs estiverem formalizados.

### 33.4 Fase 3 — Detalhamento superior

Aceita quando o refinamento adicional ampliar precisão sem reabrir o tronco soberano.

### 33.5 Fase 4 — Implementação controlada

Aceita quando o software traduzir o corpus de forma coerente.

### 33.6 Fase 5 — Testes e homologação

Aceita quando os fluxos críticos estiverem validados e o sistema estiver apto a decidir publicação.

### 33.7 Fase 6 — Implantação controlada

Aceita quando o sistema entrar em operação inicial com estabilidade mínima e sem falha bloqueadora.

---

## 34. Critérios Gerais de Aceite para Avanço de Fase

Uma fase só poderá avançar quando:

1. seu gate atual estiver satisfeito;
2. os bloqueadores centrais estiverem ausentes;
3. os documentos ou artefatos essenciais da fase estiverem completos;
4. a fase seguinte puder começar sem reconstrução do fundamento;
5. a decisão de avanço puder ser defendida por evidência e coerência.

---

## 35. Critérios de Aceite para Publicação

A publicação de uma entrega real só poderá ser considerada aceitável quando:

- fluxos públicos essenciais estiverem íntegros;
- camada administrativa mínima estiver protegida e funcional;
- critérios de qualidade tiverem sido atendidos;
- homologação favorável tiver ocorrido;
- riscos críticos estiverem tratados;
- houver estratégia mínima de rollback e suporte.

### Bloqueadores absolutos de publicação

- autenticação administrativa falha;
- contato público não confiável;
- publicação pública quebrada;
- risco crítico aberto;
- ausência de rollback mínimo;
- ausência de homologação suficiente.

---

## 36. Evidências Mínimas Aceitáveis

O aceite deverá se apoiar, conforme o item, em evidências como:

- conteúdo material do documento;
- logs de teste;
- resultado de build/lint/typecheck;
- prints ou gravações curtas de fluxo;
- checklist preenchido;
- tabela de rastreabilidade;
- resultado de homologação;
- registro de defeitos e status;
- comparação explícita entre esperado e obtido.

### Regra

Sem algum tipo de evidência proporcional ao item, o aceite perde robustez.

---

## 37. Responsabilidade pelo Aceite

No ciclo atual, a autoridade do projeto pode acumular múltiplos papéis, mas as responsabilidades continuam distintas.

### 37.1 Responsável por produção

Produz o item.

### 37.2 Responsável por validação

Confirma aderência técnica, funcional, documental ou experiencial.

### 37.3 Responsável por homologação

Valida uso real e comportamento integrado.

### 37.4 Responsável por decisão de aceite

Declara o estado final do item: aceito, aceito com ressalva, pendente, reprovado ou bloqueado.

---

## 38. Relação entre Aceite e Risco Residual

O aceite não elimina o risco residual.

Por isso, todo aceite relevante deverá considerar:

- riscos ainda presentes;
- riscos mitigados parcialmente;
- premissas ainda não totalmente validadas;
- limites operacionais aceitos temporariamente.

### Regra soberana

Risco residual conhecido pode coexistir com aceite, desde que:

- não seja crítico;
- esteja registrado;
- tenha plano de monitoramento ou tratamento.

---

## 39. Relação entre Aceite e Cronograma

Este documento deriva de `020_Cronograma_Fases_Marcos_e_Sequenciamento.md`.

Isso significa que:

- cronograma define a ordem de maturação;
- aceite define a régua de encerramento da fase.

Sem critérios de aceite, o cronograma vira só sequência.
Sem cronograma, o aceite perde contexto.

---

## 40. Relação entre Aceite e Testes

Este documento deriva diretamente de `018_Plano_de_Testes_Homologacao_e_Qualidade.md`.

Logo:

- teste fornece evidência;
- aceite transforma evidência em decisão.

Teste sem aceite gera informação sem decisão.
Aceite sem teste gera decisão sem base.

---

## 41. Relação entre Aceite e Riscos

Este documento deriva diretamente de `019_Riscos_Premissas_Restricoes_e_Mitigacoes.md`.

Portanto:

- risco crítico bloqueia aceite;
- premissa não validada aumenta rigor do aceite;
- restrição altera o que é aceitável em determinado ciclo;
- mitigação pode viabilizar aceite que antes seria inviável.

---

## 42. Relação entre Aceite e Implantação

Este documento prepara diretamente `022_Plano_de_Implantacao_Rollback_e_Suporte.md`.

Nada deve ser implantado por sentir-se pronto.

Implantação exige aceite formal daquilo que será publicado.

---

## 43. Relação entre Aceite e Rastreabilidade

Este documento prepara diretamente `023_Matriz_de_Rastreabilidade.md`.

A matriz deverá permitir responder:

- qual requisito sustenta este item aceito;
- qual teste sustenta este aceite;
- qual fluxo foi homologado;
- qual decisão arquitetural influenciou a aceitação.

---

## 44. Relação entre Aceite e ADRs

Este documento prepara diretamente `024_Registro_de_Decisoes_Arquiteturais.md`.

Sempre que o aceite depender de uma interpretação arquitetural relevante, a decisão correspondente deverá ser registrada.

---

## 45. Critérios de Aceite do Estado Atual do Projeto

No estágio atual do projeto, a leitura correta do aceite parcial é a seguinte:

### 45.1 Já aceito em alto nível estrutural

- núcleo constitucional do repositório;
- fundação estratégica;
- fundação funcional;
- fundação arquitetural principal;
- direção contratual da API;
- direção de UI/UX;
- plano de testes;
- mapa de riscos;
- cronograma lógico.

### 45.2 Ainda não plenamente aceito como fechamento total do obrigatório

O bloco `01-Obrigatorios` ainda não pode ser considerado plenamente aceito como encerrado, porque ainda restam:

- `021_Criterios_de_Aceite_Gerais.md`
- `022_Plano_de_Implantacao_Rollback_e_Suporte.md`
- `023_Matriz_de_Rastreabilidade.md`
- `024_Registro_de_Decisoes_Arquiteturais.md`

### 45.3 Consequência soberana

O projeto está em estado de **aceite parcial alto**, mas ainda não em **aceite pleno do núcleo obrigatório**.

---

## 46. Anti-padrões de Aceite Expressamente Rejeitados

Ficam rejeitados, desde já:

- aceitar item vazio porque “será preenchido depois”;
- aceitar por entusiasmo;
- aceitar só porque a implementação existe;
- aceitar documento ornamental sem utilidade real;
- aceitar fluxo central com falha conhecida não bloqueadora “por enquanto”;
- aceitar sem evidência;
- aceitar algo contraditório ao corpus soberano;
- aceitar fase sem fechamento material dos seus entregáveis;
- aceitar publicação como forma de descobrir se estava pronta.

---

## 47. Critérios de Aceite Deste Documento

Este documento será considerado corretamente consolidado quando:

1. definir o que é aceite, não aceite, bloqueio e ressalva;
2. fixar a relação entre aceite, evidência, risco e qualidade;
3. estabelecer critérios gerais para documentos, fases, API, UX, segurança e fluxos;
4. explicitar o que bloqueia aceite;
5. permitir decisões objetivas de avanço;
6. integrar-se logicamente ao cronograma, testes, riscos, implantação e rastreabilidade;
7. deixar claro que “pronto” sem régua não vale;
8. tornar o aceite uma disciplina soberana do projeto.

---

## 48. Declaração Final

Com este documento, o projeto **William Albarello** passa a possuir uma **régua soberana de aceite**, capaz de distinguir com clareza:

- o que está apenas produzido;
- o que está validado;
- o que está aceito;
- o que está aceito com ressalva;
- o que está reprovado;
- o que está bloqueado.

A partir daqui, o projeto deixa de depender de percepção vaga de conclusão.

Ele passa a depender de critérios.

E isso é decisivo, porque uma obra ambiciosa sem critério de aceite pode produzir muito material e ainda assim não saber, com verdade, o que realmente construiu.

---

## 49. Status do Documento

**Documento consolidado como base soberana de critérios gerais de aceite do projeto William Albarello, apto a orientar decisão de avanço, homologação, implantação, rastreabilidade e validação formal das entregas do sistema.**
