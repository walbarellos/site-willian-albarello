# 010_Jornadas_do_Usuario_e_Fluxos_Principais

## Identificação do Documento

- **Projeto:** William Albarello
- **Camada:** 01-Waterfall
- **Subpasta:** 01-Obrigatorios
- **Documento:** 010_Jornadas_do_Usuario_e_Fluxos_Principais.md
- **Função:** Definir as jornadas centrais dos usuários e os fluxos principais do sistema, traduzindo casos de uso macro em percursos estruturados, coerentes e orientados à experiência institucional do projeto
- **Status:** ATIVO
- **Versão:** v1.0
- **Autoridade:** Alta
- **Natureza:** Documento soberano de jornadas e fluxos principais
- **Dependência superior:**
  - 000_Indice_Mestre.md
  - 001_Manifesto_Metodologico_Waterfall_Caracol.md
  - 002_Regra_de_Nomenclatura_e_Versionamento.md
  - 024_Politica_de_Governanca_Documental.md
  - 001_Visao_Geral_do_Projeto.md
  - 002_Problema_Oportunidade_e_Tese_Central.md
  - 003_Objetivos_Estrategicos_e_Resultados_Esperados.md
  - 004_Escopo_e_Fora_de_Escopo.md
  - 005_Stakeholders_Perfis_e_Atores_do_Sistema.md
  - 006_Requisitos_Funcionais.md
  - 007_Requisitos_Nao_Funcionais.md
  - 008_Regras_de_Negocio.md
  - 009_Casos_de_Uso_Macro.md
- **Dependências relacionadas:**
  - 011_Arquitetura_Geral_do_Sistema.md
  - 015_Seguranca_Privacidade_Auditoria_e_Permissoes.md
  - 016_API_Contract_Mestre.md
  - 017_UI_UX_Arquitetura_da_Informacao.md
  - 018_Plano_de_Testes_Homologacao_e_Qualidade.md
  - 021_Criterios_de_Aceite_Gerais.md

---

## 1. Finalidade

Este documento existe para transformar os casos de uso macro do projeto em **percursos inteligíveis de interação**.

Sua função é responder, de forma estruturada, às seguintes perguntas:

1. como os principais perfis entram no sistema;
2. como avançam entre compreensão inicial, aprofundamento e relação;
3. quais são os fluxos centrais que a solução precisa sustentar;
4. como a experiência deve preservar coerência institucional, clareza e continuidade.

Sem este documento, o projeto corre o risco de possuir requisitos corretos e casos de uso bem formulados, mas ainda sem tradução suficiente para a organização da experiência, da arquitetura da informação e dos fluxos principais.

Este documento não substitui wireframes, protótipos ou contratos técnicos.

Ele fixa a lógica macro de percurso.

---

## 2. Princípio Geral das Jornadas

Neste projeto, jornada não significa apenas sequência mecânica de cliques.

Jornada significa **trajetória de sentido**.

Cada jornada deve ser entendida como o caminho pelo qual um ator:

- entra em contato com o sistema;
- compreende onde está;
- encontra um percurso compatível com seu nível de interesse;
- aprofunda-se sem perder contexto;
- alcança um estado de entendimento, relação ou operação coerente com seu papel.

A regra central é esta:

> a jornada correta não apenas leva o usuário de um ponto a outro;  
> ela organiza a progressão do seu entendimento e da sua relação com o projeto.

---

## 3. Princípios Estruturais das Jornadas

### 3.1 Entrada com clareza

Toda jornada deve começar com sinais claros de identidade, proposta e organização.

### 3.2 Aprofundamento progressivo

O sistema deve permitir que diferentes perfis avancem em níveis crescentes de compreensão, sem exigir profundidade máxima logo no primeiro contato.

### 3.3 Continuidade semântica

O usuário não deve sentir que está sendo deslocado para áreas sem relação perceptível com o todo.

### 3.4 Diferenciação por intenção

Nem todos os usuários entram com o mesmo objetivo. O sistema deve reconhecer jornadas de:

- descoberta;
- aprofundamento;
- avaliação;
- aproximação;
- operação interna.

### 3.5 Preservação da dignidade institucional

Toda jornada, mesmo a mais simples, deve reforçar a seriedade e a coerência do projeto.

---

## 4. Macrotipos de Jornada

Para este projeto, as jornadas principais serão agrupadas em cinco macrofamílias.

### 4.1 Jornada de descoberta institucional

Voltada ao visitante que chega sem contexto suficiente e precisa entender rapidamente o que é o projeto.

### 4.2 Jornada de aprofundamento qualificado

Voltada ao ator que, após a primeira compreensão, deseja explorar áreas, conteúdos ou projetos em maior profundidade.

### 4.3 Jornada de leitura e exploração relacional

Voltada ao ator cujo interesse está em navegar por materiais, temas e conexões internas do sistema.

### 4.4 Jornada de aproximação ou contato

Voltada ao ator que deseja sair da condição de visitante e aproximar-se institucionalmente do projeto.

### 4.5 Jornada de operação interna

Voltada aos atores autorizados que mantêm, atualizam, governam ou evoluem a solução.

---

## 5. Jornada J-01 — Descoberta Institucional

### 5.1 Atores principais

- Visitante Público
- Interessado Qualificado, em seu primeiro contato

### 5.2 Intenção inicial

Compreender, de forma rápida e confiável:

- quem é William Albarello;
- o que é o projeto;
- por que a presença digital existe;
- como a solução está organizada.

### 5.3 Ponto de entrada típico

- página inicial;
- rota institucional principal;
- ponto de entrada público equivalente.

### 5.4 Fluxo macro da jornada

1. o ator acessa a camada pública principal;
2. identifica sinais de identidade e proposta;
3. compreende a natureza geral do projeto;
4. reconhece as áreas centrais disponíveis;
5. decide se permanece em leitura geral ou aprofunda em uma trilha específica.

### 5.5 Resultado esperado

O ator sai do estado de desconhecimento para um estado de compreensão institucional básica, com segurança suficiente para continuar navegando.

### 5.6 Riscos que esta jornada deve evitar

- entrada confusa;
- excesso de abstração inicial;
- densidade informacional prematura;
- falta de trilha clara para aprofundamento.

---

## 6. Jornada J-02 — Aprofundamento Qualificado

### 6.1 Atores principais

- Interessado Qualificado
- Visitante Público que evoluiu de curiosidade para interesse concreto

### 6.2 Intenção inicial

Aprofundar a compreensão sobre áreas, projetos, conteúdos, mensagens centrais ou frentes relevantes do sistema.

### 6.3 Ponto de entrada típico

- área institucional específica;
- seção temática;
- rota de projeto ou conteúdo relacionado.

### 6.4 Fluxo macro da jornada

1. o ator parte de uma compreensão geral já obtida;
2. seleciona uma área de interesse específico;
3. recebe contexto suficiente sobre essa área;
4. explora conteúdos, materiais ou subblocos relacionados;
5. identifica relações entre aquela área e o restante do projeto;
6. decide aprofundar mais, regressar ao todo ou iniciar aproximação.

### 6.5 Resultado esperado

O ator compreende melhor uma parte do sistema sem perder a relação com a visão global do projeto.

### 6.6 Riscos que esta jornada deve evitar

- aprofundamento sem contexto;
- conteúdo isolado sem enquadramento;
- perda de vínculo com a arquitetura do todo;
- repetição estéril da camada introdutória.

---

## 7. Jornada J-03 — Leitura e Exploração Relacional

### 7.1 Atores principais

- Leitor de Conteúdo
- Interessado Qualificado

### 7.2 Intenção inicial

Consumir materiais, textos, projetos ou conteúdos vinculados ao projeto, com capacidade de transitar entre elementos relacionados.

### 7.3 Ponto de entrada típico

- conteúdo específico;
- seção de materiais;
- página temática;
- bloco de projeto com elementos relacionados.

### 7.4 Fluxo macro da jornada

1. o ator acessa um conteúdo ou material específico;
2. compreende o contexto daquele item;
3. consome o material principal;
4. identifica relações com outros conteúdos, áreas ou projetos;
5. continua explorando por afinidade temática ou institucional;
6. aprofunda a percepção do ecossistema do projeto.

### 7.5 Resultado esperado

A leitura não termina no item isolado; ela amplia a compreensão do conjunto e reforça a coerência interna da solução.

### 7.6 Riscos que esta jornada deve evitar

- conteúdo órfão;
- leitura sem trilha de continuidade;
- excesso de fragmentação;
- sobrecarga de opções desconectadas.

---

## 8. Jornada J-04 — Aproximação e Contato

### 8.1 Atores principais

- Interessado Qualificado
- Interlocutor Estratégico
- Visitante Público que deseja evoluir para relação

### 8.2 Intenção inicial

Encontrar meio legítimo de aproximação, contato ou manifestação de interesse, após avaliar a proposta e a coerência do projeto.

### 8.3 Ponto de entrada típico

- seção de contato;
- rota de aproximação institucional;
- chamada contextual distribuída em pontos adequados do sistema.

### 8.4 Fluxo macro da jornada

1. o ator percorre a camada pública e forma juízo de valor sobre o projeto;
2. identifica que deseja avançar para uma relação mais concreta;
3. encontra caminho de contato coerente com seu nível de interesse;
4. acessa mecanismo ou informação de aproximação;
5. inicia manifestação de interesse ou contato;
6. conclui a jornada em estado de aproximação formalizada ou encaminhada.

### 8.5 Resultado esperado

O ator consegue sair da condição de visitante para a condição de interlocutor potencial, sem ruído, sem improviso e sem quebra de dignidade institucional.

### 8.6 Riscos que esta jornada deve evitar

- contato escondido ou desorganizado;
- transição brusca entre conteúdo e aproximação;
- mecanismos de contato que empobreçam a imagem institucional;
- falta de distinção entre curiosidade difusa e interesse qualificado.

---

## 9. Jornada J-05 — Administração e Manutenção Interna

### 9.1 Atores principais

- Administrador Principal
- Editor ou Operador de Conteúdo

### 9.2 Intenção inicial

Acessar a camada interna do sistema para manter, atualizar, revisar ou governar partes autorizadas da solução.

### 9.3 Ponto de entrada típico

- área administrativa restrita;
- fluxo autenticado de operação.

### 9.4 Fluxo macro da jornada

1. o ator acessa a entrada da área interna;
2. autentica-se conforme seu perfil;
3. acessa ambiente compatível com suas permissões;
4. localiza o recurso, conteúdo ou estrutura sob sua responsabilidade;
5. realiza ação autorizada de manutenção, edição ou revisão;
6. conclui a operação preservando coerência estrutural e rastreabilidade adequada.

### 9.5 Resultado esperado

O sistema permite manutenção eficaz sem contaminar a camada pública e sem comprometer a integridade institucional.

### 9.6 Riscos que esta jornada deve evitar

- mistura entre experiência pública e operação interna;
- permissões excessivamente amplas;
- dificuldade de localização de funções internas;
- manutenção destrutiva por falta de controle ou contexto.

---

## 10. Jornada J-06 — Evolução Controlada da Estrutura

### 10.1 Atores principais

- Titular Institucional
- Administrador Principal
- Mantenedor Técnico

### 10.2 Intenção inicial

Expandir, revisar ou aperfeiçoar a estrutura do sistema sem romper a coerência já consolidada.

### 10.3 Ponto de entrada típico

- processo interno de revisão estratégica;
- análise de necessidade nova;
- ciclo de evolução arquitetural ou funcional.

### 10.4 Fluxo macro da jornada

1. surge necessidade legítima de ampliação ou ajuste;
2. a necessidade é analisada à luz da documentação soberana;
3. verifica-se aderência a visão, escopo, objetivos e regras de negócio;
4. a expansão é traduzida em ajuste estrutural ou modular coerente;
5. a solução evolui mantendo continuidade e governança;
6. o sistema preserva unidade mesmo após crescimento.

### 10.5 Resultado esperado

A evolução acontece como encaixe e maturação, e não como remendo caótico.

### 10.6 Riscos que esta jornada deve evitar

- crescimento por impulso;
- expansão sem documentação;
- modularização arbitrária;
- alteração técnica que contrarie a lógica institucional do projeto.

---

## 11. Fluxos Principais do Sistema

Além das jornadas, o projeto reconhece os seguintes fluxos principais em nível macro.

### FP-01 — Fluxo de Entrada Institucional

Fluxo pelo qual o visitante chega, identifica a proposta do projeto e entende sua natureza básica.

### FP-02 — Fluxo de Navegação Estrutural

Fluxo pelo qual o visitante se move entre áreas principais sem perder orientação.

### FP-03 — Fluxo de Aprofundamento

Fluxo pelo qual o interessado avança de leitura geral para leitura específica e contextualizada.

### FP-04 — Fluxo de Exploração Relacional

Fluxo pelo qual conteúdos, áreas e projetos se vinculam entre si de modo inteligível.

### FP-05 — Fluxo de Aproximação

Fluxo pelo qual o usuário transita da compreensão do projeto para uma ação relacional concreta, como contato ou manifestação de interesse.

### FP-06 — Fluxo de Operação Interna

Fluxo pelo qual atores autorizados acessam, mantêm e governam a solução.

### FP-07 — Fluxo de Evolução Controlada

Fluxo pelo qual o sistema cresce ou se ajusta em conformidade com a base documental e arquitetural.

---

## 12. Estados Macro do Usuário ao Longo das Jornadas

Em termos de experiência e entendimento, o projeto reconhece que os usuários podem atravessar estados macro como:

1. **desconhecimento**;
2. **compreensão inicial**;
3. **interesse qualificado**;
4. **aprofundamento contextualizado**;
5. **avaliação de valor e seriedade**;
6. **aproximação relacional**;
7. **operação interna**, no caso de perfis autorizados.

O sistema deverá favorecer transições coerentes entre esses estados, respeitando o perfil e a intenção do ator.

---

## 13. Relação entre Jornadas e Arquitetura da Informação

A arquitetura da informação futura deverá ser desenhada para sustentar estas jornadas.

Isso implica que ela deverá prever:

- pontos claros de entrada;
- diferenciação entre leitura introdutória e aprofundamento;
- organização temática ou institucional compreensível;
- rotas de continuidade entre conteúdos e áreas;
- pontos adequados de aproximação;
- separação entre público e interno.

Se a arquitetura da informação não sustentar essas jornadas, a solução ficará sem trilhas legítimas de uso.

---

## 14. Relação entre Jornadas e UI/UX

A futura camada de UI/UX deverá ser desenhada não apenas para “ficar bonita”, mas para viabilizar as jornadas aqui definidas.

Isso significa que a interface deverá:

- deixar claro onde começar;
- indicar para onde seguir;
- facilitar aprofundamento progressivo;
- reduzir perda de contexto;
- apoiar transições entre descoberta, leitura, avaliação e aproximação.

UX boa, neste projeto, é UX que organiza sentido.

---

## 15. Relação entre Jornadas e Regras de Negócio

As jornadas não podem contradizer as regras de negócio do sistema.

Isso implica que:

- conteúdos devem aparecer com contexto;
- camadas públicas e internas devem permanecer separadas;
- crescimento futuro precisa preservar coerência;
- contato deve respeitar dignidade institucional;
- manutenção não pode deformar a identidade representada.

---

## 16. O que Este Documento Não Faz

Este documento não:

- detalha wireframes;
- substitui fluxogramas finos de interface;
- define todos os passos de autenticação;
- especifica mensagens de feedback por estado;
- descreve endpoints de API;
- fixa modelo de dados;
- resolve todas as exceções operacionais.

Sua função é estabelecer a lógica soberana dos percursos e fluxos principais.

---

## 17. Riscos de Desvio em Relação a Este Documento

### 17.1 Risco de tratar jornada como navegação mecânica

Isso esvaziaria a dimensão institucional e relacional do sistema.

### 17.2 Risco de desenhar uma experiência sem progressão de profundidade

Isso tornaria o projeto superficial ou confuso.

### 17.3 Risco de misturar todas as jornadas em uma única experiência indiferenciada

Isso prejudicaria tanto visitantes gerais quanto interessados qualificados e operadores internos.

### 17.4 Risco de esquecer a jornada de evolução controlada

Isso enfraqueceria a visão de expansão disciplinada do projeto.

### 17.5 Risco de priorizar estética sobre inteligibilidade de percurso

Isso produziria experiência visualmente atraente, mas funcionalmente pobre.

---

## 18. Declaração Final

O projeto **William Albarello** deverá oferecer não apenas funções isoladas, mas percursos coerentes de descoberta, compreensão, aprofundamento, relação, operação e evolução.

As jornadas e fluxos principais aqui definidos traduzem a lógica relacional do sistema e estabelecem como os diferentes atores deverão atravessar a solução de modo significativo.

Eles orientarão arquitetura da informação, UX, arquitetura geral, critérios de aceite e futura implementação, preservando a coerência entre identidade, uso e crescimento do projeto.

---

## 19. Status deste Documento

Este documento entra em vigor imediatamente como referência soberana para as jornadas do usuário e fluxos principais do projeto.

Os documentos seguintes da pasta `01-Obrigatorios` deverão ser compatíveis com ele, salvo revisão formal explícita.
