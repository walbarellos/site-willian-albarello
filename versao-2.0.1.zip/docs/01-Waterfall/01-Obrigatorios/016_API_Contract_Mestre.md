
# 016_API_Contract_Mestre

## Identificação do Documento

- **Projeto:** William Albarello
- **Camada:** 01-Waterfall
- **Subpasta:** 01-Obrigatorios
- **Documento:** 016_API_Contract_Mestre.md
- **Função:** Definir o contrato mestre de APIs do projeto, suas fronteiras, convenções, recursos obrigatórios, envelopes, políticas de autenticação, versionamento e governança, preparando a solução para implementação coerente, validação contratual e evolução sem ruptura
- **Status:** ATIVO
- **Versão:** v1.0
- **Autoridade:** Alta
- **Natureza:** Documento soberano de contrato de API
- **Dependência superior:**
  - 000_Indice_Mestre.md
  - 001_Manifesto_Metodologico_Waterfall_Caracol.md
  - 002_Regra_de_Nomenclatura_e_Versionamento.md
  - 024_Politica_de_Governanca_Documental.md
  - 001_Visao_Geral_do_Projeto.md
  - 002_Problema_Oportunidade_e_Tese_Central.md
  - 003_Objetivos_Estrategicos_e_Resultados_Esperados.md
  - 004_Escopo_e_Fora_de_Escopo.md
  - 005_Stakeholders_Perfis_e_Atores_do_Sistema.md
  - 006_Requisitos_Funcionais.md
  - 007_Requisitos_Nao_Funcionais.md
  - 008_Regras_de_Negocio.md
  - 009_Casos_de_Uso_Macro.md
  - 010_Jornadas_do_Usuario_e_Fluxos_Principais.md
  - 011_Arquitetura_Geral_do_Sistema.md
  - 012_Modulos_Dominios_e_Limites_do_Software.md
  - 013_Modelo_de_Dados_Conceitual.md
  - 014_Integracoes_e_Sistemas_Externos.md
  - 015_Seguranca_Privacidade_Auditoria_e_Permissoes.md
- **Dependências relacionadas:**
  - 017_UI_UX_Arquitetura_da_Informacao.md
  - 018_Plano_de_Testes_Homologacao_e_Qualidade.md
  - 019_Riscos_Premissas_Restricoes_e_Mitigacoes.md
  - 021_Criterios_de_Aceite_Gerais.md
  - 023_Matriz_de_Rastreabilidade.md
  - 024_Registro_de_Decisoes_Arquiteturais.md

---

## 1. Finalidade

Este documento existe para declarar, de forma soberana, o **contrato mestre de APIs** do projeto **William Albarello**.

Sua função é transformar a arquitetura, os módulos, a modelagem conceitual, as regras de negócio, a política de segurança e as jornadas já definidas em um conjunto claro de convenções e recursos contratuais que possa ser implementado sem improviso e evoluído sem colapso semântico.

Este documento responde, de forma explícita, às seguintes perguntas:

1. quais APIs o projeto realmente precisa reconhecer neste ciclo;
2. como essas APIs devem ser organizadas;
3. quais convenções de rota, payload, autenticação, paginação e erro são obrigatórias;
4. como diferenciar contrato público de contrato administrativo;
5. quais recursos são mandatórios já no ciclo fundacional;
6. quais recursos ficam reservados para expansão posterior sem quebrar compatibilidade.

Este documento **não é o OpenAPI executável em si**.

Ele é a constituição conceitual e contratual da camada de APIs.

---

## 2. Tese Contratual Central

A tese central deste documento é a seguinte:

> a camada de APIs do projeto William Albarello deve nascer pequena, explícita, versionada, estável e semanticamente limpa, separando com nitidez a exposição pública da operação administrativa, de modo que o sistema possa crescer sem misturar representação institucional, lógica editorial, contato relacional e governança interna.

Em termos práticos, isso significa que a API **não deverá nascer** como:

- coleção solta de endpoints sem hierarquia;
- backend genérico inflado por antecipação;
- painel administrativo exposto como extensão improvisada do site público;
- contrato moldado apenas pelo código existente;
- interface de integração que contradiz a documentação soberana do projeto.

A API deverá emergir da arquitetura do projeto, e não o contrário.

---

## 3. Natureza e Autoridade do Contrato

### 3.1 Natureza

Este é o documento que fixa:

- namespaces oficiais de API;
- política de versionamento;
- envelopes de sucesso e erro;
- princípios de autenticação e autorização;
- catálogo mínimo de recursos;
- políticas de compatibilidade;
- reservas de expansão futura.

### 3.2 Autoridade

Em caso de conflito, a precedência correta será:

1. documentos soberanos do ciclo `01-Waterfall/01-Obrigatorios`;
2. este `016_API_Contract_Mestre.md`;
3. OpenAPI derivado;
4. testes de contrato;
5. implementação.

Ou seja:

> o código não redefine sozinho o contrato.

### 3.3 Relação com anexos herdados

Há anexos herdados no acervo anterior com documentação robusta de APIs, especialmente em:

- `personal-site (1)/personal-site/APIs/API-00-governanca.md`
- `personal-site (1)/personal-site/APIs/API-01-padroes-rest.md`
- `personal-site (1)/personal-site/APIs/API-02-versionamento.md`
- `personal-site (1)/personal-site/APIs/API-03-seguranca-auth.md`
- `personal-site (1)/personal-site/APIs/API-04-erros-paginacao-filtros.md`
- `personal-site (1)/personal-site/APIs/API-05-openapi-estrutura.md`
- `personal-site (1)/personal-site/APIs/API-06-openapi-public.yaml`
- `personal-site (1)/personal-site/APIs/API-07-openapi-admin.yaml`
- `personal-site (1)/personal-site/APIs/API-08-webhooks-eventos.md`

Esses materiais são **referência útil**, mas não possuem autoridade para substituir a fundação soberana deste documento.

---

## 4. Normalizações Obrigatórias

### 4.1 Nome canônico do projeto

O nome canônico deste projeto, para fins de documentação soberana, é:

**William Albarello**

Mesmo que anexos antigos tragam a grafia `Willian`, a forma soberana deste ciclo é `William`.

### 4.2 Prefixo de versão

Toda API institucional deste projeto deverá operar sob **prefixo de versão explícito**:

```text
/v1
````

### 4.3 Namespaces oficiais

Dentro de `/v1`, a API deverá separar claramente dois namespaces macro:

```text
/v1/public
/v1/admin
```

Qualquer prefixo adicional de infraestrutura, gateway, reverse proxy ou hospedagem, como `/api`, é detalhe de implantação, não do contrato lógico soberano.

### 4.4 Formato de dados

O contrato deverá operar, por padrão, com:

* JSON sobre HTTPS;
* `uuid` como identificador técnico principal;
* `slug` para identificação pública amigável quando fizer sentido;
* datas em ISO 8601 UTC;
* nomes de campos em `camelCase` no payload JSON.

### 4.5 Recursos no plural

Recursos REST deverão usar plural quando representarem coleções:

* `/publications`
* `/categories`
* `/tags`
* `/audit-logs`

### 4.6 Estado de compatibilidade

Campos novos em `v1` deverão, por padrão, entrar como opcionais, salvo quando houver ruptura formalmente planejada para nova versão.

---

## 5. Escopo Contratual do Ciclo Fundacional

A API deste projeto, neste estágio, deverá reconhecer **dois grandes domínios contratuais**.

### 5.1 Domínio A — API Pública

Voltado à composição e entrega da camada pública do sistema.

Responsabilidades principais:

* entregar páginas públicas compostas;
* listar e detalhar publicações públicas;
* receber contato ou manifestação legítima de interesse.

### 5.2 Domínio B — API Administrativa

Voltado à operação autenticada da camada interna.

Responsabilidades principais:

* autenticação e sessão administrativa;
* leitura de dashboard operacional;
* criação, edição, revisão, publicação e arquivamento de publicações;
* governança de categorias e tags;
* rastreabilidade via auditoria.

### 5.3 Domínio reservado para ciclos posteriores

Não faz parte do núcleo obrigatório imediato, mas fica desde já reservado:

* webhooks/eventos externos;
* fila assíncrona de automações;
* integrações administrativas avançadas;
* API específica para gestão de mensagens de contato;
* contratos de busca mais sofisticados;
* headless delivery mais granular de blocos institucionais.

---

## 6. Princípios Estruturais do Contrato

### 6.1 Clareza maior que exuberância

O contrato deve ser fácil de implementar, testar, documentar e consumir.

### 6.2 Separação nítida entre público e interno

Recursos públicos não devem carregar sem necessidade o peso da operação interna.

### 6.3 Minimização contratual

A API deve expor apenas o necessário para a finalidade legítima de cada fluxo.

### 6.4 Evolução sem quebra arbitrária

Mudanças contratuais relevantes devem obedecer política formal de compatibilidade.

### 6.5 Semântica alinhada ao domínio

O contrato deve refletir a organização do projeto, e não apenas uma conveniência momentânea de implementação.

### 6.6 Preparação para testes de contrato

Todo endpoint obrigatório deverá poder ser validado posteriormente por testes automatizados e checklist manual.

---

## 7. Convenções Obrigatórias de Payload

### 7.1 Envelope de sucesso

Toda resposta de sucesso com corpo JSON deverá obedecer a estrutura:

```json
{
  "data": {},
  "meta": {
    "traceId": "uuid"
  }
}
```

Quando houver paginação, `meta` deverá admitir:

```json
{
  "page": 1,
  "pageSize": 10,
  "totalItems": 42,
  "totalPages": 5,
  "traceId": "uuid"
}
```

### 7.2 Envelope de erro

Toda resposta de erro com corpo JSON deverá obedecer a estrutura:

```json
{
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "Os dados enviados são inválidos.",
    "details": []
  },
  "meta": {
    "traceId": "uuid"
  }
}
```

### 7.3 Ausência de corpo

Respostas `204 No Content` não deverão retornar corpo.

### 7.4 Meta obrigatória

`meta.traceId` é obrigatório em toda resposta JSON, inclusive em respostas de erro.

### 7.5 Campos internos não públicos

Campos internos não devem vazar para o namespace público, tais como:

* observações internas;
* flags operacionais de revisão;
* dados sensíveis de auditoria;
* identificadores técnicos desnecessários ao consumo público;
* histórico interno de alterações.

---

## 8. Convenções de Identificadores, Datas e Tipos

### 8.1 IDs

Por padrão, entidades administrativas e persistidas usarão `uuid`.

### 8.2 Slugs

Entidades públicas navegáveis poderão expor `slug` estável para leitura pública.

### 8.3 Datas

Todo timestamp deverá ser serializado em ISO 8601 UTC, por exemplo:

```text
2026-04-03T18:25:00Z
```

### 8.4 Campos booleanos

Booleans devem ser explícitos.

Evitar convenções ambíguas como string `"yes"`, `"no"`, `"1"`, `"0"`.

### 8.5 Listas

Coleções sempre deverão aparecer como arrays, ainda que vazios.

---

## 9. Política de Segurança, Sessão e Autorização

### 9.1 API pública

Rotas públicas deverão ser legíveis sem autenticação, exceto quando, no futuro, houver recurso público restrito explicitamente documentado.

### 9.2 API administrativa

Rotas administrativas exigirão autenticação por sessão segura em cookie.

### 9.3 Sessão administrativa

O padrão fundacional definido é:

* cookie `HttpOnly`;
* `Secure` em produção;
* `SameSite` adequado ao domínio de operação;
* expiração governada por política de sessão;
* invalidação explícita em logout.

### 9.4 CSRF

Rotas mutáveis do namespace `/v1/admin` deverão exigir proteção CSRF quando operarem com sessão baseada em cookie.

### 9.5 Menor privilégio

A autenticação por si só não basta.

A implementação deverá respeitar autorização por papel, no mínimo com os seguintes papéis conceituais:

* `admin`
* `editor`
* `maintainer`
* `owner`

Esses rótulos técnicos são a materialização contratual dos perfis já reconhecidos em `015_Seguranca_Privacidade_Auditoria_e_Permissoes.md`.

### 9.6 Rate limiting

No mínimo, deverão existir controles proporcionais em:

* `POST /v1/admin/auth/login`
* `POST /v1/public/contact`

### 9.7 Mensagens de erro seguras

A API não deverá vazar detalhes sensíveis de autenticação, existência de conta, configuração interna ou stack trace em respostas públicas.

---

## 10. Catálogo Oficial de Códigos HTTP

Os seguintes códigos formam o catálogo contratual base do projeto:

* `200 OK`
* `201 Created`
* `204 No Content`
* `400 Bad Request`
* `401 Unauthorized`
* `403 Forbidden`
* `404 Not Found`
* `409 Conflict`
* `422 Unprocessable Entity`
* `429 Too Many Requests`
* `500 Internal Server Error`

Códigos adicionais só deverão entrar quando documentalmente justificados.

---

## 11. Catálogo Oficial de Erros

Os seguintes códigos semânticos de erro ficam aprovados neste ciclo:

* `VALIDATION_ERROR`
* `BAD_REQUEST`
* `UNAUTHENTICATED`
* `FORBIDDEN`
* `NOT_FOUND`
* `CONFLICT`
* `RATE_LIMITED`
* `SESSION_EXPIRED`
* `INTERNAL_ERROR`

Quando necessário, `details` poderá trazer erros por campo no formato:

```json
[
  {
    "field": "email",
    "message": "Formato inválido."
  }
]
```

---

## 12. Contrato Oficial da API Pública

O núcleo obrigatório da API pública neste ciclo é o seguinte.

### 12.1 `GET /v1/public/pages/{key}`

#### Finalidade

Entregar uma página pública composta por chave lógica.

#### Finalidade arquitetural

Materializar a camada pública institucional sem expor o frontend à montagem arbitrária a partir de múltiplas fontes não governadas.

#### Exemplos de `key`

* `home`
* `sobre`
* `contato`
* `projetos`
* `conteudos`

#### Resposta conceitual esperada

```json
{
  "data": {
    "key": "home",
    "title": "William Albarello",
    "seo": {
      "title": "William Albarello",
      "description": "Base digital soberana de presença, autoridade e evolução estruturada."
    },
    "blocks": [
      {
        "type": "hero",
        "title": "Presença institucional com método",
        "body": "Arquitetura, conteúdo, organização e evolução com coerência.",
        "order": 1
      }
    ],
    "updatedAt": "2026-04-03T18:25:00Z"
  },
  "meta": {
    "traceId": "uuid"
  }
}
```

#### Observações obrigatórias

* a página pública deve ser retornada já em composição coerente;
* o contrato não obriga o frontend a conhecer regras internas de montagem;
* blocos devem ser retornados de forma ordenada.

---

### 12.2 `GET /v1/public/publications`

#### Finalidade

Listar publicações públicas disponíveis.

#### Query params aprovados

* `page`
* `pageSize`
* `q`
* `category`
* `tag`
* `sort`

#### Regras contratuais

* apenas publicações visíveis publicamente podem aparecer nesta rota;
* `pageSize` padrão será `10`;
* `pageSize` máximo será `50`;
* `sort` inicial suportado: `publishedAt:desc` e `publishedAt:asc`.

#### Payload mínimo por item

```json
{
  "id": "uuid",
  "title": "string",
  "slug": "string",
  "summary": "string",
  "category": {
    "id": "uuid",
    "name": "Arquitetura"
  },
  "tags": [
    {
      "id": "uuid",
      "name": "API"
    }
  ],
  "publishedAt": "2026-03-20T09:30:00Z",
  "readingTimeMinutes": 6
}
```

---

### 12.3 `GET /v1/public/publications/{slug}`

#### Finalidade

Obter o detalhe de uma publicação pública por `slug`.

#### Resposta mínima esperada

```json
{
  "data": {
    "id": "uuid",
    "title": "Arquitetura Resiliente em APIs",
    "slug": "arquitetura-resiliente-em-apis",
    "summary": "Estratégias práticas de resiliência.",
    "content": "conteúdo serializado da publicação",
    "category": {
      "id": "uuid",
      "name": "Arquitetura"
    },
    "tags": [
      {
        "id": "uuid",
        "name": "API"
      }
    ],
    "publishedAt": "2026-03-20T09:30:00Z",
    "updatedAt": "2026-04-01T12:00:00Z"
  },
  "meta": {
    "traceId": "uuid"
  }
}
```

#### Observações

* o contrato admite `content` como texto estruturado serializado;
* a decisão entre Markdown, HTML sanitizado ou estrutura rich text ficará subordinada à arquitetura editorial futura, mas deverá ser formalizada sem ambiguidade em OpenAPI derivado.

---

### 12.4 `GET /v1/public/publications/{slug}/related`

#### Finalidade

Entregar publicações relacionadas à publicação atual.

#### Observações

* esta rota é legítima porque favorece continuidade relacional da jornada pública;
* a heurística de relação é implementação, não contrato;
* o contrato só exige consistência do payload e exclusão do item atual da lista relacionada.

---

### 12.5 `POST /v1/public/contact`

#### Finalidade

Receber manifestação legítima de contato ou interesse.

#### Justificativa funcional

Materializa os RF-014, RF-015, RF-016 e RF-017, preservando distinção entre apresentação pública e mecanismo de aproximação.

#### Request body aprovado

```json
{
  "name": "William Albarello",
  "email": "william@example.com",
  "subject": "Projeto institucional",
  "message": "Gostaria de conversar sobre o projeto.",
  "acceptedPrivacyPolicy": true
}
```

#### Regras obrigatórias

* `name`, `email`, `message` e `acceptedPrivacyPolicy` são obrigatórios;
* `subject` é opcional, mas permitido;
* a API não deverá aceitar coleta excessiva de dados neste fluxo fundacional;
* submissões devem ser protegidas contra abuso automatizado.

#### Resposta de sucesso

```json
{
  "data": {
    "id": "uuid",
    "status": "received"
  },
  "meta": {
    "traceId": "uuid"
  }
}
```

#### Semântica de `status`

No ciclo atual, os seguintes status conceituais ficam reservados:

* `received`
* `triaged`
* `replied`
* `archived`

A gestão detalhada desses estados poderá ser exposta administrativamente em ciclo posterior.

---

## 13. Recursos Públicos Reservados para Expansão Próxima

Os seguintes endpoints ficam desde já **reservados**, mas não obrigatórios para o fechamento mínimo deste ciclo:

* `GET /v1/public/areas`
* `GET /v1/public/areas/{slug}`
* `GET /v1/public/navigation`
* `GET /v1/public/identity`

Essas rotas são legítimas porque aparecem implicitamente na modelagem conceitual e na arquitetura da informação, mas sua entrada no contrato executável deve obedecer o momento certo.

A regra correta é:

> reservar sem inflar prematuramente.

---

## 14. Contrato Oficial da API Administrativa

O núcleo administrativo obrigatório neste ciclo é o seguinte.

### 14.1 `POST /v1/admin/auth/login`

#### Finalidade

Autenticar usuário interno autorizado.

#### Request body mínimo

```json
{
  "email": "admin@dominio.com",
  "password": "senha-segura"
}
```

#### Resposta mínima esperada

```json
{
  "data": {
    "user": {
      "id": "uuid",
      "email": "admin@dominio.com",
      "displayName": "Administrador",
      "role": "admin"
    }
  },
  "meta": {
    "traceId": "uuid"
  }
}
```

#### Regras obrigatórias

* sessão deve ser estabelecida em cookie seguro;
* resposta não deve vazar motivo excessivamente detalhado em falhas de login;
* rota deve possuir rate limit.

---

### 14.2 `POST /v1/admin/auth/logout`

#### Finalidade

Encerrar a sessão administrativa atual.

#### Resposta esperada

`204 No Content`

---

### 14.3 `GET /v1/admin/auth/session`

#### Finalidade

Validar e retornar o contexto da sessão atual.

#### Utilidade

Evitar que o frontend administrativo adivinhe estado de autenticação ou reconstrua permissões sem fonte de verdade.

---

### 14.4 `GET /v1/admin/dashboard`

#### Finalidade

Retornar resumo operacional da camada administrativa.

#### Payload conceitual mínimo

```json
{
  "data": {
    "drafts": 4,
    "inReview": 2,
    "published": 18,
    "archived": 2,
    "seoPending": 3
  },
  "meta": {
    "traceId": "uuid"
  }
}
```

#### Observação

Os agregados podem amadurecer, mas o contrato inicial deve manter semântica clara e baixa ambiguidade.

---

### 14.5 `GET /v1/admin/publications`

#### Finalidade

Listar publicações administrativas com filtros.

#### Query params aprovados

* `page`
* `pageSize`
* `q`
* `status`
* `categoryId`
* `tagId`
* `sort`

#### Regras

* rota autenticada;
* pode listar itens em estados não públicos;
* payload pode incluir campos operacionais que jamais devem aparecer na API pública.

---

### 14.6 `POST /v1/admin/publications`

#### Finalidade

Criar publicação.

#### Request body aprovado

```json
{
  "title": "Arquitetura Resiliente em APIs",
  "slug": "arquitetura-resiliente-em-apis",
  "summary": "Estratégias práticas de resiliência.",
  "content": "conteúdo serializado",
  "categoryId": "uuid",
  "tagIds": ["uuid"],
  "status": "draft"
}
```

#### Regras obrigatórias

* `title`, `slug`, `summary`, `content` e `status` são obrigatórios;
* `slug` deve ser único no escopo da entidade;
* `status` inicial permitido: `draft`;
* criação direta já como `published` só poderá ocorrer se a política de papel permitir.

---

### 14.7 `GET /v1/admin/publications/{id}`

#### Finalidade

Obter detalhe administrativo de uma publicação.

#### Observação

Esta rota existe para edição segura, revisão e rastreabilidade.

---

### 14.8 `PUT /v1/admin/publications/{id}`

#### Finalidade

Atualizar publicação de forma integral ou quase integral segundo payload definido.

#### Regra de integridade

Atualizações não devem apagar campos silenciosamente sem intencionalidade explícita do consumidor.

---

### 14.9 `PATCH /v1/admin/publications/{id}/status`

#### Finalidade

Realizar transição de estado editorial de forma explícita.

#### Request body mínimo

```json
{
  "status": "published"
}
```

#### Estados aprovados neste ciclo

* `draft`
* `review`
* `published`
* `archived`

#### Transições permitidas por padrão

* `draft -> review`
* `review -> draft`
* `review -> published`
* `published -> archived`
* `archived -> draft`

Qualquer transição adicional exigirá justificativa documental.

---

### 14.10 `DELETE /v1/admin/publications/{id}`

#### Finalidade

Remover logicamente ou tornar indisponível uma publicação, conforme política operacional definida.

#### Regra soberana

Neste projeto, `DELETE` não deve ser presumido como exclusão física irrevogável.

A implementação preferencial deverá tratar este movimento como exclusão lógica, arquivamento forte ou desativação conforme a entidade e a política de retenção.

---

### 14.11 `GET /v1/admin/categories`

### 14.12 `POST /v1/admin/categories`

### 14.13 `PUT /v1/admin/categories/{id}`

### 14.14 `DELETE /v1/admin/categories/{id}`

#### Finalidade

Governar taxonomia de categorias.

#### Regras

* categoria deve possuir nome único dentro do escopo institucional aplicável;
* exclusão deve respeitar vínculo com publicações existentes;
* se houver dependência ativa, a API deverá responder com conflito coerente ou exigir reclassificação prévia.

---

### 14.15 `GET /v1/admin/tags`

### 14.16 `POST /v1/admin/tags`

### 14.17 `PUT /v1/admin/tags/{id}`

### 14.18 `DELETE /v1/admin/tags/{id}`

#### Finalidade

Governar taxonomia flexível por tags.

#### Regras

* tags devem ser semanticamente curtas e reutilizáveis;
* a API não deverá permitir caos taxonômico por duplicidade óbvia.

---

### 14.19 `GET /v1/admin/audit-logs`

#### Finalidade

Permitir leitura controlada de trilha de auditoria.

#### Payload mínimo por item

```json
{
  "id": "uuid",
  "action": "publication.status.changed",
  "actor": {
    "id": "uuid",
    "role": "admin"
  },
  "target": {
    "type": "publication",
    "id": "uuid"
  },
  "summary": "Status alterado de review para published.",
  "createdAt": "2026-04-03T18:25:00Z"
}
```

#### Regras obrigatórias

* não vazar segredos ou payloads sensíveis de sistema;
* permitir paginação;
* permitir filtros por tipo de ação, data e ator quando documentalmente refinado.

---

## 15. Recursos Administrativos Reservados para Expansão Próxima

Ficam desde já reservados, porém não obrigatórios neste fechamento inicial:

* `GET /v1/admin/contact-entries`
* `GET /v1/admin/contact-entries/{id}`
* `PATCH /v1/admin/contact-entries/{id}/status`
* `GET /v1/admin/pages`
* `PUT /v1/admin/pages/{id}`
* `GET /v1/admin/blocks`
* `PUT /v1/admin/blocks/{id}`

Esses recursos fazem sentido diante da arquitetura e do modelo conceitual, mas sua implementação deve obedecer sequência e não ansiedade arquitetural.

---

## 16. Esquemas Canônicos de Dados

Abaixo estão os esquemas conceituais mínimos que deverão orientar o OpenAPI derivado.

### 16.1 `PublicPageResponse`

Campos macro:

* `key`
* `title`
* `seo`
* `blocks[]`
* `updatedAt`

### 16.2 `PublicationListItem`

Campos macro:

* `id`
* `title`
* `slug`
* `summary`
* `category`
* `tags[]`
* `publishedAt`
* `readingTimeMinutes`

### 16.3 `PublicationDetail`

Campos macro:

* tudo de `PublicationListItem`
* `content`
* `updatedAt`

### 16.4 `ContactRequest`

Campos macro:

* `name`
* `email`
* `subject?`
* `message`
* `acceptedPrivacyPolicy`

### 16.5 `AdminSessionUser`

Campos macro:

* `id`
* `email`
* `displayName`
* `role`

### 16.6 `PublicationUpsertRequest`

Campos macro:

* `title`
* `slug`
* `summary`
* `content`
* `categoryId`
* `tagIds[]`
* `status`

### 16.7 `AuditLogEntry`

Campos macro:

* `id`
* `action`
* `actor`
* `target`
* `summary`
* `createdAt`

---

## 17. Paginação, Busca, Filtros e Ordenação

### 17.1 Paginação padrão

Os parâmetros contratuais padrão são:

* `page` com default `1`
* `pageSize` com default `10`
* `pageSize` máximo `50`

### 17.2 Busca textual

Quando houver campo `q`, ele representará busca textual simples no escopo documentado do recurso.

### 17.3 Filtros

Filtros devem ser explícitos e semanticamente nomeados.

Exemplos legítimos:

* `status`
* `category`
* `categoryId`
* `tag`
* `tagId`

### 17.4 Ordenação

A sintaxe inicial aprovada é:

```text
campo:direcao
```

Exemplos:

* `publishedAt:desc`
* `publishedAt:asc`
* `updatedAt:desc`

---

## 18. Regras de Estado, Consistência e Idempotência

### 18.1 Transições explícitas

Mudanças de estado editorial relevantes devem ocorrer em rota explícita de transição, e não apenas por sobrescrita silenciosa em update genérico.

### 18.2 Idempotência

No ciclo atual, a exigência forte de idempotência fica reservada para integrações críticas e eventos futuros.

Ainda assim, as seguintes direções já ficam aprovadas:

* o backend deve se proteger contra duplicação acidental de submissões de contato quando tecnicamente viável;
* rotas de criação crítica poderão, em evolução posterior, aceitar `Idempotency-Key`.

### 18.3 Exclusão lógica preferencial

Para entidades editoriais e operacionais, a política preferencial é exclusão lógica, arquivamento ou desativação controlada.

---

## 19. Governança de OpenAPI, Testes de Contrato e Geração

### 19.1 OpenAPI derivado

A partir deste documento, deverão ser gerados ou atualizados artefatos como:

* `openapi-public.yaml`
* `openapi-admin.yaml`
* componentes comuns de schemas;
* componentes comuns de responses.

### 19.2 Regra de fidelidade

O OpenAPI derivado deverá ser fiel a este documento.

### 19.3 Testes de contrato

Toda rota obrigatória deste documento deverá, no ciclo apropriado, receber:

* teste de sucesso;
* teste de validação;
* teste de autenticação/autorização, quando aplicável;
* teste de paginação/filtro, quando aplicável.

### 19.4 Geração futura de código

Este documento deverá servir como insumo primário para futura geração modular de:

* handlers/controladores;
* schemas de validação;
* serviços de aplicação;
* clientes tipados;
* testes de contrato;
* coleções de requests.

---

## 20. Política de Compatibilidade, Depreciação e Sunset

### 20.1 Compatibilidade em `v1`

Em `v1`, não é permitido:

* remover campo sem janela de transição;
* alterar semântica de campo sem nova versão;
* mudar forma de autenticação administrativa sem documentação formal de migração.

### 20.2 Depreciação formal

Quando um endpoint ou campo precisar ser descontinuado, a sequência correta será:

1. marcar como deprecated no OpenAPI;
2. registrar no changelog e documento de versões;
3. anunciar janela de sunset;
4. remover apenas após o prazo formal.

### 20.3 Headers recomendados de depreciação

Quando aplicável, poderão ser usados:

* `Deprecation: true`
* `Sunset: <data HTTP válida>`
* `Link: <url>; rel="deprecation"`

---

## 21. O que Fica Fora de Escopo Neste Documento

Este documento não fixa ainda:

* formato final do editor de conteúdo rico;
* detalhes de storage de mídia;
* contratos de upload de arquivos;
* webhooks operacionais completos;
* eventos assíncronos e filas;
* API analytics dedicada;
* política final de cache por endpoint;
* estratégia final de tenancy, porque o projeto atual não nasce multiempresa.

Esses temas poderão surgir em blocos posteriores, sem deformar a base contratual aqui firmada.

---

## 22. Critérios de Qualidade do Contrato

Para que a camada de API seja considerada boa neste projeto, ela deverá ser:

* semanticamente coerente com a arquitetura do sistema;
* pequena o suficiente para o presente ciclo;
* rica o suficiente para não gerar improviso posterior;
* segura o suficiente para separar público e interno;
* estável o suficiente para suportar OpenAPI e testes de contrato;
* elegante o suficiente para permitir geração modular futura.

---

## 23. Anexos e Materiais Consultados para a Consolidação Deste Documento

### 23.1 Documentos soberanos do ciclo atual

* `01-Waterfall/01-Obrigatorios/011_Arquitetura_Geral_do_Sistema.md`
* `01-Waterfall/01-Obrigatorios/012_Modulos_Dominios_e_Limites_do_Software.md`
* `01-Waterfall/01-Obrigatorios/013_Modelo_de_Dados_Conceitual.md`
* `01-Waterfall/01-Obrigatorios/014_Integracoes_e_Sistemas_Externos.md`
* `01-Waterfall/01-Obrigatorios/015_Seguranca_Privacidade_Auditoria_e_Permissoes.md`
* `01-Waterfall/01-Obrigatorios/006_Requisitos_Funcionais.md`
* `01-Waterfall/01-Obrigatorios/008_Regras_de_Negocio.md`
* `01-Waterfall/01-Obrigatorios/009_Casos_de_Uso_Macro.md`

### 23.2 Anexos herdados úteis

* `personal-site (1)/personal-site/APIs/API-00-governanca.md`
* `personal-site (1)/personal-site/APIs/API-01-padroes-rest.md`
* `personal-site (1)/personal-site/APIs/API-02-versionamento.md`
* `personal-site (1)/personal-site/APIs/API-03-seguranca-auth.md`
* `personal-site (1)/personal-site/APIs/API-04-erros-paginacao-filtros.md`
* `personal-site (1)/personal-site/APIs/API-05-openapi-estrutura.md`
* `personal-site (1)/personal-site/APIs/API-06-openapi-public.yaml`
* `personal-site (1)/personal-site/APIs/API-07-openapi-admin.yaml`
* `personal-site (1)/personal-site/APIs/API-08-webhooks-eventos.md`

### 23.3 Regra de uso dos anexos herdados

Os anexos herdados foram utilizados como **fonte de reforço estrutural**.

Eles não redefinem a soberania do ciclo atual.

---

## 24. Declaração Final

Com este documento, o projeto **William Albarello** passa a possuir uma definição contratual soberana da sua camada de APIs, distinguindo com clareza:

* o que pertence à exposição pública;
* o que pertence à operação administrativa;
* o que já é obrigatório neste ciclo;
* o que está legitimamente reservado para expansão posterior.

A partir daqui, a geração de OpenAPI, testes de contrato, scaffolds de backend, clientes tipados e fluxos administrativos deixa de depender de improviso conceitual.

A API do projeto não nasce como apêndice técnico.

Ela nasce como extensão disciplinada da arquitetura soberana do sistema.

---

## 25. Status do Documento

**Documento consolidado como contrato mestre fundacional de API do projeto William Albarello, apto a servir como fonte de verdade para OpenAPI, testes de contrato e geração modular futura.**


