# 004_Escopo_e_Fora_de_Escopo

## Identificação do Documento

- **Projeto:** William Albarello
- **Camada:** 01-Waterfall
- **Subpasta:** 01-Obrigatorios
- **Documento:** 004_Escopo_e_Fora_de_Escopo.md
- **Função:** Delimitar com precisão o que pertence ao ciclo e à natureza do projeto, o que pode ser admitido em fases futuras e o que deve permanecer explicitamente fora de escopo neste momento
- **Status:** ATIVO
- **Versão:** v1.0
- **Autoridade:** Alta
- **Natureza:** Documento soberano de delimitação estrutural do projeto
- **Dependência superior:**
  - 000_Indice_Mestre.md
  - 001_Manifesto_Metodologico_Waterfall_Caracol.md
  - 002_Regra_de_Nomenclatura_e_Versionamento.md
  - 024_Politica_de_Governanca_Documental.md
  - 001_Visao_Geral_do_Projeto.md
  - 002_Problema_Oportunidade_e_Tese_Central.md
  - 003_Objetivos_Estrategicos_e_Resultados_Esperados.md
- **Dependências relacionadas:**
  - 005_Stakeholders_Perfis_e_Atores_do_Sistema.md
  - 006_Requisitos_Funcionais.md
  - 007_Requisitos_Nao_Funcionais.md
  - 011_Arquitetura_Geral_do_Sistema.md
  - 020_Cronograma_Fases_Marcos_e_Sequenciamento.md

---

## 1. Finalidade

Este documento existe para estabelecer os limites oficiais do projeto.

Sua função é impedir que a iniciativa cresça de forma caótica, absorva ideias sem hierarquia, misture desejos futuros com compromissos presentes e perca coerência metodológica por excesso de abertura.

Ele responde, de forma objetiva, a três perguntas centrais:

1. o que está dentro do escopo do projeto neste ciclo fundacional;
2. o que não está dentro do escopo neste momento, ainda que possa ser valioso no futuro;
3. o que deve permanecer explicitamente excluído para proteger a clareza e a qualidade da construção.

Sem este documento, o projeto corre o risco de confundir ambição com inchaço, possibilidade com obrigação e visão de longo alcance com implementação prematura.

Este documento protege o projeto contra a diluição.

---

## 2. Princípio Geral de Escopo

Neste projeto, escopo não será entendido como lista aleatória de tudo o que “seria interessante ter”.

Escopo será entendido como o conjunto de elementos necessários, coerentes e justificáveis para cumprir os objetivos estratégicos declarados na fase atual do projeto.

Isso implica que:

- nem tudo o que é bom entra agora;
- nem tudo o que será útil no futuro pertence ao presente ciclo;
- nem toda ideia promissora deve ser incorporada imediatamente;
- delimitar corretamente faz parte da inteligência do sistema.

A regra central é esta:

> escopo correto não é escopo máximo;  
> escopo correto é escopo coerente.

---

## 3. Definição do Escopo do Ciclo Atual

O escopo do ciclo atual do projeto **William Albarello** compreende a construção de sua base soberana de definição, estruturação e preparação para materialização futura.

Em termos amplos, isso significa que o ciclo atual está voltado para:

- consolidar a visão do projeto;
- definir problema, oportunidade e tese central;
- estabelecer objetivos estratégicos;
- delimitar escopo e fora de escopo;
- mapear atores e perfis;
- estruturar requisitos;
- documentar regras de negócio relevantes;
- derivar arquitetura coerente;
- preparar a futura tradução gerativa;
- proteger o projeto contra improviso e crescimento desordenado.

Portanto, o ciclo atual tem natureza predominantemente **fundacional, documental, estrutural e arquitetural**.

---

## 4. O que Está Dentro do Escopo

### 4.1 Construção da base documental soberana

Está dentro do escopo criar e consolidar a camada `01-Waterfall` como fonte de verdade do projeto.

Isso inclui:

- documentos constitucionais;
- documentos obrigatórios;
- documentos de detalhamento futuro, quando chegarem no tempo correto;
- regras de governança;
- precedência documental;
- critérios de continuidade.

### 4.2 Definição estratégica do projeto

Está dentro do escopo definir:

- visão geral;
- problema central;
- oportunidade estratégica;
- tese central;
- objetivos estratégicos;
- resultados esperados.

### 4.3 Delimitação da identidade estrutural do projeto

Está dentro do escopo definir a natureza do projeto como base digital soberana de presença, autoridade, organização e expansão futura.

Isso inclui a clarificação de:

- propósito;
- posicionamento;
- valor estratégico;
- horizonte de maturidade.

### 4.4 Mapeamento de atores, perfis e relações de uso

Está dentro do escopo identificar quem se relaciona com o sistema, em que papéis e com quais expectativas, necessidades e impactos.

### 4.5 Definição de requisitos e regras de negócio

Está dentro do escopo converter a estratégia em:

- requisitos funcionais;
- requisitos não funcionais;
- regras de negócio;
- casos de uso macro;
- jornadas e fluxos principais.

### 4.6 Derivação da arquitetura soberana

Está dentro do escopo construir a arquitetura geral do sistema como consequência dos documentos anteriores.

Isso inclui:

- visão arquitetural;
- módulos, domínios e limites;
- modelo de dados conceitual;
- integrações previstas;
- segurança, permissões, privacidade e auditoria;
- contrato mestre de API em nível de definição.

### 4.7 Preparação para camada gerativa futura

Está dentro do escopo deixar o projeto em condição de, mais adiante, ser traduzido para uma camada `02-Relational-Life` robusta, modular e orientada a encaixe.

Isso não implica gerar toda a camada agora, mas implica preparar sua possibilidade com rigor.

### 4.8 Definição da arquitetura da informação e da lógica de qualidade

Está dentro do escopo, em momento adequado da sequência, definir:

- arquitetura da informação;
- lógica de UI/UX em nível estrutural;
- plano de testes e homologação;
- riscos, premissas e restrições;
- critérios de aceite;
- rastreabilidade;
- plano de implantação e suporte em nível coerente com o estágio do projeto.

---

## 5. Escopo Material Inicial da Solução

Em termos de solução final visível, está dentro do escopo conceber uma base digital que, no tempo correto, possa comportar ao menos os seguintes macroblocos:

- apresentação institucional de William Albarello;
- organização de identidade, mensagem e posicionamento;
- estruturação de áreas, conteúdos, projetos ou frentes relevantes;
- base para expansão futura em módulos, integrações e operação;
- eventual painel administrativo ou camada operacional, se isso vier a ser confirmado documentalmente em ciclos posteriores.

Importante: neste momento, o escopo inclui **conceber e documentar corretamente essa capacidade**, não necessariamente implementar todas essas frentes de imediato.

---

## 6. O que Está Fora de Escopo Neste Momento

### 6.1 Implementação completa de todas as expansões possíveis

Está fora do escopo atual implementar imediatamente todas as ideias futuras que o projeto possa um dia comportar.

Exemplos:

- sistema editorial completo;
- múltiplos painéis administrativos avançados;
- automações amplas;
- integrações extensas;
- módulos sofisticados ainda não formalizados.

### 6.2 Crescimento por hipótese não validada

Está fora do escopo incorporar funcionalidades apenas porque “talvez sejam úteis”, sem derivação clara dos objetivos estratégicos e sem enquadramento documental.

### 6.3 Complexidade técnica não justificada

Está fora do escopo adicionar arquitetura, infraestrutura, integrações ou abstrações sofisticadas sem necessidade demonstrada pelo problema, pelos objetivos e pelos requisitos.

### 6.4 Mistura descontrolada de frentes pessoais, profissionais, autorais e experimentais

Está fora do escopo permitir que o projeto se torne recipiente indiscriminado de tudo o que possa, em tese, relacionar-se ao nome William Albarello.

Qualquer nova frente precisará ser analisada quanto à sua coerência com a visão e os objetivos do projeto.

### 6.5 Execução de código antes da fundação documental mínima

Está fora do escopo inverter a lógica metodológica e iniciar implementação relevante antes da estabilização da camada soberana essencial.

### 6.6 Geração automática ampla sem base suficiente

Está fora do escopo tentar usar a camada gerativa futura como substituta da etapa de definição.

A geração só será legítima quando houver base documental adequada.

---

## 7. O que Está Explicitamente Excluído

Além do que apenas está adiado, alguns elementos ficam explicitamente excluídos enquanto não houver revisão formal.

### 7.1 Improviso estrutural como método

Está excluída a ideia de construir o projeto por acúmulo casual de páginas, decisões visuais soltas ou encaixes ad hoc.

### 7.2 Acúmulo ornamental de funcionalidades

Está excluída a lógica de adicionar funcionalidades apenas para parecer mais completo, sem valor estrutural real.

### 7.3 Reatividade sem governança

Está excluída a prática de mudar direção a cada nova ideia sem atualização formal da base documental.

### 7.4 Fragmentação da verdade do projeto

Está excluída a existência de múltiplas definições concorrentes de escopo, visão, problema ou arquitetura em artefatos paralelos.

### 7.5 Fetichização tecnológica

Está excluída a introdução de tecnologias, frameworks, padrões ou complexidades apenas por prestígio aparente ou entusiasmo momentâneo.

---

## 8. Escopo Presente versus Escopo Futuro

É essencial distinguir duas coisas.

### 8.1 Escopo presente

É aquilo que o projeto assume como compromisso legítimo no ciclo atual.

### 8.2 Escopo futuro possível

É aquilo que o projeto pode vir a receber depois, caso:

- continue coerente com a visão;
- seja justificado pelos objetivos;
- encontre lugar na arquitetura;
- seja documentado formalmente.

A existência de uma possibilidade futura não cria obrigação presente.

Essa distinção é vital para proteger a integridade do projeto.

---

## 9. Critérios de Entrada no Escopo

Para que algo entre no escopo deste projeto, deve atender cumulativamente, tanto quanto possível, aos seguintes critérios:

1. coerência com a visão geral do projeto;
2. aderência ao problema e à oportunidade definidos;
3. alinhamento com pelo menos um objetivo estratégico relevante;
4. compatibilidade com a governança documental;
5. possibilidade de encaixe arquitetural;
6. justificativa superior ao custo de complexidade introduzida.

Se um item falhar gravemente nesses critérios, sua entrada no escopo deverá ser recusada ou adiada.

---

## 10. Critérios de Saída do Escopo

Um item deve ser considerado fora de escopo quando:

- não responder ao problema central;
- não contribuir para os objetivos estratégicos;
- ampliar complexidade sem ganho proporcional;
- depender de premissas ainda não formalizadas;
- comprometer foco, coerência ou governança;
- pertencer mais ao campo de hipótese futura do que ao compromisso presente.

---

## 11. Relação entre Escopo e Prioridade

Nem tudo que está dentro do escopo possui a mesma prioridade temporal.

Há elementos que pertencem ao escopo, mas serão tratados em fases posteriores do próprio ciclo documental.

Isso significa que é possível haver:

- itens dentro do escopo atual, porém não imediatos;
- itens fora do escopo atual, mas relevantes no futuro;
- itens excluídos até revisão formal.

Escopo e prioridade não são sinônimos, mas também não podem ser dissociados sem critério.

---

## 12. Relação entre Escopo e Arquitetura

A arquitetura geral do sistema deverá respeitar este documento.

Isso significa que a arquitetura:

- não poderá pressupor complexidades fora de escopo como se fossem obrigatórias agora;
- deverá ser expansível sem depender da implementação imediata de tudo;
- deverá distinguir núcleo presente de evolução futura;
- deverá servir ao projeto real, e não a um imaginário inflado.

Arquitetura boa, aqui, é arquitetura proporcional.

---

## 13. Relação entre Escopo e Geração Futura

Este documento também protege a camada gerativa futura.

Sem delimitação de escopo, a geração modular corre o risco de:

- misturar responsabilidades;
- produzir blocos sem fronteira clara;
- incorporar hipóteses não estabilizadas;
- aumentar retrabalho.

Portanto, delimitar escopo agora é também preparar geração melhor depois.

---

## 14. Riscos de Violação de Escopo

Os principais riscos de violação são os seguintes.

### 14.1 Inchar o projeto cedo demais

Isso aumenta ruído, ansiedade decisória e fragilidade estrutural.

### 14.2 Empobrecer demais a ambição do projeto

Isso pode reduzir sua potência estratégica e sua capacidade futura.

### 14.3 Misturar presente e futuro

Isso gera compromissos indefinidos e arquitetura confusa.

### 14.4 Confundir flexibilidade com ausência de limite

Sem limite, o projeto não fica livre; ele fica instável.

### 14.5 Introduzir novas ideias sem rito de entrada

Isso rompe a governança documental e destrói a cadeia de coerência.

---

## 15. Declaração Final

O projeto **William Albarello** não será conduzido por escopo maximalista nem por redução empobrecedora.

Seu escopo atual é fundacional, estratégico, documental, arquitetural e preparatório.

Ele inclui tudo o que é necessário para construir uma base soberana de representação, organização, autoridade e expansão futura.

Ele exclui, por ora, implementações prematuras, complexidades não justificadas, hipóteses não formalizadas e crescimento desordenado.

A fidelidade a este documento será essencial para preservar clareza, foco, coerência e potência do projeto.

---

## 16. Status deste Documento

Este documento entra em vigor imediatamente como referência soberana para delimitação de escopo e fora de escopo do projeto.

Todos os documentos seguintes da pasta `01-Obrigatorios` deverão respeitar seus limites, salvo revisão formal explícita.
