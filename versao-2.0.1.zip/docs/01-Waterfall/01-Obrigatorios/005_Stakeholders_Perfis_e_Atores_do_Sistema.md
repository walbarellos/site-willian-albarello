# 005_Stakeholders_Perfis_e_Atores_do_Sistema

## Identificação do Documento

- **Projeto:** William Albarello
- **Camada:** 01-Waterfall
- **Subpasta:** 01-Obrigatorios
- **Documento:** 005_Stakeholders_Perfis_e_Atores_do_Sistema.md
- **Função:** Mapear os stakeholders, perfis e atores do sistema, definindo seus papéis, interesses, relações com a solução e implicações para escopo, requisitos, arquitetura e governança
- **Status:** ATIVO
- **Versão:** v1.0
- **Autoridade:** Alta
- **Natureza:** Documento soberano de modelagem humana, institucional e operacional do projeto
- **Dependência superior:**
  - 000_Indice_Mestre.md
  - 001_Manifesto_Metodologico_Waterfall_Caracol.md
  - 002_Regra_de_Nomenclatura_e_Versionamento.md
  - 024_Politica_de_Governanca_Documental.md
  - 001_Visao_Geral_do_Projeto.md
  - 002_Problema_Oportunidade_e_Tese_Central.md
  - 003_Objetivos_Estrategicos_e_Resultados_Esperados.md
  - 004_Escopo_e_Fora_de_Escopo.md
- **Dependências relacionadas:**
  - 006_Requisitos_Funcionais.md
  - 007_Requisitos_Nao_Funcionais.md
  - 009_Casos_de_Uso_Macro.md
  - 010_Jornadas_do_Usuario_e_Fluxos_Principais.md
  - 011_Arquitetura_Geral_do_Sistema.md
  - 015_Seguranca_Privacidade_Auditoria_e_Permissoes.md

---

## 1. Finalidade

Este documento existe para identificar, organizar e qualificar os sujeitos que se relacionam com o projeto **William Albarello**.

Sua função é esclarecer:

1. quem influencia o projeto;
2. quem será impactado pelo projeto;
3. quem utiliza ou poderá utilizar a solução;
4. quem administra, mantém, alimenta ou supervisiona o sistema;
5. quais necessidades, expectativas, riscos e responsabilidades emergem de cada perfil.

Sem este documento, o projeto corre o risco de ser pensado de forma excessivamente abstrata, como se houvesse apenas “o site” e “o visitante”, quando na verdade há múltiplos papéis com naturezas distintas.

Este documento estabelece a anatomia humana e institucional da solução.

---

## 2. Princípio Geral

Todo sistema sério precisa saber, com clareza, para quem existe, quem o governa, quem o utiliza, quem o influencia e quem sofre os efeitos de suas decisões.

No contexto deste projeto, stakeholders, perfis e atores não são sinônimos perfeitos.

A distinção adotada será a seguinte:

- **Stakeholders** = todos os sujeitos ou grupos com interesse, influência, risco, expectativa ou impacto em relação ao projeto;
- **Perfis** = tipos relativamente estáveis de usuários ou participantes com características, necessidades e comportamentos recorrentes;
- **Atores do sistema** = papéis operacionais concretos que interagem com fluxos, telas, conteúdos, permissões ou processos da solução.

Essa distinção evita confusão entre visão estratégica e modelagem operacional.

---

## 3. Tese de Modelagem Humana do Projeto

A tese adotada por este documento é a seguinte:

> o projeto William Albarello não deve ser modelado apenas como uma vitrine estática para visitantes genéricos,  
> mas como um sistema de relações entre sujeitos com diferentes níveis de interesse, autoridade, uso, manutenção e impacto.

Isso significa que a solução deve nascer preparada para lidar com, no mínimo:

- sujeito central de identidade e autoridade;
- público externo visitante;
- possíveis interessados em conteúdo, contato, projetos ou serviços;
- operadores internos ou administradores futuros;
- agentes institucionais ou parceiros que possam se relacionar com a estrutura.

---

## 4. Stakeholder Central

### 4.1 William Albarello como stakeholder central soberano

O stakeholder central e originário do projeto é **William Albarello**.

Ele ocupa posição singular porque é, simultaneamente:

- origem identitária da solução;
- principal beneficiário estratégico do projeto;
- principal sujeito representado pela presença digital;
- agente de validação de coerência entre forma, conteúdo e posicionamento;
- referência máxima para decisões de direção, sentido e legitimidade do sistema.

Neste projeto, William Albarello não é apenas “usuário”.

Ele é:

- sujeito de representação;
- eixo institucional;
- proprietário simbólico e estratégico da solução;
- referência de autoridade para validação de identidade, mensagem e orientação do sistema.

---

## 5. Macrogrupos de Stakeholders

Para efeitos de governança, os stakeholders são agrupados em macrogrupos.

### 5.1 Stakeholders centrais

Grupo formado pelos sujeitos sem os quais o projeto perde sentido ou direção.

Inclui:

- William Albarello;
- núcleo direto de decisão sobre identidade, direção e coerência do projeto.

### 5.2 Stakeholders internos operacionais

Grupo formado pelos sujeitos que podem operar, administrar, publicar, manter ou supervisionar a solução em fases posteriores.

Inclui, potencialmente:

- administrador principal;
- editor de conteúdo;
- operador técnico;
- mantenedor do sistema.

### 5.3 Stakeholders externos de audiência

Grupo formado pelos sujeitos que acessam a presença digital buscando informação, compreensão, contato, conteúdo, contexto ou relação com o projeto.

Inclui, potencialmente:

- visitantes gerais;
- leitores;
- interessados em projetos;
- interessados em contato institucional ou profissional;
- público que busca compreender identidade, visão, atuação ou materiais associados a William Albarello.

### 5.4 Stakeholders externos relacionais

Grupo formado por agentes que podem se relacionar com o projeto de maneira mais qualificada ou estratégica.

Inclui, potencialmente:

- parceiros;
- instituições;
- colaboradores;
- contratantes ou potenciais contratantes;
- agentes de imprensa, pesquisa, redes ou articulações futuras;
- pessoas interessadas em cooperação, interlocução ou desdobramentos específicos.

### 5.5 Stakeholders técnicos e de sustentação

Grupo formado pelos sujeitos responsáveis pela integridade operacional da solução.

Inclui, potencialmente:

- responsável técnico pela implementação;
- responsável por infraestrutura;
- mantenedor de conteúdo ou deploy;
- suporte operacional futuro.

---

## 6. Perfis Fundamentais do Projeto

A partir da visão atual, o projeto reconhece os seguintes perfis fundamentais.

### 6.1 Perfil: Titular Institucional

**Descrição:**  
Perfil correspondente a William Albarello enquanto centro representado, beneficiário estratégico e autoridade validante do sistema.

**Necessidades principais:**

- representação correta de identidade;
- coerência entre presença digital e posicionamento real;
- capacidade de evoluir a estrutura sem perder unidade;
- controle sobre direção, tom e legitimidade da solução.

**Sensibilidades:**

- distorção de identidade;
- empobrecimento da visão do projeto;
- excesso de dispersão;
- perda de governança sobre a própria estrutura.

### 6.2 Perfil: Visitante Geral

**Descrição:**  
Pessoa que acessa a solução para entender quem é William Albarello, o que representa o projeto e como navegar por suas áreas principais.

**Necessidades principais:**

- clareza inicial;
- boa apresentação institucional;
- navegação compreensível;
- acesso rápido às informações essenciais.

**Sensibilidades:**

- excesso de complexidade;
- desorganização da mensagem;
- ambiguidade sobre a proposta do site;
- dificuldade de localização de conteúdo central.

### 6.3 Perfil: Interessado Qualificado

**Descrição:**  
Pessoa que acessa a solução com interesse mais específico e intencional.

Pode buscar, por exemplo:

- compreender projetos;
- entrar em contato;
- acompanhar conteúdos;
- avaliar seriedade, visão e consistência;
- explorar relações profissionais, intelectuais, autorais ou estratégicas.

**Necessidades principais:**

- informação mais profunda;
- credibilidade;
- sinalização clara de proposta, áreas e possibilidades;
- rotas de contato ou aprofundamento.

**Sensibilidades:**

- superficialidade excessiva;
- falta de trilha clara de aprofundamento;
- inconsistência entre discurso e estrutura.

### 6.4 Perfil: Leitor ou Consumidor de Conteúdo

**Descrição:**  
Pessoa cujo principal interesse está em materiais autorais, reflexivos, analíticos, informativos ou institucionais vinculados ao projeto.

**Necessidades principais:**

- boa legibilidade;
- organização temática;
- permanência e continuidade de conteúdo;
- contexto suficiente para compreender a relevância do material.

**Sensibilidades:**

- conteúdo disperso;
- ausência de estrutura editorial mínima;
- dificuldade de navegação entre temas ou materiais.

### 6.5 Perfil: Administrador ou Operador Interno

**Descrição:**  
Sujeito que, em fases posteriores, poderá administrar o sistema, atualizar conteúdos, manter seções, revisar elementos institucionais ou operar recursos internos.

**Necessidades principais:**

- clareza de permissões;
- fluxos seguros;
- separação entre área pública e área administrativa;
- estabilidade operacional.

**Sensibilidades:**

- ambiguidade de responsabilidade;
- falta de rastreabilidade;
- interfaces internas mal definidas;
- risco de alteração indevida de conteúdo ou estrutura.

### 6.6 Perfil: Parceiro ou Interlocutor Estratégico

**Descrição:**  
Agente externo que se relaciona com o projeto por razões institucionais, profissionais, cooperativas ou estratégicas.

**Necessidades principais:**

- percepção de seriedade;
- clareza sobre a identidade e as frentes do projeto;
- meios de contato adequados;
- leitura de credibilidade e consistência.

**Sensibilidades:**

- aparência improvisada;
- desorganização;
- falta de lastro institucional.

---

## 7. Atores Operacionais do Sistema

Além dos perfis humanos, o projeto reconhece atores operacionais para modelagem futura de requisitos, casos de uso, segurança e arquitetura.

### 7.1 Ator: Visitante Público

Interage com a camada pública do sistema.

Ações típicas futuras:

- acessar páginas institucionais;
- navegar entre áreas centrais;
- ler conteúdos disponíveis;
- compreender identidade, visão e projetos;
- usar meios de contato públicos, se aplicável.

### 7.2 Ator: Leitor de Conteúdo

Interage com materiais autorais, editoriais ou informativos.

Ações típicas futuras:

- abrir conteúdos;
- navegar entre temas;
- consumir materiais em profundidade;
- acessar páginas de contexto relacionadas.

### 7.3 Ator: Interessado em Contato ou Relação

Interage com fluxos de aproximação, contato, manifestação de interesse ou encaminhamento.

Ações típicas futuras:

- localizar canais de contato;
- compreender proposta e áreas de atuação;
- iniciar aproximação institucional ou estratégica.

### 7.4 Ator: Administrador Principal

Interage com a camada interna da solução, quando ela existir.

Ações típicas futuras:

- autenticar-se no painel interno;
- revisar e atualizar conteúdos;
- gerenciar páginas, mensagens ou recursos;
- supervisionar integridade da presença digital.

### 7.5 Ator: Editor ou Operador de Conteúdo

Ator subordinado à lógica administrativa, voltado à manutenção de materiais e organização de seções.

Ações típicas futuras:

- criar, editar ou revisar conteúdo;
- atualizar blocos de apresentação;
- organizar publicações ou materiais.

### 7.6 Ator: Mantenedor Técnico

Ator responsável pela manutenção técnica, deploy, integridade estrutural ou evolução controlada da solução.

Ações típicas futuras:

- aplicar atualizações técnicas;
- monitorar funcionamento;
- corrigir falhas;
- manter coerência entre implementação e documentação.

---

## 8. Relação entre Perfis e Necessidades do Sistema

O sistema deverá ser pensado de forma a responder, com níveis diferentes de profundidade, às necessidades centrais desses perfis.

Isso implica que a solução deverá favorecer, conforme o caso:

- clareza institucional para visitantes gerais;
- profundidade suficiente para interessados qualificados;
- organização editorial para leitores;
- controle, segurança e rastreabilidade para operadores internos;
- percepção de consistência para parceiros e interlocutores estratégicos.

Portanto, o sistema não pode ser modelado apenas como “página bonita”.

Ele precisa responder a relações reais de uso e percepção.

---

## 9. Relação entre Perfis e Arquitetura da Informação

A arquitetura da informação futura deverá refletir a existência desses perfis.

Isso significa que a organização do conteúdo, das rotas e das áreas precisará considerar ao menos:

- entrada clara para quem chega sem contexto;
- aprofundamento progressivo para quem busca mais do que apresentação superficial;
- rotas estruturadas para conteúdo;
- pontos de contato e relação;
- eventual separação entre camadas pública e administrativa.

Se a arquitetura da informação ignorar a diversidade de perfis, o sistema ficará menos legível e menos eficiente.

---

## 10. Relação entre Perfis e Permissões

Este documento já antecipa um princípio importante:

nem todos os atores terão o mesmo nível de acesso, poder ou responsabilidade.

Em termos de futura segurança e governança, a solução deverá distinguir pelo menos:

- quem apenas acessa a camada pública;
- quem consome conteúdo com profundidade;
- quem interage com canais ou fluxos de contato;
- quem administra;
- quem edita;
- quem mantém tecnicamente.

As permissões detalhadas serão tratadas em documentos posteriores, mas a semente conceitual está fixada aqui.

---

## 11. Stakeholders Indiretos

Além dos atores centrais e operacionais, o projeto reconhece stakeholders indiretos.

São aqueles que, mesmo sem uso cotidiano direto, podem ser afetados ou beneficiar-se da boa forma do sistema.

Exemplos potenciais:

- comunidades de interesse ligadas aos conteúdos e projetos;
- instituições que venham a interagir com a presença digital;
- públicos que encontrem no sistema uma porta de entrada para compreensão mais ampla de William Albarello;
- colaboradores futuros.

Esses stakeholders indiretos reforçam a necessidade de coerência, estabilidade e legibilidade.

---

## 12. Riscos de Modelagem Humana Incorreta

Os principais riscos de erro nesta camada são os seguintes.

### 12.1 Reduzir tudo ao visitante genérico

Isso empobrece requisitos, fluxos e arquitetura.

### 12.2 Ignorar o papel singular do titular institucional

Isso enfraquece a coerência entre identidade representada e sistema construído.

### 12.3 Não prever operadores internos futuros

Isso produz arquitetura pública sem preparação para governança posterior.

### 12.4 Misturar perfis distintos em uma mesma solução sem diferenciação

Isso reduz clareza e gera conflitos de uso.

### 12.5 Criar perfis demais cedo demais

Isso pode inflar o projeto sem necessidade real.

A solução correta é equilíbrio:

- nem simplificação excessiva;
- nem inflação arbitrária de personas.

---

## 13. Implicações Diretas para os Próximos Documentos

A partir deste documento:

- `006_Requisitos_Funcionais.md` deverá derivar capacidades coerentes com esses perfis e atores;
- `007_Requisitos_Nao_Funcionais.md` deverá considerar acessibilidade, segurança, clareza e governabilidade em relação a eles;
- `009_Casos_de_Uso_Macro.md` deverá modelar interações reais com base nesses atores;
- `010_Jornadas_do_Usuario_e_Fluxos_Principais.md` deverá transformar esses perfis em percursos inteligíveis;
- `015_Seguranca_Privacidade_Auditoria_e_Permissoes.md` deverá detalhar níveis de acesso e responsabilidades.

Este documento, portanto, é ponte entre estratégia e comportamento do sistema.

---

## 14. Declaração Final

O projeto **William Albarello** será construído levando em conta que sua presença digital não se relaciona apenas com um público genérico e indiferenciado.

Há um sujeito central de representação e autoridade, há públicos externos com diferentes níveis de interesse, há interlocutores estratégicos potenciais e há possíveis atores internos de operação e manutenção.

Compreender essa pluralidade é indispensável para que o sistema seja:

- mais coerente;
- mais útil;
- mais governável;
- mais expansível;
- mais fiel à natureza do projeto.

A qualidade futura da arquitetura dependerá, em parte, da correção desta modelagem humana inicial.

---

## 15. Status deste Documento

Este documento entra em vigor imediatamente como referência soberana para a definição de stakeholders, perfis e atores do sistema.

Os documentos seguintes da pasta `01-Obrigatorios` deverão respeitar sua modelagem, salvo revisão formal explícita.
