
# 017_UI_UX_Arquitetura_da_Informacao

## Identificação do Documento

- **Projeto:** William Albarello
- **Camada:** 01-Waterfall
- **Subpasta:** 01-Obrigatorios
- **Documento:** 017_UI_UX_Arquitetura_da_Informacao.md
- **Função:** Definir a arquitetura da informação, a direção de UI/UX, a organização de rotas, navegação, hierarquia visual, padrões de tela, componentes base, estados de interface e critérios de experiência do sistema público e administrativo do projeto
- **Status:** ATIVO
- **Versão:** v1.0
- **Autoridade:** Alta
- **Natureza:** Documento soberano de UI/UX e arquitetura da informação
- **Dependência superior:**
  - 000_Indice_Mestre.md
  - 001_Manifesto_Metodologico_Waterfall_Caracol.md
  - 002_Regra_de_Nomenclatura_e_Versionamento.md
  - 024_Politica_de_Governanca_Documental.md
  - 001_Visao_Geral_do_Projeto.md
  - 002_Problema_Oportunidade_e_Tese_Central.md
  - 003_Objetivos_Estrategicos_e_Resultados_Esperados.md
  - 004_Escopo_e_Fora_de_Escopo.md
  - 005_Stakeholders_Perfis_e_Atores_do_Sistema.md
  - 006_Requisitos_Funcionais.md
  - 007_Requisitos_Nao_Funcionais.md
  - 008_Regras_de_Negocio.md
  - 009_Casos_de_Uso_Macro.md
  - 010_Jornadas_do_Usuario_e_Fluxos_Principais.md
  - 011_Arquitetura_Geral_do_Sistema.md
  - 012_Modulos_Dominios_e_Limites_do_Software.md
  - 013_Modelo_de_Dados_Conceitual.md
  - 014_Integracoes_e_Sistemas_Externos.md
  - 015_Seguranca_Privacidade_Auditoria_e_Permissoes.md
  - 016_API_Contract_Mestre.md
- **Dependências relacionadas:**
  - 018_Plano_de_Testes_Homologacao_e_Qualidade.md
  - 019_Riscos_Premissas_Restricoes_e_Mitigacoes.md
  - 021_Criterios_de_Aceite_Gerais.md
  - 023_Matriz_de_Rastreabilidade.md
  - 024_Registro_de_Decisoes_Arquiteturais.md

---

## 1. Finalidade

Este documento existe para transformar a arquitetura lógica do projeto **William Albarello** em uma **arquitetura de experiência**.

Sua função é declarar, de modo soberano:

- como a informação será organizada para o usuário;
- como o sistema público deverá ser percebido, lido e navegado;
- como o painel administrativo deverá operar com clareza e baixa ambiguidade;
- quais telas, rotas, blocos e componentes são essenciais no ciclo fundacional;
- quais estados de interface são obrigatórios;
- quais critérios de legibilidade, acessibilidade, responsividade e consistência visual são inegociáveis.

Este documento não descreve apenas estética.

Ele descreve **forma de uso**, **forma de leitura**, **forma de decisão** e **forma de organização da informação**.

Em outras palavras:

> este documento fixa a disciplina visual e experiencial do sistema.

---

## 2. Tese Central de UI/UX e Arquitetura da Informação

A tese central deste documento é a seguinte:

> a experiência do projeto William Albarello deve comunicar autoridade, clareza, organização e continuidade, fazendo com que a interface pareça menos um site improvisado e mais uma base digital soberana, editorialmente sólida e operacionalmente confiável.

Isso implica cinco compromissos fundamentais:

1. **conteúdo primeiro**;
2. **hierarquia sem ruído**;
3. **navegação legível e previsível**;
4. **conversão discreta, porém inequívoca**;
5. **experiência administrativa funcional, segura e não caótica**.

A UI não deverá competir com o conteúdo.

A UI deverá organizar o conteúdo, amplificar o posicionamento e reduzir atrito cognitivo.

---

## 3. Papel Estrutural Deste Documento

Este documento ocupa a transição entre:

- estratégia;
- arquitetura;
- contratos de API;
- futura geração de frontend;
- futura tradução em componentes, rotas, schemas de tela e testes.

Ele responde a quatro perguntas soberanas:

### 3.1 O que o usuário vê?

As páginas, blocos, componentes, estados e estruturas de navegação.

### 3.2 Em que ordem ele entende?

A hierarquia informacional, os caminhos de leitura e os fluxos de aprofundamento.

### 3.3 Como ele decide?

Por meio de CTAs claros, percursos previsíveis, prova estrutural e baixa fricção.

### 3.4 Como o sistema operacional interno funciona sem caos?

Por meio de telas administrativas com contratos claros, estados explícitos, ações reversíveis quando cabível e organização editorial coerente.

---

## 4. Escopo Deste Documento

Este documento cobre, no ciclo atual:

- arquitetura da informação pública;
- arquitetura da informação administrativa;
- estrutura macro de navegação;
- rotas centrais e famílias de páginas;
- princípios visuais e experienciais;
- componentes base e padrões de layout;
- estados de interface;
- diretrizes de copy funcional;
- responsividade e acessibilidade;
- critérios de aceite da experiência.

Este documento **não fecha ainda**:

- pixel-perfect final;
- design exploratório de branding artístico extremo;
- biblioteca completa de tokens técnicos implementados;
- animações avançadas;
- motion system detalhado quadro a quadro;
- CMS visual complexo;
- editor rico final do painel.

Ele fecha a **fundação soberana** da experiência.

---

## 5. Princípios Soberanos de UI/UX

Os princípios abaixo passam a ser obrigatórios para a evolução da camada de interface.

### 5.1 Conteúdo primeiro

A interface existe para tornar o conteúdo inteligível.

Logo:

- excesso de ornamento é falha;
- hero sem proposta de valor é falha;
- grid bonito sem semântica é falha;
- efeito visual que atrapalha leitura é falha.

### 5.2 Hierarquia sem ambiguidade

O usuário deve perceber rapidamente:

- onde está;
- o que a página representa;
- qual é a ideia principal;
- quais são os próximos passos possíveis.

### 5.3 Clareza maior que exuberância

O projeto deve transmitir sobriedade, precisão e institucionalidade.

Não deve parecer:

- landing genérica de promessa vazia;
- portfólio ornamental sem substância;
- template inchado por efeitos.

### 5.4 Conversão com dignidade

Os mecanismos de contato e aproximação devem existir com clareza, sem transformar toda a experiência em pressão comercial vulgar.

### 5.5 Coerência entre público e interno

A experiência pública e a administrativa devem pertencer ao mesmo ecossistema, mas sem confundir seus objetivos.

### 5.6 Legibilidade como critério estrutural

Se o usuário não consegue escanear, compreender e aprofundar com conforto, a interface falhou.

### 5.7 Acessibilidade como base, não como adorno

A acessibilidade deve ser pressuposto estrutural de projeto.

### 5.8 Estados explícitos

Toda ação relevante precisa comunicar seu estado.

Tela silenciosa diante de erro, vazio, carregamento ou validação é falha de UX.

---

## 6. Direção de Marca e Linguagem Visual

A direção de marca do projeto deve ser entendida como:

- **institucional**;
- **sóbria**;
- **técnica**;
- **autoral**;
- **contemporânea sem modismo**.

### 6.1 Sensação que a interface deve produzir

A interface deve comunicar:

- confiança;
- método;
- organização;
- capacidade;
- presença estruturada;
- autoridade calma.

### 6.2 Sensação que a interface não deve produzir

A interface não deve comunicar:

- improviso;
- excesso de autocelebração;
- ruído visual;
- “design por trend”;
- produto inflado além do que realmente entrega.

### 6.3 Regra estética superior

A estética deve parecer consequência de ordem, não substituto de substância.

---

## 7. Arquitetura da Informação — Visão Macro

A arquitetura da informação do projeto será organizada em **duas grandes superfícies**:

1. **superfície pública**;
2. **superfície administrativa**.

Cada uma possui objetivos, rotas, estruturas e expectativas de uso próprias.

### 7.1 Superfície pública

Objetivo:

- representar identidade;
- apresentar posicionamento;
- organizar áreas e projetos;
- entregar conteúdo;
- permitir contato.

### 7.2 Superfície administrativa

Objetivo:

- autenticar operadores autorizados;
- permitir governança editorial;
- permitir gestão de publicações;
- permitir gestão taxonômica;
- permitir observação de auditoria;
- sustentar o backoffice sem poluição semântica do ambiente público.

---

## 8. Mapa Macro de Informação do Projeto

O mapa macro soberano da informação deverá obedecer a seguinte organização.

### 8.1 Camada pública institucional

- Home
- Sobre
- Projetos
- Conteúdos / Publicações
- Contato

### 8.2 Camada pública editorial

- Lista de publicações
- Detalhe de publicação
- Relacionados
- Categoria e tag como mecanismos de descoberta, quando habilitados

### 8.3 Camada administrativa

- Login
- Dashboard
- Publicações
- Edição de publicação
- Categorias
- Tags
- Auditoria

### 8.4 Camadas reservadas para expansão posterior

- páginas institucionais compostas mais granulares;
- biblioteca de áreas de atuação;
- gestão administrativa de mensagens de contato;
- gestão de blocos institucionais;
- analytics operacional.

A regra correta é:

> a arquitetura da informação deve nascer clara o suficiente para o presente e aberta o suficiente para o futuro, sem inflar o presente com o futuro inteiro.

---

## 9. Estrutura Soberana de Rotas

A estrutura de rotas deverá seguir a separação abaixo.

## 9.1 Rotas públicas obrigatórias do ciclo

```text
/
 /sobre
 /projetos
 /conteudos
 /publicacoes
 /publicacoes/[slug]
 /contato
````

### 9.2 Rotas administrativas obrigatórias do ciclo

```text
/painel/login
/painel
/painel/publicacoes
/painel/publicacoes/novo
/painel/publicacoes/[id]
/painel/publicacoes/[id]/editar
/painel/categorias
/painel/tags
/painel/auditoria
```

### 9.3 Regra de nomenclatura

As rotas devem ser:

* curtas;
* previsíveis;
* semanticamente claras;
* consistentes com o domínio em português na camada pública;
* tecnicamente estáveis na camada administrativa.

### 9.4 Regra de idioma

A camada pública pode privilegiar português em URLs, dado o posicionamento soberano do projeto.

A camada interna deve priorizar consistência operacional e estabilidade.

---

## 10. Navegação Pública — Estrutura de Header e Footer

### 10.1 Header público obrigatório

O header público deverá conter, no mínimo:

* identidade visual/nome do projeto;
* acesso à Home;
* navegação principal;
* CTA de contato ou aproximação;
* comportamento responsivo com menu colapsável em mobile.

### 10.2 Ordem recomendada da navegação principal

1. Início
2. Sobre
3. Projetos
4. Conteúdos
5. Contato

### 10.3 Regras do header

* o header deve ser limpo;
* o usuário deve entender a navegação em poucos segundos;
* o CTA principal não deve disputar violentamente com a navegação;
* o menu mobile não pode esconder o eixo estratégico da navegação.

### 10.4 Footer público obrigatório

O footer deverá conter, no mínimo:

* identificação institucional;
* links principais de navegação;
* links editoriais relevantes;
* canal de contato principal;
* política de privacidade e termos, quando aplicável;
* créditos ou nota institucional discreta, se fizer sentido.

---

## 11. Arquitetura da Informação por Família de Página

## 11.1 Home

### Objetivo da Home

A Home deve cumprir simultaneamente quatro funções:

1. declarar identidade;
2. apresentar posicionamento;
3. provar substância;
4. abrir caminhos claros de aprofundamento.

### Estrutura macro recomendada da Home

1. Header global
2. Hero institucional
3. Bloco de proposta de valor / tese
4. Bloco de prova estrutural
5. Bloco de projetos ou frentes centrais
6. Bloco de publicações em destaque
7. CTA relacional / contato
8. Footer global

### Regras críticas da Home

* o hero precisa dizer algo real;
* a dobra inicial deve comunicar autoridade, não mistério vazio;
* a Home não deve tentar contar tudo ao mesmo tempo;
* a Home deve distribuir aprofundamento por blocos;
* cada bloco deve levar a um próximo passo legítimo.

---

## 11.2 Sobre

### Objetivo

Explicar quem é William Albarello, qual sua direção, quais eixos de atuação existem e por que o projeto possui densidade.

### Estrutura recomendada

1. abertura da seção;
2. apresentação institucional;
3. visão / método / posicionamento;
4. eixos de atuação;
5. prova de coerência ou fundamentos;
6. CTA de continuidade.

### Regras

* evitar autobiografia dispersa;
* privilegiar texto escaneável;
* usar subtítulos fortes;
* permitir leitura rápida e aprofundada.

---

## 11.3 Projetos

### Objetivo

Organizar frentes, iniciativas, obras, sistemas, produtos ou linhas de desenvolvimento associados ao ecossistema William Albarello.

### Estrutura recomendada

1. introdução da seção;
2. grid ou lista de projetos;
3. resumo objetivo por item;
4. links para aprofundamento quando existirem;
5. CTA de contato contextual.

### Regras

* não transformar o grid em vitrine vazia;
* cada card precisa explicar o que é o projeto;
* o usuário deve conseguir distinguir natureza, valor e direção de cada item.

---

## 11.4 Conteúdos / Publicações — Lista

### Objetivo

Servir como ponto de descoberta e organização editorial.

### Estrutura recomendada

1. cabeçalho da seção;
2. explicação curta do acervo editorial;
3. filtros ou taxonomias, quando habilitados;
4. lista/grid de publicações;
5. paginação;
6. bloco de continuidade relacional.

### Regras críticas

* a listagem precisa privilegiar leitura e descoberta;
* cards devem trazer contexto suficiente para clique consciente;
* filtros não podem gerar desorientação;
* paginação deve ser legível e tocável em mobile.

---

## 11.5 Publicação Individual

### Objetivo

Entregar leitura longa com conforto, hierarquia e continuidade.

### Estrutura recomendada

1. título
2. metadados editoriais
3. resumo ou lead, quando houver
4. conteúdo principal
5. relacionados
6. CTA de contato ou aprofundamento
7. footer

### Regras críticas

* tipografia para leitura longa é obrigatória;
* headings devem organizar a leitura;
* o contraste deve ser alto;
* o ritmo entre texto, subtítulos, listas e blocos auxiliares deve ser controlado;
* relacionados devem prolongar a jornada sem parecer spam interno.

---

## 11.6 Contato

### Objetivo

Converter intenção em aproximação legítima com o menor atrito possível.

### Estrutura recomendada

1. introdução curta;
2. explicação do canal;
3. formulário mínimo;
4. mensagem de privacidade/uso responsável;
5. feedback de envio.

### Regras críticas

* formulário simples;
* labels claros;
* validação por campo;
* confirmação inequívoca de sucesso ou erro;
* zero coleta excessiva no ciclo fundacional.

---

## 12. Arquitetura da Informação Administrativa

A camada administrativa deverá ser funcional, limpa, confiável e explicitamente separada da camada pública.

### 12.1 Objetivos da camada administrativa

* autenticar o operador correto;
* reduzir ambiguidades editoriais;
* permitir criação, edição e publicação com clareza;
* sustentar taxonomia;
* sustentar trilha mínima de auditoria.

### 12.2 Regra superior do painel

O painel não deve parecer uma adaptação improvisada da camada pública.

Ele deve operar como sistema interno.

### 12.3 Estrutura macro do painel

1. Login
2. Shell administrativa
3. Navegação lateral ou superior persistente
4. Área de conteúdo principal
5. Feedbacks persistentes e não destrutivos
6. Indicadores de status relevantes

---

## 13. Telas Administrativas Obrigatórias

## 13.1 Tela de Login

### Objetivo

Permitir autenticação clara, segura e sem ambiguidade.

### Elementos obrigatórios

* formulário com email e senha;
* botão primário de entrar;
* estado de loading;
* alerta de erro genérico;
* feedback de rate limit, quando aplicável;
* retorno explícito em caso de sessão inválida/expirada.

### Anti-padrões

* vazar detalhes sobre a credencial;
* excesso de elementos visuais irrelevantes;
* erro confuso;
* foco ruim para teclado.

---

## 13.2 Dashboard

### Objetivo

Oferecer visão operacional rápida do estado editorial e do ambiente interno.

### Componentes mínimos

* cards de contagem por status;
* atalhos úteis;
* indicadores simples de pendência;
* leitura clara de situação.

### Regra

O dashboard deve ser informativo, não decorativo.

---

## 13.3 Lista de Publicações

### Objetivo

Permitir localizar, filtrar e gerenciar publicações com rapidez.

### Componentes mínimos

* busca textual;
* filtro por status;
* filtro por categoria/tag, quando já disponíveis;
* tabela ou lista administrativa;
* status badge;
* ação de criar nova publicação;
* paginação ou navegação equivalente.

### Regra

A listagem deve permitir ação sem fadiga cognitiva.

---

## 13.4 Criação/Edição de Publicação

### Objetivo

Permitir criação e edição editorial com segurança e clareza.

### Seções mínimas do formulário

1. dados principais;
2. slug;
3. resumo;
4. conteúdo;
5. categoria;
6. tags;
7. status editorial;
8. campos mínimos de SEO, quando exigidos;
9. ações de salvar/publicar.

### Regras críticas

* validação inline quando possível;
* erro por campo;
* bloqueio claro para slug duplicado;
* confirmação de salvamento;
* aviso de alteração não salva, quando cabível;
* transição de status explícita.

---

## 13.5 Categorias

### Objetivo

Governar a taxonomia principal sem duplicidades óbvias.

### Componentes mínimos

* listagem;
* criação;
* edição;
* feedback de conflito;
* proteção contra exclusão inconsistente.

---

## 13.6 Tags

### Objetivo

Governar a taxonomia flexível sem gerar caos semântico.

### Regras

* tags devem ser curtas;
* duplicidade semântica óbvia deve ser inibida;
* experiência de criação deve ser rápida.

---

## 13.7 Auditoria

### Objetivo

Oferecer leitura confiável de eventos relevantes do sistema administrativo.

### Componentes mínimos

* listagem de eventos;
* data/hora;
* tipo de ação;
* alvo;
* ator, quando permitido;
* paginação;
* filtros simples futuros.

### Regra

A auditoria é para confiança operacional, não para ornamentação técnica.

---

## 14. Modelo de Navegação Administrativa

A navegação do painel deverá conter, no mínimo:

* Dashboard
* Publicações
* Categorias
* Tags
* Auditoria
* Logout

### 14.1 Comportamento

* persistente em desktop;
* colapsável em mobile/tablet;
* com destaque do item ativo;
* com nomenclatura explícita e não ambígua.

### 14.2 Regra

O usuário interno não pode precisar “descobrir” como o painel funciona.

O painel deve ser imediatamente operável.

---

## 15. Componentes Base do Sistema

Os componentes abaixo passam a formar o conjunto mínimo base do ecossistema de interface.

## 15.1 Componentes públicos

* `HeaderPublico`
* `FooterPublico`
* `HeroInstitucional`
* `SectionHeader`
* `ProjectCard`
* `PublicationCard`
* `RelatedPublications`
* `FilterBar`
* `Pagination`
* `ContactForm`
* `CTAContato`
* `SeoMetaBlock`
* `EmptyState`
* `ErrorState`
* `LoadingState`

## 15.2 Componentes administrativos

* `AdminShell`
* `AdminSidebar`
* `AdminTopbar`
* `DashboardMetricCard`
* `AdminTable`
* `SearchInput`
* `StatusBadge`
* `PublicationEditorForm`
* `SeoFields`
* `TaxonomyManager`
* `AuditLogList`
* `ConfirmActionDialog`
* `ToastFeedback`
* `InlineFieldError`

## 15.3 Regra de componentes

Todo componente base deverá declarar, futuramente:

* propósito;
* props/entradas;
* estados;
* comportamento responsivo;
* exigências de acessibilidade;
* dependência de API, quando existir.

---

## 16. Layout, Grid e Ritmo Visual

### 16.1 Largura de leitura

Conteúdos longos devem privilegiar largura confortável de leitura.

### 16.2 Ritmo vertical

A interface deve respeitar um ritmo de espaçamento consistente entre:

* seções;
* blocos;
* subtítulos;
* cards;
* elementos de formulário.

### 16.3 Densidade visual

A densidade deve variar conforme o contexto:

* público: mais respiro e leitura;
* administrativo: maior eficiência operacional, sem poluição.

### 16.4 Regra

Espaçamento não pode ser arbitrário nem ajustado “na mão” tela a tela sem lógica sistêmica.

---

## 17. Tipografia e Hierarquia de Texto

### 17.1 Regra geral

A tipografia é parte da arquitetura da informação.

Não é mero acabamento.

### 17.2 Exigências

* heading principal forte e inequívoco;
* subtítulos com hierarquia perceptível;
* corpo de texto altamente legível;
* contraste suficiente;
* line-height confortável;
* diferenciação clara entre texto principal, auxiliar e meta-informação.

### 17.3 Conteúdo longo

Publicações e páginas densas devem ser desenhadas para leitura real, não para captura de tela bonita.

---

## 18. Diretrizes de Copy Funcional e Microcopy

### 18.1 Princípio geral

A linguagem da interface deve ser:

* clara;
* precisa;
* institucional;
* humana sem excesso de informalidade;
* operacional quando interna;
* editorial quando pública.

### 18.2 CTAs

CTAs devem ser específicos.

Exemplos legítimos:

* Conhecer projetos
* Ler publicações
* Entrar em contato
* Criar publicação
* Salvar rascunho
* Publicar agora

### 18.3 Erros

Mensagens de erro devem orientar a correção.

### 18.4 Validações

Devem indicar:

* o campo com problema;
* o motivo do problema;
* o que o usuário precisa fazer.

---

## 19. Estados de Interface Obrigatórios

Toda tela relevante deverá declarar, no mínimo, seus estados.

### 19.1 Estados públicos mínimos

* `loading`
* `success`
* `empty`
* `error`

### 19.2 Estados administrativos mínimos

* `idle`
* `loading`
* `success`
* `empty`
* `error`
* `validation_error`
* `forbidden`
* `session_expired`

### 19.3 Regra de feedback

Nenhuma ação crítica deve terminar sem feedback.

### 19.4 Regra de erro

Erro sem orientação é UX incompleta.

---

## 20. Fluxos UX Críticos a Serem Preservados

Os fluxos abaixo são considerados críticos e não podem ser degradados por decisões cosméticas.

## 20.1 Fluxo de descoberta pública

1. entrar na Home;
2. compreender proposta;
3. avançar para projetos ou conteúdos;
4. abrir publicação;
5. seguir para conteúdo relacionado ou contato.

### Critérios

* até o primeiro aprofundamento relevante: poucas interações;
* sem perda de contexto;
* com orientação visual clara.

## 20.2 Fluxo de contato

1. acessar Contato;
2. preencher formulário;
3. corrigir erros, se houver;
4. enviar;
5. perceber confirmação.

## 20.3 Fluxo de login admin

1. acessar login;
2. autenticar;
3. entrar no painel;
4. recuperar-se de erro ou sessão expirada.

## 20.4 Fluxo editorial

1. entrar no painel;
2. localizar ou criar publicação;
3. editar dados;
4. salvar;
5. revisar;
6. publicar;
7. validar reflexo público.

---

## 21. Responsividade

A interface deverá operar com previsibilidade em três faixas mínimas.

### 21.1 Breakpoints conceituais

* **mobile:** 320–767
* **tablet:** 768–1023
* **desktop:** 1024+

### 21.2 Regras globais

* conteúdo textual deve permanecer legível em telas pequenas;
* menu principal deve colapsar sem esconder o eixo de navegação;
* grids devem degradar com ordem;
* alvos de toque devem ser confortáveis;
* tabelas administrativas devem priorizar colunas essenciais em telas menores.

### 21.3 Regras específicas

#### Home

* hero empilha em mobile;
* CTAs continuam visíveis;
* blocos institucionais viram pilha vertical.

#### Lista de publicações

* filtros podem migrar para drawer em mobile;
* paginação deve ser tocável;
* resumo dos cards pode ser reduzido.

#### Publicação individual

* largura de leitura adaptada;
* tabelas e códigos com rolagem quando necessário;
* headings e blocos não podem colapsar em ruído.

#### Painel admin

* sidebar colapsável;
* listagens adaptáveis;
* formulários longos com organização progressiva.

---

## 22. Acessibilidade

A acessibilidade do projeto deverá buscar, como baseline, conformidade com **WCAG AA** para o que for cabível no ciclo.

### 22.1 Regras obrigatórias

* contraste adequado;
* foco visível em elementos interativos;
* navegação por teclado nos fluxos essenciais;
* labels explícitos;
* mensagens de erro associadas aos campos;
* headings em ordem semântica coerente;
* links e botões distinguíveis;
* feedbacks que não dependam apenas de cor.

### 22.2 Formulários

Formulários devem ter:

* label clara;
* indicação de obrigatório;
* mensagem de erro próxima;
* associação acessível entre erro e input.

### 22.3 Painel

O painel interno também deve obedecer acessibilidade.

Sistema interno ruim continua sendo sistema ruim.

---

## 23. Motion e Microinterações

### 23.1 Regra superior

Movimento existe para reforçar compreensão, não para distrair.

### 23.2 Diretrizes

* transições curtas;
* hover discreto;
* loading coerente com contexto;
* feedback imediato após ação;
* respeito a `prefers-reduced-motion`.

### 23.3 Anti-padrões

* animação ornamental excessiva;
* transições lentas;
* motion que atrapalha leitura;
* skeleton exagerado quando um loading simples bastaria.

---

## 24. Mapa de Contratos de Tela por Rota

Abaixo está o contrato mínimo de tela por rota, em nível soberano.

## 24.1 `/`

* propósito: posicionamento inicial e distribuição de aprofundamento;
* entradas prováveis: página composta da Home + destaques editoriais;
* estados: `loading`, `error`, `success`;
* ações críticas: navegar para projetos, conteúdos e contato.

## 24.2 `/sobre`

* propósito: explicar identidade e direção;
* estados: `loading`, `error`, `success`;
* ação crítica: aprofundar entendimento e seguir para projetos ou contato.

## 24.3 `/projetos`

* propósito: apresentar iniciativas e frentes;
* estados: `loading`, `empty`, `error`, `success`;
* ação crítica: abrir projeto ou migrar para contato.

## 24.4 `/conteudos` ou `/publicacoes`

* propósito: descoberta editorial;
* entradas: listagem pública, filtros, paginação;
* estados: `loading`, `empty`, `error`, `success`;
* ação crítica: abrir publicação mantendo contexto.

## 24.5 `/publicacoes/[slug]`

* propósito: leitura profunda;
* entradas: detalhe da publicação + relacionados;
* estados: `loading`, `error`, `success`;
* ação crítica: avançar para relacionado ou contato.

## 24.6 `/contato`

* propósito: aproximação institucional;
* entradas: formulário + política mínima;
* estados: `idle`, `loading`, `validation_error`, `error`, `success`.

## 24.7 `/painel/login`

* propósito: autenticação;
* entradas: form de login;
* estados: `idle`, `loading`, `error`, `success`, `rate_limited`;
* ação crítica: autenticar e redirecionar.

## 24.8 `/painel`

* propósito: leitura rápida do estado operacional;
* estados: `loading`, `error`, `success`.

## 24.9 `/painel/publicacoes`

* propósito: localizar e gerenciar acervo;
* entradas: listagem administrativa;
* estados: `loading`, `empty`, `error`, `success`;
* ação crítica: criar, editar, filtrar.

## 24.10 `/painel/publicacoes/novo` e `/painel/publicacoes/[id]/editar`

* propósito: edição;
* estados: `loading`, `error`, `success`, `validation_error`;
* ação crítica: salvar rascunho, revisar, publicar.

## 24.11 `/painel/categorias`

* propósito: governança de categorias;
* estados: `loading`, `empty`, `error`, `success`, `conflict`.

## 24.12 `/painel/tags`

* propósito: governança de tags;
* estados: `loading`, `empty`, `error`, `success`, `conflict`.

## 24.13 `/painel/auditoria`

* propósito: leitura de rastreabilidade;
* estados: `loading`, `empty`, `error`, `success`.

---

## 25. Regras de SEO e Descoberta na UI Pública

A interface pública deve colaborar com SEO e descoberta, sem sacrificar legibilidade.

### 25.1 Exigências

* headings consistentes;
* títulos claros;
* meta descrição coerente por página;
* URLs legíveis;
* breadcrumbs quando fizer sentido em expansão futura;
* cards de publicação com contexto suficiente para clique qualificado.

### 25.2 Regra

SEO não deve deformar a experiência humana.

---

## 26. Anti-padrões Expressamente Rejeitados

Ficam rejeitados, desde já:

* hero genérico sem proposta clara;
* menu inflado;
* excesso de animação;
* contraste fraco;
* estética “premium” que piora leitura;
* CTAs vagos;
* cards sem explicação;
* formulários excessivos;
* painel com densidade confusa;
* erro silencioso;
* interfaces que dependem de adivinhação;
* componente novo criado sem alinhamento sistêmico.

---

## 27. Critérios de Qualidade da Experiência

Para que a camada de UI/UX deste projeto seja considerada boa, ela deverá ser:

* clara na primeira leitura;
* digna em termos institucionais;
* confortável para leitura longa;
* precisa na hierarquia;
* consistente entre telas;
* operacionalmente eficiente no painel;
* acessível no essencial;
* preparada para ser traduzida em design system, componentes e testes.

---

## 28. Critérios de Aceite Deste Documento

Este documento será considerado corretamente consolidado quando os seguintes critérios estiverem atendidos:

1. a macroarquitetura da informação pública e administrativa estiver definida;
2. as famílias de páginas estiverem formalizadas;
3. a estrutura de rotas obrigatórias estiver explicitada;
4. os princípios soberanos de UI/UX estiverem fixados;
5. os componentes base estiverem mapeados;
6. os estados de interface obrigatórios estiverem declarados;
7. responsividade e acessibilidade estiverem incorporadas como regra;
8. o documento puder servir como base direta para contratos de tela, design system, implementação frontend e testes.

---

## 29. Materiais Herdados Utilizados como Reforço Estrutural

Os seguintes artefatos herdados do acervo anterior foram reconhecidos como úteis para reforço estrutural, sem autoridade superior sobre este documento:

* `personal-site (1)/personal-site/Waterfall/DOC-05-arquitetura-da-informacao.md`
* `personal-site (1)/personal-site/Waterfall/DOC-17-ux-ui-institucional-e-branding.md`
* `personal-site (1)/personal-site/UI_UX/UIUX-01-principios-de-design.md`
* `personal-site (1)/personal-site/UI_UX/UIUX-02-design-system-base.md`
* `personal-site (1)/personal-site/UI_UX/UIUX-03-wireframes-estruturais.md`
* `personal-site (1)/personal-site/UI_UX/UIUX-07-fluxos-ux-criticos.md`
* `personal-site (1)/personal-site/UI_UX/UIUX-08-especificacao-responsividade.md`
* `personal-site (1)/personal-site/UI_UX/UIUX-11-contratos-de-tela-por-rota.md`

A regra de precedência permanece:

> reforço herdado é útil; soberania do ciclo atual é superior.

---

## 30. Declaração Final

Com este documento, o projeto **William Albarello** passa a possuir uma definição soberana da sua camada de **UI/UX e arquitetura da informação**, distinguindo com clareza:

* o que o usuário público deve ver, entender e percorrer;
* o que o operador interno deve usar para governar o sistema;
* como as rotas se organizam;
* como os componentes base se distribuem;
* quais estados de interface são obrigatórios;
* quais princípios visuais e experienciais não podem ser violados.

A partir deste ponto, a evolução para:

* contratos de tela mais finos;
* design system técnico;
* geração de componentes;
* implementação frontend;
* testes de interface e aceite

pode ocorrer com base disciplinada, sem improviso estrutural.

A experiência do projeto deixa de ser intuição estética.

Ela passa a ser arquitetura soberana.

---

## 31. Status do Documento

**Documento consolidado como base soberana de UI/UX e arquitetura da informação do projeto William Albarello, apto a orientar design system, contratos de tela, implementação frontend e critérios de validação da experiência.**


