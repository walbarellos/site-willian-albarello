# 024_Registro_de_Decisoes_Arquiteturais

## Identificação do Documento

- **Projeto:** William Albarello
- **Camada:** 01-Waterfall
- **Subpasta:** 01-Obrigatorios
- **Documento:** 024_Registro_de_Decisoes_Arquiteturais.md
- **Função:** Definir o sistema soberano de registro, governança, estrutura, ciclo de vida e uso das decisões arquiteturais do projeto, impedindo perda de contexto, rediscussão caótica de fundamentos e evolução técnica sem memória explícita
- **Status:** ATIVO
- **Versão:** v1.0
- **Autoridade:** Alta
- **Natureza:** Documento soberano de ADRs, governança decisória e memória arquitetural
- **Dependência superior:**
  - 000_Indice_Mestre.md
  - 001_Manifesto_Metodologico_Waterfall_Caracol.md
  - 002_Regra_de_Nomenclatura_e_Versionamento.md
  - 024_Politica_de_Governanca_Documental.md
  - 001_Visao_Geral_do_Projeto.md
  - 002_Problema_Oportunidade_e_Tese_Central.md
  - 003_Objetivos_Estrategicos_e_Resultados_Esperados.md
  - 004_Escopo_e_Fora_de_Escopo.md
  - 005_Stakeholders_Perfis_e_Atores_do_Sistema.md
  - 006_Requisitos_Funcionais.md
  - 007_Requisitos_Nao_Funcionais.md
  - 008_Regras_de_Negocio.md
  - 009_Casos_de_Uso_Macro.md
  - 010_Jornadas_do_Usuario_e_Fluxos_Principais.md
  - 011_Arquitetura_Geral_do_Sistema.md
  - 012_Modulos_Dominios_e_Limites_do_Software.md
  - 013_Modelo_de_Dados_Conceitual.md
  - 014_Integracoes_e_Sistemas_Externos.md
  - 015_Seguranca_Privacidade_Auditoria_e_Permissoes.md
  - 016_API_Contract_Mestre.md
  - 017_UI_UX_Arquitetura_da_Informacao.md
  - 018_Plano_de_Testes_Homologacao_e_Qualidade.md
  - 019_Riscos_Premissas_Restricoes_e_Mitigacoes.md
  - 020_Cronograma_Fases_Marcos_e_Sequenciamento.md
  - 021_Criterios_de_Aceite_Gerais.md
  - 022_Plano_de_Implantacao_Rollback_e_Suporte.md
  - 023_Matriz_de_Rastreabilidade.md
- **Dependências relacionadas:**
  - futuros ADRs formais do projeto
  - próximos blocos de detalhamento superior
  - futura tradução controlada para implementação
  - futuras revisões arquiteturais e operacionais

---

## 1. Finalidade

Este documento existe para declarar, de forma soberana, **como o projeto William Albarello registra, preserva, revisa e governa suas decisões arquiteturais**.

Sua função é impedir que escolhas centrais do projeto:

- fiquem implícitas;
- desapareçam entre ciclos;
- sejam rediscutidas sem contexto;
- sejam substituídas por conveniência momentânea;
- gerem retrabalho por perda de memória;
- contaminem a implementação com ambiguidades evitáveis.

Este documento transforma decisão arquitetural em objeto explícito de governança.

Em outras palavras:

> a arquitetura do projeto não deverá sobreviver apenas na memória, no improviso ou em inferências dispersas;  
> ela deverá sobreviver por registro formal.

---

## 2. Tese Central do Documento

A tese central deste documento é a seguinte:

> no projeto William Albarello, toda decisão arquitetural relevante precisa deixar rastro explícito, porque aquilo que não é formalmente decidido tende a retornar como disputa, retrabalho, contradição ou acoplamento invisível.

Isso significa que o projeto rejeita explicitamente a lógica de:

- “depois a gente lembra por que escolheu isso”;
- “o código fala por si”;
- “essa decisão está espalhada em vários lugares, então está tudo bem”;
- “não precisamos registrar porque parece óbvio agora”;
- “vamos mudar porque hoje parece melhor, sem formalizar o impacto”.

Neste projeto, uma decisão arquitetural só é madura quando, no mínimo, é capaz de responder:

1. qual problema estava sendo resolvido;
2. quais opções existiam;
3. qual opção foi escolhida;
4. por que essa opção venceu;
5. que consequências ela produz;
6. o que precisará ser revisto no futuro;
7. quais artefatos e camadas ela impacta.

---

## 3. Papel Estrutural Deste Documento

Este documento ocupa a camada de memória decisória do projeto.

Ele conecta:

- riscos;
- critérios de aceite;
- cronograma;
- rastreabilidade;
- implantação;
- arquitetura;
- API;
- segurança;
- UX;
- modularização;
- evolução futura.

Ele responde às seguintes perguntas soberanas:

### 3.1 O que é uma decisão arquitetural neste projeto?

Qualquer escolha estrutural que afete organização, comportamento, contrato, governança, risco, implementação ou evolução da obra.

### 3.2 Quando uma decisão precisa virar ADR?

Quando sua ausência explícita começar a gerar risco de confusão, divergência, retrabalho, impacto transversal ou reabertura indevida.

### 3.3 Quem governa a decisão?

A autoridade arquitetural do projeto, vinculada ao corpus soberano do Waterfall e aos gates definidos.

### 3.4 Como a decisão evolui?

Por registro, revisão controlada, impacto conhecido e eventual substituição formal — nunca por desaparecimento silencioso.

---

## 4. Escopo do Documento

Este documento cobre:

- conceito de ADR no projeto;
- critérios para abrir ADR;
- estrutura oficial de um ADR;
- estados oficiais de uma decisão;
- ciclo de vida de uma decisão arquitetural;
- relação entre ADR e restante do corpus;
- critérios de revisão, supersessão e cancelamento;
- taxonomia de decisões;
- regras de autoridade;
- catálogo inicial de decisões já implícitas no projeto;
- estratégia de governança futura dos ADRs.

Este documento **não substitui**:

- os ADRs individuais;
- a matriz de rastreabilidade;
- o cronograma;
- o plano de testes;
- o plano de implantação;
- a documentação técnica de implementação.

Ele define a **constituição soberana das decisões arquiteturais**.

---

## 5. Definições Soberanas

Para evitar ambiguidade, o projeto adotará as definições abaixo.

### 5.1 Decisão arquitetural

Escolha relevante sobre estrutura, organização, contrato, tecnologia, governança, segurança, UX estrutural, implantação ou evolução do sistema.

### 5.2 ADR

Registro formal de decisão arquitetural.

### 5.3 Contexto decisório

Problema real que tornou a decisão necessária.

### 5.4 Opções consideradas

Alternativas plausíveis analisadas antes da decisão.

### 5.5 Decisão adotada

Opção escolhida como soberana para o contexto em questão.

### 5.6 Consequência da decisão

Impactos positivos, custos, limites e efeitos colaterais que decorrem da escolha.

### 5.7 Supersessão

Substituição formal de uma decisão anterior por uma nova.

### 5.8 Dívida decisória

Situação em que o projeto já depende de uma escolha estrutural, mas essa escolha ainda não está formalizada adequadamente.

---

## 6. Princípios Soberanos de Governança Decisória

Os princípios abaixo tornam-se obrigatórios.

### 6.1 Decisão importante deve deixar rastro

Se a escolha impacta o projeto de modo não trivial, ela deve ser formalizada.

### 6.2 ADR não é literatura ornamental

Um ADR só existe para resolver confusão futura, proteger coerência e orientar ação real.

### 6.3 Decisão registrada é melhor que consenso difuso

Quando todo mundo “acha que sabe”, ninguém realmente sabe com segurança.

### 6.4 Revisão é legítima; amnésia não

Decisões podem ser revisitadas.
O que não se aceita é perder o motivo original.

### 6.5 O custo da decisão deve ser visível

Toda escolha traz ganhos e perdas.
Um ADR precisa dizer ambos.

### 6.6 Nem toda escolha merece ADR

O projeto não deve burocratizar detalhes irrelevantes.

### 6.7 Toda mudança estrutural relevante precisa de análise de impacto

Trocar sem saber o que afeta é antiarquitetura.

### 6.8 ADR serve ao projeto, não ao ego técnico

O objetivo não é parecer sofisticado; é preservar clareza, memória e governança.

---

## 7. Quando um ADR é Obrigatório

Um ADR deverá ser aberto obrigatoriamente quando a decisão afetar qualquer um dos pontos abaixo.

### 7.1 Estrutura macro do sistema

Exemplos:

- separação entre público e admin;
- modularização principal;
- desenho de camadas;
- fronteiras entre serviços.

### 7.2 Contratos de API

Exemplos:

- versionamento;
- envelopes de sucesso e erro;
- política de autenticação;
- separação de namespaces.

### 7.3 Segurança estrutural

Exemplos:

- estratégia de sessão;
- autorização por papéis;
- tratamento de proteção administrativa;
- política de exposição pública.

### 7.4 UX estrutural e arquitetura da informação

Exemplos:

- organização de rotas;
- shell administrativo;
- superfície pública institucional versus editorial.

### 7.5 Dados e entidades centrais

Exemplos:

- modelagem das entidades mestres;
- política de slug;
- estratégia de status editorial;
- governança taxonômica.

### 7.6 Implantação e operação

Exemplos:

- estratégia de rollout;
- rollback por camada;
- política de staging;
- gates de publicação.

### 7.7 Continuidade metodológica

Exemplos:

- primazia do bloco obrigatório;
- política de reaproveitamento do legado;
- abertura da futura camada Relational-Life.

---

## 8. Quando um ADR Não é Necessário

Nem toda escolha precisa virar ADR.

Um ADR não é necessário, em regra, para:

- microdetalhes visuais sem impacto estrutural;
- copy pontual de interface;
- ordem local de elementos sem efeito sistêmico;
- refatoração interna sem mudança de contrato ou arquitetura;
- ajuste menor de estilo;
- correção operacional que não altera premissa estrutural.

### Regra soberana

ADR é para escolha estrutural relevante.
Não para qualquer microdecisão.

---

## 9. Objetivos do Sistema de ADRs do Projeto

Os objetivos soberanos deste sistema são:

1. preservar memória arquitetural;
2. impedir rediscussão caótica do fundamento;
3. vincular decisão a contexto real;
4. tornar revisões futuras mais inteligentes;
5. fortalecer rastreabilidade entre decisão e implementação;
6. reduzir retrabalho por ambiguidade;
7. permitir evolução disciplinada;
8. sustentar a futura tradução em software real.

---

## 10. Estados Oficiais de um ADR

Todo ADR do projeto deverá estar em um dos estados abaixo.

### 10.1 Proposto

A decisão foi identificada como necessária, mas ainda não está oficialmente adotada.

### 10.2 Em análise

O contexto foi aberto e as opções estão sendo avaliadas.

### 10.3 Aceito

A decisão foi adotada como soberana para o contexto atual.

### 10.4 Rejeitado

A proposta foi analisada e não adotada.

### 10.5 Substituído

A decisão existiu, mas foi formalmente supersedida por outra.

### 10.6 Obsoleto

A decisão perdeu centralidade por mudança do projeto, sem necessariamente ter sido “errada”.

### 10.7 Suspenso

A decisão foi temporariamente congelada, aguardando informação adicional ou mudança de contexto.

---

## 11. Estrutura Oficial de um ADR no Projeto

Todo ADR deverá obedecer, no mínimo, à estrutura abaixo.

### 11.1 Identificação

- código do ADR;
- título;
- status;
- data;
- projeto;
- camada;
- autoridade.

### 11.2 Contexto

- qual problema motivou a decisão;
- em que fase/camada o problema surgiu;
- quais riscos ou conflitos estavam presentes.

### 11.3 Forças em jogo

- requisitos;
- restrições;
- riscos;
- critérios de aceite;
- impactos arquiteturais;
- impactos operacionais.

### 11.4 Opções consideradas

- opção A;
- opção B;
- opção C, quando houver;
- prós e contras.

### 11.5 Decisão adotada

- qual opção foi escolhida;
- formulação clara e inequívoca.

### 11.6 Consequências

- ganhos;
- perdas;
- trade-offs;
- impactos em outros artefatos;
- impactos em futuras fases.

### 11.7 Relações

- documentos afetados;
- APIs afetadas;
- módulos afetados;
- fluxos impactados;
- testes e aceite relacionados;
- riscos mitigados ou criados.

### 11.8 Próximos passos

- o que precisa ser atualizado após a decisão;
- o que dependerá dela.

---

## 12. Nomenclatura Oficial dos ADRs

Os ADRs do projeto deverão seguir padrão canônico como:

```text
ADR-001_TITULO_EM_MAIUSCULAS_COM_UNDERSCORE.md
````

Exemplos:

* `ADR-001_SEPARACAO_ENTRE_SUPERFICIE_PUBLICA_E_ADMINISTRATIVA.md`
* `ADR-002_VERSIONAMENTO_EXPLICITO_DA_API_EM_V1.md`
* `ADR-003_SESSAO_ADMINISTRATIVA_BASEADA_EM_COOKIE_SEGURO.md`

### Regras

* numeração sequencial;
* título objetivo;
* sem nomes vagos;
* sem dependência de memória implícita.

---

## 13. Regras de Autoridade dos ADRs

### 13.1 Precedência

Um ADR aceito passa a ter força normativa abaixo dos documentos soberanos do bloco obrigatório, mas acima de improvisos de implementação.

A hierarquia correta será:

1. bloco soberano `01-Waterfall/01-Obrigatorios`;
2. ADRs aceitos;
3. artefatos derivados;
4. implementação.

### 13.2 Limite de autoridade

Um ADR não pode contradizer um documento soberano superior sem que a mudança seja refletida formalmente nesse documento superior ou em revisão legítima do corpus.

### 13.3 Efeito prático

Quando um ADR aceito existe, a implementação deve obedecê-lo.

---

## 14. Ciclo de Vida Oficial de uma Decisão Arquitetural

O ciclo de vida de uma decisão seguirá, em regra, a ordem abaixo.

1. surgimento do problema;
2. identificação da necessidade decisória;
3. abertura do contexto;
4. análise de opções;
5. decisão;
6. registro formal;
7. propagação para artefatos afetados;
8. validação do impacto;
9. eventual revisão futura;
10. supersessão ou obsolescência, quando cabível.

---

## 15. Gatilhos para Revisão de um ADR

Um ADR deverá ser revisado quando ocorrer qualquer uma das situações abaixo.

### 15.1 Mudança relevante de escopo

Exemplo: o projeto passa a exigir capacidade estrutural não contemplada pela decisão anterior.

### 15.2 Mudança relevante de risco

Exemplo: a solução escolhida se prova operacionalmente mais frágil do que o previsto.

### 15.3 Mudança relevante de contexto técnico

Exemplo: a arquitetura antes adequada passa a bloquear a evolução.

### 15.4 Descoberta de consequência não prevista

Exemplo: a decisão gera acoplamento ou custo indevido.

### 15.5 Evidência empírica contra a decisão

Exemplo: homologação ou produção mostram falha estrutural repetida.

### 15.6 Conflito formal com novo corpus soberano

Exemplo: novo documento obrigatório torna explícita uma orientação incompatível com o ADR vigente.

---

## 16. Regras de Supersessão

Quando um ADR for substituído, a supersessão deverá obedecer à disciplina abaixo.

### 16.1 Nunca apagar o histórico

O ADR antigo continua existindo como memória do projeto.

### 16.2 Registrar a substituição explicitamente

O novo ADR deve apontar qual decisão substitui.

### 16.3 Explicar o motivo da supersessão

É obrigatório dizer o que mudou no contexto.

### 16.4 Atualizar os artefatos impactados

Matriz, critérios, testes, APIs, cronograma ou implantação podem precisar ser ajustados.

---

## 17. Relação entre ADR e Matriz de Rastreabilidade

Este documento depende diretamente de `023_Matriz_de_Rastreabilidade.md`.

A matriz deve ser capaz de responder:

* qual ADR justifica tal módulo;
* qual ADR sustenta tal contrato;
* qual ADR explica tal separação;
* qual ADR precisa ser revisado se tal fluxo falhar.

### Regra soberana

ADR sem rastreabilidade vira arquivo morto.
Rastreabilidade sem ADR vira memória frágil.

---

## 18. Relação entre ADR e Cronograma

Este documento depende diretamente de `020_Cronograma_Fases_Marcos_e_Sequenciamento.md`.

Decisões arquiteturais influenciam:

* ordem de implementação;
* bloqueios de avanço;
* gates;
* paralelismo legítimo;
* mudança de fase;
* replanejamento.

Logo, mudança arquitetural relevante pode alterar cronograma.

---

## 19. Relação entre ADR e Critérios de Aceite

Este documento depende diretamente de `021_Criterios_de_Aceite_Gerais.md`.

Um item pode ser reprovado se violar ADR aceito.

Exemplos:

* interface que mistura público e admin;
* API sem versionamento explícito, se ADR tiver fixado isso;
* solução de autenticação incompatível com decisão soberana.

---

## 20. Relação entre ADR e Implantação

Este documento depende diretamente de `022_Plano_de_Implantacao_Rollback_e_Suporte.md`.

Certas decisões arquiteturais possuem impacto direto em:

* estratégia de rollout;
* reversão por camada;
* política de staging;
* suporte inicial;
* superfície de risco operacional.

---

## 21. Relação entre ADR e Riscos

Este documento depende diretamente de `019_Riscos_Premissas_Restricoes_e_Mitigacoes.md`.

Todo ADR relevante deverá explicitar, quando aplicável:

* quais riscos tenta mitigar;
* quais riscos introduz;
* quais riscos aumenta;
* quais riscos deixa residuais.

---

## 22. Relação entre ADR e Testes/Homologação

Este documento depende diretamente de `018_Plano_de_Testes_Homologacao_e_Qualidade.md`.

Toda decisão arquitetural importante deverá, em algum momento, ser verificável por:

* teste estrutural;
* teste de contrato;
* homologação de fluxo;
* validação de segurança;
* revisão documental.

### Regra

Decisão que não pode ser testada ou observada tende a ser perigosa ou vaga demais.

---

## 23. Taxonomia Oficial de ADRs do Projeto

O projeto reconhecerá, no mínimo, os seguintes tipos de ADR.

### 23.1 ADR de estrutura macro

Exemplo: separação entre superfícies e camadas.

### 23.2 ADR de contrato

Exemplo: versionamento de API, envelopes, política de erro.

### 23.3 ADR de segurança

Exemplo: autenticação, sessão, autorização.

### 23.4 ADR de dados

Exemplo: modelagem de entidade, política de slug, estratégia de estados.

### 23.5 ADR de UX estrutural

Exemplo: arquitetura da informação, shell admin, rotas macro.

### 23.6 ADR de operação e implantação

Exemplo: rollout, rollback, staging, publicação por camada.

### 23.7 ADR metodológico

Exemplo: precedência do obrigatório, uso controlado do legado, abertura de novas camadas.

---

## 24. Catálogo Inicial de Decisões Arquiteturais Já Implicitamente Consolidadas

Embora ainda não estejam necessariamente abertas como ADRs individuais, as decisões abaixo já estão implicitamente consolidadas no corpus do projeto.

---

## 25. DEC-001 — O projeto será construído a partir de um repositório documental soberano

### Estado

Aceita implicitamente

### Contexto

O projeto optou por não depender apenas do repositório anterior, mas por reconstruir a soberania documental.

### Consequência

O documento governa o código; o legado vira referência, não autoridade.

### Futuro ADR sugerido

`ADR-001_REPOSITORIO_DOCUMENTAL_SOBERANO_COMO_FONTE_PRIMARIA_DE_VERDADE.md`

---

## 26. DEC-002 — O bloco `01-Obrigatorios` tem precedência sobre expansão lateral

### Estado

Aceita implicitamente

### Contexto

Foi reconhecido que detalhamento, high tech e futura geração só são legítimos após fechamento do núcleo.

### Consequência

Aceleração sem fechamento do obrigatório é considerada desvio metodológico.

### Futuro ADR sugerido

`ADR-002_PRECEDENCIA_DO_BLOCO_OBRIGATORIO_SOBRE_CAMADAS_SUPERIORES.md`

---

## 27. DEC-003 — O legado `personal-site (1)` é referência útil, mas não soberana

### Estado

Aceita implicitamente

### Contexto

O acervo antigo contém valor, mas pode trazer conflitos semânticos e estruturais se absorvido sem curadoria.

### Consequência

Todo reaproveitamento deve ser curado e harmonizado.

### Futuro ADR sugerido

`ADR-003_REAPROVEITAMENTO_CURADO_DO_ACERVO_LEGADO.md`

---

## 28. DEC-004 — O sistema terá separação nítida entre superfície pública e superfície administrativa

### Estado

Aceita implicitamente

### Contexto

A tese do projeto exige distinção forte entre representação pública e operação interna.

### Consequência

Arquitetura, API, UX e segurança precisam respeitar essa fronteira.

### Futuro ADR sugerido

`ADR-004_SEPARACAO_ENTRE_SUPERFICIE_PUBLICA_E_ADMINISTRATIVA.md`

---

## 29. DEC-005 — A API nascerá versionada e semanticamente limpa

### Estado

Aceita implicitamente

### Contexto

Foi fixado prefixo `/v1` e separação `/v1/public` e `/v1/admin`.

### Consequência

A implementação não poderá inventar contratos sem obediência a esse desenho.

### Futuro ADR sugerido

`ADR-005_VERSIONAMENTO_EXPLICITO_E_NAMESPACES_DISTINTOS_DA_API.md`

---

## 30. DEC-006 — A autenticação administrativa adotará sessão segura baseada em cookie

### Estado

Aceita implicitamente

### Contexto

A política de segurança do corpus aponta nessa direção como baseline fundacional.

### Consequência

Fluxos admin, logout, proteção de rota e CSRF precisam obedecer essa escolha.

### Futuro ADR sugerido

`ADR-006_SESSAO_ADMINISTRATIVA_BASEADA_EM_COOKIE_SEGURO.md`

---

## 31. DEC-007 — O conteúdo primeiro governa a UI pública

### Estado

Aceita implicitamente

### Contexto

A camada pública deve comunicar autoridade, densidade, clareza e continuidade, não apenas efeito visual.

### Consequência

A estética não poderá derrotar a semântica.

### Futuro ADR sugerido

`ADR-007_PRIMAZIA_DO_CONTEUDO_E_DA_HIERARQUIA_INFORMACIONAL.md`

---

## 32. DEC-008 — O fluxo de contato é núcleo relacional do projeto

### Estado

Aceita implicitamente

### Contexto

O contato não é acessório; ele materializa a ponte entre presença digital e aproximação legítima.

### Consequência

Qualquer falha nesse fluxo é estruturalmente séria.

### Futuro ADR sugerido

`ADR-008_FLUXO_DE_CONTATO_COMO_CAPACIDADE_RELACIONAL_CRITICA.md`

---

## 33. DEC-009 — A governança editorial será baseada em estados explícitos

### Estado

Aceita implicitamente

### Contexto

A existência de `draft`, `review`, `published`, `archived` já estrutura o conteúdo e a superfície pública.

### Consequência

Publicação não pode ser modelada como estado implícito.

### Futuro ADR sugerido

`ADR-009_MODELO_DE_STATUS_EDITORIAL_EXPLICITO.md`

---

## 34. DEC-010 — A taxonomia deve ser governada e não caótica

### Estado

Aceita implicitamente

### Contexto

Categorias e tags precisam ser utilitárias, semânticas e controladas.

### Consequência

O painel admin deverá conter mecanismos de governança taxonômica.

### Futuro ADR sugerido

`ADR-010_GOVERNANCA_TAXONOMICA_DE_CATEGORIAS_E_TAGS.md`

---

## 35. DEC-011 — A qualidade será decidida por evidência e gates

### Estado

Aceita implicitamente

### Contexto

O projeto já fixou plano de testes, critérios de aceite e gates por fase.

### Consequência

Nada importante poderá avançar apenas por impressão.

### Futuro ADR sugerido

`ADR-011_QUALIDADE_ORIENTADA_A_EVIDENCIA_E_GATES.md`

---

## 36. DEC-012 — Implantação deve ser controlada, reversível e seguida de suporte inicial

### Estado

Aceita implicitamente

### Contexto

A entrada em operação foi definida como ato controlado, com smoke e rollback.

### Consequência

Produção não pode funcionar como laboratório informal.

### Futuro ADR sugerido

`ADR-012_IMPLANTACAO_CONTROLADA_COM_ROLLBACK_E_SUPORTE_INICIAL.md`

---

## 37. DEC-013 — A rastreabilidade é parte constitutiva do projeto

### Estado

Aceita implicitamente

### Contexto

O corpus exige ligação entre origem, implementação, validação, aceite e implantação.

### Consequência

Mudança sem análise de impacto será tratada como risco estrutural.

### Futuro ADR sugerido

`ADR-013_RASTREABILIDADE_COMO_EIXO_DE_GOVERNANCA_DA_OBRA.md`

---

## 38. DEC-014 — A futura tradução em código deverá ser controlada e derivada do corpus

### Estado

Aceita implicitamente

### Contexto

O projeto foi explicitamente conduzido para reduzir retrabalho e permitir geração modular futura.

### Consequência

O código não poderá nascer como reação caótica ao momento.

### Futuro ADR sugerido

`ADR-014_TRADUCAO_CONTROLADA_DO_CORPUS_PARA_IMPLEMENTACAO.md`

---

## 39. Matriz de Impacto de uma Decisão Arquitetural

Toda decisão arquitetural relevante deve ser lida segundo a seguinte pergunta:

> “se eu mudar isso, o que exatamente se move?”

No projeto, os alvos mínimos de impacto a verificar serão:

* requisitos;
* regras de negócio;
* fluxos;
* módulos;
* entidades;
* APIs;
* telas;
* testes;
* critérios de aceite;
* riscos;
* implantação;
* documentos correlatos.

### Regra

ADR sem análise de impacto é ADR incompleto.

---

## 40. Critérios para Aceitar um ADR

Um ADR só deverá ser considerado aceito quando:

1. o problema estiver claramente descrito;
2. as opções consideradas forem reais e inteligíveis;
3. a decisão escolhida estiver formulada sem ambiguidade;
4. as consequências estiverem explicitadas;
5. os impactos em outros artefatos estiverem reconhecidos;
6. não houver contradição com o corpus soberano;
7. a decisão puder orientar ação futura sem depender de suposições ocultas.

---

## 41. Critérios para Rejeitar um ADR

Um ADR deverá ser rejeitado quando:

* o problema não estiver claro;
* a decisão for vaga ou ornamental;
* as opções forem artificiais;
* contradizer o corpus soberano sem revisão formal correspondente;
* não explicitar consequências;
* não servir de fato para orientar o projeto;
* existir apenas para parecer formal, sem utilidade real.

---

## 42. Critérios para Marcar um ADR como Substituído

Um ADR só deverá ser marcado como substituído quando:

1. existir novo ADR aceito cobrindo o mesmo território decisório;
2. a mudança de contexto estiver claramente explicada;
3. o vínculo entre decisão antiga e nova estiver explicitado;
4. os impactos da mudança tiverem sido reconhecidos;
5. os artefatos afetados entrarem em atualização correspondente.

---

## 43. Relação entre ADR e Implementação Futura

O sistema de ADRs existe precisamente para preparar o projeto para a fase em que código real, componentes, rotas, autenticação, persistência e deploy começarem a se multiplicar.

Quando isso acontecer, o ADR será a camada que permitirá responder:

* por que a arquitetura foi desenhada assim;
* por que a API está organizada assim;
* por que a autenticação foi escolhida assim;
* por que as superfícies foram separadas assim;
* por que o fluxo editorial funciona assim;
* por que certas decisões não podem ser desfeitas casualmente.

---

## 44. Política de Abertura Inicial de ADRs Após o Fechamento do Obrigatório

Assim que o bloco `01-Obrigatorios` estiver plenamente fechado, a sequência recomendada de abertura inicial de ADRs é:

1. ADR sobre repositório documental soberano;
2. ADR sobre precedência do bloco obrigatório;
3. ADR sobre reaproveitamento curado do legado;
4. ADR sobre separação entre superfície pública e administrativa;
5. ADR sobre versionamento e namespaces da API;
6. ADR sobre sessão administrativa e segurança base;
7. ADR sobre primazia do conteúdo na UI;
8. ADR sobre fluxo de contato como capacidade crítica;
9. ADR sobre estados editoriais explícitos;
10. ADR sobre implantação controlada.

Essa ordem é inteligente porque acompanha o tronco soberano já consolidado.

---

## 45. Regras de Atualização deste Documento

Este documento deverá ser revisto quando ocorrer qualquer um dos eventos abaixo:

* aumento relevante da complexidade arquitetural;
* abertura formal da camada `02-Relational-Life`;
* início da tradução controlada para implementação;
* mudança na política de governança documental;
* amadurecimento do catálogo de ADRs;
* necessidade de revisão da taxonomia de decisões.

### Regra soberana

Este documento não deve ser alterado por capricho.
Ele deve ser revisto por mudança real de governança arquitetural.

---

## 46. Materiais Herdados Úteis para Consulta

Como reforço contextual e comparativo, podem ser consultados, quando úteis:

* `personal-site (1)/personal-site/Waterfall/`
* `personal-site (1)/personal-site/APIs/`
* `personal-site (1)/personal-site/UI_UX/`
* `personal-site (1)/personal-site/Execucao/`
* `personal-site (1)/personal-site/Implementacao/`
* `personal-site (1)/personal-site/Scaffold/`
* `personal-site (1)/personal-site/Monorepo/`

### Regra de precedência

Esses materiais podem ajudar a reconhecer decisões já tomadas implicitamente no legado, mas não possuem autoridade para redefinir o sistema soberano de ADRs do ciclo atual.

---

## 47. Anti-padrões de Governança Decisória Expressamente Rejeitados

Ficam rejeitados, desde já:

* “todo mundo sabe por que isso foi feito” sem registro;
* mudar estrutura por impulso;
* tratar o código como única memória da arquitetura;
* reabrir fundamento sem contexto;
* adotar solução estrutural sem listar consequências;
* apagar o histórico decisório;
* confundir preferência pessoal com decisão soberana;
* burocratizar irrelevâncias enquanto decisões reais seguem implícitas;
* aceitar contradições entre ADR e corpus sem reconciliação formal;
* usar ADR como decoração intelectual.

---

## 48. Critérios de Aceite Deste Documento

Este documento será considerado corretamente consolidado quando:

1. definir o que é decisão arquitetural no projeto;
2. estabelecer quando um ADR é obrigatório;
3. fixar a estrutura mínima de um ADR;
4. definir estados, ciclo de vida e regras de supersessão;
5. conectar ADR com rastreabilidade, cronograma, testes, aceite, riscos e implantação;
6. mapear as decisões implícitas já consolidadas no projeto;
7. preparar abertura disciplinada do catálogo futuro de ADRs;
8. transformar memória arquitetural em governança explícita.

---

## 49. Declaração Final

Com este documento, o projeto **William Albarello** passa a possuir uma **política soberana de registro de decisões arquiteturais**, encerrando uma das fragilidades mais comuns de obras complexas: depender da lembrança difusa do porquê de suas próprias escolhas.

A partir daqui:

* a decisão deixa de ser implícita;
* a arquitetura deixa de depender de memória oral;
* a revisão deixa de ser amnésia;
* a mudança deixa de ser salto sem contexto.

A obra passa a possuir memória decisória formal.

E isso é decisivo, porque um projeto ambicioso sem registro de suas decisões mais importantes tende, cedo ou tarde, a lutar contra si mesmo.

---

## 50. Status do Documento

**Documento consolidado como base soberana de registro de decisões arquiteturais do projeto William Albarello, apto a governar ADRs futuros, preservar memória estrutural, orientar evolução disciplinada e proteger a coerência arquitetural da obra.**


