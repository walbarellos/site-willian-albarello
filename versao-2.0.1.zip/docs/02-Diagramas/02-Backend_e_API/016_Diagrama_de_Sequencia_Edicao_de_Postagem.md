
# 016_Diagrama_de_Sequencia_Edicao_de_Postagem

## 1. Identificação do documento

- **Projeto:** William Albarello
- **Diretório:** `02-Diagramas`
- **Caminho oficial:** `/home/user/Documents/Softwares/Willian Albarello/William Albarello/02-Diagramas/02-Backend_e_API/016_Diagrama_de_Sequencia_Edicao_de_Postagem.md`
- **Natureza do documento:** Diagrama de sequência da edição de postagem existente
- **Função sistêmica:** Descrever, em ordem temporal, a sequência técnica e funcional da edição de uma postagem já cadastrada, desde a abertura no painel até validação, atualização persistida, eventual versionamento e retorno de sucesso ou erro
- **Posição no bloco:** Oitavo documento do bloco `02-Backend_e_API`
- **Dependência imediata:** `015_Diagrama_de_Sequencia_Publicacao_de_Conteudo.md`

---

## 2. Objetivo

Este documento existe para formalizar a **sequência de edição de uma postagem já existente** no projeto William Albarello.

Se o documento `015_Diagrama_de_Sequencia_Publicacao_de_Conteudo.md` mostrou a sequência de publicação de conteúdo do painel até o site, este documento aprofunda um cenário distinto e igualmente essencial:

**a manutenção de uma postagem que já existe no sistema.**

Seu objetivo é mostrar, em ordem lógica e técnica:

- como o administrador localiza uma postagem existente;
- como o painel solicita seu carregamento;
- como a API devolve os dados atuais da postagem;
- como o administrador altera o conteúdo;
- como o frontend valida minimamente a edição;
- como a API valida contrato, autenticação e autorização;
- como a camada de conteúdo/CMS atualiza a postagem;
- como ocorre versionamento, se aplicável à arquitetura;
- como o sistema devolve sucesso ou falha;
- como a atualização se reflete no painel e, quando apropriado, na camada pública.

Este documento não substitui o modelo de estados da postagem nem o fluxo editorial completo. Seu foco é a **sequência técnica da edição de um registro já existente**.

---

## 3. Fontes de referência no Waterfall

Este documento deriva principalmente dos seguintes arquivos do Diretório `01-Waterfall`:

- `013_Modelo_de_Dados_e_CMS.md`
- `016_API_Contract_Mestre.md`
- `017_UI_UX_Arquitetura_da_Informacao.md`

Fontes complementares relevantes:

- `006_Requisitos_Funcionais.md`
- `008_Arquitetura_da_Informacao.md`
- `009_Jornada_do_Usuario_e_Fluxos_Principais.md`
- `010_Wireframes_e_Estrutura_de_Paginas.md`
- `012_Estrategia_de_Conteudo_e_SEO.md`
- `014_Arquitetura_Tecnica.md`
- `015_Seguranca_Autenticacao_e_Autorizacao.md`
- `018_Plano_de_Testes_Homologacao_e_Qualidade.md`
- `021_Criterios_de_Aceite_Gerais.md`
- `023_Matriz_de_Rastreabilidade.md`
- `024_Registro_de_Decisoes_Arquiteturais.md`

Quando disponíveis, também devem ser confrontados:

- frontend real do painel;
- backend real;
- modelos reais de postagem/conteúdo;
- rotas reais de listagem, leitura e atualização;
- estratégia real de versionamento, se existir;
- prints da UI administrativa e do editor.

---

## 4. Premissas e limites

## 4.1 Premissas adotadas

Para fins deste documento, adotam-se as seguintes premissas conservadoras e coerentes com o projeto:

- existe um painel interno com listagem e edição de conteúdos/postagens;
- a postagem já existe previamente na persistência;
- o administrador autenticado e autorizado pode abrir a postagem para edição;
- o sistema consegue carregar os dados atuais da postagem para o formulário/editor;
- a edição dispara uma operação de atualização, e não de criação;
- a arquitetura pode ou não suportar versionamento explícito, mas o documento deve contemplar essa possibilidade como capacidade arquitetural relevante;
- a atualização pode impactar a camada pública, principalmente se a postagem já estiver publicada;
- o retorno ao frontend precisa distinguir sucesso, falha de validação, falha de autorização e falha de persistência.

## 4.2 Limites deste documento

Este arquivo não fixa sem prova de código:

- nome exato do endpoint de edição/atualização;
- uso obrigatório de autosave;
- mecanismo exato de versionamento;
- política exata de publicação imediata vs. revisão;
- revalidação exata de cache ou rebuild da camada pública;
- estrutura detalhada de auditoria por campo.

Seu papel é mostrar a **sequência arquitetural correta da edição**, não congelar detalhes ainda não comprovados.

## 4.3 Regra de prudência

Sempre que o mecanismo exato não estiver comprovado, este documento usa formulações como:

- **atualização persistida**
- **versionamento, se aplicável**
- **camada pública refletida conforme estado editorial**
- **retorno padronizado de sucesso ou erro**

---

## 5. Participantes da sequência

A sequência de edição de postagem é compreendida a partir dos seguintes participantes técnicos e funcionais:

- **Administrador / Autor**: ator humano que localiza e edita a postagem
- **Painel Administrativo / Frontend**: interface de listagem, abertura e edição
- **API Administrativa**: porta de entrada das operações de leitura e atualização da postagem
- **Validação de Contrato / Regras de Entrada**: camada que valida payload, identificação do recurso e consistência mínima
- **Autorização / Acesso Administrativo**: camada que confirma se o usuário pode editar o recurso
- **Serviço de Conteúdo / CMS**: camada que coordena a lógica de edição
- **Repositório / Persistência de Conteúdo**: camada que carrega e atualiza os dados estruturados
- **Camada de Versionamento**: capacidade lógica opcional/relevante para preservar histórico, se aplicável
- **Camada Pública do Site**: superfície que pode refletir a atualização, conforme o estado editorial da postagem

---

## 6. Visão geral da sequência

Em nível macro, a edição de uma postagem segue esta lógica:

1. o administrador abre a listagem de conteúdos;
2. escolhe uma postagem existente;
3. o frontend solicita os dados atuais à API;
4. a API valida acesso e carrega o conteúdo da persistência;
5. o editor é preenchido com os dados existentes;
6. o administrador altera o conteúdo;
7. o frontend valida minimamente os campos alterados;
8. o administrador aciona salvar/atualizar;
9. a API valida contrato, autenticação e autorização;
10. a camada de conteúdo atualiza a postagem;
11. o sistema registra versão anterior ou nova versão, se aplicável;
12. a persistência confirma a atualização;
13. a API devolve resposta padronizada;
14. o painel reflete o sucesso ou erro;
15. se a postagem já estiver publicada e a política assim permitir, a camada pública passa a refletir a atualização.

---

## 7. Diagrama principal — Sequência de Edição de Postagem

```mermaid
sequenceDiagram
    actor Admin as Administrador / Autor
    participant UI as Painel Administrativo / Frontend
    participant API as API Administrativa
    participant VAL as Validação de Contrato / Entrada
    participant AUTHZ as Autorização / Acesso Administrativo
    participant CMS as Serviço de Conteúdo / CMS
    participant REPO as Repositório / Persistência de Conteúdo
    participant VER as Camada de Versionamento
    participant SITE as Camada Pública do Site

    Admin->>UI: acessa listagem de conteúdos
    UI-->>Admin: exibe lista de postagens

    Admin->>UI: seleciona postagem existente para editar
    UI->>API: solicita carregamento da postagem
    API->>AUTHZ: valida contexto autenticado e permissão de leitura/edição

    alt Sem autenticação ou sem permissão
        AUTHZ-->>API: acesso negado
        API-->>UI: erro de autenticação/autorização
        UI-->>Admin: informa bloqueio de acesso
    else Acesso permitido
        API->>REPO: buscar postagem por identificador
        alt Postagem não encontrada
            REPO-->>API: recurso inexistente
            API-->>UI: erro de não encontrado
            UI-->>Admin: informa indisponibilidade da postagem
        else Postagem encontrada
            REPO-->>API: dados atuais da postagem
            API-->>UI: entrega conteúdo atual
            UI-->>Admin: exibe editor preenchido

            Admin->>UI: altera título, corpo, campos editoriais e/ou metadata
            UI->>UI: valida campos mínimos e consistência local

            alt Dados locais inválidos
                UI-->>Admin: exibe erro de preenchimento
            else Dados locais válidos
                Admin->>UI: aciona salvar / atualizar
                UI->>API: envia requisição de atualização

                API->>VAL: valida schema / contrato / consistência mínima
                alt Payload inválido
                    VAL-->>API: falha de validação
                    API-->>UI: erro de validação
                    UI-->>Admin: exibe mensagem e mantém edição
                else Payload válido
                    API->>AUTHZ: valida permissão de edição
                    alt Acesso negado para editar
                        AUTHZ-->>API: edição não autorizada
                        API-->>UI: erro de autorização
                        UI-->>Admin: informa bloqueio de edição
                    else Edição autorizada
                        API->>CMS: solicita atualização editorial
                        CMS->>REPO: carregar versão atual persistida
                        REPO-->>CMS: estado atual da postagem

                        opt Versionamento aplicável
                            CMS->>VER: registrar versão anterior / snapshot
                            VER-->>CMS: versionamento concluído
                        end

                        CMS->>REPO: persistir atualização da postagem
                        alt Falha de persistência
                            REPO-->>CMS: erro na atualização
                            CMS-->>API: falha de atualização
                            API-->>UI: erro interno / persistência
                            UI-->>Admin: informa falha ao salvar
                        else Atualização persistida
                            REPO-->>CMS: postagem atualizada
                            CMS-->>API: edição concluída com sucesso
                            API-->>UI: sucesso de atualização + dados retornados
                            UI-->>Admin: confirma sucesso e atualiza estado local

                            opt Postagem já publicada e política permite refletir atualização
                                UI->>SITE: atualização refletida na camada pública
                                SITE-->>Admin: conteúdo público atualizado / disponível
                            end
                        end
                    end
                end
            end
        end
    end
````

---

## 8. Leitura do diagrama

## 8.1 Abertura da postagem para edição

A sequência começa com o administrador:

* acessando a listagem de conteúdos;
* escolhendo uma postagem já existente;
* solicitando sua abertura para edição.

O painel não trabalha “às cegas”; ele precisa carregar o estado atual da postagem.

## 8.2 Validação de acesso ao recurso

Antes mesmo de devolver os dados da postagem ao editor, a API precisa verificar:

* se o contexto autenticado é válido;
* se o papel do usuário permite acessar aquele recurso administrativo;
* se a leitura/edição do conteúdo é permitida.

Sem isso, a interface não deve sequer abrir o recurso administrativo sensível.

## 8.3 Carregamento do estado atual

Se o acesso for permitido, a API busca a postagem na persistência.

Há duas saídas importantes aqui:

* postagem inexistente;
* postagem encontrada.

Se encontrada, seus dados são enviados ao frontend e o editor é preenchido.

## 8.4 Edição pelo administrador

O administrador altera:

* título;
* corpo;
* campos editoriais;
* eventualmente slug, metadata ou outros campos do CMS.

O frontend faz validações mínimas locais antes do envio.

## 8.5 Submissão da atualização

Ao acionar salvar/atualizar, o frontend envia a requisição administrativa à API.

Esse é o ponto em que a edição do usuário vira tentativa formal de atualização persistida.

## 8.6 Validação do payload e nova validação de autorização

A API valida:

* o contrato de atualização;
* a consistência mínima do payload;
* a permissão efetiva do usuário para editar aquele recurso.

Isso é importante porque a autorização para “entrar no painel” não equivale automaticamente à autorização para “editar qualquer recurso”.

## 8.7 Atualização editorial e versionamento

Com a edição autorizada, a camada de conteúdo:

* carrega o estado atual persistido;
* compara ou prepara a atualização;
* registra histórico/versionamento, se a arquitetura assim suportar;
* persiste os novos dados.

O versionamento aparece como bloco opcional porque é arquiteturalmente relevante, mas pode depender do desenho real do sistema.

## 8.8 Persistência e retorno

Se a persistência falhar, a operação termina em erro.

Se a persistência for bem-sucedida:

* a API devolve confirmação;
* o frontend atualiza o estado do editor/listagem;
* o administrador recebe feedback positivo.

## 8.9 Reflexo na camada pública

Se a postagem já estiver publicada e a política editorial permitir atualização direta:

* a camada pública passa a refletir a nova versão;
* a postagem atualizada fica disponível ao leitor.

Se o fluxo do projeto exigir revisão ou outro estado intermediário, esse comportamento deve ser refinado no diagrama de estados, não aqui.

---

## 9. Descrição detalhada das etapas

## 9.1 Acessar listagem de conteúdos

### Finalidade

Permitir localizar a postagem que será editada.

### Responsabilidade principal

Administrador + painel.

### Resultado esperado

Lista de conteúdos disponíveis para abertura.

---

## 9.2 Selecionar postagem existente

### Finalidade

Indicar ao sistema qual recurso será carregado para edição.

### Responsabilidade principal

Administrador + frontend.

### Resultado esperado

Identificador da postagem enviado para a API de leitura/edição.

---

## 9.3 Validar acesso ao recurso

### Finalidade

Impedir que recursos administrativos sejam abertos sem contexto válido.

### Responsabilidade principal

API + camada de autorização.

### Resultado esperado

Acesso permitido ou negado.

---

## 9.4 Carregar dados atuais da postagem

### Finalidade

Popular o editor com o estado atual persistido.

### Responsabilidade principal

API + repositório de conteúdo.

### Resultado esperado

Dados atuais disponíveis na UI ou erro de recurso inexistente.

---

## 9.5 Exibir editor preenchido

### Finalidade

Permitir que o administrador trabalhe sobre a versão atual da postagem.

### Responsabilidade principal

Frontend.

### Resultado esperado

Campos preenchidos com os dados existentes.

---

## 9.6 Editar campos do conteúdo

### Finalidade

Permitir modificação da postagem já existente.

### Responsabilidade principal

Administrador + frontend.

### Resultado esperado

Novo estado desejado da postagem preparado para envio.

---

## 9.7 Validar minimamente no frontend

### Finalidade

Evitar submissão de edição evidentemente inválida.

### Responsabilidade principal

Frontend.

### Resultado esperado

Bloqueio local de erros triviais.

### Limite

Não substitui a validação da API.

---

## 9.8 Enviar atualização à API

### Finalidade

Formalizar a operação de edição.

### Responsabilidade principal

Frontend.

### Resultado esperado

Payload de atualização entregue à API administrativa.

---

## 9.9 Validar contrato de atualização

### Finalidade

Garantir que o payload de edição respeita o contrato esperado.

### Responsabilidade principal

API + validação de entrada.

### Resultado esperado

Atualização aceita para processamento ou rejeitada por inconsistência.

---

## 9.10 Confirmar permissão de edição

### Finalidade

Garantir que o ator autenticado pode alterar aquele recurso.

### Responsabilidade principal

API + autorização.

### Resultado esperado

Permissão concedida ou negada.

---

## 9.11 Carregar estado persistido atual

### Finalidade

Permitir atualização segura e, se aplicável, comparação/versionamento.

### Responsabilidade principal

Serviço de conteúdo / CMS.

### Resultado esperado

Estado atual conhecido antes da gravação da nova versão.

---

## 9.12 Registrar versionamento, se aplicável

### Finalidade

Preservar histórico ou snapshot anterior da postagem.

### Responsabilidade principal

Camada de versionamento.

### Resultado esperado

Versão anterior registrada antes da atualização definitiva.

### Observação

A existência real desse mecanismo deve ser confirmada pelo backend. Aqui ele aparece como capacidade arquitetural opcional relevante.

---

## 9.13 Persistir atualização

### Finalidade

Gravar a nova versão da postagem.

### Responsabilidade principal

Repositório / persistência.

### Resultado esperado

Postagem atualizada ou falha devidamente sinalizada.

---

## 9.14 Retornar sucesso ou erro ao frontend

### Finalidade

Encerrar a operação administrativa de forma clara.

### Responsabilidade principal

API.

### Resultado esperado

Resposta padronizada de sucesso ou falha.

---

## 9.15 Refletir atualização no painel e, se aplicável, no site público

### Finalidade

Tornar o resultado visível ao administrador e, quando couber, ao público.

### Responsabilidade principal

Frontend administrativo + camada pública.

### Resultado esperado

Editor/listagem atualizados e, em caso de postagem publicada, conteúdo público refletido.

---

## 10. Fluxo de sucesso

O caminho ideal de sucesso é:

1. administrador acessa a listagem;
2. abre postagem existente;
3. API autoriza e carrega os dados;
4. editor é preenchido;
5. administrador altera o conteúdo;
6. frontend valida minimamente;
7. API valida contrato e permissão;
8. CMS atualiza o conteúdo;
9. versionamento é registrado, se aplicável;
10. persistência confirma a atualização;
11. painel recebe sucesso;
12. conteúdo atualizado é refletido onde couber.

Esse é o fluxo central da manutenção editorial contínua.

---

## 11. Fluxos de falha

## 11.1 Falha de acesso inicial ao recurso

Ocorre quando:

* o usuário não está autenticado;
* a sessão/token não é válido;
* o papel não pode abrir o recurso;
* a postagem está fora da fronteira de acesso do usuário.

### Efeito

O editor não deve ser aberto.

---

## 11.2 Falha por recurso inexistente

Ocorre quando:

* a postagem não é encontrada;
* o identificador é inválido;
* o recurso foi removido ou não está disponível.

### Efeito

A UI informa indisponibilidade da postagem.

---

## 11.3 Falha de validação local

Ocorre quando:

* campos obrigatórios mínimos não foram respeitados;
* há inconsistência evidente antes do envio.

### Efeito

O frontend impede a submissão.

---

## 11.4 Falha de contrato na API

Ocorre quando:

* o payload de atualização está malformado;
* os dados não respeitam o schema;
* há inconsistência estrutural.

### Efeito

A API devolve erro de validação; a edição não é persistida.

---

## 11.5 Falha de autorização para editar

Ocorre quando:

* o usuário está autenticado;
* mas não pode editar aquele recurso.

### Efeito

A operação é interrompida antes da atualização.

---

## 11.6 Falha de persistência

Ocorre quando:

* a gravação da atualização falha;
* há inconsistência interna;
* a persistência não confirma a alteração.

### Efeito

O sistema não deve sinalizar sucesso falso ao administrador.

---

## 11.7 Falha em versionamento, se aplicável

Ocorre quando:

* a política exige versionamento;
* mas o snapshot/histórico não pode ser preservado corretamente.

### Efeito

Dependendo da política do sistema, a operação pode:

* falhar por completo; ou
* prosseguir com logging/alerta, se a arquitetura assim definir.

Neste documento, a abordagem conservadora é: versionamento importante deve ser tratado com seriedade e não silenciosamente ignorado.

---

## 12. Fronteiras de responsabilidade

## 12.1 Responsabilidade do painel / frontend administrativo

O painel é responsável por:

* exibir a listagem;
* abrir o editor;
* carregar os dados recebidos;
* permitir alteração dos campos;
* validar minimamente antes do envio;
* mostrar retorno de sucesso ou erro.

## 12.2 Responsabilidade da API

A API é responsável por:

* validar acesso ao recurso;
* validar contrato da atualização;
* aplicar autorização;
* encaminhar a operação ao domínio correto;
* devolver resposta padronizada.

## 12.3 Responsabilidade do domínio de conteúdo / CMS

A camada de conteúdo é responsável por:

* tratar a postagem como entidade administrável;
* orquestrar a atualização;
* garantir coerência editorial;
* interagir com versionamento e persistência.

## 12.4 Responsabilidade do versionamento

A camada de versionamento, quando existir, é responsável por:

* preservar histórico;
* permitir rastreabilidade;
* reduzir perda de estado anterior;
* apoiar governança editorial.

## 12.5 Responsabilidade da camada pública

A camada pública é responsável apenas por refletir a versão vigente/publicada da postagem conforme o estado editorial aplicável.

---

## 13. Relação com o modelo de dados / CMS

A sequência de edição depende fortemente de um modelo de dados que suporte:

* identificação única da postagem;
* carregamento do estado atual;
* atualização de campos editoriais;
* estado editorial;
* eventual histórico/versionamento;
* metadata associada;
* consistência entre versão interna e versão pública.

Sem esse suporte, o painel não consegue manter o conteúdo com segurança.

---

## 14. Relação com UI/UX do editor

Este documento influencia diretamente a UI/UX do painel porque o editor precisa suportar:

* carregamento de conteúdo existente;
* feedback de loading;
* feedback de erro de recurso não encontrado;
* feedback de erro de validação;
* feedback de falta de permissão;
* confirmação de sucesso;
* eventual indicação de status/versionamento.

Isso significa que o editor não é apenas um formulário, mas uma interface de manutenção contínua de um recurso vivo.

---

## 15. Relação com os diagramas anteriores

## 15.1 Relação com `015_Diagrama_de_Sequencia_Publicacao_de_Conteudo.md`

O `015` mostrou a criação/publicação do conteúdo.

O `016` mostra a manutenção de conteúdo já existente, com foco em carregamento, alteração e atualização persistida.

## 15.2 Relação com `013_Diagrama_de_Casos_de_Uso_do_Painel_Interno.md`

O `013` mostrou “Editar Conteúdo” como caso de uso central do painel.

O `016` traduz esse caso de uso em sequência técnica real.

## 15.3 Relação com `012_Diagrama_de_Autorizacao_e_Papeis.md`

O `012` mostrou que editar é operação protegida.

O `016` deixa explícito em que ponto da sequência a autorização participa.

## 15.4 Relação com `010_Diagrama_de_Componentes_da_API.md`

O `010` mostrou validação, autorização, services, repositórios e persistência.

O `016` coloca essa anatomia em ação no cenário de atualização de postagem.

---

## 16. Relação com os documentos seguintes

Este documento prepara diretamente a leitura e geração de:

* `017_Diagrama_de_Sequencia_Consulta_Publica_do_Site.md`
* `018_Diagrama_de_Fluxo_das_Requisicoes_API.md`
* `022_Diagrama_de_Estados_da_Postagem.md`
* `023_Diagrama_de_Versionamento_de_Conteudo.md`
* `029_Diagrama_de_Jornada_do_Administrador.md`
* `031_Diagrama_de_Fluxo_do_Painel_Interno.md`
* `042_Diagrama_de_Fluxo_Editorial.md`

### Motivo

A edição de postagem faz ponte entre:

* painel;
* CMS;
* publicação;
* estados editoriais;
* histórico/versionamento;
* reflexo público do conteúdo.

---

## 17. Observações de consistência

## 17.1 Coerência com CMS/modelo de dados

O fluxo respeita a ideia de que a postagem já existe e precisa ser carregada antes de ser alterada.

## 17.2 Coerência com segurança

A edição é tratada como operação protegida, dependente de autorização válida.

## 17.3 Coerência com UI/UX

O processo contempla feedback ao administrador em várias fases críticas.

## 17.4 Coerência com versionamento

O versionamento aparece com prudência: como capacidade relevante, mas dependente do desenho real do sistema.

## 17.5 Coerência com a camada pública

O documento evita supor que toda edição altera imediatamente o público em todos os casos; isso depende do estado editorial e da política de publicação.

---

## 18. Critérios de aceite deste documento

Este documento será considerado adequado se:

* representar a sequência de edição de uma postagem já existente;
* incluir carregamento inicial da postagem;
* incluir validação, autorização, atualização persistida e retorno ao painel;
* contemplar versionamento como capacidade aplicável, sem inventar implementação não comprovada;
* mostrar falhas relevantes;
* distinguir claramente responsabilidades entre painel, API, CMS, versionamento e camada pública;
* permanecer coerente com o modelo de dados/CMS, API e UI/UX.

---

## 19. Conclusão executiva

A edição de uma postagem no projeto William Albarello deve ser entendida como um processo técnico mais amplo do que apenas “abrir e salvar um texto”.

Esse processo envolve:

* localizar e carregar um recurso existente;
* validar acesso ao recurso;
* permitir alterações controladas;
* validar contrato e autorização;
* atualizar a persistência;
* preservar histórico, se aplicável;
* devolver confirmação ou erro;
* refletir o resultado no painel e, quando apropriado, na camada pública.

Esse desenho é essencial porque a maturidade de um sistema editorial não depende apenas da capacidade de publicar, mas da capacidade de **manter, evoluir e governar o conteúdo já publicado ou em gestão**.

---

