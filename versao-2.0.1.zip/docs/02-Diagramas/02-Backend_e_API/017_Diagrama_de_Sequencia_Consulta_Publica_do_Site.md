
# 017_Diagrama_de_Sequencia_Consulta_Publica_do_Site

## 1. Identificação do documento

- **Projeto:** William Albarello
- **Diretório:** `02-Diagramas`
- **Caminho oficial:** `/home/user/Documents/Softwares/Willian Albarello/William Albarello/02-Diagramas/02-Backend_e_API/017_Diagrama_de_Sequencia_Consulta_Publica_do_Site.md`
- **Natureza do documento:** Diagrama de sequência da consulta pública do site
- **Função sistêmica:** Descrever, em ordem temporal, como o visitante acessa conteúdo público do site, desde a navegação inicial até a obtenção dos dados, renderização da página e entrega da resposta
- **Posição no bloco:** Nono documento do bloco `02-Backend_e_API`
- **Dependência imediata:** `015_Diagrama_de_Sequencia_Publicacao_de_Conteudo.md` e `016_Diagrama_de_Sequencia_Edicao_de_Postagem.md`

---

## 2. Objetivo

Este documento existe para formalizar a **sequência de consulta pública do site** do projeto William Albarello.

Se os documentos anteriores deste bloco detalharam fluxos administrativos, autenticação, publicação e edição, este arquivo faz o movimento complementar: ele mostra o que acontece quando um **visitante** acessa a face pública da solução para consultar páginas e conteúdo já disponibilizados.

Seu objetivo é tornar claro:

- como o visitante inicia a navegação pública;
- como a camada pública resolve a rota solicitada;
- como o frontend/página consulta a API pública ou a camada de dados compatível com a arquitetura;
- como o backend localiza o conteúdo correto;
- como o sistema garante que apenas conteúdo público/publicado seja entregue;
- como a página é renderizada;
- como a resposta final chega ao visitante;
- como falhas como recurso inexistente ou indisponível devem ser tratadas.

Este documento não fixa a implementação exata de SSR, SSG, ISR, CSR ou mecanismo equivalente. Seu papel é mostrar a **sequência arquitetural correta da consulta pública**.

---

## 3. Fontes de referência no Waterfall

Este documento deriva principalmente dos seguintes arquivos do Diretório `01-Waterfall`:

- `008_Arquitetura_da_Informacao.md`
- `009_Jornada_do_Usuario_e_Fluxos_Principais.md`
- `010_Wireframes_e_Estrutura_de_Paginas.md`
- `012_Estrategia_de_Conteudo_e_SEO.md`
- `014_Arquitetura_Tecnica.md`
- `017_UI_UX_Arquitetura_da_Informacao.md`

Fontes complementares relevantes:

- `001_Visao_Geral_do_Projeto.md`
- `005_Escopo_MVP_e_Fora_de_Escopo.md`
- `006_Requisitos_Funcionais.md`
- `007_Requisitos_Nao_Funcionais.md`
- `013_Modelo_de_Dados_e_CMS.md`
- `015_Seguranca_Autenticacao_e_Autorizacao.md`
- `016_API_Contract_Mestre.md`
- `018_Plano_de_Testes_Homologacao_e_Qualidade.md`
- `021_Criterios_de_Aceite_Gerais.md`
- `023_Matriz_de_Rastreabilidade.md`
- `024_Registro_de_Decisoes_Arquiteturais.md`

Quando disponíveis, também devem ser confrontados:

- frontend real;
- backend real;
- rotas públicas reais;
- componentes reais de listagem e detalhe;
- payloads públicos reais;
- prints da UI pública.

---

## 4. Premissas e limites

## 4.1 Premissas adotadas

Para fins deste documento, adotam-se as seguintes premissas conservadoras e coerentes com o projeto:

- o site possui uma camada pública acessível sem autenticação;
- existem páginas institucionais e/ou conteúdos editoriais publicados;
- a consulta pública depende de rota pública válida;
- a camada pública obtém conteúdo por meio de API pública, camada de leitura pública ou mecanismo equivalente compatível com a arquitetura;
- o backend distingue conteúdo público/publicado de conteúdo interno/rascunho;
- a resposta pública já considera, quando aplicável, slug, metadata e estrutura de exposição definidas pela camada editorial/SEO;
- a renderização final acontece na camada pública do site, segundo a estratégia técnica adotada pelo projeto.

## 4.2 Limites deste documento

Este arquivo não fixa sem prova de código:

- se a renderização é SSR, SSG, ISR ou CSR;
- mecanismo exato de cache;
- endpoint exato usado por cada página;
- política detalhada de revalidação;
- presença obrigatória de CDN, edge ou camada avançada de cache;
- estratégia exata de composição de metadata em runtime.

Seu foco é a **sequência da consulta pública**, não a tecnologia de renderização específica.

## 4.3 Regra de prudência

Sempre que o mecanismo exato não estiver comprovado, o texto usa formulações como:

- **camada pública do site**
- **API pública ou camada de leitura compatível**
- **renderização compatível com a arquitetura**
- **conteúdo publicado/disponível**
- **resposta pública estruturada**

---

## 5. Participantes da sequência

A consulta pública do site é compreendida a partir dos seguintes participantes técnicos e funcionais:

- **Visitante / Leitor**: ator humano que acessa a face pública do site
- **Página / Frontend Público**: camada de interface que recebe a navegação e organiza a renderização
- **Camada de Roteamento / Resolução de Página**: responsabilidade que identifica a rota pública solicitada
- **API Pública / Camada de Leitura Pública**: porta de entrada da obtenção de conteúdo público
- **Validação / Resolução de Consulta Pública**: camada que valida parâmetros, slug e elegibilidade do recurso
- **Serviço de Leitura Pública**: camada que aplica a lógica de consulta pública
- **Repositório / Persistência de Conteúdo**: camada que recupera os dados publicados
- **Camada de Publicação / SEO / Exposição**: responsabilidade que garante que o conteúdo entregue esteja apto à exposição pública
- **Resposta Renderizada**: resultado final exibido ao visitante

---

## 6. Visão geral da sequência

Em nível macro, a consulta pública segue esta lógica:

1. o visitante acessa uma rota pública;
2. a camada pública resolve a página ou recurso solicitado;
3. a página solicita dados à API pública ou camada de leitura;
4. o backend valida a consulta e verifica se o recurso é público/publicado;
5. a persistência é consultada;
6. o conteúdo é devolvido já em condição de exposição pública;
7. a página renderiza o conteúdo;
8. a resposta final é entregue ao visitante;
9. se o recurso não existir ou não estiver disponível publicamente, a resposta deve refletir isso com clareza.

---

## 7. Diagrama principal — Sequência de Consulta Pública do Site

```mermaid
sequenceDiagram
    actor Visitor as Visitante / Leitor
    participant Page as Página / Frontend Público
    participant Router as Roteamento / Resolução de Página
    participant API as API Pública / Camada de Leitura
    participant VAL as Validação / Resolução de Consulta
    participant READ as Serviço de Leitura Pública
    participant REPO as Repositório / Persistência de Conteúdo
    participant PUB as Camada de Publicação / SEO / Exposição
    participant Render as Renderização da Resposta

    Visitor->>Page: acessa URL pública
    Page->>Router: resolver rota/slug/página solicitada

    alt Rota pública inválida
        Router-->>Page: recurso não encontrado
        Page->>Render: preparar resposta 404 / não encontrado
        Render-->>Visitor: página de erro pública
    else Rota pública válida
        Router-->>Page: rota resolvida
        Page->>API: solicitar conteúdo público correspondente

        API->>VAL: validar parâmetros, slug e tipo de recurso
        alt Consulta inválida
            VAL-->>API: erro de consulta pública
            API-->>Page: erro de consulta / recurso inválido
            Page->>Render: preparar erro de navegação
            Render-->>Visitor: resposta pública de erro
        else Consulta válida
            API->>READ: solicitar leitura pública do conteúdo
            READ->>REPO: buscar recurso por slug/identificador público

            alt Recurso inexistente
                REPO-->>READ: não encontrado
                READ-->>API: recurso não encontrado
                API-->>Page: 404 / não encontrado
                Page->>Render: renderizar página 404
                Render-->>Visitor: página não encontrada
            else Recurso encontrado
                REPO-->>READ: dados persistidos do conteúdo
                READ->>PUB: validar elegibilidade pública e preparar exposição

                alt Conteúdo não publicado / indisponível
                    PUB-->>READ: recurso não elegível para exposição pública
                    READ-->>API: indisponível para público
                    API-->>Page: recurso indisponível / oculto
                    Page->>Render: renderizar resposta pública adequada
                    Render-->>Visitor: conteúdo indisponível
                else Conteúdo publicado e elegível
                    PUB-->>READ: conteúdo pronto para exposição
                    READ-->>API: payload público estruturado
                    API-->>Page: dados públicos do recurso
                    Page->>Render: renderizar página com conteúdo
                    Render-->>Visitor: página pública carregada
                end
            end
        end
    end
````

---

## 8. Leitura do diagrama

## 8.1 Início da navegação pública

A sequência começa quando o visitante acessa uma URL pública do site.

Essa URL pode representar, conforme a arquitetura real:

* uma página institucional;
* uma página de artigo/postagem;
* uma rota pública de listagem;
* uma rota pública de detalhe.

O primeiro papel da camada pública é resolver qual recurso aquela URL pretende representar.

## 8.2 Resolução de rota

A camada de roteamento/resolução verifica:

* se a rota existe;
* se o slug ou identificador é válido;
* se a página pretendida pertence ao espaço público.

Se a rota for inválida, o processo já termina em resposta pública apropriada, como 404.

## 8.3 Solicitação de dados públicos

Se a rota for válida, a página pública solicita o conteúdo correspondente à API pública ou camada de leitura equivalente.

Essa chamada representa a ponte entre:

* navegação pública;
* obtenção de conteúdo estruturado.

## 8.4 Validação da consulta pública

A camada de validação da consulta verifica:

* se o slug/parâmetro faz sentido;
* se a consulta é estruturalmente aceitável;
* se o recurso pedido cabe no espaço público.

Essa etapa evita que a camada pública faça chamadas inúteis, incoerentes ou potencialmente inseguras.

## 8.5 Leitura do conteúdo persistido

A partir de uma consulta válida, o serviço de leitura pública consulta o repositório/persistência de conteúdo.

Aqui há dois resultados principais:

* o recurso não existe;
* o recurso existe.

## 8.6 Verificação de elegibilidade pública

Mesmo que o recurso exista, ele ainda precisa ser elegível à exposição pública.

A camada de publicação/SEO/exposição verifica, por exemplo, de forma conceitual:

* se o recurso está publicado;
* se pode ser exibido ao público;
* se possui estrutura pública suficiente para renderização.

Sem essa elegibilidade, o recurso não deve ser tratado como resposta pública normal.

## 8.7 Renderização final

Se o conteúdo for elegível, o frontend/página recebe os dados públicos estruturados e os entrega à camada de renderização.

A partir daí, a página é montada e devolvida ao visitante.

---

## 9. Descrição detalhada das etapas

## 9.1 Acessar URL pública

### Finalidade

Iniciar a navegação pública no site.

### Responsabilidade principal

Visitante + camada pública do frontend.

### Resultado esperado

Pedido de carregamento de uma página pública.

---

## 9.2 Resolver rota / slug / página

### Finalidade

Descobrir qual recurso público a URL representa.

### Responsabilidade principal

Camada de roteamento / resolução de página.

### Resultado esperado

Rota pública válida ou erro de não encontrado.

---

## 9.3 Solicitar conteúdo público

### Finalidade

Obter da API ou da camada de leitura os dados públicos necessários para montar a página.

### Responsabilidade principal

Página / frontend público.

### Resultado esperado

Chamada pública à camada de leitura.

---

## 9.4 Validar consulta pública

### Finalidade

Garantir que a consulta de leitura pública é estruturalmente aceitável e coerente.

### Responsabilidade principal

API pública / camada de validação.

### Resultado esperado

Consulta aceita para leitura ou rejeitada por inconsistência.

---

## 9.5 Executar leitura pública

### Finalidade

Buscar o conteúdo adequado à rota solicitada.

### Responsabilidade principal

Serviço de leitura pública.

### Resultado esperado

Recurso encontrado ou não encontrado.

---

## 9.6 Consultar persistência

### Finalidade

Localizar o conteúdo persistido associado ao recurso público solicitado.

### Responsabilidade principal

Repositório / persistência de conteúdo.

### Resultado esperado

Dados estruturados do conteúdo ou ausência de recurso.

---

## 9.7 Verificar elegibilidade de exposição pública

### Finalidade

Garantir que nem todo conteúdo existente na persistência seja necessariamente visível ao público.

### Responsabilidade principal

Camada de publicação / SEO / exposição.

### Resultado esperado

Recurso marcado como:

* elegível à exposição pública; ou
* indisponível ao público.

### Observação

Essa etapa é fundamental para preservar a separação entre:

* conteúdo interno;
* rascunho;
* conteúdo efetivamente publicado.

---

## 9.8 Entregar payload público estruturado

### Finalidade

Fornecer à camada pública apenas os dados já prontos para renderização pública.

### Responsabilidade principal

Serviço de leitura pública + API pública.

### Resultado expected

Resposta pública coerente com a rota e com o estado editorial do recurso.

---

## 9.9 Renderizar a página

### Finalidade

Montar a resposta final exibida ao visitante.

### Responsabilidade principal

Página / frontend público + camada de renderização.

### Resultado esperado

Página pública carregada com conteúdo visível e estrutura adequada.

---

## 10. Fluxo de sucesso

O caminho ideal de sucesso é:

1. visitante acessa uma URL pública válida;
2. o roteamento resolve corretamente a página;
3. a página solicita conteúdo público;
4. a API valida a consulta;
5. a camada de leitura busca o recurso;
6. a persistência devolve o conteúdo;
7. a camada de publicação confirma elegibilidade pública;
8. a API devolve payload estruturado;
9. a camada pública renderiza a página;
10. o visitante visualiza o conteúdo.

Esse é o fluxo básico da experiência pública do site.

---

## 11. Fluxos de falha

## 11.1 Rota inválida

Ocorre quando:

* a URL não corresponde a nenhuma página pública válida;
* o slug é estruturalmente inválido;
* a rota não existe.

### Efeito

A camada pública deve responder com página de não encontrado ou erro equivalente.

---

## 11.2 Consulta pública inválida

Ocorre quando:

* parâmetros estão incoerentes;
* a consulta não respeita a estrutura esperada;
* há inconsistência entre rota e formato do recurso solicitado.

### Efeito

A API devolve erro de consulta, e a página pública responde de forma segura e compreensível.

---

## 11.3 Recurso inexistente

Ocorre quando:

* a rota é formalmente válida;
* mas o conteúdo correspondente não existe na persistência.

### Efeito

O sistema retorna não encontrado.

---

## 11.4 Recurso existente, mas não publicado

Ocorre quando:

* o conteúdo existe internamente;
* mas ainda não está elegível à exposição pública;
* ou não está publicado.

### Efeito

A resposta pública não deve tratar esse recurso como conteúdo público normal.

---

## 11.5 Falha de obtenção de dados

Ocorre quando:

* a persistência falha;
* a API não consegue montar resposta adequada;
* há erro interno na leitura pública.

### Efeito

A camada pública deve retornar erro controlado, sem expor detalhes sensíveis.

---

## 12. Fronteiras de responsabilidade

## 12.1 Responsabilidade do visitante

O visitante apenas:

* acessa a rota;
* consome a resposta pública.

Ele não participa da lógica de obtenção de dados.

## 12.2 Responsabilidade da camada pública do frontend

A camada pública é responsável por:

* resolver rota;
* solicitar dados públicos;
* montar ou renderizar a resposta;
* exibir página ou erro adequado.

## 12.3 Responsabilidade da API pública / leitura pública

A API é responsável por:

* validar a consulta;
* buscar o conteúdo;
* garantir que apenas recursos públicos elegíveis sejam entregues;
* devolver payload coerente.

## 12.4 Responsabilidade da persistência

A persistência é responsável por:

* armazenar o conteúdo;
* devolver o recurso existente;
* não decidir, sozinha, se ele pode ser exposto ao público.

## 12.5 Responsabilidade da camada de publicação / SEO / exposição

Essa camada é responsável por:

* separar o que existe do que está publicável/publicado;
* preparar a exposição pública;
* garantir coerência entre estado editorial e visibilidade pública.

---

## 13. Relação com arquitetura da informação e UI/UX

Este documento se relaciona fortemente com a arquitetura da informação e com a UI/UX pública, porque o fluxo de consulta depende de:

* rotas claras;
* páginas bem definidas;
* hierarquia de conteúdo coerente;
* estrutura pública navegável;
* percepção rápida do conteúdo pelo visitante.

Em outras palavras, a consulta pública não é apenas leitura de banco. Ela é uma operação arquitetural que precisa respeitar a forma como a informação foi desenhada para o usuário.

---

## 14. Relação com SEO e publicação

Este documento deixa claro que SEO e consulta pública se tocam em dois pontos fundamentais:

### 14.1 O conteúdo precisa estar publicado

Sem publicação, não há exposição pública consistente.

### 14.2 O conteúdo precisa estar apto à exposição

A camada pública deve receber o recurso já organizado para:

* leitura;
* renderização;
* descoberta;
* indexação.

Ou seja, a consulta pública consome o resultado do fluxo editorial/publicação, não o substitui.

---

## 15. Relação com frontend e backend reais

Quando o frontend e o backend reais estiverem disponíveis, este documento deve ser usado para verificar:

* se a resolução de rotas públicas está coerente;
* se a API pública separa bem leitura pública de operações administrativas;
* se conteúdo não publicado é corretamente bloqueado da superfície pública;
* se erros 404 e indisponibilidade são tratados corretamente;
* se a renderização pública recebe exatamente o payload necessário;
* se o comportamento real do site corresponde ao fluxo arquitetural pretendido.

Este documento, portanto, também serve como matriz de auditoria funcional da experiência pública.

---

## 16. Relação com os diagramas anteriores

## 16.1 Relação com `015_Diagrama_de_Sequencia_Publicacao_de_Conteudo.md`

O `015` mostrou como o conteúdo sai do painel e chega à condição de publicação.

O `017` mostra o outro lado da ponte: como esse conteúdo é efetivamente consultado pelo visitante.

## 16.2 Relação com `016_Diagrama_de_Sequencia_Edicao_de_Postagem.md`

O `016` mostrou a manutenção de conteúdo existente.

O `017` mostra o consumo público do resultado editorial vigente.

## 16.3 Relação com `010_Diagrama_de_Componentes_da_API.md`

O `010` apresentou a anatomia da API.

O `017` coloca a camada de leitura pública dessa API em ação.

---

## 17. Relação com os documentos seguintes

Este documento prepara diretamente a leitura e geração de:

* `018_Diagrama_de_Fluxo_das_Requisicoes_API.md`
* `027_Diagrama_de_Rotas_e_Paginas.md`
* `028_Diagrama_de_Jornada_do_Visitante.md`
* `030_Diagrama_de_Fluxo_de_Navegacao_Publica.md`
* `043_Diagrama_de_Indexacao_e_SEO.md`
* `045_Diagrama_de_Canonicals_Sitemap_e_Metadata.md`

### Motivo

A consulta pública é o elo entre:

* arquitetura da informação;
* publicação;
* experiência do visitante;
* rotas públicas;
* indexação e descoberta.

---

## 18. Observações de consistência

## 18.1 Coerência com arquitetura pública

O fluxo respeita a separação entre:

* frontend público;
* API pública;
* domínio editorial;
* persistência.

## 18.2 Coerência com segurança

O site público não exige autenticação para leitura normal, mas ainda depende de regras claras para não expor conteúdo indevido.

## 18.3 Coerência com SEO

A página pública e a camada de exposição são tratadas como base da indexabilidade, sem misturar isso com operação administrativa.

## 18.4 Coerência com UI/UX

A sequência contempla:

* rota válida;
* rota inválida;
* recurso inexistente;
* recurso indisponível;
* resposta pública adequada.

---

## 19. Critérios de aceite deste documento

Este documento será considerado adequado se:

* representar a sequência de consulta pública do site;
* incluir visitante, página pública, API/camada de leitura, persistência, renderização e resposta;
* contemplar rota inválida, recurso inexistente e recurso não publicado;
* distinguir claramente responsabilidades entre frontend público, backend e camada editorial;
* permanecer prudente quanto à tecnologia exata de renderização;
* manter coerência com arquitetura da informação, jornadas, wireframes, SEO, arquitetura técnica e UI/UX.

---

## 20. Conclusão executiva

A consulta pública do site William Albarello deve ser entendida como uma cadeia arquitetural organizada que começa na URL acessada pelo visitante e termina na entrega de uma página pública renderizada com conteúdo elegível à exposição.

Essa cadeia envolve:

* resolução de rota;
* consulta pública estruturada;
* leitura do conteúdo persistido;
* validação de elegibilidade pública;
* composição de resposta;
* renderização da página.

Esse desenho é importante porque impede que a camada pública seja tratada como vitrine desconectada da arquitetura real. Em vez disso, ela passa a ser entendida como resultado direto e disciplinado da relação entre:

* navegação pública;
* conteúdo publicado;
* backend de leitura;
* exposição pública coerente.

---

