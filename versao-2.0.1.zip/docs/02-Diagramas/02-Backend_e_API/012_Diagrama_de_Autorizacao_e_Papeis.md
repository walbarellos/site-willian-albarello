
# 012_Diagrama_de_Autorizacao_e_Papeis

## 1. Identificação do documento

- **Projeto:** William Albarello
- **Diretório:** `02-Diagramas`
- **Caminho oficial:** `/home/user/Documents/Softwares/Willian Albarello/William Albarello/02-Diagramas/02-Backend_e_API/012_Diagrama_de_Autorizacao_e_Papeis.md`
- **Natureza do documento:** Diagrama de autorização, papéis e fronteiras de acesso
- **Função sistêmica:** Modelar RBAC/perfis e regras de acesso da solução, deixando claros os papéis, suas permissões, os recursos protegidos e as fronteiras de autorização
- **Posição no bloco:** Quarto documento do bloco `02-Backend_e_API`
- **Dependência imediata:** `011_Diagrama_de_Fluxo_de_Autenticacao.md`

---

## 2. Objetivo

Este documento existe para formalizar a camada de **autorização e papéis** do projeto William Albarello.

Se o documento `011_Diagrama_de_Fluxo_de_Autenticacao.md` respondeu à pergunta:

**“como o sistema autentica um usuário administrativo?”**

este documento responde à pergunta:

**“depois de autenticado, o que cada perfil pode ou não pode fazer?”**

Seu objetivo é tornar explícito:

- quais perfis existem na solução;
- quais recursos são públicos e quais são protegidos;
- quais permissões cada papel possui;
- onde estão as fronteiras de acesso;
- como a API e o painel devem decidir acesso permitido ou negado;
- como o modelo de autorização se mantém coerente com segurança, contrato de API e critérios de aceite.

Este documento não trata de credenciais em si. Ele trata da **decisão de acesso após a autenticação**.

---

## 3. Fontes de referência no Waterfall

Este documento deriva principalmente dos seguintes arquivos do Diretório `01-Waterfall`:

- `004_Publico_Alvo_e_Personas.md`
- `015_Seguranca_Autenticacao_e_Autorizacao.md`
- `016_API_Contract_Mestre.md`
- `021_Criterios_de_Aceite_Gerais.md`

Fontes complementares relevantes:

- `005_Escopo_MVP_e_Fora_de_Escopo.md`
- `006_Requisitos_Funcionais.md`
- `008_Arquitetura_da_Informacao.md`
- `009_Jornada_do_Usuario_e_Fluxos_Principais.md`
- `013_Modelo_de_Dados_e_CMS.md`
- `017_UI_UX_Arquitetura_da_Informacao.md`
- `018_Plano_de_Testes_Homologacao_e_Qualidade.md`
- `023_Matriz_de_Rastreabilidade.md`
- `024_Registro_de_Decisoes_Arquiteturais.md`

Quando disponível, também devem ser confrontados:

- backend real;
- middlewares/guards reais;
- modelos reais de usuário/papel/permissão;
- endpoints administrativos reais;
- política real de sessão e acesso.

---

## 4. Premissas e limites

## 4.1 Premissas adotadas

Na ausência de confirmação exaustiva do código real neste contexto, este documento adota as seguintes premissas conservadoras e coerentes com o projeto:

- o site público é amplamente acessível sem autenticação;
- a área administrativa é protegida;
- existe ao menos um perfil administrativo com acesso interno;
- o sistema precisa distinguir claramente:
  - usuário público não autenticado;
  - usuário autenticado com poder administrativo;
- o modelo de autorização deve ser simples o suficiente para o MVP, mas robusto o suficiente para impedir acesso indevido;
- permissões devem ser pensadas por **recurso** e por **ação**;
- a autorização deve acontecer no backend, ainda que a UI também esconda ações visualmente.

## 4.2 Limites deste documento

Este arquivo não fixa, como verdade absoluta sem prova de código:

- nomes exatos das enums ou tabelas de papéis;
- mecanismo físico exato de RBAC/ABAC;
- granularidade final de permissões por endpoint;
- existência de múltiplos níveis administrativos avançados.

Seu papel é modelar a **arquitetura de autorização mais coerente com os anexos**, preservando prudência e utilidade real.

## 4.3 Regra de prudência

Onde o projeto ainda não comprovar multiplicidade real de perfis, este documento evita criar uma constelação exagerada de papéis.

Portanto, trabalha com o seguinte princípio:

- **mínimo de papéis, máximo de clareza**;
- **mínimo de abstração vazia, máximo de governança de acesso**.

---

## 5. Conceito de autorização adotado

Este documento adota um modelo de autorização baseado em **papéis e permissões lógicas por recurso**, compatível com RBAC.

Em termos simples:

- primeiro o sistema **autentica** a identidade;
- depois o sistema **autoriza** o acesso ao recurso;
- a autorização depende do **papel** e da **ação pretendida**.

### 5.1 Elementos centrais do modelo

O modelo aqui proposto trabalha com:

- **papel**: quem o usuário é do ponto de vista de acesso;
- **recurso**: qual parte do sistema está sendo acessada;
- **ação**: o que o usuário quer fazer;
- **decisão**: permitir ou negar.

### 5.2 Regra de ouro

A autenticação responde:

**“quem é você?”**

A autorização responde:

**“o que você pode fazer aqui?”**

---

## 6. Papéis-base da solução

Considerando o escopo do projeto e a prudência documental, os papéis-base da solução devem ser entendidos assim:

### 6.1 Visitante / Leitor Público
Perfil externo, não autenticado, que acessa a camada pública do site.

### 6.2 Administrador / Autor
Perfil autenticado que opera o painel, administra conteúdo, executa ações protegidas e mantém a solução institucional.

### 6.3 Papel técnico opcional de expansão futura
Caso o backend real confirme mais de um nível administrativo, a expansão coerente seria:

- **Editor**
- **Administrador**
- **Superadministrador**

Porém, sem confirmação forte do código, este documento trata **Administrador / Autor** como o papel administrativo principal do MVP.

---

## 7. Diagrama principal — Autorização e Papéis

```mermaid
flowchart LR

    subgraph papeis["Papéis"]
        visitante["Papel: Visitante / Leitor Público"]
        admin["Papel: Administrador / Autor"]
    end

    subgraph recursos_publicos["Recursos Públicos"]
        paginas["Recurso: Páginas Públicas"]
        conteudo_publico["Recurso: Conteúdo Publicado"]
        rotas_publicas["Recurso: Rotas Públicas / Leitura"]
    end

    subgraph recursos_protegidos["Recursos Protegidos"]
        login_admin["Recurso: Tela / Endpoint de Login Administrativo"]
        painel["Recurso: Painel Interno"]
        gestao_conteudo["Recurso: Gestão de Conteúdo"]
        publicacao["Recurso: Publicação / SEO / Metadata"]
        config_admin["Recurso: Operações Administrativas Internas"]
    end

    subgraph motor["Decisão de Acesso"]
        authz["Componente Lógico: Autorização / Regras de Acesso"]
    end

    visitante -->|pode acessar| paginas
    visitante -->|pode acessar| conteudo_publico
    visitante -->|pode acessar| rotas_publicas
    visitante -->|pode acessar apenas para iniciar autenticação| login_admin

    admin -->|pode autenticar e operar| login_admin
    admin -->|solicita acesso protegido| authz

    authz -->|permite| painel
    authz -->|permite| gestao_conteudo
    authz -->|permite| publicacao
    authz -->|permite conforme regra administrativa| config_admin

    visitante -. não autorizado .-> painel
    visitante -. não autorizado .-> gestao_conteudo
    visitante -. não autorizado .-> publicacao
    visitante -. não autorizado .-> config_admin
````

---

## 8. Leitura do diagrama

## 8.1 Visão geral

O diagrama mostra que a solução possui dois grandes territórios de acesso:

* **território público**, acessível ao visitante;
* **território protegido**, acessível apenas após autenticação e decisão de autorização.

## 8.2 Papel do visitante

O visitante:

* pode consumir páginas públicas;
* pode ler conteúdo publicado;
* pode navegar na camada pública;
* não pode operar o painel;
* não pode administrar conteúdo;
* não pode publicar, editar ou alterar configuração interna.

## 8.3 Papel do administrador

O administrador:

* autentica-se;
* solicita acesso a recursos internos;
* passa pela camada de autorização;
* recebe acesso aos recursos protegidos compatíveis com seu papel.

## 8.4 Papel da autorização

A autorização funciona como o ponto de decisão entre:

* papel autenticado;
* recurso solicitado;
* ação pretendida.

Ela é a barreira que impede que a simples autenticação vire acesso irrestrito.

---

## 9. Fronteiras de acesso

## 9.1 Fronteira pública

A fronteira pública inclui:

* páginas institucionais;
* conteúdo publicado;
* navegação pública;
* consumo de informação;
* descoberta e leitura.

### Regra

Tudo que está na fronteira pública deve ser acessível sem autenticação, salvo indicação contrária muito específica do projeto.

## 9.2 Fronteira de autenticação

A fronteira de autenticação inclui:

* tela de login administrativo;
* endpoint de login;
* submissão de credenciais.

### Regra

Esse recurso pode ser “acessado” publicamente apenas no sentido de iniciar autenticação. Isso **não** significa acesso ao conteúdo administrativo.

## 9.3 Fronteira protegida

A fronteira protegida inclui:

* painel interno;
* operações administrativas;
* gestão de conteúdo;
* publicação e SEO;
* configurações internas ou ações de governança administrativa.

### Regra

Nada dentro dessa fronteira deve ser tratado como público.

---

## 10. Recursos e ações do sistema

Para modelar autorização corretamente, é útil separar **recurso** de **ação**.

## 10.1 Recursos principais

Os recursos principais da solução são:

* páginas públicas
* conteúdo publicado
* rotas públicas
* login administrativo
* painel interno
* gestão de conteúdo
* publicação / SEO / metadata
* operações administrativas internas

## 10.2 Ações principais por tipo

### Ações públicas

* visualizar
* navegar
* consultar
* ler

### Ações protegidas

* entrar
* criar
* editar
* publicar
* atualizar
* remover
* administrar

## 10.3 Regra de decisão

A autorização correta deve responder sempre no formato:

**papel + recurso + ação = permitido ou negado**

---

## 11. Matriz lógica de permissões

Abaixo está a matriz lógica mínima coerente com o projeto.

### 11.1 Matriz resumida

| Papel                      | Páginas públicas | Conteúdo publicado | Login administrativo                     | Painel interno | Gestão de conteúdo | Publicação / SEO | Operações administrativas internas |
| -------------------------- | ---------------- | ------------------ | ---------------------------------------- | -------------- | ------------------ | ---------------- | ---------------------------------- |
| Visitante / Leitor Público | Permitir leitura | Permitir leitura   | Permitir acesso à tela/endpoint de login | Negar          | Negar              | Negar            | Negar                              |
| Administrador / Autor      | Permitir leitura | Permitir leitura   | Permitir                                 | Permitir       | Permitir           | Permitir         | Permitir conforme política interna |

### 11.2 Interpretação correta da tabela

A tabela não significa que o visitante “usa” o login administrativamente. Significa apenas que ele pode alcançar a tela de login ou o endpoint de submissão de credenciais sem já estar autenticado.

A partir daí, tudo que for painel e operação protegida exige decisão positiva de autorização.

---

## 12. Regras por perfil

## 12.1 Perfil: Visitante / Leitor Público

### Pode

* acessar páginas públicas;
* ler conteúdo publicado;
* navegar em rotas públicas;
* consumir a face institucional do site;
* alcançar a tela de login administrativo, sem ganhar acesso administrativo por isso.

### Não pode

* entrar no painel como usuário válido sem autenticação;
* criar, editar ou remover conteúdo;
* publicar material;
* alterar SEO interno;
* executar ações administrativas.

### Regra de negócio

O visitante é um papel de consumo, não de operação.

---

## 12.2 Perfil: Administrador / Autor

### Pode

* autenticar-se;
* acessar o painel interno;
* gerir conteúdo;
* operar publicação;
* manter a camada institucional do projeto;
* executar ações administrativas compatíveis com o papel;
* acessar recursos protegidos do backend.

### Deve

* passar por autenticação válida;
* respeitar regras de sessão;
* operar dentro das fronteiras permitidas;
* ter acesso verificado no backend e não apenas na interface.

### Regra de negócio

O administrador é o papel operativo do sistema. Seu acesso é amplo dentro do escopo do projeto, mas continua sendo governado por rotas protegidas, sessão válida e autorização backend.

---

## 13. Política lógica de autorização

## 13.1 Política para recursos públicos

Regra:

* se o recurso for público, o acesso deve ser permitido sem autenticação.

Exemplos:

* página inicial;
* páginas institucionais;
* conteúdo já publicado;
* rotas públicas de leitura.

## 13.2 Política para recursos administrativos

Regra:

* se o recurso for administrativo, o acesso exige autenticação válida.

Exemplos:

* painel;
* listagem de conteúdo interno;
* criação/edição de conteúdo;
* publicação;
* gestão de metadata;
* operações administrativas internas.

## 13.3 Política para decisão de acesso

Regra:

* autenticação válida é condição necessária, mas não suficiente;
* ainda deve haver autorização compatível com o papel.

Mesmo em um MVP com um único papel administrativo principal, essa regra continua importante porque evita colapso conceitual entre login e permissão irrestrita.

---

## 14. Onde a autorização deve acontecer

## 14.1 Backend como fonte de verdade

A autorização real deve acontecer no backend.

### Motivo

O frontend pode esconder botões, menus e rotas, mas isso não basta como garantia de segurança.

O backend deve ser a instância final que decide:

* se o papel é válido;
* se a sessão/token é válido;
* se o recurso pode ser usado;
* se a ação pretendida deve ser permitida.

## 14.2 Frontend como reforço de UX

O frontend também deve refletir autorização em termos de experiência, por exemplo:

* esconder áreas não acessíveis;
* bloquear navegação indevida;
* redirecionar quando não houver contexto válido;
* reduzir confusão do usuário.

### Regra

Frontend melhora UX. Backend garante segurança.

---

## 15. Modelo lógico de decisão de autorização

A lógica de decisão ideal pode ser descrita assim:

1. existe contexto autenticado?
2. a identidade é válida?
3. o papel associado é conhecido?
4. o recurso solicitado é público ou protegido?
5. se protegido, o papel pode executar a ação desejada?
6. se sim, permitir;
7. se não, negar com resposta adequada.

Essa cadeia deve ser aplicada de forma consistente em rotas protegidas.

---

## 16. Diagrama complementar — Fluxo lógico da decisão de autorização

```mermaid
flowchart TD

    A["Requisição a recurso do sistema"] --> B{"Recurso é público?"}

    B -- "Sim" --> C["Permitir acesso sem autenticação"]
    B -- "Não" --> D["Exigir contexto autenticado"]

    D --> E{"Sessão / token / identidade válida?"}
    E -- "Não" --> F["Negar acesso e redirecionar / responder não autenticado"]
    E -- "Sim" --> G["Resolver papel do usuário"]

    G --> H{"Papel pode executar a ação no recurso?"}
    H -- "Não" --> I["Negar acesso por autorização insuficiente"]
    H -- "Sim" --> J["Permitir acesso ao recurso protegido"]
```

---

## 17. Relação entre autorização, autenticação e sessão

## 17.1 Autenticação

Responde:

* quem é o usuário?

## 17.2 Sessão / token

Responde:

* o contexto autenticado ainda é válido?

## 17.3 Autorização

Responde:

* esse usuário pode executar esta ação neste recurso?

### Regra de ouro

Esses três conceitos não devem ser misturados:

* autenticar não é autorizar;
* manter sessão não é conceder permissão;
* esconder rota no frontend não é proteger recurso.

---

## 18. Relação com API contract e critérios de aceite

## 18.1 Relação com contrato de API

A API precisa refletir claramente:

* quais endpoints são públicos;
* quais endpoints são protegidos;
* quais exigem contexto autenticado;
* quais retornam erro de autenticação;
* quais retornam erro de autorização.

Isso torna o contrato previsível para frontend, testes e manutenção.

## 18.2 Relação com critérios de aceite

Do ponto de vista de aceite, a solução deve ser capaz de demonstrar que:

* visitante acessa apenas o que é público;
* usuário autenticado administrativo acessa o que é protegido;
* acesso não autenticado ao painel é negado;
* acesso autenticado, porém sem permissão suficiente, é negado;
* a UI reflete corretamente o acesso permitido;
* o backend impõe corretamente a proteção real.

---

## 19. Relação com backend real

Quando o backend real estiver disponível, este documento deve ser usado para verificar:

* se existe separação entre rotas públicas e protegidas;
* se o middleware de autenticação está aplicado corretamente;
* se há lógica clara de papel/permissão;
* se a autorização está concentrada no backend e não apenas na UI;
* se as respostas 401/403 ou equivalentes estão coerentes;
* se há coerência entre papel, recurso e ação.

Ou seja, este documento também funciona como instrumento de auditoria do controle de acesso.

---

## 20. Relação com os diagramas anteriores

## 20.1 Relação com `011_Diagrama_de_Fluxo_de_Autenticacao.md`

O `011` mostrou como o usuário entra no sistema.

O `012` mostra o que acontece **depois que ele entra**, em termos de permissão e fronteira de acesso.

## 20.2 Relação com `010_Diagrama_de_Componentes_da_API.md`

O `010` mostrou middleware, guardas e regras de acesso como componentes.

O `012` traduz essa estrutura em política concreta de papéis e permissões.

## 20.3 Relação com `009_Diagrama_de_Modulos_do_Backend.md`

O `009` mostrou autenticação e administração como módulos.

O `012` explicita as regras que conectam esses módulos aos recursos protegidos.

---

## 21. Relação com os documentos seguintes

Este documento prepara diretamente a leitura e geração de:

* `013_Diagrama_de_Casos_de_Uso_do_Painel_Interno.md`
* `014_Diagrama_de_Sequencia_Login.md`
* `040_Diagrama_de_Permissoes_por_Perfil.md`
* `041_Diagrama_de_Auditoria_e_Rastreabilidade.md`

### Motivo

Esses documentos exigem uma base clara sobre:

* quem pode acessar o quê;
* quais ações existem;
* como o sistema decide permissão.

---

## 22. Observações de consistência

## 22.1 Coerência com personas

A distinção entre visitante e administrador respeita a divisão natural do projeto entre público externo e operador interno.

## 22.2 Coerência com segurança

A autorização aparece como camada separada da autenticação, o que é metodologicamente correto.

## 22.3 Coerência com contrato de API

A distinção entre recursos públicos e protegidos sustenta endpoints previsíveis e testáveis.

## 22.4 Coerência com critérios de aceite

A matriz de permissões ajuda a transformar segurança em critério verificável, e não em ideia abstrata.

## 22.5 Coerência com escopo

O documento evita sobreengenharia de papéis não comprovados e permanece aderente ao escopo do projeto.

---

## 23. Critérios de aceite deste documento

Este documento será considerado adequado se:

* modelar com clareza os papéis relevantes da solução;
* distinguir recursos públicos de recursos protegidos;
* mostrar a fronteira entre visitante e administrador;
* apresentar matriz lógica de permissões;
* explicitar que a autorização real acontece no backend;
* distinguir autenticação, sessão e autorização;
* permanecer prudente quanto a papéis ainda não confirmados por código;
* ser utilizável como base para testes e auditoria.

---

## 24. Conclusão executiva

A autorização do projeto William Albarello deve ser entendida como uma política clara de controle de acesso baseada em papéis, recursos e ações.

No núcleo do MVP, a solução distingue pelo menos dois perfis funcionais:

* **Visitante / Leitor Público**
* **Administrador / Autor**

A partir disso, o sistema deve operar com duas fronteiras principais:

* **fronteira pública**, liberada para navegação e leitura;
* **fronteira protegida**, reservada à administração autenticada e autorizada.

Esse desenho é importante porque impede confundir:

* estar logado com estar autorizado;
* esconder interface com realmente proteger recurso;
* área pública com área operacional.

Este documento formaliza a lógica de autorização do sistema e prepara a continuação para casos de uso administrativos, permissões por perfil e rastreabilidade de ações.

---

