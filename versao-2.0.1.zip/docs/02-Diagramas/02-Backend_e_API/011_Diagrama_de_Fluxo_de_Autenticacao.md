
# 011_Diagrama_de_Fluxo_de_Autenticacao

## 1. Identificação do documento

- **Projeto:** William Albarello
- **Diretório:** `02-Diagramas`
- **Caminho oficial:** `/home/user/Documents/Softwares/Willian Albarello/William Albarello/02-Diagramas/02-Backend_e_API/011_Diagrama_de_Fluxo_de_Autenticacao.md`
- **Natureza do documento:** Diagrama de fluxo de autenticação de ponta a ponta
- **Função sistêmica:** Representar o fluxo completo de autenticação, desde o envio das credenciais até o estabelecimento do contexto autenticado no painel administrativo, incluindo validação, geração de sessão ou token, armazenamento seguro, middleware e tratamento de falhas
- **Posição no bloco:** Terceiro documento do bloco `02-Backend_e_API`
- **Dependência imediata:** `010_Diagrama_de_Componentes_da_API.md`

---

## 2. Objetivo

Este documento existe para formalizar, de forma clara e operacional, o fluxo de autenticação do projeto William Albarello.

Seu objetivo é mostrar, em sequência lógica:

- onde o usuário administrativo inicia o login;
- como as credenciais são enviadas;
- como o backend valida o contrato de entrada;
- como a identidade é verificada;
- como a autorização inicial é determinada;
- como a sessão ou token é criada;
- como o frontend armazena o contexto autenticado de forma segura;
- como o middleware passa a proteger as rotas administrativas;
- como o sistema responde em cenários de sucesso e falha.

Este documento não pretende detalhar cada endpoint ou cada implementação de framework. Ele existe para estabilizar o **fluxo de autenticação fim a fim**.

---

## 3. Fontes de referência no Waterfall

Este documento deriva principalmente dos seguintes arquivos do Diretório `01-Waterfall`:

- `015_Seguranca_Autenticacao_e_Autorizacao.md`
- `016_API_Contract_Mestre.md`
- `018_Plano_de_Testes_Homologacao_e_Qualidade.md`

Fontes complementares relevantes:

- `014_Arquitetura_Tecnica.md`
- `017_UI_UX_Arquitetura_da_Informacao.md`
- `021_Criterios_de_Aceite_Gerais.md`
- `023_Matriz_de_Rastreabilidade.md`
- `024_Registro_de_Decisoes_Arquiteturais.md`

Quando disponíveis, também devem ser considerados:

- backend real;
- frontend real;
- prints de tela;
- Swagger ou documentação viva;
- estrutura real de rotas protegidas.

---

## 4. Premissas e limites

## 4.1 Premissas adotadas

Para fins deste documento, adotam-se as seguintes premissas conservadoras e coerentes com o corpus do projeto:

- a autenticação se aplica principalmente à **área administrativa / painel interno**;
- o site público não exige autenticação para navegação comum;
- existe um endpoint ou mecanismo equivalente de login administrativo;
- o backend valida credenciais contra uma fonte persistente confiável;
- o sistema estabelece um **contexto autenticado** sob a forma de sessão, token ou estrutura equivalente;
- o frontend administrativo armazena esse contexto de forma segura, dentro das capacidades permitidas pela arquitetura adotada;
- o middleware ou guardas de rota utilizam esse contexto para autorizar o acesso às rotas protegidas;
- existe tratamento explícito para falhas de autenticação e sessão inválida/expirada.

## 4.2 Limites deste documento

Este documento não fixa, como verdade absoluta, detalhes de implementação como:

- nome exato do endpoint de login;
- estratégia específica de cookie, JWT, session store ou outro mecanismo;
- política completa de refresh token;
- provider externo de identidade;
- detalhes de MFA, caso não estejam comprovados pelos anexos.

Seu papel é mostrar o **fluxo correto e completo**, não engessar detalhes ainda não confirmados.

## 4.3 Regra de prudência

Sempre que o código real não confirmar o mecanismo exato, este documento usa formulações como:

- **sessão ou token**
- **contexto autenticado**
- **middleware de autenticação**
- **armazenamento seguro compatível com a arquitetura**

Isso preserva aderência documental sem inventar implementação.

---

## 5. Visão geral do fluxo

Em nível macro, o fluxo de autenticação do projeto segue esta lógica:

1. o administrador acessa a tela de login;
2. informa credenciais;
3. o frontend envia a requisição ao backend;
4. o backend valida o contrato de entrada;
5. o backend busca o usuário e verifica credenciais;
6. o backend decide se o acesso deve ser permitido;
7. em caso de sucesso, cria contexto autenticado;
8. o frontend recebe e armazena o contexto de forma segura;
9. o painel passa a operar com middleware/guardas de rota;
10. as requisições subsequentes incluem prova de autenticação;
11. falhas, expiração ou revogação devolvem o usuário ao fluxo de login.

---

## 6. Diagrama principal — Fluxo de Autenticação

```mermaid
flowchart TD

    A["Administrador acessa a tela de login"] --> B["Frontend exibe formulário de autenticação"]
    B --> C["Administrador informa credenciais"]
    C --> D["Frontend valida campos obrigatórios e formato mínimo"]
    D --> E["Frontend envia requisição de login para a API"]

    E --> F["API recebe a requisição de autenticação"]
    F --> G["Validação do contrato de entrada / schema"]
    G --> H{"Payload válido?"}

    H -- "Não" --> I["API retorna erro de validação"]
    I --> J["Frontend exibe mensagem e mantém usuário na tela de login"]

    H -- "Sim" --> K["Camada de autenticação localiza identidade do usuário"]
    K --> L{"Usuário existe e está apto?"}

    L -- "Não" --> M["API retorna falha de autenticação"]
    M --> J

    L -- "Sim" --> N["API verifica segredo / credencial"]
    N --> O{"Credencial confere?"}

    O -- "Não" --> P["API registra falha e retorna credenciais inválidas"]
    P --> J

    O -- "Sim" --> Q["API resolve contexto de acesso e permissões iniciais"]
    Q --> R{"Perfil pode acessar o painel?"}

    R -- "Não" --> S["API retorna acesso negado"]
    S --> J

    R -- "Sim" --> T["API gera sessão ou token de acesso"]
    T --> U["API monta resposta autenticada"]
    U --> V["Frontend recebe contexto autenticado"]

    V --> W["Frontend armazena sessão/token de forma segura"]
    W --> X["Frontend atualiza estado autenticado da aplicação"]
    X --> Y["Frontend redireciona para o painel interno"]

    Y --> Z["Rotas protegidas passam a exigir middleware / guardas"]
    Z --> AA["Requisições subsequentes enviam prova de autenticação"]
    AA --> AB["Middleware valida sessão/token em cada acesso protegido"]
    AB --> AC{"Sessão/token válido?"}

    AC -- "Sim" --> AD["Acesso permitido ao recurso protegido"]
    AC -- "Não" --> AE["Sessão inválida, expirada ou revogada"]
    AE --> AF["Frontend limpa contexto autenticado"]
    AF --> AG["Usuário retorna ao fluxo de login"]
````

---

## 7. Leitura do diagrama

## 7.1 Etapa de entrada

O fluxo começa quando o administrador acessa a tela de login. Nesse momento:

* o frontend exibe o formulário;
* o usuário informa credenciais;
* há uma validação inicial mínima do lado do cliente para evitar envio inútil de payload obviamente incompleto.

Essa validação inicial **não substitui** a validação do backend.

## 7.2 Etapa de recebimento e validação pela API

Ao receber a requisição, a API:

* valida o formato do payload;
* garante que a requisição respeita o contrato esperado;
* rejeita entradas inválidas antes mesmo de consultar a lógica de autenticação.

Essa etapa protege a aplicação contra:

* payload quebrado;
* tipos incorretos;
* ausência de campos obrigatórios;
* inconsistência contratual.

## 7.3 Etapa de verificação de identidade

Se o payload for válido, a camada de autenticação:

* localiza a identidade do usuário;
* verifica se o usuário existe;
* verifica se está apto a autenticar-se;
* compara o segredo informado com o segredo esperado, segundo o mecanismo da aplicação.

Neste ponto, o sistema ainda **não** está concedendo acesso; está apenas verificando identidade.

## 7.4 Etapa de decisão de acesso

Mesmo com credenciais corretas, o sistema ainda precisa decidir:

* se o perfil pode acessar a área administrativa;
* se a conta está habilitada;
* se não há restrições lógicas adicionais.

Só depois disso o acesso administrativo é concedido.

## 7.5 Etapa de geração de contexto autenticado

Uma vez aprovado, o backend:

* cria sessão, token ou estrutura equivalente;
* monta resposta autenticada;
* entrega ao frontend o material necessário para sustentar o contexto autenticado.

## 7.6 Etapa de armazenamento seguro

O frontend:

* recebe o contexto autenticado;
* o armazena segundo a política segura compatível com a arquitetura adotada;
* atualiza o estado interno da aplicação;
* redireciona o usuário ao painel.

## 7.7 Etapa de proteção contínua

Depois do login inicial, as rotas protegidas não dependem mais do formulário de login, mas do middleware/guardas de autenticação, que:

* verificam a validade do contexto autenticado;
* liberam ou bloqueiam o acesso;
* exigem prova de autenticação em cada requisição sensível.

## 7.8 Etapa de falha, expiração ou revogação

Se a sessão/token estiver:

* inválido;
* expirado;
* revogado;
* ausente;
* incompatível com a rota protegida,

o sistema deve:

* bloquear o acesso;
* limpar o estado autenticado local, quando apropriado;
* devolver o usuário ao fluxo de login.

---

## 8. Explicação das etapas do fluxo

## 8.1 Tela de login

### Função

É a porta de entrada da autenticação administrativa.

### Responsabilidades

* coletar credenciais;
* orientar o usuário;
* exibir mensagens de erro ou sucesso;
* iniciar o fluxo de autenticação.

### Limite

Não decide autenticação real. Apenas inicia o processo.

---

## 8.2 Validação inicial no frontend

### Função

Reduzir erros triviais antes do envio.

### Responsabilidades

* verificar campos vazios;
* validar formato mínimo;
* impedir submissões manifestamente inválidas.

### Limite

Não valida identidade nem substitui a API.

---

## 8.3 Requisição de login à API

### Função

Transferir as credenciais ao backend por canal apropriado e contrato definido.

### Responsabilidades

* respeitar o contrato de autenticação;
* acionar o endpoint correto;
* tratar loading, retorno e falhas.

### Limite

O frontend não autentica por si mesmo; ele solicita autenticação.

---

## 8.4 Validação de contrato na API

### Função

Garantir que a entrada recebida seja estruturalmente válida.

### Responsabilidades

* validar schema;
* garantir coerência mínima do payload;
* evitar processamento de entrada malformada.

### Limite

Não decide se o usuário é legítimo; isso vem depois.

---

## 8.5 Verificação de identidade e credenciais

### Função

Confirmar se a identidade existe e se o segredo apresentado corresponde ao esperado.

### Responsabilidades

* localizar usuário;
* validar credencial;
* impedir falsos positivos de acesso.

### Limite

Não basta existir credencial válida; ainda é preciso verificar acesso permitido ao painel.

---

## 8.6 Resolução de acesso e perfil

### Função

Verificar se a identidade autenticada pode efetivamente entrar na área administrativa.

### Responsabilidades

* aplicar regras de autorização inicial;
* impedir login administrativo por perfis sem permissão;
* sustentar coerência entre autenticação e controle de acesso.

### Limite

Não substitui verificações posteriores de autorização por recurso.

---

## 8.7 Geração de sessão ou token

### Função

Criar um contexto autenticado reutilizável.

### Responsabilidades

* emitir prova de autenticação;
* estabelecer contexto do usuário;
* permitir que o frontend mantenha estado autenticado.

### Limite

A geração de contexto não encerra as obrigações de segurança; ela inaugura a fase de proteção contínua.

---

## 8.8 Armazenamento seguro no frontend

### Função

Manter o contexto autenticado de forma segura e consistente com a arquitetura.

### Responsabilidades

* armazenar conforme a política definida;
* evitar exposição desnecessária;
* sincronizar estado autenticado da aplicação;
* preparar envio de prova de autenticação nas chamadas seguintes.

### Limite

Esse armazenamento deve seguir o desenho real do projeto. O documento não impõe, sem prova, o mecanismo exato.

---

## 8.9 Middleware / Guardas de rota

### Função

Aplicar autenticação de forma contínua no uso do painel.

### Responsabilidades

* verificar sessão/token em rotas protegidas;
* bloquear acesso indevido;
* evitar entrada direta em área restrita sem contexto válido;
* reforçar coerência entre login inicial e uso contínuo do sistema.

### Limite

Middleware protege acesso, mas não substitui toda autorização de negócio.

---

## 8.10 Tratamento de falhas

### Função

Normalizar cenários negativos.

### Responsabilidades

* retornar erros claros e previsíveis;
* evitar comportamento ambíguo;
* garantir que o usuário saiba se:

  * preencheu algo errado;
  * informou credencial inválida;
  * perdeu sessão;
  * foi bloqueado por falta de permissão.

### Limite

A falha não deve expor informação sensível além do necessário.

---

## 9. Fluxo de sucesso

O caminho de sucesso é este:

1. administrador abre a tela de login;
2. preenche credenciais válidas;
3. frontend envia requisição correta;
4. backend valida contrato;
5. backend encontra usuário apto;
6. backend confirma credencial;
7. backend confirma permissão de acesso ao painel;
8. backend gera contexto autenticado;
9. frontend armazena contexto de forma segura;
10. painel é liberado;
11. middleware passa a proteger o acesso contínuo.

Esse fluxo representa a trilha ideal do sistema autenticado.

---

## 10. Fluxos de falha

## 10.1 Falha de validação de entrada

Ocorre quando:

* faltam campos;
* formato está quebrado;
* contrato não foi respeitado.

### Resultado

* a API rejeita a entrada;
* o frontend permanece na tela de login;
* o usuário recebe feedback adequado.

## 10.2 Falha por usuário inexistente ou inapto

Ocorre quando:

* identidade não é localizada;
* conta não está apta ao login administrativo.

### Resultado

* o sistema não gera contexto autenticado;
* a tentativa falha;
* o frontend permanece no login.

## 10.3 Falha por credencial inválida

Ocorre quando:

* a credencial informada não confere.

### Resultado

* o backend rejeita a autenticação;
* não há sessão/token válido;
* o login falha.

## 10.4 Falha por falta de permissão

Ocorre quando:

* o usuário até pode existir e ter credencial válida;
* mas não possui permissão para o painel ou recurso administrativo.

### Resultado

* acesso negado;
* o sistema evita escalonamento indevido.

## 10.5 Falha por sessão expirada, inválida ou revogada

Ocorre em requisições subsequentes quando:

* a sessão expirou;
* o token se tornou inválido;
* houve logout;
* houve revogação lógica;
* o contexto autenticado ficou inconsistente.

### Resultado

* middleware bloqueia a rota;
* frontend limpa o estado local;
* usuário é levado novamente ao fluxo de login.

---

## 11. Segurança implícita no fluxo

Mesmo sem fixar a tecnologia exata, este fluxo pressupõe as seguintes boas práticas arquiteturais:

* validação de entrada antes da lógica de autenticação;
* verificação de identidade separada da autorização inicial;
* ausência de acesso ao painel sem contexto autenticado;
* armazenamento do contexto autenticado de forma segura;
* uso de middleware/guardas nas rotas protegidas;
* tratamento normalizado de falhas;
* limpeza do estado autenticado quando o contexto deixa de ser válido.

Esses princípios são mais importantes, neste ponto, do que cravar o mecanismo exato de implementação.

---

## 12. Relação com frontend e backend

## 12.1 Responsabilidade do frontend

O frontend é responsável por:

* apresentar a tela de login;
* coletar credenciais;
* disparar o pedido de autenticação;
* armazenar o contexto autenticado conforme o desenho aprovado;
* usar esse contexto para navegar no painel e acionar rotas protegidas;
* reagir corretamente a erros e expiração.

## 12.2 Responsabilidade do backend

O backend é responsável por:

* validar a entrada;
* verificar identidade;
* conferir credenciais;
* decidir acesso;
* gerar sessão/token/contexto autenticado;
* responder de forma segura e previsível;
* verificar continuamente a validade do acesso nas requisições protegidas.

## 12.3 Fronteira entre os dois

A fronteira é clara:

* o frontend **solicita** autenticação;
* o backend **decide** autenticação.

---

## 13. Relação com os diagramas anteriores

## 13.1 Relação com `009_Diagrama_de_Modulos_do_Backend.md`

O `009` apresentou autenticação como módulo do backend. Este documento mostra como esse módulo se comporta em fluxo ponta a ponta.

## 13.2 Relação com `010_Diagrama_de_Componentes_da_API.md`

O `010` mostrou rotas, middleware, schemas, services e persistência. Este documento pega esse desenho interno e o organiza como jornada lógica de autenticação.

Em resumo:

* `010` mostra a anatomia da API;
* `011` mostra o fluxo real de autenticação dentro dessa anatomia.

---

## 14. Relação com os documentos seguintes

Este documento prepara diretamente a leitura e geração de:

* `012_Diagrama_de_Autorizacao_e_Papeis.md`
* `014_Diagrama_de_Sequencia_Login.md`
* `039_Diagrama_de_Fluxo_de_Sessao.md`
* `040_Diagrama_de_Permissoes_por_Perfil.md`

### Motivo

Esses documentos dependem de uma noção clara do que acontece no login ponta a ponta antes de descer para:

* papéis;
* decisões de autorização;
* sequência temporal fina;
* ciclo de vida da sessão.

---

## 15. Observações de consistência

## 15.1 Coerência com segurança

O fluxo preserva distinção correta entre:

* autenticação;
* autorização inicial;
* sessão/token;
* middleware de proteção contínua.

## 15.2 Coerência com API contract

O fluxo respeita a existência de contrato de entrada, contrato de saída e falhas padronizadas.

## 15.3 Coerência com UI/UX

A presença de feedback ao usuário e retorno ao login em falhas é coerente com uma experiência administrativa minimamente robusta.

## 15.4 Coerência com testes

O fluxo permite derivar casos de teste claros para:

* login válido;
* payload inválido;
* usuário inexistente;
* credencial incorreta;
* falta de permissão;
* sessão expirada;
* retorno ao login.

---

## 16. Critérios de aceite deste documento

Este documento será considerado adequado se:

* representar o fluxo de autenticação do início ao fim;
* incluir credenciais, validação, verificação de identidade, geração de sessão/token e middleware;
* mostrar o retorno ao painel após sucesso;
* mostrar tratamento de falhas relevantes;
* distinguir responsabilidades de frontend e backend;
* manter prudência quanto ao mecanismo exato quando ele não estiver comprovado;
* permanecer coerente com segurança, contrato de API e QA.

---

## 17. Conclusão executiva

O fluxo de autenticação do projeto William Albarello deve ser entendido como uma cadeia contínua que começa na tela de login e só se completa quando o sistema passa a proteger, de forma consistente, o acesso ao painel interno.

Essa cadeia envolve:

* coleta de credenciais;
* validação de contrato;
* verificação de identidade;
* conferência de credencial;
* decisão de acesso;
* geração de contexto autenticado;
* armazenamento seguro;
* proteção contínua por middleware;
* tratamento robusto de falhas e expiração.

Esse desenho é essencial porque transforma “login” de um simples formulário em uma **capacidade arquitetural completa de controle de acesso**.

---

