
# 015_Diagrama_de_Sequencia_Publicacao_de_Conteudo

## 1. Identificação do documento

- **Projeto:** William Albarello
- **Diretório:** `02-Diagramas`
- **Caminho oficial:** `/home/user/Documents/Softwares/Willian Albarello/William Albarello/02-Diagramas/02-Backend_e_API/015_Diagrama_de_Sequencia_Publicacao_de_Conteudo.md`
- **Natureza do documento:** Diagrama de sequência da publicação de conteúdo
- **Função sistêmica:** Descrever, em ordem temporal, a sequência técnica e funcional da publicação de conteúdo, desde a ação do administrador no painel até a persistência, estruturação editorial/SEO e disponibilização pública no site
- **Posição no bloco:** Sétimo documento do bloco `02-Backend_e_API`
- **Dependência imediata:** `013_Diagrama_de_Casos_de_Uso_do_Painel_Interno.md` e `014_Diagrama_de_Sequencia_Login.md`

---

## 2. Objetivo

Este documento existe para formalizar a **sequência de publicação de conteúdo** do projeto William Albarello.

Seu objetivo é mostrar, em ordem clara e tecnicamente coerente:

- como o administrador cria ou edita um conteúdo no painel;
- como o frontend administrativo envia os dados para a API;
- como a API valida contrato, autorização e consistência;
- como a camada de conteúdo/CMS persiste os dados;
- como a camada de publicação/SEO prepara o conteúdo para exposição pública;
- como o sistema atualiza a disponibilidade pública do conteúdo;
- como o site público passa a refletir a nova publicação;
- como a indexação se torna possível a partir da camada pública;
- como falhas são tratadas em pontos críticos do processo.

Este documento não tenta substituir o fluxo editorial completo nem o diagrama de estados da postagem. Seu foco é a **sequência ponta a ponta da publicação**.

---

## 3. Fontes de referência no Waterfall

Este documento deriva principalmente dos seguintes arquivos do Diretório `01-Waterfall`:

- `012_Estrategia_de_Conteudo_e_SEO.md`
- `013_Modelo_de_Dados_e_CMS.md`
- `016_API_Contract_Mestre.md`
- `017_UI_UX_Arquitetura_da_Informacao.md`

Fontes complementares relevantes:

- `006_Requisitos_Funcionais.md`
- `008_Arquitetura_da_Informacao.md`
- `009_Jornada_do_Usuario_e_Fluxos_Principais.md`
- `010_Wireframes_e_Estrutura_de_Paginas.md`
- `014_Arquitetura_Tecnica.md`
- `015_Seguranca_Autenticacao_e_Autorizacao.md`
- `018_Plano_de_Testes_Homologacao_e_Qualidade.md`
- `021_Criterios_de_Aceite_Gerais.md`
- `023_Matriz_de_Rastreabilidade.md`
- `024_Registro_de_Decisoes_Arquiteturais.md`

Quando disponíveis, também devem ser confrontados:

- frontend real do painel;
- backend real;
- modelos reais de conteúdo;
- rotas reais de publicação;
- estrutura real de campos editoriais e metadata;
- prints do painel e/ou Swagger.

---

## 4. Premissas e limites

## 4.1 Premissas adotadas

Para fins deste documento, adotam-se as seguintes premissas conservadoras e coerentes com o projeto:

- existe um painel interno por meio do qual o administrador cria ou edita conteúdo;
- existe um modelo de conteúdo persistente compatível com CMS;
- a publicação depende de autenticação e autorização válidas;
- o backend possui lógica de validação, persistência e publicação;
- há uma camada ou responsabilidade de **publicação / SEO / metadata** relevante na arquitetura;
- o conteúdo publicado passa a integrar a camada pública do site;
- a indexação por motores de busca ocorre a partir da **superfície pública exposta**, e não por ação direta do painel sobre buscadores;
- podem existir estados intermediários como rascunho e publicado, ainda que o detalhamento formal de estados pertença a outro documento.

## 4.2 Limites deste documento

Este arquivo não fixa sem prova de código:

- endpoint exato de criação/publicação;
- tecnologia exata de CMS;
- mecanismo exato de invalidação de cache ou rebuild;
- política detalhada de sitemap/canonical em runtime;
- fila assíncrona obrigatória de publicação;
- mecanismo exato de revalidação do frontend.

Seu papel é mostrar a **sequência arquitetural correta**, e não congelar um detalhe técnico ainda não confirmado.

## 4.3 Regra de prudência

Sempre que o mecanismo exato não estiver comprovado, este documento usa formulações como:

- **conteúdo persistido**
- **camada de publicação / SEO**
- **disponibilização pública**
- **superfície indexável**
- **atualização da camada pública compatível com a arquitetura**

---

## 5. Participantes da sequência

A sequência de publicação é compreendida a partir dos seguintes participantes técnicos e funcionais:

- **Administrador / Autor**: ator humano que cria, edita e decide publicar
- **Painel Administrativo / Frontend**: interface de edição e publicação
- **API Administrativa**: porta de entrada das operações de conteúdo
- **Validação de Contrato e Regras de Entrada**: camada que valida payload e pré-condições
- **Serviço de Conteúdo / CMS**: camada que trata a lógica editorial central
- **Persistência / Repositório de Conteúdo**: camada que grava e recupera dados estruturados
- **Serviço de Publicação / SEO / Metadata**: camada que transforma o conteúdo em conteúdo publicável/indexável
- **Camada Pública do Site**: superfície onde o conteúdo passa a ficar disponível
- **Motores de Busca**: atores externos que podem descobrir e indexar o conteúdo público

---

## 6. Visão geral da sequência

Em nível macro, a publicação de conteúdo segue esta lógica:

1. o administrador abre ou cria um conteúdo no painel;
2. preenche ou edita campos editoriais;
3. aciona a ação de publicar;
4. o frontend envia os dados à API administrativa;
5. a API valida contrato, autenticação e autorização;
6. o serviço de conteúdo persiste o conteúdo e o estado editorial apropriado;
7. a camada de publicação/SEO estrutura slug, metadata e prontidão pública;
8. o conteúdo passa a estar disponível na superfície pública;
9. a camada pública reflete a publicação;
10. a partir dessa exposição pública, o conteúdo se torna elegível à descoberta/indexação.

---

## 7. Diagrama principal — Sequência de Publicação de Conteúdo

```mermaid
sequenceDiagram
    actor Admin as Administrador / Autor
    participant UI as Painel Administrativo / Frontend
    participant API as API Administrativa
    participant VAL as Validação de Contrato / Regras de Entrada
    participant AUTHZ as Autorização / Acesso Administrativo
    participant CMS as Serviço de Conteúdo / CMS
    participant REPO as Repositório / Persistência de Conteúdo
    participant PUB as Serviço de Publicação / SEO / Metadata
    participant SITE as Camada Pública do Site
    participant SEARCH as Motores de Busca

    Admin->>UI: cria ou abre conteúdo existente
    UI-->>Admin: exibe editor administrativo

    Admin->>UI: preenche/edita título, corpo e campos editoriais
    UI->>UI: valida campos mínimos no frontend

    alt Dados locais inválidos
        UI-->>Admin: exibe erro de preenchimento
    else Dados locais válidos
        Admin->>UI: aciona publicar
        UI->>API: envia requisição administrativa de publicação

        API->>VAL: valida schema / contrato / consistência mínima
        alt Payload inválido
            VAL-->>API: falha de validação
            API-->>UI: erro de validação
            UI-->>Admin: exibe mensagem e mantém edição
        else Payload válido
            API->>AUTHZ: valida contexto autenticado e permissão
            alt Sem autenticação ou sem permissão
                AUTHZ-->>API: acesso negado
                API-->>UI: erro de autenticação/autorização
                UI-->>Admin: informa bloqueio de operação
            else Acesso permitido
                API->>CMS: solicita processamento editorial
                CMS->>REPO: criar/atualizar conteúdo e estado persistido
                REPO-->>CMS: conteúdo persistido

                CMS->>PUB: acionar preparação de publicação
                PUB->>PUB: resolver slug, metadata e prontidão pública
                PUB->>REPO: gravar dados editoriais/publicação, se necessário
                REPO-->>PUB: persistência confirmada

                PUB-->>CMS: publicação preparada
                CMS-->>API: operação concluída
                API-->>UI: sucesso de publicação + dados mínimos de retorno
                UI-->>Admin: confirma publicação bem-sucedida

                UI->>SITE: redireciona ou atualiza visão pública / preview / listagem
                SITE-->>Admin: conteúdo visível na camada pública

                SEARCH->>SITE: rastreia conteúdo publicado
                SITE-->>SEARCH: entrega página pública e sinais de indexação
            end
        end
    end
````

---

## 8. Leitura do diagrama

## 8.1 Início da sequência

A publicação começa com uma ação editorial no painel:

* abrir um conteúdo existente para edição; ou
* iniciar um novo conteúdo.

O painel exibe a interface administrativa apropriada para edição.

## 8.2 Preparação do conteúdo

O administrador preenche ou altera campos como:

* título;
* corpo;
* informações editoriais;
* campos auxiliares;
* eventualmente slug, metadata ou campos SEO, conforme o desenho do sistema.

Antes do envio ao backend, o frontend executa validações mínimas de integridade.

## 8.3 Submissão da publicação

Ao acionar “publicar”, o frontend envia uma requisição administrativa para a API.

Esse é o marco em que a intenção editorial vira operação técnica formal.

## 8.4 Validação de contrato e acesso

A API primeiro verifica:

* se o payload respeita o contrato;
* se o usuário está autenticado;
* se o usuário possui permissão para publicar.

Sem essas condições, o processo é interrompido antes da persistência.

## 8.5 Processamento editorial e persistência

Se a requisição for válida e autorizada, o serviço de conteúdo/CMS:

* trata a operação editorial;
* grava ou atualiza o conteúdo;
* define ou consolida o estado persistido coerente com a publicação.

## 8.6 Preparação de publicação e SEO

Depois da persistência editorial, o serviço de publicação/SEO:

* resolve ou valida slug;
* organiza metadata;
* ajusta informações necessárias à exposição pública;
* garante prontidão do conteúdo para ser mostrado no site.

## 8.7 Exposição pública

Com a publicação concluída, a camada pública do site passa a refletir o novo conteúdo ou a nova versão do conteúdo.

É nesse ponto que o conteúdo deixa de ser apenas registro interno e passa a integrar a experiência pública.

## 8.8 Descoberta e indexação

Somente após a exposição pública o conteúdo pode ser:

* visitado por usuários;
* rastreado por buscadores;
* indexado, de acordo com a política e o comportamento dos motores de busca.

A indexação não é “enviada” diretamente pelo painel; ela decorre da publicação pública e da estrutura SEO adequada.

---

## 9. Descrição detalhada das etapas

## 9.1 Abrir ou criar conteúdo no painel

### Finalidade

Iniciar a manipulação editorial do conteúdo.

### Responsabilidade principal

Administrador + painel.

### Resultado esperado

Editor administrativo aberto com conteúdo novo ou existente.

---

## 9.2 Preencher e editar dados editoriais

### Finalidade

Construir o conteúdo que poderá ser publicado.

### Responsabilidade principal

Administrador + frontend administrativo.

### Resultado esperado

Conteúdo pronto para validação e submissão.

### Observação

O painel deve permitir edição coerente com o modelo de conteúdo definido no projeto.

---

## 9.3 Validação local no frontend

### Finalidade

Evitar submissão de conteúdo claramente incompleto ou malformado.

### Responsabilidade principal

Frontend.

### Resultado esperado

Bloqueio de erros triviais antes da chamada à API.

### Limite

Não substitui validação backend.

---

## 9.4 Envio da requisição de publicação

### Finalidade

Transformar a ação editorial em operação formal da aplicação.

### Responsabilidade principal

Frontend.

### Resultado esperado

Payload administrativo enviado à API.

---

## 9.5 Validação do contrato de entrada

### Finalidade

Garantir integridade mínima do payload.

### Responsabilidade principal

API + camada de validação.

### Resultado esperado

Requisição aceita para processamento ou rejeitada.

---

## 9.6 Validação de autenticação e autorização

### Finalidade

Impedir que publicação seja executada por contexto inválido ou papel inadequado.

### Responsabilidade principal

API + camada de autorização.

### Resultado esperado

Operação permitida ou negada.

---

## 9.7 Processamento editorial no CMS

### Finalidade

Transformar a requisição em alteração persistente do conteúdo.

### Responsabilidade principal

Serviço de conteúdo / CMS.

### Resultado esperado

Conteúdo criado ou atualizado na persistência com consistência editorial mínima.

---

## 9.8 Persistência do conteúdo

### Finalidade

Registrar o conteúdo e seus dados estruturais.

### Responsabilidade principal

Repositório / persistência.

### Resultado esperado

Estado persistido da publicação disponível para as etapas seguintes.

---

## 9.9 Preparação de publicação / SEO / metadata

### Finalidade

Garantir que o conteúdo não apenas exista no banco, mas esteja pronto para exposição pública e descoberta.

### Responsabilidade principal

Serviço de publicação / SEO.

### Resultado esperado

Slug, metadata, estrutura de exposição e outros sinais públicos coerentes.

---

## 9.10 Confirmação ao frontend

### Finalidade

Encerrar a operação administrativa com resposta clara.

### Responsabilidade principal

API.

### Resultado esperado

Frontend recebe confirmação de sucesso e pode atualizar seu estado.

---

## 9.11 Reflexo na camada pública

### Finalidade

Tornar o conteúdo efetivamente visível no site.

### Responsabilidade principal

Camada pública do site.

### Resultado esperado

Página ou conteúdo público acessível.

---

## 9.12 Elegibilidade para indexação

### Finalidade

Permitir que buscadores descubram e, eventualmente, indexem o novo conteúdo.

### Responsabilidade principal

Camada pública do site + buscadores.

### Resultado esperado

Conteúdo disponível para rastreamento.

### Observação

A decisão final de indexação pertence ao buscador, não ao painel.

---

## 10. Fluxo de sucesso

O caminho ideal de sucesso é:

1. administrador edita ou cria conteúdo;
2. frontend valida minimamente;
3. backend aceita o payload;
4. autorização administrativa é confirmada;
5. conteúdo é persistido;
6. publicação/SEO é preparada;
7. resposta de sucesso retorna ao painel;
8. conteúdo aparece na camada pública;
9. a página se torna elegível à descoberta/indexação.

Esse é o fluxo central que conecta o painel à face pública do site.

---

## 11. Fluxos de falha

## 11.1 Falha de preenchimento local

Ocorre quando:

* campos mínimos não foram preenchidos;
* o formulário está evidentemente inconsistente.

### Efeito

Frontend bloqueia a submissão e mantém o administrador no editor.

---

## 11.2 Falha de contrato na API

Ocorre quando:

* o payload não respeita o schema;
* dados obrigatórios estão ausentes ou malformados;
* a estrutura enviada está inconsistente.

### Efeito

API devolve erro de validação; o conteúdo não é publicado.

---

## 11.3 Falha de autenticação ou autorização

Ocorre quando:

* a sessão/token é inválido;
* o contexto autenticado expirou;
* o papel não possui permissão para publicar.

### Efeito

A operação é interrompida antes da persistência ou da exposição pública.

---

## 11.4 Falha de persistência

Ocorre quando:

* o conteúdo não pode ser salvo;
* há inconsistência estrutural;
* ocorre erro interno na camada de repositório/persistência.

### Efeito

A publicação não deve ser considerada concluída.

---

## 11.5 Falha na preparação de publicação / SEO

Ocorre quando:

* slug, metadata ou informações estruturais não podem ser resolvidos;
* a camada de publicação encontra inconsistência impeditiva.

### Efeito

O sistema não deve sinalizar publicação completa como sucesso total.

---

## 12. Fronteiras de responsabilidade

## 12.1 Responsabilidade do painel / frontend administrativo

O painel é responsável por:

* oferecer interface de criação/edição;
* coletar dados editoriais;
* validar minimamente;
* disparar a ação de publicar;
* exibir sucesso ou falha;
* refletir o resultado da operação.

## 12.2 Responsabilidade da API

A API é responsável por:

* validar contrato;
* validar autenticação/autorização;
* encaminhar ao domínio correto;
* orquestrar conteúdo e publicação;
* devolver respostas padronizadas.

## 12.3 Responsabilidade do domínio de conteúdo / CMS

O domínio editorial é responsável por:

* tratar o conteúdo como entidade administrável;
* persistir ou atualizar dados editoriais;
* manter coerência entre edição e estado persistido.

## 12.4 Responsabilidade da camada de publicação / SEO

A camada de publicação/SEO é responsável por:

* estruturar o conteúdo para exposição pública;
* preparar campos de descoberta/indexação;
* garantir que o conteúdo publicado esteja coerente com a camada pública.

## 12.5 Responsabilidade da camada pública do site

A camada pública é responsável por:

* expor o conteúdo publicado;
* disponibilizar a página pública;
* servir como superfície indexável.

## 12.6 Responsabilidade dos motores de busca

Os buscadores são responsáveis apenas por:

* rastrear, quando decidirem fazê-lo;
* interpretar a página pública;
* indexar conforme suas próprias políticas.

O sistema não controla integralmente a decisão final de indexação.

---

## 13. Relação com conteúdo, CMS e SEO

Este documento deixa explícito que a publicação não é um único ato simples de “salvar”.

Ela envolve pelo menos três níveis:

### 13.1 Nível editorial

Criação e organização do conteúdo.

### 13.2 Nível estrutural

Persistência, estado e coerência do registro.

### 13.3 Nível público/indexável

Disponibilização da página, slug, metadata e prontidão para descoberta.

Essa separação é importante porque evita reduzir SEO/publicação a um detalhe invisível do fluxo editorial.

---

## 14. Relação com frontend e backend reais

Quando frontend e backend reais estiverem disponíveis, este documento deve ser usado para validar:

* se o painel realmente suporta o fluxo de publicar;
* se há separação entre criar, salvar e publicar;
* se o backend distingue conteúdo persistido de conteúdo efetivamente publicado;
* se existem campos editoriais/SEO coerentes;
* se o sucesso no painel corresponde a efeito real na camada pública;
* se erros em qualquer etapa são tratados corretamente.

Ou seja, este documento também funciona como matriz de auditoria funcional da publicação.

---

## 15. Relação com os diagramas anteriores

## 15.1 Relação com `013_Diagrama_de_Casos_de_Uso_do_Painel_Interno.md`

O `013` mostrou que publicar conteúdo é caso de uso central do painel.

O `015` mostra como isso acontece tecnicamente em sequência.

## 15.2 Relação com `010_Diagrama_de_Componentes_da_API.md`

O `010` mostrou os componentes internos da API.

O `015` mostra esses componentes em ação no cenário de publicação.

## 15.3 Relação com `012_Diagrama_de_Autorizacao_e_Papeis.md`

O `012` mostrou que publicar é recurso/ação protegida.

O `015` evidencia exatamente onde essa autorização participa da sequência.

---

## 16. Relação com os documentos seguintes

Este documento prepara diretamente a leitura e geração de:

* `016_Diagrama_de_Sequencia_Edicao_de_Postagem.md`
* `017_Diagrama_de_Sequencia_Consulta_Publica_do_Site.md`
* `018_Diagrama_de_Fluxo_das_Requisicoes_API.md`
* `022_Diagrama_de_Estados_da_Postagem.md`
* `042_Diagrama_de_Fluxo_Editorial.md`
* `043_Diagrama_de_Indexacao_e_SEO.md`
* `044_Diagrama_de_Geracao_e_Publicacao_de_Posts.md`

### Motivo

A sequência de publicação conecta backend, CMS, camada pública e SEO, e serve como base para os fluxos editoriais e públicos posteriores.

---

## 17. Observações de consistência

## 17.1 Coerência com o modelo de conteúdo

O fluxo respeita a necessidade de conteúdo estruturado e persistido antes da exposição pública.

## 17.2 Coerência com segurança

A publicação é tratada como operação protegida, dependente de autorização administrativa.

## 17.3 Coerência com API contract

A presença de validação, resposta de sucesso e falha padronizada preserva aderência contratual.

## 17.4 Coerência com SEO

A indexação não é representada como ato mágico; ela decorre da publicação pública e da estruturação adequada do conteúdo.

## 17.5 Coerência com UI/UX

O painel continua sendo o ponto de controle da operação editorial, com retorno claro ao administrador.

---

## 18. Critérios de aceite deste documento

Este documento será considerado adequado se:

* representar a sequência da publicação do painel até o site;
* incluir edição/criação, envio à API, validação, autorização, persistência, publicação e disponibilização pública;
* contemplar preparação de SEO/metadata;
* distinguir claramente responsabilidades entre painel, API, CMS, publicação e camada pública;
* mostrar falhas relevantes;
* manter prudência quanto a mecanismos técnicos não confirmados;
* permanecer coerente com conteúdo, API, UI/UX e SEO.

---

## 19. Conclusão executiva

A publicação de conteúdo no projeto William Albarello deve ser entendida como uma sequência arquitetural completa, e não como um simples botão que “salva um texto”.

Essa sequência envolve:

* trabalho editorial no painel;
* validação técnica e funcional;
* autorização administrativa;
* persistência estruturada;
* preparação de publicação e SEO;
* exposição na camada pública;
* elegibilidade para descoberta/indexação.

Esse desenho é essencial porque transforma a operação editorial em processo confiável, rastreável e coerente com a proposta de um site institucional com autoridade digital e gestão interna organizada.

---

