
# 014_Diagrama_de_Sequencia_Login

## 1. Identificação do documento

- **Projeto:** William Albarello
- **Diretório:** `02-Diagramas`
- **Caminho oficial:** `/home/user/Documents/Softwares/Willian Albarello/William Albarello/02-Diagramas/02-Backend_e_API/014_Diagrama_de_Sequencia_Login.md`
- **Natureza do documento:** Diagrama de sequência técnica do login
- **Função sistêmica:** Descrever, em ordem temporal, o fluxo técnico do login administrativo, desde a interface até a persistência do contexto autenticado e o acesso ao painel
- **Posição no bloco:** Sexto documento do bloco `02-Backend_e_API`
- **Dependência imediata:** `011_Diagrama_de_Fluxo_de_Autenticacao.md`, `012_Diagrama_de_Autorizacao_e_Papeis.md` e `013_Diagrama_de_Casos_de_Uso_do_Painel_Interno.md`

---

## 2. Objetivo

Este documento existe para detalhar a **sequência técnica do login administrativo** do projeto William Albarello.

Se o documento `011_Diagrama_de_Fluxo_de_Autenticacao.md` apresentou o fluxo ponta a ponta em nível lógico, este documento aprofunda o mesmo cenário em forma de **sequência temporal entre participantes técnicos**.

Seu objetivo é mostrar, em ordem:

- como a interface de login participa do processo;
- como as credenciais são coletadas e enviadas;
- como a API valida o payload;
- como a camada de autenticação verifica identidade e credencial;
- como a autorização inicial é resolvida;
- como a sessão ou token é gerado;
- como o frontend persiste o contexto autenticado;
- como ocorre o redirecionamento ao painel;
- como o sistema trata falhas em pontos diferentes da sequência.

Este arquivo não tenta descrever todos os detalhes do mecanismo criptográfico nem todos os estados possíveis de sessão. Seu foco é a **sequência técnica operacional do login**.

---

## 3. Fontes de referência no Waterfall

Este documento deriva principalmente dos seguintes arquivos do Diretório `01-Waterfall`:

- `015_Seguranca_Autenticacao_e_Autorizacao.md`
- `016_API_Contract_Mestre.md`

Fontes complementares relevantes:

- `014_Arquitetura_Tecnica.md`
- `017_UI_UX_Arquitetura_da_Informacao.md`
- `018_Plano_de_Testes_Homologacao_e_Qualidade.md`
- `021_Criterios_de_Aceite_Gerais.md`
- `023_Matriz_de_Rastreabilidade.md`
- `024_Registro_de_Decisoes_Arquiteturais.md`

Quando disponíveis, também devem ser confrontados:

- frontend real;
- backend real;
- endpoint real de login;
- modelo real de sessão/token;
- middlewares/guards reais;
- prints reais de tela e fluxo.

---

## 4. Premissas e limites

## 4.1 Premissas adotadas

Para fins deste documento, adotam-se as seguintes premissas conservadoras e coerentes com o projeto:

- existe uma **interface de login administrativo**;
- o login é voltado à entrada no painel interno;
- a API possui um contrato de autenticação definido ou inferível;
- o backend tem camada responsável por:
  - validação de entrada;
  - autenticação;
  - autorização inicial;
  - geração de sessão ou token;
- o frontend persiste o contexto autenticado de forma compatível com a arquitetura adotada;
- após autenticação bem-sucedida, o usuário é redirecionado ao painel administrativo;
- em caso de erro, o frontend permanece ou retorna ao estado de login com feedback apropriado.

## 4.2 Limites deste documento

Este arquivo não fixa sem prova de código:

- nome exato do endpoint;
- uso obrigatório de JWT, cookie httpOnly, session store ou outra estratégia específica;
- estratégia completa de refresh token;
- MFA;
- integração com provedor externo de identidade.

Seu papel é mostrar a **sequência técnica correta**, não congelar um detalhe tecnológico ainda não comprovado.

## 4.3 Regra de prudência

Sempre que o mecanismo exato não estiver documentalmente confirmado, o texto usa expressões como:

- **sessão ou token**
- **contexto autenticado**
- **armazenamento seguro compatível**
- **middleware / guarda de acesso**

---

## 5. Participantes da sequência

A sequência de login é compreendida a partir dos seguintes participantes técnicos:

- **Administrador**: ator humano que inicia a autenticação
- **Tela de Login / Frontend**: interface que coleta credenciais e trata retorno
- **API de Login**: ponto de entrada HTTP da autenticação
- **Validação de Contrato**: camada que verifica o payload de entrada
- **Serviço de Autenticação**: camada que executa a lógica de login
- **Repositório / Persistência de Usuário**: camada que localiza identidade e dados necessários
- **Motor de Segurança / Sessão**: camada que verifica credencial e emite contexto autenticado
- **Armazenamento Seguro no Frontend**: local/mecanismo adotado para manter o contexto autenticado
- **Painel Administrativo**: destino final após login bem-sucedido

---

## 6. Diagrama principal — Sequência do Login

```mermaid
sequenceDiagram
    actor Admin as Administrador
    participant UI as Tela de Login / Frontend
    participant API as API de Login
    participant VAL as Validação de Contrato
    participant AUTH as Serviço de Autenticação
    participant REPO as Repositório de Usuário
    participant SEC as Motor de Segurança / Sessão
    participant STORE as Armazenamento Seguro no Frontend
    participant DASH as Painel Administrativo

    Admin->>UI: abre tela de login
    UI-->>Admin: exibe formulário

    Admin->>UI: informa credenciais
    UI->>UI: valida campos obrigatórios e formato mínimo

    alt Dados locais inválidos
        UI-->>Admin: exibe erro de preenchimento
    else Dados locais válidos
        UI->>API: envia requisição de login
        API->>VAL: valida schema / contrato de entrada

        alt Payload inválido
            VAL-->>API: falha de validação
            API-->>UI: resposta de erro de validação
            UI-->>Admin: exibe mensagem e mantém login
        else Payload válido
            VAL-->>API: payload aceito
            API->>AUTH: solicita autenticação
            AUTH->>REPO: busca identidade do usuário

            alt Usuário inexistente ou inapto
                REPO-->>AUTH: identidade não encontrada / bloqueada
                AUTH-->>API: falha de autenticação
                API-->>UI: credenciais inválidas ou acesso negado
                UI-->>Admin: exibe erro
            else Usuário encontrado e apto
                REPO-->>AUTH: dados do usuário
                AUTH->>SEC: verificar credencial e resolver acesso inicial

                alt Credencial inválida
                    SEC-->>AUTH: credencial rejeitada
                    AUTH-->>API: falha de autenticação
                    API-->>UI: credenciais inválidas
                    UI-->>Admin: exibe erro
                else Credencial válida, mas sem permissão
                    SEC-->>AUTH: autenticado sem permissão administrativa
                    AUTH-->>API: acesso negado
                    API-->>UI: resposta de autorização insuficiente
                    UI-->>Admin: exibe erro
                else Credencial válida e acesso permitido
                    SEC-->>AUTH: contexto autenticado gerado
                    AUTH-->>API: login bem-sucedido
                    API-->>UI: sessão/token + dados mínimos do perfil
                    UI->>STORE: persistir contexto autenticado de forma segura
                    STORE-->>UI: contexto armazenado
                    UI->>DASH: redirecionar para painel
                    DASH-->>Admin: painel carregado
                end
            end
        end
    end
````

---

## 7. Leitura do diagrama

## 7.1 Início da sequência

O administrador inicia o processo ao abrir a tela de login. A interface apenas apresenta o formulário e aguarda credenciais.

Aqui, ainda não existe contexto autenticado.

## 7.2 Validação local no frontend

Ao preencher credenciais, a interface executa validações mínimas do lado do cliente, como:

* campos obrigatórios;
* formato mínimo esperado;
* prevenção de submissão vazia.

Essa etapa melhora UX, mas não autentica nada.

## 7.3 Entrada na API

Se os dados mínimos estiverem adequados, o frontend envia a requisição para a API de login.

A API não deve confiar no frontend. Por isso, o primeiro passo no backend é validar o contrato de entrada novamente.

## 7.4 Validação de contrato

A camada de validação recebe o payload e decide:

* se a estrutura está correta;
* se os campos obrigatórios existem;
* se o formato respeita o contrato.

Se essa etapa falhar, a sequência termina com erro de validação e o usuário permanece no login.

## 7.5 Autenticação propriamente dita

Com o payload aceito, a API delega ao serviço de autenticação, que:

* busca a identidade do usuário;
* verifica se o usuário existe;
* verifica se está apto a autenticar-se;
* aciona a verificação de credencial.

## 7.6 Verificação de credencial e permissão inicial

A camada de segurança/sessão decide:

* se a credencial confere;
* se o usuário possui acesso administrativo;
* se pode ser gerado contexto autenticado.

Aqui há três saídas negativas distintas:

* credencial inválida;
* identidade inexistente/inapta;
* identidade válida, mas sem permissão administrativa.

## 7.7 Geração de contexto autenticado

No cenário positivo, o motor de segurança/sessão devolve à API:

* sessão, token ou mecanismo equivalente;
* contexto mínimo de identidade;
* resultado de autenticação bem-sucedida.

A API responde ao frontend com esse material.

## 7.8 Persistência segura no frontend

Ao receber a resposta, o frontend:

* persiste o contexto autenticado de forma segura e compatível com a arquitetura;
* atualiza o estado local da aplicação;
* prepara a navegação protegida.

## 7.9 Redirecionamento ao painel

Depois da persistência segura do contexto autenticado, o usuário é redirecionado ao painel administrativo.

A partir desse momento, a navegação passa a depender de middleware/guardas e do contexto autenticado válido.

---

## 8. Descrição detalhada das etapas

## 8.1 Abertura da tela de login

### Finalidade

Iniciar o processo de autenticação administrativa.

### Responsabilidade principal

Frontend.

### Resultado esperado

Formulário disponível ao administrador.

---

## 8.2 Preenchimento das credenciais

### Finalidade

Permitir que o administrador forneça os dados necessários para autenticar-se.

### Responsabilidade principal

Administrador + frontend.

### Resultado esperado

Dados prontos para submissão.

---

## 8.3 Validação local do formulário

### Finalidade

Evitar submissões manifestamente inválidas.

### Responsabilidade principal

Frontend.

### Resultado esperado

Bloquear submissões vazias ou estruturalmente incoerentes antes da chamada remota.

### Observação

Não substitui a validação do backend.

---

## 8.4 Envio da requisição de login

### Finalidade

Solicitar autenticação ao backend.

### Responsabilidade principal

Frontend.

### Resultado esperado

Payload de login enviado à API conforme contrato.

---

## 8.5 Validação do contrato de entrada

### Finalidade

Garantir integridade estrutural da requisição.

### Responsabilidade principal

API + camada de validação.

### Resultado esperado

Requisição aceita para autenticação ou rejeitada por schema inválido.

---

## 8.6 Busca da identidade do usuário

### Finalidade

Localizar o usuário que tenta autenticar-se.

### Responsabilidade principal

Serviço de autenticação + repositório de usuário.

### Resultado esperado

Identidade encontrada e apta, ou falha apropriada.

---

## 8.7 Verificação da credencial

### Finalidade

Confirmar que o segredo apresentado corresponde ao esperado.

### Responsabilidade principal

Serviço de autenticação + motor de segurança.

### Resultado esperado

Credencial aceita ou rejeitada.

---

## 8.8 Resolução de permissão inicial

### Finalidade

Impedir que uma identidade válida, porém sem acesso administrativo, entre no painel.

### Responsabilidade principal

Serviço de autenticação + camada de autorização inicial.

### Resultado esperado

Acesso administrativo permitido ou negado.

---

## 8.9 Geração de sessão ou token

### Finalidade

Criar a prova de autenticação necessária para as próximas requisições.

### Responsabilidade principal

Motor de segurança/sessão.

### Resultado esperado

Contexto autenticado pronto para ser devolvido ao frontend.

---

## 8.10 Retorno da API

### Finalidade

Entregar ao frontend o resultado da autenticação.

### Responsabilidade principal

API.

### Resultado esperado

Resposta de sucesso ou erro, sempre em formato previsível.

---

## 8.11 Persistência segura do contexto autenticado

### Finalidade

Manter o usuário autenticado ao longo da navegação no painel.

### Responsabilidade principal

Frontend.

### Resultado esperado

Contexto autenticado armazenado de modo seguro e consistente.

### Observação

O mecanismo exato depende da arquitetura real, mas a exigência de segurança permanece.

---

## 8.12 Redirecionamento ao painel

### Finalidade

Concluir a sequência de login bem-sucedido.

### Responsabilidade principal

Frontend.

### Resultado esperado

Painel administrativo carregado sob contexto autenticado válido.

---

## 9. Cenários de falha contemplados

## 9.1 Falha de validação local

Ocorre quando:

* campos estão vazios;
* formato é insuficiente;
* o formulário não deve ser enviado.

### Efeito

Erro imediato no frontend, sem chamada ao backend.

---

## 9.2 Falha de contrato de entrada na API

Ocorre quando:

* payload chega quebrado;
* schema não é respeitado;
* os dados enviados não cumprem o contrato de login.

### Efeito

API devolve erro de validação; o frontend mantém o usuário no login.

---

## 9.3 Usuário inexistente ou inapto

Ocorre quando:

* a identidade não é localizada;
* a conta não está habilitada para autenticação.

### Efeito

Login negado antes da geração de sessão/token.

---

## 9.4 Credencial inválida

Ocorre quando:

* a identidade existe;
* mas o segredo informado não confere.

### Efeito

Falha de autenticação com retorno seguro ao frontend.

---

## 9.5 Falta de permissão administrativa

Ocorre quando:

* a identidade é válida;
* a autenticação técnica funciona;
* mas o papel não pode acessar o painel.

### Efeito

O usuário não recebe acesso à área administrativa.

---

## 10. Fronteiras de responsabilidade

## 10.1 O que pertence ao frontend

O frontend é responsável por:

* renderizar a tela de login;
* coletar credenciais;
* validar minimamente os campos;
* enviar a requisição;
* armazenar o contexto autenticado com segurança;
* redirecionar ao painel;
* exibir mensagens de erro ou sucesso.

## 10.2 O que pertence ao backend

O backend é responsável por:

* validar contrato de entrada;
* localizar identidade;
* verificar credencial;
* decidir acesso administrativo;
* gerar sessão/token/contexto autenticado;
* responder com formato consistente.

## 10.3 O que pertence à camada de segurança

A camada de segurança é responsável por:

* comparação/verificação de credencial;
* montagem do contexto autenticado;
* suporte à continuidade da sessão;
* reforço da proteção de rotas subsequentes.

---

## 11. Relação com o contrato de API

A sequência técnica de login pressupõe que o contrato de API consiga expressar claramente:

* estrutura de entrada do login;
* tipos de erro possíveis;
* formato da resposta de sucesso;
* formato da resposta de falha;
* material de contexto autenticado devolvido ao frontend.

Ou seja, este diagrama deve ser compatível com o contrato documental e, idealmente, com o contrato implementado.

---

## 12. Relação com testes

Este documento sustenta diretamente casos de teste como:

* login com payload válido;
* login com payload inválido;
* login com usuário inexistente;
* login com credencial incorreta;
* login com usuário sem permissão administrativa;
* login bem-sucedido com redirecionamento;
* falha em armazenamento do contexto autenticado, se aplicável;
* bloqueio de acesso ao painel sem contexto válido em sequência posterior.

Esses cenários reforçam sua utilidade prática para QA e homologação.

---

## 13. Relação com os diagramas anteriores

## 13.1 Relação com `011_Diagrama_de_Fluxo_de_Autenticacao.md`

O `011` apresentou o fluxo ponta a ponta em nível lógico.

O `014` transforma esse fluxo em sequência técnica entre participantes específicos.

## 13.2 Relação com `012_Diagrama_de_Autorizacao_e_Papeis.md`

O `012` explicou que autenticação não basta e que a autorização por papel é necessária.

O `014` mostra exatamente onde essa checagem entra na sequência do login.

## 13.3 Relação com `010_Diagrama_de_Componentes_da_API.md`

O `010` mostrou a anatomia da API.

O `014` mostra essa anatomia em ação no caso específico do login.

---

## 14. Relação com os documentos seguintes

Este documento prepara diretamente a leitura e geração de:

* `015_Diagrama_de_Sequencia_Publicacao_de_Conteudo.md`
* `016_Diagrama_de_Sequencia_Edicao_de_Postagem.md`
* `017_Diagrama_de_Sequencia_Consulta_Publica_do_Site.md`
* `018_Diagrama_de_Fluxo_das_Requisicoes_API.md`
* `039_Diagrama_de_Fluxo_de_Sessao.md`

### Motivo

A sequência de login é a base temporal de entrada na fronteira protegida e ajuda a organizar as demais sequências do sistema.

---

## 15. Observações de consistência

## 15.1 Coerência com segurança

A sequência distingue corretamente:

* validação de entrada;
* autenticação;
* autorização inicial;
* geração de contexto;
* armazenamento seguro;
* uso posterior do contexto.

## 15.2 Coerência com UI/UX

O diagrama respeita a necessidade de feedback claro ao usuário e de navegação consistente após sucesso ou falha.

## 15.3 Coerência com backend/API

O fluxo respeita uma arquitetura em camadas e não empurra toda a lógica para o frontend.

## 15.4 Coerência com critérios de aceite

A sequência permite provar tecnicamente o comportamento esperado do login administrativo.

---

## 16. Critérios de aceite deste documento

Este documento será considerado adequado se:

* representar a sequência técnica do login do início ao fim;
* incluir interface, envio de credenciais, validação, autenticação, autorização inicial, geração de sessão/token e persistência do contexto;
* mostrar redirecionamento ao painel após sucesso;
* contemplar falhas relevantes;
* distinguir responsabilidades de frontend, API, autenticação e persistência de contexto;
* manter prudência quanto a tecnologias específicas não comprovadas.

---

## 17. Conclusão executiva

A sequência de login do projeto William Albarello deve ser entendida como uma cadeia técnica disciplinada que conecta:

* interface de login;
* validação de entrada;
* serviço de autenticação;
* verificação de credencial;
* decisão inicial de acesso;
* geração de contexto autenticado;
* armazenamento seguro no frontend;
* redirecionamento ao painel.

Esse desenho é importante porque impede tratar login como simples “submissão de formulário” e o reposiciona como processo arquitetural completo, com papéis claros, pontos de falha controlados e continuidade de sessão coerente.

---


