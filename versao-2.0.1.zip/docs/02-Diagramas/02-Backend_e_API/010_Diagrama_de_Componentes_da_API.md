
# 010_Diagrama_de_Componentes_da_API

## 1. Identificação do documento

- **Projeto:** William Albarello
- **Diretório:** `02-Diagramas`
- **Caminho oficial:** `/home/user/Documents/Softwares/Willian Albarello/William Albarello/02-Diagramas/02-Backend_e_API/010_Diagrama_de_Componentes_da_API.md`
- **Natureza do documento:** Diagrama de componentes da API
- **Função sistêmica:** Explicar os componentes internos da camada de API, evidenciando rotas, autenticação, autorização, controllers, schemas, services, persistência e fluxo interno das requisições
- **Posição no bloco:** Segundo documento do bloco `02-Backend_e_API`
- **Dependência imediata:** `009_Diagrama_de_Modulos_do_Backend.md`

---

## 2. Objetivo

Este documento existe para detalhar a **camada de API** do backend do projeto William Albarello em um nível mais preciso do que o diagrama de módulos.

Se o documento `009_Diagrama_de_Modulos_do_Backend.md` respondeu:

**“quais módulos compõem o backend?”**

este documento responde:

**“como a API se organiza internamente para receber, validar, proteger, encaminhar, executar e persistir uma requisição?”**

Seu objetivo é permitir que qualquer leitor compreenda:

- quais são os componentes internos da API;
- qual é o papel da camada de rotas;
- onde entram autenticação e autorização;
- como controllers, services, schemas e persistência se articulam;
- qual é o fluxo interno de uma requisição pública ou administrativa;
- como a API preserva separação de responsabilidades.

Este documento ainda não entra em endpoints específicos nem em sequências detalhadas por caso de uso isolado. Seu foco é a **estrutura interna da API como sistema de componentes cooperantes**.

---

## 3. Fontes de referência no Waterfall

Este documento deriva principalmente dos seguintes arquivos do Diretório `01-Waterfall`:

- `014_Arquitetura_Tecnica.md`
- `015_Seguranca_Autenticacao_e_Autorizacao.md`
- `016_API_Contract_Mestre.md`

Fontes complementares relevantes:

- `005_Escopo_MVP_e_Fora_de_Escopo.md`
- `006_Requisitos_Funcionais.md`
- `007_Requisitos_Nao_Funcionais.md`
- `013_Modelo_de_Dados_e_CMS.md`
- `017_UI_UX_Arquitetura_da_Informacao.md`
- `018_Plano_de_Testes_Homologacao_e_Qualidade.md`
- `021_Criterios_de_Aceite_Gerais.md`
- `023_Matriz_de_Rastreabilidade.md`
- `024_Registro_de_Decisoes_Arquiteturais.md`

Quando disponíveis, também devem ser considerados:

- backend real;
- árvore real de diretórios;
- Swagger;
- prints de rotas;
- documentação viva da API.

---

## 4. Premissas e limites

## 4.1 Premissas adotadas

Na ausência de inspeção exaustiva do código real neste contexto, este documento adota as seguintes premissas conservadoras e coerentes com o corpus do projeto:

- a API possui separação entre entrada pública e entrada administrativa;
- a API possui alguma forma de camada de rotas/controllers;
- contratos de entrada e saída são formalizados por schemas/DTOs equivalentes;
- autenticação e autorização são aplicadas antes da execução dos casos de uso protegidos;
- a lógica de negócio principal não deve ficar nas rotas;
- services/casos de uso orquestram a operação;
- persistência é acessada por abstrações controladas;
- tratamento de erro e resposta devem ser padronizados;
- a API deve sustentar tanto o site público quanto o painel administrativo.

## 4.2 Limites deste documento

Este arquivo não detalha:

- cada endpoint individual;
- payloads específicos de cada rota;
- entidades e atributos do banco;
- estados completos de sessão ou conteúdo;
- infraestrutura de deploy;
- observabilidade e logs em detalhe;
- fluxos de sequência por caso de uso isolado.

Esses temas serão aprofundados nos documentos posteriores.

## 4.3 Regra de prudência

Na ausência de confirmação absoluta do código, o diagrama abaixo representa a **arquitetura de API tecnicamente mais coerente com os anexos**, sem presumir sobreengenharia nem estruturas artificiais.

---

## 5. Papel da API dentro da solução

A API do projeto William Albarello não deve ser entendida apenas como lista de rotas. Ela é a camada que:

- recebe requisições do frontend público e do painel;
- aplica políticas de segurança;
- valida dados;
- encaminha a execução ao domínio correto;
- aciona regras de negócio;
- coordena persistência;
- devolve respostas padronizadas.

Portanto, sua arquitetura precisa ser lida como um fluxo interno disciplinado, em que cada componente faz apenas o que lhe compete.

---

## 6. Modelo de componentes adotado

Neste documento, a camada de API é decomposta nas seguintes zonas:

- **Entradas da API**
- **Segurança e Controle**
- **Contratos e Validação**
- **Orquestração e Domínio**
- **Persistência**
- **Saída e Tratamento de Resposta**

Essa decomposição existe para deixar claro:

- quem recebe a chamada;
- quem valida;
- quem protege;
- quem decide;
- quem grava/lê;
- quem responde.

---

## 7. Diagrama principal — Componentes da API

```mermaid
flowchart LR

    subgraph entrada["Camada de Entrada da API"]
        rotas_publicas["Componente: Rotas Públicas"]
        rotas_admin["Componente: Rotas Administrativas"]
        controllers["Componente: Controllers / Handlers"]
    end

    subgraph seguranca["Camada de Segurança e Controle"]
        middleware_auth["Componente: Middleware / Guardas de Auth"]
        autorizacao["Componente: Autorização / Regras de Acesso"]
        sessao["Componente: Sessão / Token / Contexto de Identidade"]
    end

    subgraph contratos["Camada de Contratos"]
        schemas_in["Componente: Schemas de Entrada / DTOs"]
        validadores["Componente: Validação de Entrada"]
        schemas_out["Componente: Schemas de Saída / Response Models"]
    end

    subgraph dominio["Camada de Orquestração e Domínio"]
        services["Componente: Services / Casos de Uso"]
        conteudo["Componente: Domínio de Conteúdo / CMS"]
        publicacao["Componente: Domínio de Publicação / SEO"]
        leitura["Componente: Domínio de Leitura Pública"]
        admin["Componente: Domínio Administrativo"]
    end

    subgraph persist["Camada de Persistência"]
        repositories["Componente: Repositories / Gateways de Dados"]
        models["Componente: Models / Mapeamento de Persistência"]
        banco["Componente: Banco / CMS / Persistência Física"]
    end

    subgraph resposta["Camada de Saída"]
        errors["Componente: Tratamento de Erros / Exceções"]
        responses["Componente: Respostas Padronizadas"]
    end

    rotas_publicas -->|encaminham requisição| controllers
    rotas_admin -->|encaminham requisição| controllers

    rotas_admin -->|aplicam proteção| middleware_auth
    middleware_auth -->|resolve identidade| sessao
    middleware_auth -->|consulta permissões| autorizacao
    autorizacao -->|libera acesso ao handler| controllers

    controllers -->|desserializam e recebem contrato| schemas_in
    schemas_in -->|validam formato| validadores
    validadores -->|entregam dados válidos| services

    controllers -->|acionam casos de uso| services

    services -->|executam leitura pública| leitura
    services -->|executam gestão editorial| conteudo
    services -->|executam publicação e SEO| publicacao
    services -->|executam operações internas| admin

    leitura -->|consulta dados| repositories
    conteudo -->|lê/grava conteúdo| repositories
    publicacao -->|lê/grava publicação e metadados| repositories
    admin -->|consulta e atualiza dados internos| repositories

    repositories -->|usa mapeamento persistente| models
    models -->|acessa armazenamento| banco

    services -->|montam resultado| schemas_out
    controllers -->|convertem saída| schemas_out
    controllers -->|em falha| errors
    services -->|em falha| errors
    errors -->|normalizam erro| responses
    schemas_out -->|serializam resposta| responses

    classDef entry fill:#e8f0fe,stroke:#1a73e8,stroke-width:1px;
    classDef security fill:#fde8e8,stroke:#b42318,stroke-width:1px;
    classDef contract fill:#f3e8ff,stroke:#7e22ce,stroke-width:1px;
    classDef domain fill:#e6f4ea,stroke:#137333,stroke-width:1px;
    classDef persist fill:#fff4d6,stroke:#b06000,stroke-width:1px;
    classDef output fill:#f5f5f5,stroke:#333,stroke-width:1px;

    class rotas_publicas,rotas_admin,controllers entry
    class middleware_auth,autorizacao,sessao security
    class schemas_in,validadores,schemas_out contract
    class services,conteudo,publicacao,leitura,admin domain
    class repositories,models,banco persist
    class errors,responses output
````

---

## 8. Legenda e regras de leitura

## 8.1 Tipos de componente

Os elementos deste diagrama devem ser lidos assim:

* **Rotas**: ponto formal de entrada HTTP da API;
* **Controllers / Handlers**: camada que recebe a chamada já roteada e a encaminha corretamente;
* **Middleware / Guardas**: camada de interceptação para segurança e contexto;
* **Schemas / DTOs**: contratos formais de entrada e saída;
* **Validadores**: validação estrutural e de formato;
* **Services / Casos de Uso**: orquestração da lógica da aplicação;
* **Domínios**: responsabilidades funcionais específicas;
* **Repositories / Models / Banco**: persistência e abstração de dados;
* **Errors / Responses**: padronização de falhas e respostas.

## 8.2 Sentido das setas

As setas representam:

* encaminhamento lógico;
* dependência de execução;
* fluxo de processamento de requisição;
* relação de coordenação entre camadas.

Elas não devem ser lidas como cronograma exato de todos os fluxos nem como implementação literal de framework específico.

## 8.3 Regra de interpretação

O diagrama mostra a **anatomia interna da API** e o caminho macro que uma requisição percorre. Ele não substitui os diagramas de sequência posteriores, mas os prepara.

---

## 9. Fluxo interno de uma requisição

## 9.1 Entrada pela rota

Toda requisição chega primeiro por:

* `Rotas Públicas`, quando for consumo público;
* `Rotas Administrativas`, quando for operação protegida do painel.

A rota é a fronteira HTTP da API. Seu papel é:

* mapear URL/verbo;
* delegar ao handler correto;
* aplicar, quando necessário, proteção e contratos de entrada.

## 9.2 Passagem por segurança

Nas rotas administrativas, a chamada deve atravessar:

* `Middleware / Guardas de Auth`
* `Sessão / Token / Contexto de Identidade`
* `Autorização / Regras de Acesso`

Essa camada resolve:

* quem está chamando;
* se a identidade é válida;
* se a sessão/token é aceitável;
* se o ator possui permissão para a operação.

## 9.3 Controllers / Handlers

Depois do roteamento e da segurança inicial, a requisição alcança a camada de controllers/handlers.

Seu papel é:

* receber a chamada já contextualizada;
* acionar contratos de entrada;
* chamar o caso de uso adequado;
* devolver saída padronizada ou erro padronizado.

O controller não deve absorver regra de negócio pesada.

## 9.4 Schemas de entrada e validação

Antes da execução da lógica principal, a requisição passa por:

* `Schemas de Entrada / DTOs`
* `Validação de Entrada`

Essa camada resolve:

* formato de payload;
* campos obrigatórios;
* tipos e coerência estrutural;
* integridade mínima do contrato.

## 9.5 Services / Casos de Uso

Os services são o centro de orquestração da API. Eles:

* recebem dados já validados;
* escolhem o fluxo de negócio correto;
* articulam domínios funcionais;
* acionam persistência;
* montam resultado.

## 9.6 Domínios funcionais

Os services dialogam com domínios específicos conforme a natureza do caso de uso:

* `Domínio de Leitura Pública`
* `Domínio de Conteúdo / CMS`
* `Domínio de Publicação / SEO`
* `Domínio Administrativo`

Isso preserva separação de responsabilidades e evita concentrar toda a lógica em um único bloco.

## 9.7 Persistência

Quando necessário, os domínios usam:

* `Repositories / Gateways de Dados`
* `Models / Mapeamento de Persistência`
* `Banco / CMS / Persistência Física`

Essa camada garante que o acesso a dados seja mediado, previsível e testável.

## 9.8 Saída e tratamento de erros

Por fim, a API devolve:

* respostas padronizadas, via `Schemas de Saída / Response Models`;
* erros normalizados, via `Tratamento de Erros / Exceções`.

Isso evita respostas arbitrárias e preserva coerência contratual.

---

## 10. Explicação dos componentes por camada

## 10.1 Camada de Entrada da API

### Rotas Públicas

Responsáveis por expor endpoints públicos usados pelo site, leitura de conteúdo e capacidades não protegidas.

### Rotas Administrativas

Responsáveis por expor endpoints protegidos usados pelo painel interno.

### Controllers / Handlers

Responsáveis por coordenar o recebimento da requisição, acionar validação e delegar ao caso de uso correto.

### Regra desta camada

A camada de entrada não deve concentrar regra de negócio pesada nem acesso direto ao banco.

---

## 10.2 Camada de Segurança e Controle

### Middleware / Guardas de Auth

Responsável por interceptar chamadas protegidas e garantir pré-condições de segurança.

### Autorização / Regras de Acesso

Responsável por decidir se a identidade autenticada pode ou não executar a operação.

### Sessão / Token / Contexto de Identidade

Responsável por manter contexto de quem chama, token, sessão ou equivalente.

### Regra desta camada

Segurança deve ser transversal, mas não deve contaminar todo o sistema a ponto de embaralhar fronteiras arquiteturais.

---

## 10.3 Camada de Contratos

### Schemas de Entrada / DTOs

Responsáveis por formalizar o que a API aceita receber.

### Validação de Entrada

Responsável por garantir integridade estrutural do que entra.

### Schemas de Saída / Response Models

Responsáveis por formalizar o que a API devolve.

### Regra desta camada

Contratos devem ser explícitos, estáveis e independentes da persistência física.

---

## 10.4 Camada de Orquestração e Domínio

### Services / Casos de Uso

Responsáveis por orquestrar a lógica da aplicação, coordenando validação final, domínio e persistência.

### Domínio de Conteúdo / CMS

Responsável por gestão editorial, conteúdo e estrutura de CMS.

### Domínio de Publicação / SEO

Responsável por disponibilização pública, metadados, slugs e regras editoriais de publicação.

### Domínio de Leitura Pública

Responsável por entregar conteúdo e dados públicos de forma coerente.

### Domínio Administrativo

Responsável por ações protegidas do painel e governança interna da aplicação.

### Regra desta camada

É aqui que deve morar a lógica relevante do sistema, e não nas rotas.

---

## 10.5 Camada de Persistência

### Repositories / Gateways de Dados

Responsáveis por abstrair acesso a dados.

### Models / Mapeamento de Persistência

Responsáveis por representar ou mediar o vínculo com a camada persistente.

### Banco / CMS / Persistência Física

Responsável por armazenar efetivamente dados e conteúdo.

### Regra desta camada

Persistência deve ser acessada por mediação controlada e nunca diretamente pela camada de entrada.

---

## 10.6 Camada de Saída

### Tratamento de Erros / Exceções

Responsável por capturar falhas e transformá-las em respostas coerentes e previsíveis.

### Respostas Padronizadas

Responsável por uniformizar a saída da API.

### Regra desta camada

Nenhuma falha relevante deve “escapar crua” da API sem normalização adequada.

---

## 11. Responsabilidades por camada

## 11.1 Entrada

Responsável por:

* receber;
* rotear;
* encaminhar.

## 11.2 Segurança

Responsável por:

* autenticar;
* autorizar;
* manter contexto.

## 11.3 Contratos

Responsável por:

* formalizar entrada e saída;
* validar estrutura.

## 11.4 Orquestração e domínio

Responsável por:

* decidir;
* executar;
* coordenar.

## 11.5 Persistência

Responsável por:

* ler;
* gravar;
* manter estado.

## 11.6 Saída

Responsável por:

* responder;
* normalizar;
* reportar erro com consistência.

---

## 12. Dependências aceitáveis

Este documento considera aceitáveis, em arquitetura saudável de API, as seguintes dependências:

* rotas → controllers;
* rotas administrativas → middleware/guardas;
* controllers → schemas/DTOs;
* controllers → services;
* services → domínios funcionais;
* domínios → repositories;
* repositories → models/persistência;
* controllers/services → tratamento de erro;
* services/controllers → schemas de saída.

### Regra

As dependências devem seguir fluxo de responsabilidade descendente e previsível.

---

## 13. Dependências que devem ser evitadas

Devem ser evitadas, salvo justificativa muito forte:

* rotas acessando banco diretamente;
* controllers contendo regra editorial profunda;
* controllers contendo RBAC completo inline;
* schemas contendo regra de negócio rica;
* repositories decidindo política de autorização;
* models definindo comportamento de domínio complexo;
* camada de persistência conhecendo detalhes de interface;
* saída padronizada sendo construída manualmente em cada rota de forma inconsistente.

### Regra de ouro

Quando a rota sabe demais, a API está mal distribuída.

---

## 14. Fronteiras internas da API

## 14.1 Fronteira entre rotas e lógica

Rotas devem expor a API, não carregar o domínio.

## 14.2 Fronteira entre segurança e negócio

Segurança protege acesso, mas não substitui domínio funcional.

## 14.3 Fronteira entre contratos e domínio

DTOs descrevem estrutura, mas não devem decidir a regra do sistema.

## 14.4 Fronteira entre domínio e persistência

Domínio opera conceitos do produto; persistência guarda estado.

## 14.5 Fronteira entre erro técnico e erro de negócio

A API deve conseguir distinguir:

* falha de validação;
* falha de autenticação/autorização;
* falha de regra de negócio;
* falha interna;
* falha de persistência.

---

## 15. Relação com o backend real e com Swagger

Quando o backend real e/ou Swagger estiverem disponíveis, este documento deve ser usado como matriz de conferência para validar:

* se a separação entre rotas públicas e administrativas existe de fato;
* se contratos de entrada/saída estão bem definidos;
* se controllers estão finos ou obesos;
* se existe camada de service/casos de uso;
* se a persistência está devidamente mediada;
* se tratamento de erro e segurança estão organizados;
* se o comportamento real da API respeita a arquitetura pretendida.

Ou seja, este documento também serve como ferramenta de auditoria arquitetural.

---

## 16. Relação deste documento com o diagrama de módulos do backend

O documento `009_Diagrama_de_Modulos_do_Backend.md` apresentou os módulos do backend em visão estrutural ampla.

Este documento `010_Diagrama_de_Componentes_da_API.md` faz um recorte mais fino:

* o foco sai do backend inteiro;
* e passa para a **camada de API como mecanismo interno de entrada, segurança, contrato, execução e resposta**.

Em resumo:

* `009` responde: **como o backend se divide em módulos/domínios**;
* `010` responde: **como a API funciona por dentro**.

---

## 17. Relação com os documentos seguintes

Este documento prepara diretamente a leitura e geração de:

* `011_Diagrama_de_Fluxo_de_Autenticacao.md`
* `012_Diagrama_de_Autorizacao_e_Papeis.md`
* `014_Diagrama_de_Sequencia_Login.md`
* `015_Diagrama_de_Sequencia_Publicacao_de_Conteudo.md`
* `016_Diagrama_de_Sequencia_Edicao_de_Postagem.md`
* `017_Diagrama_de_Sequencia_Consulta_Publica_do_Site.md`
* `018_Diagrama_de_Fluxo_das_Requisicoes_API.md`

### Motivo

Todos esses arquivos dependem de entendimento prévio da anatomia interna da API.

---

## 18. Observações de consistência

## 18.1 Coerência com arquitetura técnica

A API aparece aqui como camada disciplinada e mediadora, coerente com a arquitetura técnica do projeto.

## 18.2 Coerência com segurança

A segurança está representada como camada transversal relevante, em conformidade com o documento de autenticação e autorização.

## 18.3 Coerência com contrato de API

A presença explícita de schemas, validação e respostas padronizadas preserva aderência ao contrato mestre.

## 18.4 Coerência com backend modular

O desenho não contradiz o diagrama de módulos do backend; ele o aprofunda em uma área específica.

## 18.5 Coerência com QA e testes

A separação em camadas favorece testabilidade, previsibilidade e menor acoplamento.

---

## 19. Critérios de aceite deste documento

Este documento será considerado adequado se:

* explicar com clareza os componentes internos da API;
* representar rotas públicas e administrativas;
* explicitar middleware/guardas, sessão e autorização;
* mostrar controllers, schemas, validação, services, domínios e persistência;
* apresentar um fluxo interno coerente de requisição;
* preservar separação de responsabilidades por camada;
* evitar detalhe excessivo de endpoint;
* permanecer consistente com arquitetura técnica, segurança e contrato de API.

---

## 20. Conclusão executiva

A camada de API do projeto William Albarello deve ser entendida como uma arquitetura interna organizada em:

* entradas públicas e administrativas;
* proteção por autenticação, autorização e sessão;
* contratos formais de entrada e saída;
* controllers enxutos;
* services/casos de uso como orquestradores;
* domínios funcionais distintos;
* persistência mediada por abstrações;
* respostas e erros padronizados.

Esse desenho é importante porque impede que a API se transforme em um bloco confuso de rotas acopladas diretamente ao banco, sem contrato, sem separação de responsabilidades e sem controle de acesso estruturado.

Este documento fixa a anatomia da API e prepara o avanço para fluxos mais específicos de autenticação, autorização e casos de uso concretos.

---

