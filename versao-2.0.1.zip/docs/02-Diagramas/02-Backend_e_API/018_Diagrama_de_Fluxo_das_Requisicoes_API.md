
# 018_Diagrama_de_Fluxo_das_Requisicoes_API

## 1. Identificação do documento

- **Projeto:** William Albarello
- **Diretório:** `02-Diagramas`
- **Caminho oficial:** `/home/user/Documents/Softwares/Willian Albarello/William Albarello/02-Diagramas/02-Backend_e_API/018_Diagrama_de_Fluxo_das_Requisicoes_API.md`
- **Natureza do documento:** Diagrama global do fluxo de requisições da API
- **Função sistêmica:** Mapear o ciclo de vida completo das requisições da API, desde a entrada até a resposta final, incluindo validação, autenticação, autorização, orquestração, persistência e tratamento de erros
- **Posição no bloco:** Décimo documento do bloco `02-Backend_e_API`
- **Dependência imediata:** `010_Diagrama_de_Componentes_da_API.md`, `011_Diagrama_de_Fluxo_de_Autenticacao.md`, `012_Diagrama_de_Autorizacao_e_Papeis.md`, `014_Diagrama_de_Sequencia_Login.md`, `015_Diagrama_de_Sequencia_Publicacao_de_Conteudo.md`, `016_Diagrama_de_Sequencia_Edicao_de_Postagem.md` e `017_Diagrama_de_Sequencia_Consulta_Publica_do_Site.md`

---

## 2. Objetivo

Este documento existe para consolidar, em uma visão única e sistêmica, **como uma requisição percorre a API do projeto William Albarello**.

Se os documentos anteriores deste bloco detalharam fluxos específicos, como:

- autenticação;
- autorização;
- login;
- publicação;
- edição;
- consulta pública;

este documento responde a uma pergunta mais ampla:

**“qual é o ciclo de vida geral de qualquer requisição da API, do recebimento até a resposta?”**

Seu objetivo é mostrar, de forma organizada e operacional:

- como a requisição entra na API;
- como é roteada;
- como o contrato é validado;
- quando autenticação e autorização se aplicam;
- como a camada de serviços/casos de uso é acionada;
- como a persistência é consultada ou atualizada;
- como o resultado é transformado em resposta;
- como falhas são classificadas e tratadas.

Este documento não substitui os diagramas específicos. Ele funciona como **mapa-mestre da circulação interna das requisições**.

---

## 3. Fontes de referência no Waterfall

Este documento deriva principalmente dos seguintes arquivos do Diretório `01-Waterfall`:

- `014_Arquitetura_Tecnica.md`
- `015_Seguranca_Autenticacao_e_Autorizacao.md`
- `016_API_Contract_Mestre.md`
- `018_Plano_de_Testes_Homologacao_e_Qualidade.md`

Fontes complementares relevantes:

- `005_Escopo_MVP_e_Fora_de_Escopo.md`
- `006_Requisitos_Funcionais.md`
- `007_Requisitos_Nao_Funcionais.md`
- `013_Modelo_de_Dados_e_CMS.md`
- `017_UI_UX_Arquitetura_da_Informacao.md`
- `021_Criterios_de_Aceite_Gerais.md`
- `023_Matriz_de_Rastreabilidade.md`
- `024_Registro_de_Decisoes_Arquiteturais.md`

Quando disponíveis, também devem ser confrontados:

- backend real;
- Swagger;
- contratos reais de endpoints;
- middlewares/guards reais;
- estrutura real de services e repositories;
- respostas reais da API em cenários de sucesso e falha.

---

## 4. Premissas e limites

## 4.1 Premissas adotadas

Para fins deste documento, adotam-se as seguintes premissas conservadoras e coerentes com o projeto:

- a API possui rotas públicas e rotas administrativas;
- a API trabalha com contratos formais de entrada e saída;
- a validação de entrada ocorre antes da execução da lógica principal;
- autenticação e autorização são aplicadas nas rotas protegidas;
- a camada de serviços/casos de uso centraliza orquestração;
- a persistência é acessada por abstrações como repositórios ou equivalentes;
- há tratamento padronizado de respostas e falhas;
- o backend deve ser capaz de sustentar tanto leitura pública quanto operações administrativas.

## 4.2 Limites deste documento

Este arquivo não detalha:

- cada endpoint individualmente;
- cada payload específico;
- cada entidade do banco;
- códigos HTTP exatos por cenário, salvo em nível conceitual;
- política detalhada de observabilidade;
- estratégia específica de cache;
- tecnologia exata de framework.

Seu foco é o **fluxo arquitetural global das requisições**.

## 4.3 Regra de prudência

Sempre que o código real não estiver plenamente disponível, este documento usa formulações arquiteturais estáveis, como:

- **rota pública / rota administrativa**
- **middleware / guarda**
- **contrato de entrada**
- **serviço / caso de uso**
- **repositório / persistência**
- **resposta padronizada**
- **tratamento de erro**

---

## 5. Visão geral do ciclo de vida da requisição

Toda requisição da API, em nível macro, percorre a seguinte cadeia:

1. entrada pela rota correspondente;
2. identificação do tipo de rota;
3. validação do contrato de entrada;
4. autenticação, quando aplicável;
5. autorização, quando aplicável;
6. execução do caso de uso/serviço;
7. acesso à persistência, quando necessário;
8. transformação do resultado em resposta;
9. retorno de sucesso ou erro padronizado.

Essa cadeia é o “esqueleto” do comportamento da API.

---

## 6. Diagrama principal — Fluxo Global das Requisições da API

```mermaid
flowchart TD

    A["Requisição entra na API"] --> B["Roteamento da requisição"]
    B --> C{"Rota pública ou protegida?"}

    C -- "Pública" --> D["Aplicar validação de contrato de entrada"]
    C -- "Protegida" --> E["Aplicar middleware / guarda de autenticação"]

    E --> F{"Contexto autenticado válido?"}
    F -- "Não" --> G["Retornar erro de autenticação"]
    F -- "Sim" --> H["Aplicar autorização por papel/recurso/ação"]

    H --> I{"Acesso autorizado?"}
    I -- "Não" --> J["Retornar erro de autorização"]
    I -- "Sim" --> D

    D --> K{"Payload / parâmetros válidos?"}
    K -- "Não" --> L["Retornar erro de validação"]
    K -- "Sim" --> M["Encaminhar para controller / handler"]

    M --> N["Acionar service / caso de uso"]
    N --> O{"Requer leitura/escrita em persistência?"}

    O -- "Não" --> P["Montar resultado de domínio"]
    O -- "Sim" --> Q["Acionar repositório / gateway de dados"]
    Q --> R["Consultar ou atualizar persistência"]
    R --> S{"Operação de persistência bem-sucedida?"}

    S -- "Não" --> T["Retornar erro de persistência / erro interno"]
    S -- "Sim" --> P

    P --> U["Aplicar schemas de saída / normalização da resposta"]
    U --> V["Retornar resposta padronizada de sucesso"]

    G --> W["Tratamento padronizado de erro"]
    J --> W
    L --> W
    T --> W

    W --> X["Retornar resposta padronizada de falha"]
````

---

## 7. Leitura do diagrama

## 7.1 Entrada e roteamento

Toda requisição começa quando a API recebe uma chamada e a encaminha para a rota correspondente.

O roteamento responde, em essência:

* qual endpoint foi chamado;
* qual handler/controller deve ser acionado;
* se a rota pertence ao espaço público ou protegido.

## 7.2 Classificação da rota

A primeira bifurcação importante do fluxo é:

* rota pública;
* rota protegida.

Essa distinção é fundamental porque define se a requisição:

* pode seguir direto para validação de contrato; ou
* precisa antes atravessar autenticação e autorização.

## 7.3 Validação de autenticação

Nas rotas protegidas, a requisição precisa provar que existe:

* contexto autenticado;
* sessão/token válido;
* identidade resolvida.

Se isso falhar, a requisição não deve alcançar a lógica de negócio.

## 7.4 Validação de autorização

Mesmo com autenticação válida, ainda é preciso decidir se o papel do usuário pode:

* acessar aquele recurso;
* executar aquela ação.

Se essa etapa falhar, a requisição também não deve alcançar a lógica de negócio.

## 7.5 Validação de contrato

Uma vez superadas as barreiras de segurança aplicáveis, a API valida:

* payload;
* parâmetros;
* tipos;
* consistência estrutural;
* aderência ao contrato esperado.

Sem contrato válido, a lógica principal não deve ser executada.

## 7.6 Controller / Handler

Depois da validação, a requisição é encaminhada ao handler/controller adequado, que:

* recebe dados já pré-filtrados;
* não deve concentrar a regra de negócio;
* delega ao service ou caso de uso correto.

## 7.7 Service / Caso de uso

A camada de serviços:

* interpreta a intenção da operação;
* orquestra domínios;
* decide fluxo funcional;
* aciona persistência, se necessário;
* prepara o resultado da operação.

## 7.8 Persistência

Se a operação exigir dados, o fluxo passa por:

* repositório/gateway;
* modelo/mapeamento persistente;
* armazenamento principal.

Se a persistência falhar, a API não deve sinalizar sucesso.

## 7.9 Resposta

Com o resultado da operação resolvido, a API:

* aplica schema de saída;
* normaliza a resposta;
* devolve sucesso padronizado.

Se houver erro, a falha é:

* classificada;
* normalizada;
* devolvida de forma consistente.

---

## 8. Descrição detalhada das etapas

## 8.1 Requisição entra na API

### Finalidade

Iniciar o processamento formal da chamada.

### Responsabilidade principal

Camada de entrada / roteamento.

### Resultado esperado

Requisição reconhecida e associada a uma rota conhecida.

---

## 8.2 Roteamento da requisição

### Finalidade

Identificar o endpoint e seu handler correspondente.

### Responsabilidade principal

Camada de rotas.

### Resultado esperado

Requisição encaminhada ao fluxo correto.

### Observação

Se a rota não existir, a falha pode ocorrer já aqui, antes mesmo de qualquer lógica adicional.

---

## 8.3 Determinar se a rota é pública ou protegida

### Finalidade

Definir se a requisição precisa atravessar segurança obrigatória.

### Responsabilidade principal

Camada de rotas + política de proteção.

### Resultado esperado

Classificação correta da rota.

---

## 8.4 Middleware / guarda de autenticação

### Finalidade

Verificar se há contexto autenticado válido nas rotas protegidas.

### Responsabilidade principal

Camada de segurança.

### Resultado esperado

Requisição autenticada ou bloqueada por falta de autenticação.

---

## 8.5 Autorização por papel/recurso/ação

### Finalidade

Impedir que contexto autenticado sem permissão suficiente execute operação indevida.

### Responsabilidade principal

Camada de autorização.

### Resultado esperado

Permissão concedida ou negada.

---

## 8.6 Validação do contrato de entrada

### Finalidade

Garantir integridade estrutural antes da lógica de negócio.

### Responsabilidade principal

Schemas / validação de entrada.

### Resultado esperado

Payload aceito ou rejeitado.

---

## 8.7 Encaminhamento ao controller / handler

### Finalidade

Transferir o fluxo para a camada responsável por iniciar o caso de uso.

### Responsabilidade principal

Controller / handler.

### Resultado esperado

Chamada do service correto.

---

## 8.8 Acionamento do service / caso de uso

### Finalidade

Executar a lógica principal da operação.

### Responsabilidade principal

Service / camada de aplicação.

### Resultado esperado

Resultado funcional da operação, com ou sem persistência.

---

## 8.9 Consulta ou atualização da persistência

### Finalidade

Ler ou gravar o estado necessário à operação.

### Responsabilidade principal

Repositório / gateway + persistência.

### Resultado esperado

Dados recuperados, atualização confirmada ou erro de persistência.

---

## 8.10 Normalização da saída

### Finalidade

Garantir resposta previsível ao consumidor da API.

### Responsabilidade principal

Schemas de saída / camada de resposta.

### Resultado esperado

Payload de sucesso consistente.

---

## 8.11 Tratamento de falhas

### Finalidade

Padronizar erros e impedir respostas arbitrárias ou confusas.

### Responsabilidade principal

Camada de tratamento de exceções / erros.

### Resultado esperado

Resposta de falha coerente com a natureza do problema.

---

## 9. Classes de requisição contempladas por este fluxo

O fluxo global deste documento deve acomodar, em termos arquiteturais, pelo menos as seguintes classes de requisição:

## 9.1 Requisições públicas

Exemplos conceituais:

* consulta de conteúdo público;
* leitura de página;
* resolução de recurso público.

### Característica

Não exigem autenticação, mas ainda exigem:

* contrato válido;
* regra de exposição pública;
* leitura consistente.

---

## 9.2 Requisições administrativas autenticadas

Exemplos conceituais:

* login já estabelecido e acesso ao painel;
* listar conteúdos;
* criar/editar/publicar;
* operar metadata;
* ações administrativas internas.

### Característica

Exigem:

* autenticação;
* autorização;
* contrato válido;
* lógica de domínio;
* persistência.

---

## 9.3 Requisições de autenticação

Exemplos conceituais:

* login;
* eventual logout;
* renovação de contexto, se houver.

### Característica

São um caso especial:

* não são públicas como leitura comum;
* mas também não partem de contexto autenticado já estabelecido, no caso do login inicial.

---

## 10. Fluxos de falha globais

## 10.1 Falha de autenticação

Ocorre quando:

* rota protegida exige autenticação;
* o contexto não existe, expirou, foi revogado ou é inválido.

### Resultado

A requisição é interrompida antes da lógica principal.

---

## 10.2 Falha de autorização

Ocorre quando:

* o contexto autenticado é válido;
* mas o papel não pode executar a ação no recurso.

### Resultado

A operação é negada antes da regra de negócio.

---

## 10.3 Falha de validação

Ocorre quando:

* payload ou parâmetros não respeitam o contrato;
* há inconsistência estrutural.

### Resultado

A lógica principal não é executada.

---

## 10.4 Falha de persistência

Ocorre quando:

* a operação de banco/CMS falha;
* há erro na leitura ou escrita;
* o estado necessário não pode ser garantido.

### Resultado

A API não deve devolver sucesso.

---

## 10.5 Falha interna não prevista

Ocorre quando:

* há erro de aplicação não classificado em camada anterior;
* há exceção não tratada no domínio;
* ocorre falha inesperada durante orquestração.

### Resultado

O erro deve ser capturado e normalizado pela camada de tratamento global.

---

## 11. Fronteiras de responsabilidade no fluxo da API

## 11.1 Camada de entrada

Responsável por:

* receber;
* rotear;
* classificar a rota.

Não deve carregar regra de negócio pesada.

## 11.2 Camada de segurança

Responsável por:

* autenticação;
* autorização;
* proteção de rotas.

Não deve assumir todo o domínio funcional.

## 11.3 Camada de contrato

Responsável por:

* aceitar ou rejeitar a forma da entrada;
* padronizar a forma da saída.

Não deve decidir o negócio em profundidade.

## 11.4 Camada de serviços / domínio

Responsável por:

* executar o caso de uso;
* coordenar operações;
* acionar persistência;
* produzir o resultado funcional.

## 11.5 Camada de persistência

Responsável por:

* ler;
* gravar;
* manter estado.

Não deve decidir política de negócio rica nem segurança de alto nível.

## 11.6 Camada de resposta / erro

Responsável por:

* transformar resultado em resposta utilizável;
* transformar falha em erro compreensível e padronizado.

---

## 12. Relação com segurança

Este documento reforça que a segurança da API não se limita ao login. Ela aparece no fluxo global como:

* autenticação em rotas protegidas;
* autorização por papel/recurso/ação;
* negação antecipada de acesso;
* separação entre público e protegido;
* não execução de lógica sensível sem contexto válido.

Isso significa que a segurança está embutida no ciclo de vida da requisição, não apenas em um endpoint isolado.

---

## 13. Relação com contrato de API

O fluxo global depende de um contrato de API bem definido porque:

* sem contrato, a validação de entrada fica fraca;
* sem contrato, a saída tende à inconsistência;
* sem contrato, testes e integração frontend/backend ficam frágeis.

Este documento reforça que o contrato não é apêndice documental. Ele é parte ativa do fluxo das requisições.

---

## 14. Relação com testes e QA

O diagrama global de fluxo da API sustenta a derivação de casos de teste para:

* rotas públicas válidas;
* rotas públicas inválidas;
* rotas protegidas sem autenticação;
* rotas protegidas com autenticação, mas sem autorização;
* payload inválido;
* sucesso de leitura;
* sucesso de atualização;
* falha de persistência;
* falha interna tratada;
* resposta de erro padronizada;
* resposta de sucesso padronizada.

Isso o torna particularmente útil para QA, homologação e auditoria técnica.

---

## 15. Relação com Swagger e backend real

Quando Swagger e backend real estiverem disponíveis, este documento deve ser usado como matriz de verificação para responder:

* as rotas estão corretamente classificadas em públicas e protegidas?
* a autenticação está aplicada onde deveria?
* a autorização é verificável?
* os contratos de entrada/saída estão coerentes com o fluxo?
* existem camadas visíveis de service e persistência, ou a lógica está colapsada nas rotas?
* as respostas de erro e sucesso são consistentes?
* o comportamento real do backend respeita a arquitetura pretendida?

Em outras palavras: este documento também serve como **instrumento de inspeção arquitetural do backend implementado**.

---

## 16. Relação com os diagramas anteriores

## 16.1 Relação com `010_Diagrama_de_Componentes_da_API.md`

O `010` mostrou os componentes internos da API.

O `018` mostra o fluxo transversal que percorre esses componentes em praticamente qualquer requisição.

## 16.2 Relação com `011`, `014`, `015`, `016` e `017`

Esses documentos mostraram cenários específicos:

* autenticação;
* login;
* publicação;
* edição;
* consulta pública.

O `018` generaliza esses cenários em um único mapa arquitetural de circulação.

## 16.3 Relação com `012_Diagrama_de_Autorizacao_e_Papeis.md`

O `012` mostrou quando e por que uma requisição deve ser autorizada.

O `018` mostra onde essa decisão entra no ciclo de vida global da chamada.

---

## 17. Relação com os documentos seguintes

Este documento prepara diretamente a leitura e geração de:

* `019_Diagrama_ER_Entidade_Relacionamento.md`
* `021_Diagrama_do_Modelo_de_Dados_de_Usuarios_e_Papeis.md`
* `024_Diagrama_de_Backup_e_Restauracao.md`
* `038_Diagrama_de_Seguranca_da_Aplicacao.md`
* `039_Diagrama_de_Fluxo_de_Sessao.md`
* `041_Diagrama_de_Auditoria_e_Rastreabilidade.md`
* `047_Mapa_de_Rastreabilidade_RF_x_Diagramas.md`

### Motivo

O fluxo global da API se conecta diretamente com:

* dados;
* sessão;
* segurança;
* rastreabilidade;
* cobertura funcional.

---

## 18. Observações de consistência

## 18.1 Coerência com arquitetura técnica

O fluxo global respeita a separação saudável entre entrada, segurança, contratos, serviços, persistência e resposta.

## 18.2 Coerência com segurança

Autenticação e autorização aparecem como bifurcações reais do fluxo, e não como adereços.

## 18.3 Coerência com contrato

A validação de contrato aparece antes da lógica principal, o que é metodologicamente correto.

## 18.4 Coerência com QA

O diagrama é útil para derivar casos de teste e critérios de inspeção do comportamento da API.

## 18.5 Coerência com backend modular

O fluxo global é compatível com uma API organizada, e não com um backend amorfo em que tudo acontece dentro da rota.

---

## 19. Critérios de aceite deste documento

Este documento será considerado adequado se:

* mapear o ciclo de vida global das requisições da API;
* incluir entrada, roteamento, validação, autenticação, autorização, service, persistência, resposta e erro;
* distinguir corretamente fluxo público de fluxo protegido;
* mostrar falhas relevantes em pontos estruturais do ciclo;
* permanecer coerente com arquitetura, segurança, contrato de API e testes;
* servir como guia de leitura e auditoria do backend real.

---

## 20. Conclusão executiva

O fluxo global das requisições da API do projeto William Albarello deve ser entendido como uma cadeia arquitetural disciplinada em que nenhuma operação relevante pula etapas críticas.

Toda requisição, para ser tratada corretamente, precisa passar por uma combinação coerente de:

* entrada e roteamento;
* classificação de proteção;
* validação contratual;
* autenticação, quando necessária;
* autorização, quando necessária;
* orquestração por serviços/casos de uso;
* acesso seguro à persistência;
* resposta padronizada;
* tratamento padronizado de falhas.

Esse desenho é importante porque transforma a API de uma simples coleção de endpoints em uma infraestrutura lógica confiável, testável, segura e rastreável.

---

