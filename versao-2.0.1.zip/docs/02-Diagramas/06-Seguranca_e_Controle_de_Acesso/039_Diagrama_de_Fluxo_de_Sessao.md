
# 039_Diagrama_de_Fluxo_de_Sessao

## 1. Identificação do documento

- **Projeto:** William Albarello
- **Diretório:** `02-Diagramas`
- **Caminho oficial:** `/home/user/Documents/Softwares/Willian Albarello/William Albarello/02-Diagramas/06-Seguranca_e_Controle_de_Acesso/039_Diagrama_de_Fluxo_de_Sessao.md`
- **Natureza do documento:** Diagrama e contrato lógico do ciclo de vida da sessão administrativa
- **Função sistêmica:** Mostrar criação, persistência, validação, renovação, expiração, invalidação, revogação e logout da sessão/token administrativo
- **Posição no bloco:** Segundo documento do bloco `06-Seguranca_e_Controle_de_Acesso`
- **Dependências principais:** `015_Seguranca_Privacidade_Auditoria_e_Permissoes.md`, `016_API_Contract_Mestre.md`, `018_Plano_de_Testes_Homologacao_e_Qualidade.md`, `024_Registro_de_Decisoes_Arquiteturais.md`, `038_Diagrama_de_Seguranca_da_Aplicacao.md`
- **Status:** ATIVO
- **Versão:** v1.0
- **Autoridade:** Alta

---

## 2. Objetivo

Este documento existe para formalizar, de modo claro e soberano, **como a sessão administrativa do projeto William Albarello deve nascer, viver, ser renovada, expirar e ser encerrada com segurança**.

Ele responde às seguintes perguntas:

1. como a sessão é criada após login;
2. onde e como ela é persistida;
3. como ela é validada a cada requisição;
4. quando ela pode ser renovada;
5. quando ela deve expirar;
6. como ela é invalidada;
7. como o logout deve funcionar;
8. o que já está comprovado no código atual;
9. o que ainda é arquitetura soberana em consolidação.

Este documento trata sessão como **ativo de segurança**, e não como mero detalhe técnico de autenticação.

---

## 3. Fontes reais utilizadas

Este documento foi construído com base em artefatos efetivamente encontrados no acervo técnico do projeto.

### 3.1 Documentos soberanos do projeto principal
- `01-Waterfall/01-Obrigatorios/015_Seguranca_Privacidade_Auditoria_e_Permissoes.md`
- `01-Waterfall/01-Obrigatorios/016_API_Contract_Mestre.md`
- `01-Waterfall/01-Obrigatorios/018_Plano_de_Testes_Homologacao_e_Qualidade.md`
- `01-Waterfall/01-Obrigatorios/024_Registro_de_Decisoes_Arquiteturais.md`

### 3.2 Documentação complementar real do monorepo
- `Waterfall/DOC-12-especificacao-de-apis-e-contratos.md`
- `Waterfall/DOC-13-arquitetura-de-autenticacao-e-sessao.md`
- `Waterfall/DOC-14-seguranca-p0.md`
- `Waterfall/DOC-19-plano-de-testes-e-criterios-de-aceite.md`
- `Waterfall/DOC-21-observabilidade-logs-e-incidentes.md`
- `Waterfall/DOC-24-go-live-checklist-e-handover-final.md`

### 3.3 Código real e contratos efetivamente encontrados
- `apps/api/src/routes/auth.ts`
- `apps/api/src/server.ts`
- `apps/api/src/lib/env.ts`
- `APIs/API-03-seguranca-auth.md`
- `APIs/API-07-openapi-admin.yaml`
- `Diagrama/DGM-02-fluxo-autenticacao-admin.mmd`

### 3.4 Diagramas já consolidados
- `038_Diagrama_de_Seguranca_da_Aplicacao.md`

---

## 4. Regra de honestidade técnica deste documento

Este ponto é obrigatório.

O acervo **comprova diretamente** que o projeto já possui:

- autenticação administrativa por `email + password`;
- rota de login administrativa real;
- emissão de cookie `__Host-session`;
- atributos seguros no cookie:
  - `HttpOnly`
  - `Secure`
  - `SameSite=Strict`
  - `Path=/`
- backend com suporte a cookie e CSRF;
- política soberana de sessão curta, revogável e orientada ao servidor;
- necessidade documental de:
  - `idle timeout`
  - `absolute timeout`
  - logout
  - revogação
  - rastreabilidade de eventos de sessão

O acervo **não comprova diretamente**, no runtime atual:

- tabela real de sessões já materializada e usada em produção;
- persistência completa de sessão com `token_hash`;
- renovação deslizante já implementada;
- endpoint real de logout já completo;
- endpoint real de refresh/renovação de sessão;
- revogação automática por evento de risco já implementada;
- invalidação por troca de senha já implementada;
- listagem de sessões por usuário/admin já implementada.

Portanto, este documento distingue com rigor:

### 4.1 Estado comprovado
O que já existe de fato no acervo e no bootstrap real.

### 4.2 Estado soberano desejado
A forma correta e segura como o ciclo de vida da sessão deve operar segundo a arquitetura do projeto.

Essa distinção precisa permanecer explícita.

---

## 5. Tese central do fluxo de sessão

A tese central deste documento é a seguinte:

> a sessão administrativa do projeto William Albarello deve ser server-oriented, curta, segura, revogável, validada a cada requisição crítica e encerrável de forma explícita ou automática, com rastreabilidade suficiente para investigação e governança.

Em linguagem simples:

- o navegador não deve ser dono da verdade da sessão;
- a API é a autoridade sobre a validade da sessão;
- o cookie é apenas o portador seguro do identificador;
- a sessão precisa ter nascimento, vida, renovação controlada e morte explícita;
- logout não pode ser apenas “sumir da tela”;
- expiração e invalidação devem ser tratadas como eventos normais do ciclo.

---

## 6. Princípios soberanos do ciclo de sessão

O fluxo de sessão deve obedecer aos seguintes princípios:

1. **sessão orientada ao servidor**
2. **cookie seguro e restrito**
3. **validação backend-first**
4. **revogação possível a qualquer momento**
5. **expiração por inatividade e por tempo absoluto**
6. **renovação controlada, nunca infinita**
7. **negação por padrão quando a sessão estiver ausente, inválida ou expirada**
8. **rastreabilidade mínima de eventos de sessão**

Esses princípios formam a base de todo o ciclo de vida.

---

## 7. Modelo soberano de sessão

## 7.1 Conceito
A sessão administrativa não deve ser entendida como “token livre no frontend”.

Ela deve ser entendida como:

- um registro de autorização temporária;
- mantido sob controle do backend;
- referenciado por cookie seguro;
- validado em toda rota administrativa protegida.

## 7.2 Componentes do modelo
O modelo soberano correto envolve:

1. **credencial de entrada**
   - email
   - senha

2. **registro de sessão**
   - associado ao usuário/admin
   - com timestamps e estado

3. **identificador de sessão**
   - representado ao cliente por cookie

4. **políticas temporais**
   - idle timeout
   - absolute timeout

5. **eventos de encerramento**
   - logout
   - revogação
   - expiração
   - incidente de segurança

---

## 8. Estrutura lógica da sessão

No modelo soberano do projeto, uma sessão administrativa deve conter logicamente, no mínimo:

- `session_id`
- `user_id`
- `role`
- `created_at`
- `last_seen_at`
- `expires_at`
- `absolute_expires_at`
- `revoked_at` (quando aplicável)
- `revocation_reason` (quando aplicável)
- `ip_hash` ou contexto de origem quando apropriado
- `user_agent_hash` ou fingerprint prudencial quando apropriado

### Observação importante
O acervo não comprova ainda a implementação integral de todos esses campos no runtime atual.  
Esta é a estrutura soberana esperada.

---

## 9. Diagrama principal do fluxo de sessão

```mermaid
flowchart TB

    A[Administrador]
    FE[Painel / frontend admin]
    API[API admin]
    VAL[Validacao de credenciais]
    SESS[(Registro de sessao)]
    COOKIE[Cookie __Host-session]
    CHECK[Validacao de sessao por requisicao]
    REN[Renovacao controlada]
    EXP[Expiracao]
    REV[Revogacao/Invalidação]
    LOGOUT[Logout]
    AUD[Audit trail]

    A --> FE
    FE --> API
    API --> VAL
    VAL -->|Sucesso| SESS
    SESS --> COOKIE
    COOKIE --> FE

    FE --> CHECK
    CHECK --> API
    API --> SESS

    SESS --> REN
    SESS --> EXP
    SESS --> REV
    FE --> LOGOUT
    LOGOUT --> API
    API --> REV

    VAL --> AUD
    REN --> AUD
    EXP --> AUD
    REV --> AUD
    LOGOUT --> AUD
````

---

## 10. Fase 1 — Criação da sessão

A sessão nasce após autenticação bem-sucedida.

## 10.1 Fluxo soberano de criação

1. admin envia `email + password`;
2. backend valida o payload;
3. backend valida as credenciais;
4. backend cria ou referencia registro de sessão;
5. backend emite cookie seguro;
6. backend registra evento de auditoria;
7. frontend passa a operar em contexto autenticado.

## 10.2 Evidência real já existente

O código atual já comprova:

* login via `POST /v1/admin/auth/login`;
* validação com `zod`;
* emissão de cookie `__Host-session`.

## 10.3 Limitação atual do bootstrap

O cookie emitido hoje ainda carrega valor placeholder, o que mostra que:

* o fluxo está arquitetonicamente correto;
* a persistência real e o identificador definitivo ainda precisam ser consolidados.

---

## 11. Diagrama de criação da sessão

```mermaid id="nd6j5r"
sequenceDiagram
    participant ADM as Admin
    participant FE as Painel
    participant API as Backend
    participant DB as Sessao/Persistencia
    participant AUD as Auditoria

    ADM->>FE: informa email e senha
    FE->>API: POST /v1/admin/auth/login
    API->>API: valida payload
    API->>API: valida credenciais
    API->>DB: cria/referencia sessao
    API->>AUD: registra AUTH_LOGIN_SUCCESS
    API-->>FE: Set-Cookie __Host-session
    FE-->>ADM: acesso liberado
```

---

## 12. Fase 2 — Persistência da sessão

Sessão segura exige persistência sob controle do backend.

## 12.1 Política soberana

A sessão deve ser persistida em camada controlada pelo servidor, e não apenas “codificada” no cliente.

O identificador do cliente deve apontar para um estado que o backend consegue:

* validar;
* expirar;
* revogar;
* renovar;
* auditar.

## 12.2 Estrutura prudencial de persistência

A documentação soberana já aponta para modelo de sessão com `token_hash` e registro seguro.

### Interpretação correta

O navegador deve carregar apenas o necessário para referenciar a sessão.
A verdade da sessão permanece do lado do servidor.

## 12.3 Benefícios desse modelo

* revogação centralizada;
* expiração confiável;
* menor exposição do token;
* compatibilidade com auditoria;
* melhor resposta a incidente.

---

## 13. Fase 3 — Validação por requisição

Toda sessão administrativa deve ser validada nas rotas protegidas.

## 13.1 Regra soberana

Cada requisição administrativa relevante deve verificar, no mínimo:

1. presença do cookie;
2. integridade formal do identificador;
3. existência da sessão correspondente;
4. não revogada;
5. não expirada por inatividade;
6. não expirada por limite absoluto;
7. papel/permissão adequados à rota.

## 13.2 Consequência

Não existe “sessão presumida”.
Toda requisição protegida precisa provar que ainda está autorizada.

## 13.3 Falhas possíveis

* cookie ausente;
* cookie inválido;
* sessão não encontrada;
* sessão revogada;
* sessão expirada;
* sessão sem papel suficiente.

Nesses casos, a resposta correta é negar acesso de forma padronizada.

---

## 14. Diagrama de validação da sessão por requisição

```mermaid id="r4z1ua"
flowchart TD

    REQ[Requisicao admin] --> CK{Cookie presente?}
    CK -->|Nao| NO1[UNAUTHENTICATED]
    CK -->|Sim| FIND[Buscar sessao no backend]

    FIND --> EX{Sessao existe?}
    EX -->|Nao| NO2[UNAUTHENTICATED]

    EX --> REV{Sessao revogada?}
    REV -->|Sim| NO3[SESSION_REVOKED]

    REV --> IDLE{Idle timeout excedido?}
    IDLE -->|Sim| NO4[SESSION_EXPIRED]

    IDLE --> ABS{Absolute timeout excedido?}
    ABS -->|Sim| NO5[SESSION_EXPIRED]

    ABS --> ROLE{Role/permissao suficiente?}
    ROLE -->|Nao| NO6[FORBIDDEN]
    ROLE -->|Sim| OK[Acesso permitido]
```

---

## 15. Fase 4 — Renovação da sessão

A sessão não deve ser eterna, mas pode precisar de renovação controlada.

## 15.1 Política soberana

O projeto admite **renovação controlada**, não renovação infinita e invisível.

A renovação serve para:

* manter sessão válida durante operação legítima;
* evitar queda abrupta no meio de fluxo administrativo;
* não abrir janela indefinida de sequestro de sessão.

## 15.2 Dois limites soberanos

### Idle timeout

Tempo máximo sem atividade útil.

### Absolute timeout

Tempo máximo total da sessão, ainda que o usuário esteja ativo.

## 15.3 Valores de referência soberanos

Conforme a documentação complementar do projeto:

* **idle timeout:** 30 minutos
* **absolute timeout:** 12 horas

## 15.4 Regra correta

A renovação pode atualizar:

* `last_seen_at`
* e, quando permitido, `expires_at`

Mas **não pode ignorar** o teto de `absolute timeout`.

---

## 16. Renovação deslizante: interpretação correta

A renovação deslizante deve ser prudente.

## 16.1 Quando renovar

* após atividade administrativa válida;
* quando a sessão ainda estiver saudável;
* quando a operação não indicar risco;
* antes de atingir o limite de inatividade, mas sem estender infinitamente.

## 16.2 Quando não renovar

* em requisições inválidas;
* quando a sessão já estiver próxima ou além do limite absoluto;
* após indício de revogação;
* em evento de segurança;
* em contexto inconsistente.

## 16.3 Regra de segurança

Renovar toda sessão a qualquer custo enfraquece a segurança.
Renovar de forma seletiva preserva usabilidade sem sacrificar governança.

---

## 17. Diagrama de renovação controlada

```mermaid id="9s4hqc"
flowchart LR

    ATV[Atividade administrativa valida] --> V1{Sessao valida?}
    V1 -->|Nao| STOP[Negar e exigir novo login]
    V1 -->|Sim| V2{Dentro do absolute timeout?}
    V2 -->|Nao| STOP2[Expirar e exigir novo login]
    V2 -->|Sim| REN[Atualizar last_seen_at / renovar expires_at]
    REN --> OK[Continuar operacao]
```

---

## 18. Fase 5 — Expiração da sessão

Expirar sessão é comportamento normal e saudável do sistema.

## 18.1 Expiração por inatividade

Ocorre quando o admin fica tempo demais sem uso relevante.

### Objetivo

Reduzir risco de sessão esquecida, abandonada ou reaproveitada.

## 18.2 Expiração por tempo absoluto

Ocorre quando a sessão atinge o teto máximo de vida.

### Objetivo

Impedir permanência indefinida de contexto autenticado.

## 18.3 Tratamento correto

Quando expirar:

* a sessão deve ser considerada inválida;
* o cookie deve deixar de ser aceito;
* o frontend deve redirecionar ao login ou exigir reautenticação;
* evento deve ser rastreável.

---

## 19. Fase 6 — Invalidação e revogação

Sessão pode precisar “morrer” antes do tempo natural.

## 19.1 Diferença prática

### Expiração

Morte natural por regra temporal.

### Invalidação / revogação

Encerramento antecipado por decisão do sistema ou do operador.

## 19.2 Casos típicos de revogação

* logout explícito;
* troca de senha;
* incidente de segurança;
* suspeita de comprometimento;
* revogação administrativa;
* política de hardening após evento crítico.

## 19.3 Regra soberana

Toda sessão revogada deve ser rejeitada imediatamente nas próximas validações.

---

## 20. Diagrama de expiração e revogação

```mermaid id="v2q1en"
flowchart TD

    S[Sessao ativa] --> I{Idle timeout excedido?}
    I -->|Sim| E1[Expirar sessao]
    I -->|Nao| A{Absolute timeout excedido?}
    A -->|Sim| E2[Expirar sessao]
    A -->|Nao| R{Evento de revogacao?}
    R -->|Sim| RV[Revogar sessao]
    R -->|Nao| KEEP[Manter sessao ativa]
```

---

## 21. Fase 7 — Logout

Logout é o encerramento explícito da sessão pelo usuário ou pelo sistema.

## 21.1 Política soberana de logout

Logout correto deve:

1. invalidar a sessão no backend;
2. instruir o cliente a remover/expirar o cookie;
3. registrar evento de auditoria;
4. impedir reutilização do contexto autenticado;
5. redirecionar o usuário para estado não autenticado.

## 21.2 O que não é logout verdadeiro

* esconder menu admin;
* apenas limpar estado visual local;
* apenas trocar rota sem invalidar sessão real.

## 21.3 Conclusão

Logout é operação de segurança e governança, não simples navegação.

---

## 22. Diagrama de logout

```mermaid id="1qotn8"
sequenceDiagram
    participant ADM as Admin
    participant FE as Painel
    participant API as Backend
    participant DB as Sessao
    participant AUD as Auditoria

    ADM->>FE: aciona logout
    FE->>API: POST /logout
    API->>DB: marca sessao como revogada/inativa
    API->>AUD: registra AUTH_LOGOUT
    API-->>FE: expira cookie
    FE-->>ADM: redireciona para login
```

---

## 23. Estados possíveis da sessão

Para fins arquiteturais, a sessão administrativa pode existir nos seguintes estados:

1. **created**
2. **active**
3. **renewed**
4. **expired_idle**
5. **expired_absolute**
6. **revoked**
7. **logged_out**

### Observação

Nem todos esses estados estão comprovados como enum real do runtime atual.
Eles representam o modelo soberano correto.

---

## 24. Diagrama de máquina de estados da sessão

```mermaid id="k9l4db"
stateDiagram-v2
    [*] --> Created
    Created --> Active: login bem-sucedido
    Active --> Renewed: atividade valida + renovacao
    Renewed --> Active: sessao segue valida
    Active --> ExpiredIdle: idle timeout
    Renewed --> ExpiredIdle: idle timeout
    Active --> ExpiredAbsolute: absolute timeout
    Renewed --> ExpiredAbsolute: absolute timeout
    Active --> Revoked: evento de revogacao
    Renewed --> Revoked: evento de revogacao
    Active --> LoggedOut: logout explicito
    Renewed --> LoggedOut: logout explicito
```

---

## 25. Respostas corretas para falhas de sessão

Quando houver problema de sessão, a aplicação deve reagir de modo coerente e padronizado.

## 25.1 Cookie ausente

Resposta correta:

* `UNAUTHENTICATED`
* redirecionamento para login quando apropriado

## 25.2 Sessão expirada

Resposta correta:

* `SESSION_EXPIRED`
* frontend deve exigir novo login

## 25.3 Sessão revogada

Resposta correta:

* `SESSION_REVOKED` ou equivalente de autenticação negada
* frontend deve encerrar estado autenticado

## 25.4 Sessão sem papel suficiente

Resposta correta:

* `FORBIDDEN`

## 25.5 Regra de ouro

Falhas de sessão devem ser claras para o sistema e prudentes para o atacante.

---

## 26. Relação entre sessão e autorização

Sessão válida **não equivale** automaticamente a permissão total.

## 26.1 Ordem correta

1. autenticar;
2. validar sessão;
3. verificar role/permissão;
4. só então executar a ação.

## 26.2 Consequência arquitetural

O fluxo de sessão é base da identidade temporária, mas a autorização continua sendo camada separada.

---

## 27. Relação entre sessão e CSRF

Como a sessão é baseada em cookie, a proteção CSRF é obrigatória nas operações mutáveis autenticadas.

## 27.1 Papel da sessão aqui

A sessão autentica o contexto.

## 27.2 Papel do CSRF aqui

O CSRF prova que a mutação veio de contexto legítimo esperado, e não de requisição forjada por terceiro.

## 27.3 Regra soberana

Sessão segura sem CSRF em mutações continua sendo segurança incompleta.

---

## 28. Relação entre sessão e observabilidade

Sessão precisa ser observável.

## 28.1 Eventos mínimos de observação

* login com sucesso;
* login com falha;
* sessão criada;
* sessão renovada;
* sessão expirada por inatividade;
* sessão expirada por tempo absoluto;
* logout;
* sessão revogada;
* falha repetida de validação;
* anomalia por IP/origem quando aplicável.

## 28.2 Benefícios

* investigação de incidente;
* análise de abuso;
* depuração de auth;
* apoio a auditoria;
* correlação com `traceId`.

---

## 29. Audit trail do ciclo de sessão

O fluxo de sessão precisa gerar trilha de auditoria suficiente para governança.

## 29.1 Eventos auditáveis mínimos

* `AUTH_LOGIN_SUCCESS`
* `AUTH_LOGIN_FAILURE`
* `SESSION_CREATED`
* `SESSION_RENEWED`
* `SESSION_EXPIRED_IDLE`
* `SESSION_EXPIRED_ABSOLUTE`
* `SESSION_REVOKED`
* `AUTH_LOGOUT`

## 29.2 Campos mínimos recomendados

* `timestamp`
* `user_id` ou identidade conhecida
* `event_type`
* `session_id` quando aplicável
* `traceId` quando aplicável
* `ip_hash` ou contexto de origem
* `reason` quando houver revogação/expiração relevante

---

## 30. Testes mínimos do fluxo de sessão

O ciclo de sessão precisa entrar no bloco de testes obrigatórios.

## 30.1 Casos mínimos P0

1. login válido cria sessão segura;
2. login inválido não cria sessão;
3. cookie ausente bloqueia rota protegida;
4. sessão expirada por idle bloqueia rota;
5. sessão expirada por absolute bloqueia rota;
6. logout invalida sessão;
7. sessão revogada não pode ser reutilizada;
8. rota mutável com sessão mas sem CSRF falha;
9. sessão válida + role inadequada gera `FORBIDDEN`.

## 30.2 Casos mínimos P1

1. renovação controlada atualiza `last_seen_at`;
2. renovação não ultrapassa o teto absoluto;
3. evento de troca de senha revoga sessões antigas;
4. trilha de auditoria registra eventos corretos.

---

## 31. Estado real materializado hoje

Este bloco é decisivo para honestidade operacional.

## 31.1 Já comprovado no acervo

* login administrativo real;
* validação de payload com `zod`;
* emissão de cookie `__Host-session`;
* atributos de segurança no cookie:

  * `HttpOnly`
  * `Secure`
  * `SameSite=Strict`
  * `Path=/`
* documentação soberana detalhando:

  * sessão server-oriented
  * idle timeout
  * absolute timeout
  * revogação
  * logout
  * auditoria do ciclo de sessão

## 31.2 Ainda não comprovado como implementação completa

* persistência real da sessão em tabela/armazenamento definitivo;
* renovação implementada de ponta a ponta;
* logout real já finalizado no código atual;
* revogação central de sessões;
* expiração automatizada já comprovada no runtime;
* gestão de múltiplas sessões por usuário;
* trilha de auditoria já persistida e consultável.

## 31.3 Leitura correta

O projeto possui **modelo de sessão maduro documentalmente** e **bootstrap técnico inicial coerente**, mas ainda precisa consolidar o ciclo completo no runtime.

---

## 32. Riscos do estágio atual

## 32.1 Risco de bootstrap correto, mas ciclo incompleto

O login já existe, mas o restante do ciclo ainda precisa ser fechado.

### Mitigação

* implementar persistência real;
* fechar validação, renovação, revogação e logout;
* garantir testes P0.

## 32.2 Risco de sessão placeholder induzir falsa sensação de prontidão

O cookie atual comprova a direção, não a finalização.

### Mitigação

* substituir placeholder por identificador real;
* auditar todo o caminho de sessão.

## 32.3 Risco de sessão válida sem governança temporal real

Sem idle/absolute timeout implementados, a segurança fica inferior ao modelo soberano.

### Mitigação

* materializar políticas temporais no backend;
* cobrir por testes.

## 32.4 Risco de logout superficial

Se o frontend só “limpar interface” sem invalidar backend, a sessão continua viva.

### Mitigação

* logout backend-first;
* expiração real do cookie;
* revogação do estado server-side.

---

## 33. Decisões arquiteturais firmadas por este documento

1. A sessão administrativa do projeto é orientada ao servidor.
2. O cookie é apenas portador seguro do identificador, não a verdade completa da sessão.
3. A sessão deve nascer após login válido, ser validada por requisição, renovar-se com prudência e morrer por expiração, revogação ou logout.
4. Idle timeout e absolute timeout são ambos obrigatórios.
5. Logout deve invalidar a sessão no backend e expirar o cookie no cliente.
6. Revogação é diferente de expiração natural e deve ser tratada explicitamente.
7. Sessão válida não substitui a checagem de autorização.
8. Sessão baseada em cookie exige CSRF em operações mutáveis.
9. O ciclo da sessão deve ser auditável e observável.
10. O modelo soberano está mais maduro do que a implementação atual, e essa diferença deve permanecer explícita até o fechamento do runtime.

---

## 34. O que este documento resolve

Este documento resolve:

* a visão completa do ciclo de vida da sessão;
* criação, persistência, validação, renovação, expiração, revogação e logout;
* a distinção entre modelo comprovado e modelo soberano;
* a relação entre sessão, autorização, CSRF, auditoria e observabilidade;
* os testes mínimos obrigatórios do fluxo de sessão.

---

## 35. O que este documento ainda não resolve

Este documento ainda não resolve, em detalhe fino:

* modelagem física exata da tabela de sessões;
* endpoint final de logout/refresh já materializado;
* política de múltiplas sessões simultâneas;
* revogação em massa por usuário;
* integração com passkeys/WebAuthn;
* UX detalhada de reautenticação silenciosa ou explícita.

Esses pontos pertencem à implementação técnica progressiva e aos próximos documentos do bloco.

---

## 36. Critérios de aceite do documento

Este documento será considerado aceito quando cumprir simultaneamente os seguintes critérios:

1. mostrar corretamente o ciclo de vida da sessão;
2. distinguir honestamente o que já existe e o que ainda é diretriz soberana;
3. cobrir criação, persistência, renovação, expiração, invalidação e logout;
4. manter coerência com os documentos de segurança e contrato de API;
5. servir como base sólida para implementação e testes do fluxo de sessão.

---

## 37. Conclusão arquitetural

O projeto William Albarello já possui uma doutrina de sessão madura e conceitualmente saudável:

* login gera sessão segura;
* backend mantém a autoridade da validade;
* sessão é temporária e revogável;
* expiração faz parte do ciclo normal;
* logout é encerramento real;
* auditoria acompanha os eventos principais.

A leitura correta do momento atual é esta:

* o projeto já sabe **como a sessão deve nascer e morrer**;
* já sabe **que cookie seguro não basta sem backend soberano**;
* já sabe **que renovação precisa de limite**;
* e já sabe **que logout sem invalidação real é incompleto**.

Em linguagem simples:

> a arquitetura de sessão já está claramente desenhada; o próximo trabalho é transformar esse desenho em ciclo fechado, testado e plenamente operacional.

---

