
# 041_Diagrama_de_Auditoria_e_Rastreabilidade

## 1. Identificação do documento

- **Projeto:** William Albarello
- **Diretório:** `02-Diagramas`
- **Caminho oficial:** `/home/user/Documents/Softwares/Willian Albarello/William Albarello/02-Diagramas/06-Seguranca_e_Controle_de_Acesso/041_Diagrama_de_Auditoria_e_Rastreabilidade.md`
- **Natureza do documento:** Diagrama e contrato lógico de auditoria, trilhas de ação e rastreabilidade operacional
- **Função sistêmica:** Mostrar logs de ação, trilhas, evidências de operação, origem dos registros, persistência, consulta, correlação e valor probatório/operacional dos eventos do sistema
- **Posição no bloco:** Quarto e último documento do bloco `06-Seguranca_e_Controle_de_Acesso`
- **Dependências principais:** `018_Plano_de_Testes_Homologacao_e_Qualidade.md`, `023_Matriz_de_Rastreabilidade.md`, `024_Registro_de_Decisoes_Arquiteturais.md`, `036_Diagrama_de_Observabilidade_e_Logs.md`, `038_Diagrama_de_Seguranca_da_Aplicacao.md`, `039_Diagrama_de_Fluxo_de_Sessao.md`, `040_Diagrama_de_Permissoes_por_Perfil.md`
- **Status:** ATIVO
- **Versão:** v1.0
- **Autoridade:** Alta

---

## 2. Objetivo

Este documento existe para formalizar **como o projeto William Albarello registra, preserva, consulta e interpreta rastros operacionais e administrativos**.

Ele responde, com clareza, às seguintes perguntas:

1. quais eventos devem gerar registro de auditoria;
2. quais eventos pertencem a log operacional e quais pertencem a audit trail;
3. como os registros devem ser correlacionados com usuário, rota, entidade, horário e `traceId`;
4. onde e como esses registros devem ser persistidos;
5. quem pode consultar esses registros;
6. qual é o valor operacional e probatório dos eventos armazenados;
7. o que já está comprovado no acervo técnico;
8. o que ainda é arquitetura soberana em consolidação.

Este documento trata auditoria e rastreabilidade como **camada de governança, segurança, suporte, prova e continuidade**, e não como detalhe secundário de backend.

---

## 3. Fontes reais utilizadas

Este documento foi construído com base em artefatos efetivamente encontrados no acervo técnico do projeto.

### 3.1 Documentos soberanos do projeto principal
- `01-Waterfall/01-Obrigatorios/015_Seguranca_Privacidade_Auditoria_e_Permissoes.md`
- `01-Waterfall/01-Obrigatorios/016_API_Contract_Mestre.md`
- `01-Waterfall/01-Obrigatorios/018_Plano_de_Testes_Homologacao_e_Qualidade.md`
- `01-Waterfall/01-Obrigatorios/021_Criterios_de_Aceite_Gerais.md`
- `01-Waterfall/01-Obrigatorios/023_Matriz_de_Rastreabilidade.md`
- `01-Waterfall/01-Obrigatorios/024_Registro_de_Decisoes_Arquiteturais.md`

### 3.2 Documentação complementar real do monorepo
- `Waterfall/DOC-12-especificacao-de-apis-e-contratos.md`
- `Waterfall/DOC-13-arquitetura-de-autenticacao-e-sessao.md`
- `Waterfall/DOC-14-seguranca-p0.md`
- `Waterfall/DOC-19-plano-de-testes-e-criterios-de-aceite.md`
- `Waterfall/DOC-21-observabilidade-logs-e-incidentes.md`
- `Waterfall/DOC-22-operacao-runbooks-e-rotina-de-publicacao.md`
- `Waterfall/DOC-24-go-live-checklist-e-handover-final.md`
- `Execucao/EXEC-05-checklist-de-gates-tecnicos.md`
- `Execucao/EXEC-11-runbook-evidencias-release-real.md`

### 3.3 Backend e contratos reais
- `apps/api/src/server.ts`
- `apps/api/src/routes/auth.ts`
- `apps/api/src/routes/health.ts`
- `APIs/API-03-seguranca-auth.md`
- `APIs/API-07-openapi-admin.yaml`
- `APIs/openapi/components/schemas.common.yaml`
- `APIs/openapi/components/responses.common.yaml`

### 3.4 Diagramas já consolidados
- `036_Diagrama_de_Observabilidade_e_Logs.md`
- `038_Diagrama_de_Seguranca_da_Aplicacao.md`
- `039_Diagrama_de_Fluxo_de_Sessao.md`
- `040_Diagrama_de_Permissoes_por_Perfil.md`

---

## 4. Regra de honestidade técnica deste documento

Este ponto é obrigatório.

O acervo **comprova diretamente** que o projeto já possui:

- obrigação formal de auditoria para eventos críticos;
- distinção conceitual entre log operacional e trilha de auditoria;
- exigência de rastreabilidade em eventos administrativos, segurança e release;
- uso arquitetural de `traceId` em contratos de resposta;
- runbooks que dependem de logs e correlação temporal;
- previsão de consulta de audit logs na superfície administrativa;
- papel `admin` como perfil de leitura legítima da auditoria;
- preocupação explícita com valor operacional e probatório dos registros.

O acervo **não comprova diretamente**, no runtime atual:

- tabela final de audit logs já implementada e populada;
- endpoint funcional completo de consulta de auditoria no backend atual;
- storage definitivo dos audit logs já materializado;
- UI operacional de consulta/auditoria finalizada;
- cadeia completa de correlação automática entre audit log e log operacional;
- política técnica implementada de retenção e expurgo em código;
- hash/imutabilidade forte de eventos já implementados no runtime;
- assinatura digital ou mecanismo criptográfico avançado de não repúdio.

Portanto, este documento distingue explicitamente:

### 4.1 Estado comprovado
A obrigação arquitetural, os contratos, a governança e os sinais reais já presentes no projeto.

### 4.2 Estado soberano desejado
A forma correta como a auditoria e a rastreabilidade devem operar quando plenamente consolidadas.

Essa distinção precisa permanecer clara para não confundir intenção madura com implementação já fechada.

---

## 5. Tese central de auditoria e rastreabilidade

A tese central deste documento é a seguinte:

> o projeto William Albarello deve registrar eventos sensíveis, administrativos e operacionais de modo suficientemente estruturado para permitir reconstrução confiável do que aconteceu, por quem aconteceu, quando aconteceu, em qual entidade aconteceu e com qual impacto técnico ou institucional.

Em linguagem simples:

- não basta saber que “alguém mexeu”;
- é preciso saber **quem**, **o quê**, **quando**, **onde**, **sobre qual objeto** e **em qual contexto**;
- log técnico e auditoria não são a mesma coisa;
- sem rastreabilidade, segurança, suporte e governança ficam cegos;
- sem trilha mínima, a prova operacional enfraquece.

---

## 6. Princípios soberanos de auditoria e rastreabilidade

A trilha de auditoria do projeto deve obedecer aos seguintes princípios:

1. **registro de eventos sensíveis**
2. **correlação por contexto**
3. **distinção entre operação técnica e ação humana**
4. **imutabilidade lógica dos registros relevantes**
5. **consulta restrita por papel**
6. **retenção proporcional ao valor operacional e probatório**
7. **rastreabilidade sem vazamento indevido**
8. **uso simultâneo para suporte, segurança e governança**
9. **eventos críticos não podem depender da memória humana**
10. **cada evento precisa ser interpretável posteriormente**

---

## 7. Diferença entre log operacional e audit trail

Este ponto é central e não pode ficar ambíguo.

## 7.1 Log operacional
Explica o comportamento do sistema.

Exemplos:
- erro 500;
- latência alta;
- falha no healthcheck;
- falha de deploy;
- exceção em endpoint.

### Finalidade
- suporte técnico;
- diagnóstico;
- observabilidade;
- incidentes;
- performance.

---

## 7.2 Audit trail
Explica a ação relevante de um ator ou de um processo com valor administrativo, institucional ou de segurança.

Exemplos:
- login bem-sucedido;
- falha de login;
- publicação criada;
- status alterado;
- taxonomia alterada;
- logout;
- sessão revogada;
- leitura de audit logs;
- alteração sensível de configuração.

### Finalidade
- governança;
- segurança;
- responsabilização;
- histórico administrativo;
- prova operacional.

---

## 7.3 Relação correta entre ambos
Eles devem ser **distintos, mas correlacionáveis**.

Exemplo:
- log operacional mostra erro em `PATCH /admin/publications/{id}/status`;
- audit trail mostra tentativa do usuário X de mudar o status da publicação Y;
- `traceId`, timestamp e actor ligam os dois planos.

---

## 8. Macrovisão da rastreabilidade do sistema

A rastreabilidade do projeto deve cobrir quatro planos simultaneamente:

### 8.1 Plano de ação humana
Quem executou algo no painel ou em superfície protegida.

### 8.2 Plano de ação técnica do sistema
Como a API, o banco e o deploy reagiram.

### 8.3 Plano de entidade de negócio
Qual publicação, categoria, tag, sessão ou configuração foi afetada.

### 8.4 Plano de contexto temporal e de release
Quando aconteceu, em qual ambiente e sob qual release/versão.

---

## 9. Diagrama principal de auditoria e rastreabilidade

```mermaid
flowchart TB

    subgraph ORIGENS["Origens de evento"]
        ADM[Administrador / editor]
        API[API admin]
        SYS[Eventos do sistema]
        CI[Deploy / release]
    end

    subgraph REGISTRO["Registros"]
        OPLOG[Logs operacionais]
        AUDIT[Audit trail]
        TRACE[Correlacao por traceId]
        REL[Contexto de release / ambiente]
    end

    subgraph PERSIST["Persistencia e consulta"]
        STORE[(Armazenamento de auditoria)]
        QUERY[Consulta restrita]
        DASH[Leitura operacional / investigativa]
    end

    subgraph USO["Uso"]
        SEC[Seguranca]
        SUP[Suporte]
        GOV[Governanca]
        RCA[Investigacao / RCA]
        PROVA[Valor probatorio operacional]
    end

    ADM --> AUDIT
    API --> OPLOG
    API --> TRACE
    SYS --> OPLOG
    CI --> REL

    AUDIT --> STORE
    OPLOG --> TRACE
    TRACE --> DASH
    REL --> DASH
    STORE --> QUERY
    QUERY --> DASH

    DASH --> SEC
    DASH --> SUP
    DASH --> GOV
    DASH --> RCA
    DASH --> PROVA
````

---

## 10. O que deve ser auditado

Nem todo evento precisa virar audit trail.
Mas certos eventos **devem obrigatoriamente** virar.

## 10.1 Eventos de autenticação e sessão

* login com sucesso;
* login com falha;
* logout;
* sessão criada;
* sessão expirada;
* sessão revogada;
* leitura de sessão sensível quando aplicável.

## 10.2 Eventos editoriais

* publicação criada;
* publicação editada;
* mudança de status;
* publicação arquivada;
* exclusão lógica;
* restauração de conteúdo;
* alteração de slug ou metadado crítico quando aplicável.

## 10.3 Eventos taxonômicos

* categoria criada;
* categoria alterada;
* tag criada;
* tag alterada;
* associação taxonômica relevante.

## 10.4 Eventos de segurança

* acesso negado relevante;
* mudança de perfil/permissão;
* revogação administrativa de sessão;
* ação em superfície de segurança;
* tentativa anômala relevante.

## 10.5 Eventos de operação sensível

* release em produção;
* rollback;
* incidente severo;
* alteração de configuração sensível;
* ação manual extraordinária de manutenção.

---

## 11. O que não precisa virar audit trail forte por padrão

Para evitar ruído, alguns eventos pertencem melhor ao plano de log técnico, e não ao audit trail pesado.

Exemplos:

* leitura simples de página pública;
* asset servido com sucesso;
* requisição pública sem impacto sensível;
* healthcheck de rotina;
* polling técnico sem relevância administrativa.

### Regra

Audit trail deve ser **seletivo, significativo e útil**.

---

## 12. Estrutura mínima de um evento de auditoria

Cada evento de auditoria relevante deve conter, no mínimo:

* `audit_id`
* `event_type`
* `occurred_at`
* `actor_type`
* `actor_id` quando aplicável
* `actor_role` quando aplicável
* `entity_type`
* `entity_id`
* `route`
* `method`
* `traceId` quando aplicável
* `environment`
* `release_id` ou contexto equivalente quando aplicável
* `result` (`success`, `failure`, `denied`, etc.)
* `reason` quando aplicável
* `summary`
* `metadata` prudencial estruturada

### Observação importante

O acervo não comprova ainda a implementação integral de todos esses campos no runtime atual.
Esta é a estrutura soberana recomendada.

---

## 13. Diagrama de composição do evento auditável

```mermaid id="8knt7j"
flowchart LR

    A[Ator] --> E[Evento auditavel]
    R[Rota/acao] --> E
    N[Entidade afetada] --> E
    T[Tempo] --> E
    X[traceId] --> E
    ENV[Ambiente / release] --> E
    RES[Resultado] --> E
    META[Metadata prudencial] --> E
```

---

## 14. Categorias de ator

Para a trilha fazer sentido, é necessário distinguir quem ou o que originou o evento.

## 14.1 Ator humano autenticado

Exemplos:

* `admin`
* `editor`
* outro papel interno futuramente legitimado

## 14.2 Ator humano não autenticado

Exemplos:

* tentativa de login;
* tentativa de acesso negado sem sessão válida

## 14.3 Ator sistêmico

Exemplos:

* rotina de release;
* rollback;
* processo técnico automatizado;
* expiração automática de sessão.

### Regra

Mesmo quando não há usuário humano, o evento ainda precisa identificar sua origem sistêmica.

---

## 15. Categorias de entidade afetada

A auditoria precisa registrar **sobre o que** a ação incidiu.

### Entidades mínimas relevantes

* `session`
* `publication`
* `category`
* `tag`
* `audit_log`
* `permission`
* `configuration`
* `release`
* `security_event`

### Exemplo

Não basta registrar “status alterado”.
É preciso registrar:

* status alterado **de qual publicação**
* por **qual ator**
* em **qual momento**
* com **qual resultado**

---

## 16. Diagrama de correlação entre ator, ação e entidade

```mermaid id="ixot7p"
flowchart TD

    ACT[Ator]
    ACTION[Acao]
    ENTITY[Entidade]
    CTX[Contexto]
    EVT[Evento auditavel]

    ACT --> EVT
    ACTION --> EVT
    ENTITY --> EVT
    CTX --> EVT
```

---

## 17. Persistência dos registros

A auditoria precisa de armazenamento adequado.

## 17.1 Regra soberana

Eventos auditáveis relevantes devem ser armazenados em estrutura própria e consultável.

## 17.2 Características desejadas do armazenamento

* ordenação temporal confiável;
* consulta por filtros;
* retenção controlada;
* dificuldade de adulteração casual;
* separação conceitual do log operacional bruto;
* integridade lógica suficiente para uso operacional e investigativo.

## 17.3 O que o acervo comprova

O acervo comprova a necessidade arquitetural de persistência e consulta, mas **não comprova ainda o storage definitivo implementado**.

---

## 18. Consulta de auditoria

Os registros só têm valor real se puderem ser consultados de forma controlada.

## 18.1 Consulta mínima esperada

A consulta de audit trail deve permitir filtrar por:

* intervalo de tempo;
* ator;
* tipo de evento;
* entidade;
* resultado;
* `traceId`;
* ambiente;
* rota quando aplicável.

## 18.2 Papel autorizado

Com base no desenho já consolidado:

* `admin` pode consultar audit logs;
* `editor` não deve acessar audit logs amplos por padrão;
* perfis técnicos ou institucionais, quando vierem a existir em runtime, devem acessar somente conforme legitimidade.

## 18.3 Regra de governança

Consultar audit trail também pode ser, por si, evento auditável.

---

## 19. Diagrama de persistência e consulta

```mermaid id="u7q6da"
flowchart TB

    EVT[Evento auditavel] --> STORE[(Storage de auditoria)]
    STORE --> IDX[Filtros e indices]
    IDX --> Q1[Consulta por ator]
    IDX --> Q2[Consulta por entidade]
    IDX --> Q3[Consulta por periodo]
    IDX --> Q4[Consulta por traceId]
    IDX --> Q5[Consulta por resultado]
```

---

## 20. Relação com `traceId`

O `traceId` é a ponte entre auditoria e investigação técnica.

## 20.1 O que o projeto já reconhece

* contratos de resposta com `traceId`
* investigação operacional baseada em correlação
* observabilidade documental madura

## 20.2 Como a auditoria deve usar isso

Sempre que houver contexto de requisição:

* o evento auditável deve carregar o `traceId`;
* o `traceId` deve permitir navegar até o log operacional correspondente;
* suporte e segurança devem poder reconstruir o episódio completo.

## 20.3 Exemplo

* `admin` altera status de publicação;
* evento de auditoria registra o ator, a entidade, o resultado e o `traceId`;
* log operacional da API mostra latência, rota, payload validado e resposta;
* os dois registros se encontram pelo mesmo `traceId`.

---

## 21. Relação com a Matriz de Rastreabilidade

O documento `023_Matriz_de_Rastreabilidade` existe para ligar objetivos, requisitos, testes e artefatos.
A trilha de auditoria complementa isso no plano runtime.

## 21.1 Matriz de rastreabilidade

Pergunta:

* qual requisito levou a qual artefato e qual teste?

## 21.2 Auditoria runtime

Pergunta:

* qual ação aconteceu de fato no sistema e qual rastro deixou?

## 21.3 Conclusão

Os dois planos se complementam:

* **023** amarra construção e verificação do software;
* **041** amarra operação e prova do que ocorreu em produção ou administração.

---

## 22. Relação com observabilidade e logs

Este documento conversa diretamente com o `036`.

## 22.1 Observabilidade

Foca em:

* métricas;
* logs operacionais;
* alertas;
* incidentes;
* saúde do sistema.

## 22.2 Auditoria

Foca em:

* ação sensível;
* ator;
* entidade;
* decisão administrativa;
* governança;
* rastro consultável.

## 22.3 Regra correta

Observabilidade e auditoria não se substituem.
Elas se cruzam.

---

## 23. Valor operacional dos registros

A trilha de auditoria tem valor operacional direto.

## 23.1 Suporte

Ajuda a responder:

* o que o usuário interno tentou fazer?
* a ação foi executada?
* foi negada?
* falhou?
* em qual entidade?

## 23.2 Segurança

Ajuda a responder:

* houve login anômalo?
* houve tentativa repetida de acesso negado?
* alguém alterou algo sensível?
* alguma sessão foi revogada?
* qual foi o contexto?

## 23.3 Governança

Ajuda a responder:

* quem publicou?
* quem alterou status?
* quem mexeu em taxonomia?
* quando isso ocorreu?
* com qual resultado?

## 23.4 Release e incidente

Ajuda a responder:

* o erro ocorreu após qual release?
* houve rollback?
* alguma ação administrativa coincidiu com o incidente?

---

## 24. Valor probatório dos registros

Este ponto exige precisão.

## 24.1 Valor probatório operacional

Os registros servem como:

* evidência de ação realizada;
* apoio a investigação interna;
* base para RCA;
* base para responsabilização administrativa;
* insumo de reconstrução cronológica.

## 24.2 Limite de honestidade

O acervo atual não comprova ainda mecanismos avançados de prova forte como:

* assinatura criptográfica dos eventos;
* cadeia de custódia formal;
* imutabilidade jurídica forte;
* carimbo temporal externo de terceiros.

## 24.3 Conclusão correta

O valor probatório aqui deve ser entendido como:

* **probatório-operacional e administrativo**
* e não automaticamente como prova forense perfeita já blindada em todos os níveis.

---

## 25. Retenção, acesso e prudência

A trilha de auditoria precisa de retenção e acesso proporcionais.

## 25.1 Retenção recomendada

Conforme a linha já consolidada no projeto:

* eventos operacionais críticos: retenção mínima coerente com investigação;
* eventos de segurança e auditoria: retenção superior à de logs comuns;
* referência prudencial: **90+ dias** para eventos de segurança/auditoria.

## 25.2 Acesso

Acesso deve ser:

* restrito por papel;
* rastreável;
* proporcional;
* nunca aberto indiscriminadamente.

## 25.3 Prudência de conteúdo

Não registrar em claro, sem necessidade:

* senha;
* segredo bruto;
* token bruto;
* dado sensível além do necessário;
* payload excessivo com risco desnecessário.

---

## 26. Catálogo mínimo de eventos auditáveis

Ficam definidos como eventos mínimos obrigatórios:

### 26.1 Autenticação e sessão

* `AUTH_LOGIN_SUCCESS`
* `AUTH_LOGIN_FAILURE`
* `SESSION_CREATED`
* `SESSION_EXPIRED_IDLE`
* `SESSION_EXPIRED_ABSOLUTE`
* `SESSION_REVOKED`
* `AUTH_LOGOUT`

### 26.2 Conteúdo

* `PUBLICATION_CREATED`
* `PUBLICATION_UPDATED`
* `PUBLICATION_STATUS_CHANGED`
* `PUBLICATION_ARCHIVED`
* `PUBLICATION_SOFT_DELETED`

### 26.3 Taxonomia

* `CATEGORY_CREATED`
* `CATEGORY_UPDATED`
* `TAG_CREATED`
* `TAG_UPDATED`

### 26.4 Segurança e governança

* `ACCESS_DENIED`
* `ROLE_CHANGED` quando existir
* `SENSITIVE_CONFIG_CHANGED`
* `AUDIT_LOG_VIEWED`

### 26.5 Operação

* `RELEASE_PROMOTED`
* `ROLLBACK_EXECUTED`
* `SEV_INCIDENT_DECLARED`

---

## 27. Diagrama de cadeia de evidência operacional

```mermaid id="w0yq18"
flowchart LR

    ACT[Ator / sistema]
    EVT[Evento auditavel]
    ST[(Storage)]
    IDX[Indice / consulta]
    CORR[Correlacao com logs / traceId]
    USE[Suporte / seguranca / governanca / RCA]

    ACT --> EVT
    EVT --> ST
    ST --> IDX
    IDX --> CORR
    CORR --> USE
```

---

## 28. Testes mínimos da camada de auditoria

A auditoria precisa entrar nos testes obrigatórios.

## 28.1 Casos mínimos P0

1. login com sucesso gera evento auditável;
2. login com falha gera evento auditável;
3. criação de publicação gera evento auditável;
4. mudança de status gera evento auditável;
5. logout gera evento auditável;
6. consulta de audit log, quando permitida, gera rastro;
7. `editor` não acessa audit logs amplos;
8. `admin` acessa audit logs;
9. evento carrega ator, entidade e timestamp;
10. evento relevante de sessão carrega contexto suficiente.

## 28.2 Casos mínimos P1

1. evento auditável correlaciona com `traceId`;
2. filtros de consulta funcionam;
3. retenção respeita política mínima;
4. eventos críticos não são perdidos em fluxo nominal.

---

## 29. Estado real materializado hoje

Este bloco é decisivo para honestidade operacional.

## 29.1 Já comprovado no acervo

* obrigação formal de audit trail;
* necessidade de consulta de audit logs no painel/admin API;
* separação conceitual entre auditoria e log técnico;
* uso esperado de `traceId` para correlação;
* runbooks e documentos operacionais dependentes de rastreabilidade;
* papel `admin` como leitor legítimo da auditoria;
* eventos críticos de auth, sessão e conteúdo claramente reconhecidos pela arquitetura.

## 29.2 Ainda não comprovado como implementação completa

* tabela/storage final dos audit logs;
* endpoint funcional completo de listagem/filtragem;
* UI pronta de consulta;
* trilha de auditoria persistida e consultável em runtime;
* política de integridade forte dos registros;
* cadeia de retenção automatizada;
* correlação automática completa entre observabilidade e auditoria no código atual.

## 29.3 Leitura correta

A arquitetura de auditoria e rastreabilidade está **muito madura documentalmente**, mas a implementação concreta ainda precisa alcançar esse nível.

---

## 30. Riscos do estágio atual

## 30.1 Risco de operação sem prova suficiente

Sem audit trail efetivo, a reconstrução de ação administrativa fica dependente de memória, prints e inferência.

### Mitigação

* materializar storage e consulta;
* registrar eventos mínimos críticos desde cedo.

## 30.2 Risco de misturar log técnico com auditoria

Isso gera ruído e enfraquece leitura posterior.

### Mitigação

* manter categorias distintas;
* correlacionar sem confundir.

## 30.3 Risco de consultar sem controle

Audit log amplo sem controle de acesso vira novo risco de segurança.

### Mitigação

* restringir por papel;
* registrar leitura sensível;
* aplicar menor privilégio.

## 30.4 Risco de ausência de `traceId` fim a fim

Sem correlação, a investigação perde profundidade.

### Mitigação

* consolidar middleware de correlação;
* propagar `traceId` em respostas, logs e audit trail.

---

## 31. Decisões arquiteturais firmadas por este documento

1. Audit trail e log operacional são distintos, mas correlacionáveis.
2. Eventos críticos de auth, sessão, conteúdo, taxonomia, segurança e operação devem gerar rastro auditável.
3. A trilha de auditoria deve conter ator, ação, entidade, tempo, resultado e contexto.
4. `traceId` é chave estratégica de correlação entre auditoria e observabilidade.
5. Audit logs devem ser persistidos em armazenamento próprio e consultável.
6. O acesso à auditoria deve ser restrito por papel.
7. O valor dos registros é operacional, administrativo e probatório em sentido prudencial, não automaticamente forense pleno.
8. Eventos críticos não podem depender apenas de logs técnicos genéricos.
9. Consultar audit trail pode ser, por si, ação auditável.
10. O desenho arquitetural da auditoria está mais maduro do que a implementação atual, e isso deve permanecer explícito.

---

## 32. O que este documento resolve

Este documento resolve:

* a visão macro de auditoria e rastreabilidade;
* os eventos mínimos que devem ser registrados;
* a diferença entre logs operacionais e trilha de auditoria;
* a composição de um evento auditável;
* persistência, consulta e correlação;
* o valor operacional e probatório dos registros;
* a base de testes e governança da camada de auditoria.

---

## 33. O que este documento ainda não resolve

Este documento ainda não resolve, em detalhe fino:

* modelagem física final da tabela de audit logs;
* indexação exata do storage;
* UI final de leitura e filtros;
* mecanismo de integridade forte dos registros;
* política automatizada de expurgo;
* exportação controlada de trilhas para investigação externa;
* assinatura ou selagem criptográfica de eventos.

Esses pontos pertencem à implementação técnica posterior e a endurecimentos operacionais futuros.

---

## 34. Critérios de aceite do documento

Este documento será considerado aceito quando cumprir simultaneamente os seguintes critérios:

1. explicar claramente eventos, origem, persistência, consulta e valor dos registros;
2. distinguir honestamente estado comprovado e direção soberana;
3. separar auditoria de log operacional sem romper a correlação;
4. manter coerência com testes, rastreabilidade, segurança e observabilidade;
5. servir como base prática para implementação do audit trail do projeto.

---

## 35. Conclusão arquitetural

O projeto William Albarello já possui uma visão muito clara de que rastreabilidade não é luxo.

A leitura correta do momento atual é esta:

* o projeto já sabe **o que precisa rastrear**;
* já sabe **que log técnico e auditoria não são iguais**;
* já sabe **que sem ator, entidade e contexto o registro perde valor**;
* já sabe **que segurança, suporte e governança dependem dessa trilha**;
* e já sabe **que o runtime ainda precisa alcançar a maturidade documental já definida**.

Em linguagem simples:

> a memória institucional do sistema já foi desenhada com clareza; agora ela precisa ser plenamente materializada para que nada importante dependa apenas de lembrança humana.

---

## 36. Fechamento do bloco 06

Com este documento, o bloco `06-Seguranca_e_Controle_de_Acesso` fica logicamente fechado com a seguinte sequência:

* `038_Diagrama_de_Seguranca_da_Aplicacao.md`
* `039_Diagrama_de_Fluxo_de_Sessao.md`
* `040_Diagrama_de_Permissoes_por_Perfil.md`
* `041_Diagrama_de_Auditoria_e_Rastreabilidade.md`

---

