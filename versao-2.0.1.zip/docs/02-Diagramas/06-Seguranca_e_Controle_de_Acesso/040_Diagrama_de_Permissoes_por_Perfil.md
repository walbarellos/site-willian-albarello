
# 040_Diagrama_de_Permissoes_por_Perfil

## 1. Identificação do documento

- **Projeto:** William Albarello
- **Diretório:** `02-Diagramas`
- **Caminho oficial:** `/home/user/Documents/Softwares/Willian Albarello/William Albarello/02-Diagramas/06-Seguranca_e_Controle_de_Acesso/040_Diagrama_de_Permissoes_por_Perfil.md`
- **Natureza do documento:** Diagrama e matriz soberana de permissões por perfil/papel administrativo
- **Função sistêmica:** Mapear permissões por papel administrativo, recursos acessíveis, restrições operacionais, fronteiras entre perfis internos e regras de controle proporcional
- **Posição no bloco:** Terceiro documento do bloco `06-Seguranca_e_Controle_de_Acesso`
- **Dependências principais:** `004_Escopo_e_Fora_de_Escopo.md`, `006_Requisitos_Funcionais.md`, `015_Seguranca_Privacidade_Auditoria_e_Permissoes.md`, `021_Criterios_de_Aceite_Gerais.md`, `038_Diagrama_de_Seguranca_da_Aplicacao.md`, `039_Diagrama_de_Fluxo_de_Sessao.md`
- **Status:** ATIVO
- **Versão:** v1.0
- **Autoridade:** Alta

---

## 2. Objetivo

Este documento existe para formalizar, de forma clara e operacional, **quem pode fazer o quê dentro da camada administrativa do projeto William Albarello**.

Ele responde, com precisão, às seguintes perguntas:

1. quais perfis internos o projeto reconhece;
2. quais permissões cada perfil deve possuir;
3. quais recursos podem ser acessados por cada papel;
4. quais operações são livres, controladas ou proibidas;
5. quais ações exigem autoridade maior;
6. como a matriz conceitual conversa com o backend real e com o contrato administrativo;
7. o que já está implementado;
8. o que ainda é permissão soberana prevista para evolução controlada.

Este documento trata permissões como **mecanismo de governança e contenção de dano**, e não como conveniência de interface.

---

## 3. Fontes reais utilizadas

Este documento foi construído com base em artefatos efetivamente encontrados no acervo do projeto.

### 3.1 Documentos soberanos do projeto principal
- `01-Waterfall/01-Obrigatorios/004_Escopo_e_Fora_de_Escopo.md`
- `01-Waterfall/01-Obrigatorios/005_Stakeholders_Perfis_e_Atores_do_Sistema.md`
- `01-Waterfall/01-Obrigatorios/006_Requisitos_Funcionais.md`
- `01-Waterfall/01-Obrigatorios/010_Jornadas_do_Usuario_e_Fluxos_Principais.md`
- `01-Waterfall/01-Obrigatorios/015_Seguranca_Privacidade_Auditoria_e_Permissoes.md`
- `01-Waterfall/01-Obrigatorios/021_Criterios_de_Aceite_Gerais.md`
- `01-Waterfall/01-Obrigatorios/024_Registro_de_Decisoes_Arquiteturais.md`

### 3.2 Documentação complementar real do monorepo
- `Waterfall/DOC-06-mapa-de-paginas-e-jornadas.md`
- `Waterfall/DOC-13-arquitetura-de-autenticacao-e-sessao.md`
- `Waterfall/DOC-14-seguranca-p0.md`
- `Waterfall/DOC-16-estrategia-editorial-e-governanca.md`
- `Waterfall/DOC-18-plano-de-implementacao-por-fases.md`
- `Waterfall/DOC-19-plano-de-testes-e-criterios-de-aceite.md`
- `Waterfall/DOC-22-operacao-runbooks-e-rotina-de-publicacao.md`
- `Waterfall/DOC-23-riscos-dependencias-e-mitigacao.md`

### 3.3 Backend e contrato administrativo reais
- `apps/api/src/routes/auth.ts`
- `APIs/API-07-openapi-admin.yaml`
- `APIs/API-03-seguranca-auth.md`

### 3.4 Diagramas já consolidados
- `038_Diagrama_de_Seguranca_da_Aplicacao.md`
- `039_Diagrama_de_Fluxo_de_Sessao.md`

---

## 4. Regra de honestidade técnica deste documento

Este ponto é absolutamente central.

O acervo **comprova diretamente** que o projeto já reconhece:

- distinção entre camada pública e administrativa;
- necessidade de controle de acesso proporcional por papel;
- perfis conceituais internos como:
  - Administrador Principal
  - Editor ou Operador de Conteúdo
  - Mantenedor Técnico
  - Titular Institucional, quando autenticado
- papel inicial de runtime:
  - `admin`
- papel evolutivo previsto em contrato e arquitetura:
  - `editor`
- rotas administrativas para:
  - login/logout/sessão
  - dashboard
  - publicações
  - categorias
  - tags
  - audit logs
- regra de que publicação e ações estruturais exigem mais controle que simples edição;
- regra de que permissões não devem ser amplas por comodidade;
- regra de que auditoria é obrigatória em ações críticas.

O acervo **não comprova diretamente**, no runtime atual:

- enumeração completa em banco de todos os perfis conceituais;
- implementação total de RBAC multi-perfil já no backend;
- perfis `mantenedor_tecnico` e `titular_institucional` já expostos como roles reais no contrato atual;
- engine ABAC fina em produção;
- painel real de administração de usuários/papéis;
- fluxo completo de delegação de permissão.

Portanto, este documento distingue explicitamente:

### 4.1 Camada de runtime/contrato atual
O que o backend e a OpenAPI já reconhecem de modo mais concreto:
- `admin`
- `editor` (previsto no contrato/evolução, ainda não plenamente materializado no bootstrap)

### 4.2 Camada soberana conceitual de governança
Perfis internos mais ricos usados para modelagem organizacional:
- Administrador Principal
- Editor ou Operador de Conteúdo
- Mantenedor Técnico
- Titular Institucional

Essa distinção precisa permanecer clara.

---

## 5. Tese central da matriz de permissões

A tese central deste documento é a seguinte:

> no projeto William Albarello, permissões devem seguir a hierarquia real de impacto da ação, de modo que editar rascunho seja mais leve que publicar, publicar seja mais leve que alterar segurança, e alterar segurança/configuração seja mais restrito que operar conteúdo cotidiano.

Em linguagem simples:

- nem todo usuário interno é equivalente;
- conteúdo e infraestrutura não têm o mesmo peso;
- taxonomia, publicação, auditoria e segurança exigem níveis diferentes de autoridade;
- o backend deve negar por padrão e liberar só o que estiver explicitamente autorizado;
- toda permissão mais sensível deve deixar rastro.

---

## 6. Princípios soberanos de permissão

A política de permissão do projeto deve obedecer aos seguintes princípios:

1. **negação por padrão**
2. **menor privilégio**
3. **papel define escopo**
4. **responsabilidade define limite**
5. **ação sensível exige controle proporcional**
6. **publicação exige mais rigor que edição**
7. **segurança e configuração exigem autoridade superior**
8. **auditoria obrigatória em ação crítica**
9. **frontend não decide sozinho; backend decide**
10. **acúmulo de poder precisa ser explícito, nunca implícito**

---

## 7. Conceitos-base deste documento

Antes da matriz, é importante fixar quatro conceitos.

## 7.1 Perfil
É a figura de negócio/organização.

Exemplos:
- Administrador Principal
- Editor ou Operador de Conteúdo
- Mantenedor Técnico
- Titular Institucional

## 7.2 Role
É a representação técnica do perfil no sistema.

Exemplos no estado atual/evolutivo:
- `admin`
- `editor`

## 7.3 Recurso
É o objeto sobre o qual a permissão incide.

Exemplos:
- dashboard
- publicações
- categorias
- tags
- audit logs
- configuração
- sessão
- deploy

## 7.4 Ação
É o verbo aplicado ao recurso.

Exemplos:
- ler
- listar
- criar
- editar
- alterar status
- publicar
- arquivar
- auditar
- configurar
- administrar permissões

---

## 8. Leitura correta das duas camadas de perfil

## 8.1 Camada A — Perfis soberanos de governança
Esta camada responde ao desenho organizacional e documental.

Perfis reconhecidos:
- Visitante Público
- Interessado Externo
- Editor ou Operador de Conteúdo
- Administrador Principal
- Mantenedor Técnico
- Titular Institucional

## 8.2 Camada B — Roles técnicas do painel/admin
Esta camada responde ao backend/admin API.

Estado atual/evolutivo comprovado:
- `admin` (P0 real)
- `editor` (P1 e contrato evolutivo)

## 8.3 Conclusão correta
A matriz deste documento será apresentada em dois níveis:

1. **matriz soberana conceitual**
2. **matriz técnica mínima compatível com runtime/contrato**

Isso evita dois erros:
- empobrecer demais o desenho organizacional;
- fingir que o runtime atual já implementa tudo.

---

## 9. Perfis considerados neste documento

## 9.1 Perfis externos de contexto
Não são foco administrativo, mas ajudam a delimitar fronteiras.

### Visitante Público
Pode consumir superfícies públicas legitimamente expostas.

### Interessado Externo em Aproximação
Pode usar mecanismos legítimos de contato, sem qualquer acesso interno.

---

## 9.2 Perfis internos administrativos/técnicos
São o foco principal deste documento.

### Editor ou Operador de Conteúdo
Ator de manutenção editorial cotidiana, com escopo controlado.

### Administrador Principal
Ator com escopo administrativo amplo e governança de publicação/operação.

### Mantenedor Técnico
Ator focado em sustentação, integridade técnica, deploy e manutenção estrutural.

### Titular Institucional
Ator de supervisão/decisão institucional, não necessariamente operador cotidiano do painel.

---

## 10. Catálogo de recursos administrativos

Para fins de RBAC, os recursos do sistema são agrupados assim:

### R-01 — Autenticação e sessão
- login
- logout
- leitura da própria sessão

### R-02 — Dashboard administrativo
- visão resumida operacional
- leitura de indicadores internos

### R-03 — Publicações
- listar
- criar
- editar
- visualizar internamente
- remover logicamente

### R-04 — Status editorial
- `draft`
- `review`
- `ready_to_publish`
- `published`
- `archived`

### R-05 — Taxonomia
- categorias
- tags
- associação taxonômica
- manutenção de termos

### R-06 — Auditoria
- consulta a audit logs
- interpretação de eventos sensíveis

### R-07 — Segurança e permissões
- gestão de papéis
- políticas de acesso
- revisão de eventos de segurança
- revogação de sessão
- decisões de hardening

### R-08 — Configuração institucional
- configurações sensíveis
- identidade estrutural
- parâmetros críticos do sistema

### R-09 — Manutenção técnica / operação
- deploy
- sustentação
- incidentes
- observabilidade
- correções operacionais

---

## 11. Regras soberanas de sensibilidade por recurso

Nem todos os recursos têm o mesmo peso.

### 11.1 Sensibilidade baixa a moderada
- leitura de dashboard
- edição de rascunho
- manutenção editorial básica

### 11.2 Sensibilidade moderada a alta
- alteração de status editorial
- criação e mudança de taxonomia
- arquivamento
- exclusão lógica
- leitura de auditoria

### 11.3 Sensibilidade alta
- publicação final
- alteração de permissões
- gestão de sessões de terceiros
- configuração estrutural
- segurança
- deploy e manutenção técnica sensível

---

## 12. Diagrama principal de papéis e escopos

```mermaid
flowchart TB

    subgraph PERFIS["Perfis internos"]
        E[Editor / Operador de Conteudo]
        A[Administrador Principal]
        M[Mantenedor Tecnico]
        T[Titular Institucional]
    end

    subgraph RECURSOS["Recursos"]
        PUB[Publicacoes]
        TAX[Taxonomia]
        AUD[Auditoria]
        CFG[Configuracao / seguranca]
        OPS[Operacao tecnica / deploy]
        SES[Sessao / auth]
        DSH[Dashboard]
    end

    E --> PUB
    E --> TAX
    E --> DSH
    E --> SES

    A --> PUB
    A --> TAX
    A --> AUD
    A --> CFG
    A --> SES
    A --> DSH

    M --> OPS
    M --> CFG
    M --> AUD
    M --> SES

    T --> DSH
    T --> AUD
    T --> PUB
````

---

## 13. Matriz técnica mínima de permissões por role

Esta é a matriz mais aderente ao estado técnico atual/evolutivo do contrato administrativo.

### Legenda

* **SIM** = acesso autorizado
* **PARCIAL** = acesso condicionado, restrito ou dependente de regra adicional
* **NÃO** = acesso negado por padrão

| Recurso / Ação                                 |                          `admin` | `editor` |
| ---------------------------------------------- | -------------------------------: | -------: |
| Login / logout / sessão própria                |                              SIM |      SIM |
| Ler dashboard                                  |                              SIM |      SIM |
| Listar publicações admin                       |                              SIM |      SIM |
| Criar publicação                               |                              SIM |      SIM |
| Editar rascunho                                |                              SIM |      SIM |
| Editar conteúdo em revisão                     |                              SIM |      SIM |
| Alterar status `draft -> review`               |                              SIM |      SIM |
| Alterar status `review -> ready_to_publish`    |                              SIM |  PARCIAL |
| Alterar status `ready_to_publish -> published` |                              SIM |  PARCIAL |
| Alterar status `published -> archived`         |                              SIM |  PARCIAL |
| Soft delete de publicação                      |                              SIM |  PARCIAL |
| Gerir categorias                               |                              SIM |  PARCIAL |
| Gerir tags                                     |                              SIM |  PARCIAL |
| Ler audit logs                                 |                              SIM |      NÃO |
| Alterar permissões / perfis                    |                              SIM |      NÃO |
| Revogar sessão de terceiros                    |                              SIM |      NÃO |
| Alterar configuração sensível                  |                              SIM |      NÃO |
| Atuar em segurança/hardening                   |                              SIM |      NÃO |
| Atuar em deploy/infra                          | NÃO pelo painel editorial padrão |      NÃO |

### Interpretação correta

* `admin` é a role ampla e soberana do painel.
* `editor` é uma role de governança editorial controlada.
* `editor` **não** deve receber, por padrão, permissão crítica de segurança/configuração.
* publicação final e arquivamento devem permanecer governados, não triviais.

---

## 14. Justificativa da restrição de publicação final

Este ponto merece destaque próprio.

A documentação soberana já fixa que:

> publicação exige mais cuidado que rascunho.

Além disso, a estratégia editorial fixa transições como:

* `draft -> review`
* `review -> ready_to_publish`
* `ready_to_publish -> published`

Isso significa que o sistema deve reconhecer que:

* criar e editar não é o mesmo que publicar;
* publicar não é o mesmo que manter em rascunho;
* arquivar também é ação sensível.

### Consequência arquitetural

O `editor` pode participar fortemente do fluxo editorial, mas:

* a publicação final deve ser tratada como **ação governada**;
* o `admin` conserva o escopo pleno;
* o `editor` pode ter atuação parcial, condicionada ao desenho da fase.

---

## 15. Matriz soberana conceitual por perfil

A tabela abaixo traduz o desenho organizacional mais rico, acima do runtime P0.

### Legenda

* **AMPLA** = pode atuar com poder principal nesse eixo
* **CONTROLADA** = pode atuar, mas com fronteiras e limites
* **SUPERVISÃO** = pode acompanhar/decidir sem operar tudo diretamente
* **NEGADA** = sem acesso por padrão

| Recurso / Eixo                         |        Editor / Operador | Administrador Principal |         Mantenedor Técnico |                                 Titular Institucional |
| -------------------------------------- | -----------------------: | ----------------------: | -------------------------: | ----------------------------------------------------: |
| Login e sessão própria                 |               CONTROLADA |                   AMPLA |                      AMPLA |                                            CONTROLADA |
| Dashboard interno                      |               CONTROLADA |                   AMPLA |                 CONTROLADA |                                            SUPERVISÃO |
| Criar/editar rascunhos                 |                    AMPLA |                   AMPLA |                     NEGADA |                                     NEGADA por padrão |
| Revisar conteúdo                       |                    AMPLA |                   AMPLA |                     NEGADA |                                            SUPERVISÃO |
| Publicar                               |               CONTROLADA |                   AMPLA |                     NEGADA | SUPERVISÃO / aprovação institucional quando aplicável |
| Arquivar                               |               CONTROLADA |                   AMPLA |                     NEGADA |                                            SUPERVISÃO |
| Gerir categorias e tags                |               CONTROLADA |                   AMPLA |                     NEGADA |                                            SUPERVISÃO |
| Ler audit logs                         | NEGADA ou muito restrita |                   AMPLA |                 CONTROLADA |                                            SUPERVISÃO |
| Gestão de segurança/permissões         |                   NEGADA |                   AMPLA |         CONTROLADA técnica |                                     NEGADA por padrão |
| Configuração estrutural                |                   NEGADA |              CONTROLADA |              AMPLA técnica |                                            SUPERVISÃO |
| Deploy / sustentação / observabilidade |                   NEGADA |              CONTROLADA |                      AMPLA |                                            SUPERVISÃO |
| Gestão de usuários e papéis            |                   NEGADA |                   AMPLA | NEGADA ou técnica auxiliar |                                     NEGADA por padrão |

---

## 16. Diagrama de fronteira de autoridade por impacto

```mermaid
flowchart LR

    A1[Baixo impacto\neditar rascunho / organizar conteudo] --> P1[Editor ou Admin]

    A2[Medio impacto\nrevisar / taxonomia / preparar publicacao] --> P2[Editor controlado + Admin]

    A3[Alto impacto\npublicar / arquivar / auditoria / exclusao logica] --> P3[Admin principal\nou fluxo fortemente governado]

    A4[Critico\nseguranca / permissoes / configuracao / deploy] --> P4[Admin principal e/ou Mantenedor Tecnico]
```

---

## 17. Leitura específica por perfil

## 17.1 Editor ou Operador de Conteúdo

### Missão principal

Manter o acervo editorial vivo sem receber poderes estruturais excessivos.

### Pode

* autenticar-se no painel;
* acessar dashboard compatível;
* listar publicações;
* criar publicações;
* editar rascunhos;
* revisar conteúdo;
* preparar conteúdo para publicação;
* associar categorias e tags dentro das regras de governança;
* atuar no fluxo editorial cotidiano.

### Não deve poder, por padrão

* alterar permissões globais;
* mudar configuração sensível;
* acessar segurança estrutural;
* gerir sessões de terceiros;
* operar deploy;
* agir como administrador total.

### Observação crítica

O `editor` é um papel **operacional**, não um papel de soberania total.

---

## 17.2 Administrador Principal

### Missão principal

Governar a operação interna, a publicação, a organização administrativa e a integridade do painel.

### Pode

* tudo que o editor pode;
* publicar e arquivar com autoridade plena;
* supervisionar taxonomia;
* consultar auditoria;
* governar fluxos internos;
* decidir sobre ações administrativas mais sensíveis;
* operar recursos de sessão e segurança no escopo do painel.

### Não deve, por padrão conceitual

* agir sem rastreabilidade em ações críticas;
* bypassar auditoria;
* misturar poderes técnicos profundos sem legitimidade ou necessidade.

### Observação crítica

O administrador principal é a role de **governança operacional ampla** do painel.

---

## 17.3 Mantenedor Técnico

### Missão principal

Sustentar a integridade estrutural, disponibilidade e coerência técnica da solução.

### Pode

* atuar em deploy;
* atuar em observabilidade;
* atuar em incidentes;
* corrigir falhas;
* manter coerência entre implementação, ambiente e documentação;
* operar recursos técnicos sensíveis quando legitimado.

### Não deve, por padrão

* ser confundido automaticamente com editor;
* assumir fluxo editorial cotidiano sem necessidade;
* publicar conteúdo institucional só por deter acesso técnico.

### Observação crítica

Mantenedor técnico é papel **técnico-operacional**, não papel editorial por natureza.

---

## 17.4 Titular Institucional

### Missão principal

Supervisionar e decidir em nível institucional quando necessário.

### Pode

* acompanhar dashboard e auditoria quando legitimado;
* aprovar direções e publicações estratégicas;
* supervisionar coerência institucional;
* acumular papel formal quando explicitamente investido.

### Não deve, por padrão

* ser tratado como operador cotidiano do painel;
* receber automaticamente poderes técnicos ou administrativos detalhados apenas por titularidade simbólica;
* substituir o desenho de permissão do sistema por status informal.

### Observação crítica

Titular institucional é perfil de **supervisão e legitimidade**, não necessariamente role operacional de runtime.

---

## 18. Regras soberanas de segregação de funções

O desenho do projeto já sugere uma segregação saudável entre responsabilidades.

### 18.1 Segregação editorial

* quem escreve/edita não precisa ser quem publica sempre;
* quem organiza conteúdo não precisa controlar segurança.

### 18.2 Segregação técnica

* quem faz deploy não precisa publicar conteúdo;
* quem resolve incidente não precisa ter poder editorial pleno.

### 18.3 Segregação institucional

* quem supervisiona institucionalmente não precisa operar cada tela do painel.

### 18.4 Conclusão

O sistema deve favorecer **segregação de função**, mesmo quando o time é pequeno e parte dos papéis se acumula temporariamente.

---

## 19. Regras de transição editorial e permissões

Com base na governança editorial real do projeto, as transições devem ser compreendidas assim:

| Transição                       |              Editor | Admin |
| ------------------------------- | ------------------: | ----: |
| `draft -> review`               |                 SIM |   SIM |
| `review -> ready_to_publish`    |                 SIM |   SIM |
| `ready_to_publish -> published` | PARCIAL / governado |   SIM |
| `published -> archived`         | PARCIAL / governado |   SIM |

### Interpretação correta

* o editor participa do ciclo;
* o admin possui poder final pleno;
* a publicação e o arquivamento exigem autoridade maior ou fluxo controlado.

---

## 20. Regras de taxonomia e permissões

Taxonomia não é detalhe cosmético.
Ela impacta SEO, organização e governança editorial.

### 20.1 Categorias

Por serem macrotemas e afetarem a estrutura de navegação e descoberta, devem receber governança mais rígida.

### 20.2 Tags

Podem admitir operação mais flexível, mas ainda precisam de controle contra redundância e ruído.

### 20.3 Regra soberana

* editor pode **usar** taxonomia e, conforme a fase, atuar de modo controlado;
* admin governa a taxonomia de forma ampla;
* alterações taxonômicas relevantes devem ser rastreáveis.

---

## 21. Regras de auditoria por perfil

Nem todo papel precisa ver tudo.

### 21.1 Editor

Não deve ler audit logs amplos por padrão, salvo recorte estritamente necessário e legitimado.

### 21.2 Admin

Pode e deve acessar auditoria suficiente para governança operacional.

### 21.3 Mantenedor Técnico

Pode precisar de leitura técnica ou contextual de eventos, mas não necessariamente da auditoria editorial ampla como rotina de negócio.

### 21.4 Titular Institucional

Pode ter leitura de supervisão, não necessariamente operação detalhada de todos os eventos.

---

## 22. Regras de segurança e configuração por perfil

### 22.1 Segurança/permissões

Devem ficar sob escopo do:

* Administrador Principal
* e, quando houver componente técnico-operacional, do Mantenedor Técnico em sua área legítima

### 22.2 Editor

Não deve tocar:

* permissões globais
* sessões de terceiros
* segredos
* hardening
* configuração estrutural

### 22.3 Titular Institucional

Pode determinar direção, mas não deve receber permissão operacional ampla sem investidura formal e controlada.

---

## 23. Diagrama de restrições operacionais

```mermaid
flowchart TD

    E[Editor] -->|nao pode por padrao| S1[Seguranca global]
    E -->|nao pode por padrao| S2[Permissoes de terceiros]
    E -->|nao pode por padrao| S3[Deploy]
    E -->|nao pode por padrao| S4[Configuracao sensivel]

    A[Admin] -->|pode| G1[Governanca editorial]
    A -->|pode| G2[Auditoria]
    A -->|pode| G3[Publicacao e arquivamento]
    A -->|pode| G4[Permissoes do painel]

    M[Mantenedor Tecnico] -->|pode| T1[Deploy]
    M -->|pode| T2[Observabilidade]
    M -->|pode| T3[Recuperacao tecnica]
    M -->|nao deve por padrao| T4[Operacao editorial cotidiana]
```

---

## 24. Como o backend deve aplicar esta matriz

A aplicação correta da matriz não pode ficar só na interface.

## 24.1 Regra soberana

Toda rota administrativa deve:

1. autenticar;
2. validar sessão;
3. verificar role/perfil suficiente;
4. só então executar a ação.

## 24.2 Consequência

Ocultar botão no frontend **não** substitui checagem de permissão no backend.

## 24.3 Implementação mínima coerente

* `GET /admin/dashboard` -> `admin` e, futuramente, `editor` com recorte apropriado
* CRUD de publicações -> `admin` e `editor`, com limites por ação
* status editorial final -> `admin`, ou `editor` somente quando política explícita permitir
* audit logs -> `admin`
* segurança/configuração -> `admin` ou role técnica própria quando vier a existir

---

## 25. Mapa sugerido de rotas e papéis

A tabela abaixo traduz a OpenAPI administrativa em leitura de permissão.

| Rota administrativa                     | `admin` | `editor` | Observação                        |
| --------------------------------------- | ------: | -------: | --------------------------------- |
| `POST /admin/auth/login`                |     SIM |      SIM | entrada autenticada               |
| `POST /admin/auth/logout`               |     SIM |      SIM | encerra sessão própria            |
| `GET /admin/auth/session`               |     SIM |      SIM | lê sessão própria                 |
| `GET /admin/dashboard`                  |     SIM |      SIM | escopo do dashboard pode variar   |
| `GET /admin/publications`               |     SIM |      SIM | listagem editorial                |
| `POST /admin/publications`              |     SIM |      SIM | criação de conteúdo               |
| `GET /admin/publications/{id}`          |     SIM |      SIM | leitura interna                   |
| `PUT /admin/publications/{id}`          |     SIM |      SIM | edição de conteúdo                |
| `DELETE /admin/publications/{id}`       |     SIM |  PARCIAL | soft delete deve ser governado    |
| `PATCH /admin/publications/{id}/status` |     SIM |  PARCIAL | status final exige governança     |
| `GET /admin/categories`                 |     SIM |      SIM | leitura/uso taxonômico            |
| `POST /admin/categories`                |     SIM |  PARCIAL | criação taxonômica com controle   |
| `PUT /admin/categories/{id}`            |     SIM |  PARCIAL | alteração taxonômica com controle |
| `GET /admin/tags`                       |     SIM |      SIM | leitura/uso taxonômico            |
| `POST /admin/tags`                      |     SIM |  PARCIAL | criação taxonômica com controle   |
| `PUT /admin/tags/{id}`                  |     SIM |  PARCIAL | alteração taxonômica com controle |
| `GET /admin/audit-logs`                 |     SIM |      NÃO | governança/auditoria              |

---

## 26. Critérios de aceite relacionados a permissões

A camada administrativa só deve ser considerada aceita quando:

1. login funcionar;
2. sessão válida não conceder poder acima do papel;
3. rota administrativa protegida negar acesso indevido;
4. `editor` não conseguir executar ação crítica não autorizada;
5. `admin` conseguir concluir fluxos administrativos essenciais;
6. auditoria refletir ações relevantes;
7. público e admin não se misturarem;
8. publicação final obedecer governança real.

### Bloqueadores absolutos

* rota admin acessível sem autenticação;
* `editor` alterando segurança/configuração sem legitimidade;
* publicação final sem controle de autoridade;
* audit log inexistente onde deveria existir;
* backend aceitando ação acima do papel.

---

## 27. Testes mínimos da matriz de permissão

A matriz precisa entrar em testes.

### 27.1 Casos mínimos P0

1. `admin` acessa dashboard.
2. `editor` acessa dashboard compatível.
3. `editor` cria publicação.
4. `editor` edita rascunho.
5. `editor` não acessa audit logs.
6. `editor` não altera configuração sensível.
7. `admin` consulta audit logs.
8. `admin` publica conteúdo.
9. rota administrativa sem sessão retorna negação.
10. role insuficiente retorna `FORBIDDEN`.

### 27.2 Casos mínimos P1

1. `editor` altera taxonomia apenas dentro do escopo permitido.
2. `editor` tenta publicar sem autoridade final e é bloqueado.
3. `mantenedor técnico`, quando existir em runtime, não recebe poderes editoriais indevidos.
4. acúmulo formal de papel funciona sem quebrar rastreabilidade.

---

## 28. Estado real materializado hoje

Este bloco é decisivo para honestidade operacional.

## 28.1 Já comprovado no acervo

* necessidade de distinção entre público e admin;
* perfis internos conceituais claros;
* política soberana de permissão proporcional;
* papel inicial `admin`;
* papel evolutivo `editor`;
* rotas administrativas para publicações, taxonomia, auditoria e sessão;
* critérios de aceite exigindo autenticação, proteção e rastreabilidade.

## 28.2 Ainda não comprovado como implementação completa

* RBAC completo já executando todos os perfis conceituais;
* `editor` plenamente operacional no runtime atual;
* perfis `mantenedor_tecnico` e `titular_institucional` como roles reais do painel;
* tabela de usuários/papéis consultável no painel;
* delegação/gestão de permissões por UI;
* ABAC fino contextual em produção.

## 28.3 Leitura correta

A governança de permissões está **mais madura documentalmente** do que no runtime atual, mas o desenho já é suficientemente claro para orientar implementação segura.

---

## 29. Riscos do estágio atual

## 29.1 Risco de tudo virar `admin`

É comum em estágios iniciais concentrar tudo em um único papel.

### Mitigação

* manter a role `admin` só como P0 transitório;
* abrir `editor` com limites claros;
* não banalizar superpoder administrativo.

## 29.2 Risco de editor virar pseudo-admin por conveniência

Isso contradiz frontalmente a política soberana do projeto.

### Mitigação

* distinguir edição de publicação;
* distinguir taxonomia de segurança;
* negar segurança/configuração ao editor.

## 29.3 Risco de perfis conceituais não se traduzirem tecnicamente

Documentação rica sem enforcement vira fragilidade.

### Mitigação

* mapear perfis conceituais para roles/claims reais;
* testar todas as rotas sensíveis;
* auditar negações e acessos críticos.

## 29.4 Risco de falta de segregação de função

Quando um único ator concentra tudo sem rastreabilidade, aumenta o dano potencial.

### Mitigação

* separar papéis sempre que possível;
* acumular papel apenas formalmente;
* manter auditoria dos eventos críticos.

---

## 30. Decisões arquiteturais firmadas por este documento

1. Permissões do projeto obedecem à hierarquia de impacto da ação.
2. O backend é a autoridade final de autorização.
3. `admin` é a role ampla do painel no estado atual.
4. `editor` é a role editorial controlada da evolução prevista.
5. Publicação final, arquivamento, auditoria e segurança exigem autoridade superior à edição cotidiana.
6. Taxonomia deve ser governada, não livre por conveniência.
7. Perfis conceituais mais ricos existem acima da camada mínima de runtime.
8. Mantenedor Técnico não deve ser confundido com editor.
9. Titular Institucional não deve receber automaticamente poder operacional total.
10. Toda permissão crítica precisa ser compatível com rastreabilidade e auditoria.

---

## 31. O que este documento resolve

Este documento resolve:

* a visão macro de permissões por perfil;
* a diferença entre perfil conceitual e role técnica;
* a matriz de acesso por recurso e ação;
* as restrições operacionais de cada papel;
* a relação entre publicação, taxonomia, segurança e auditoria;
* a base para testes e enforcement backend.

---

## 32. O que este documento ainda não resolve

Este documento ainda não resolve, em detalhe fino:

* modelagem física da tabela de roles/claims;
* UI de administração de usuários e papéis;
* acúmulo formal de múltiplos papéis em runtime;
* ABAC contextual por horário, origem ou ambiente;
* políticas finas de delegação temporária;
* exceções emergenciais de acesso sob break-glass controlado.

Esses pontos pertencem à evolução técnica posterior e ao fechamento do bloco de segurança.

---

## 33. Critérios de aceite do documento

Este documento será considerado aceito quando cumprir simultaneamente os seguintes critérios:

1. representar com clareza os perfis internos relevantes;
2. distinguir honestamente estado atual e estado soberano;
3. mostrar recursos acessíveis, restrições e zonas de autoridade;
4. manter coerência com requisitos funcionais, segurança, critérios de aceite e backend real;
5. servir como base prática para implementação de RBAC seguro.

---

## 34. Conclusão arquitetural

O projeto William Albarello já possui uma política de permissões conceitualmente madura:

* o público é separado do admin;
* o editor não deve ser admin por comodidade;
* o admin governa a operação interna;
* publicação final é mais sensível que rascunho;
* segurança e configuração pertencem a uma fronteira superior de autoridade;
* auditoria existe para sustentar confiança operacional.

A leitura correta do momento atual é esta:

* o desenho de papéis já está claro;
* o contrato técnico já aponta `admin` e `editor`;
* os perfis conceituais organizacionais já foram pensados;
* o próximo passo é endurecer isso no runtime sem perder a elegância do modelo.

Em linguagem simples:

> o projeto já sabe quem deve mandar em quê; agora precisa transformar essa hierarquia documentada em autorização backend plenamente executável.

---

