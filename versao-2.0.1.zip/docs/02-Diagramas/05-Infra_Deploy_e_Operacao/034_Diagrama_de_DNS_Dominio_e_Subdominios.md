
# 034_Diagrama_de_DNS_Dominio_e_Subdominios

## 1. Identificação do documento

- **Projeto:** William Albarello
- **Diretório:** `02-Diagramas`
- **Caminho oficial:** `/home/user/Documents/Softwares/Willian Albarello/William Albarello/02-Diagramas/05-Infra_Deploy_e_Operacao/034_Diagrama_de_DNS_Dominio_e_Subdominios.md`
- **Natureza do documento:** Diagrama e contrato lógico de DNS, domínio e subdomínios
- **Função sistêmica:** Explicar a política de domínio, subdomínios, apontamentos, fronteiras públicas, responsabilidades, ambientes e impactos operacionais do projeto
- **Posição no bloco:** Terceiro documento do bloco `05-Infra_Deploy_e_Operacao`
- **Dependências principais:** `012_Modulos_Dominios_e_Limites_do_Software.md`, `014_Integracoes_e_Sistemas_Externos.md`, `015_Seguranca_Privacidade_Auditoria_e_Permissoes.md`, `022_Plano_de_Implantacao_Rollback_e_Suporte.md`, `032_Diagrama_de_Deploy_Vercel_Render.md`, `033_Diagrama_de_Infraestrutura_Geral.md`
- **Status:** ATIVO
- **Versão:** v1.0
- **Autoridade:** Alta

---

## 2. Objetivo

Este documento existe para declarar, de forma clara e soberana, **como o projeto William Albarello organiza sua presença nominal na internet**.

Sua finalidade é responder, com precisão, às seguintes perguntas:

1. qual é o domínio principal do projeto;
2. qual é o subdomínio da API;
3. qual é a fronteira entre superfície pública e superfície administrativa;
4. como os nomes públicos se conectam a Vercel, Render e demais componentes;
5. como staging e produção devem ser compreendidos;
6. quais impactos operacionais um erro de DNS pode causar;
7. quais responsabilidades pertencem ao domínio principal, aos subdomínios e às rotas protegidas.

Este documento trata DNS não como detalhe técnico periférico, mas como parte estrutural da identidade e da operação do sistema.

---

## 3. Fontes reais usadas para construir este documento

Este documento foi construído com base em artefatos efetivamente encontrados no acervo do projeto.

### 3.1 Documentação soberana
- `01-Waterfall/01-Obrigatorios/012_Modulos_Dominios_e_Limites_do_Software.md`
- `01-Waterfall/01-Obrigatorios/014_Integracoes_e_Sistemas_Externos.md`
- `01-Waterfall/01-Obrigatorios/015_Seguranca_Privacidade_Auditoria_e_Permissoes.md`
- `01-Waterfall/01-Obrigatorios/022_Plano_de_Implantacao_Rollback_e_Suporte.md`
- `01-Waterfall/01-Obrigatorios/024_Registro_de_Decisoes_Arquiteturais.md`

### 3.2 Infraestrutura e diagramas já consolidados
- `032_Diagrama_de_Deploy_Vercel_Render.md`
- `033_Diagrama_de_Infraestrutura_Geral.md`

### 3.3 Monorepo real `personal-site`
- `.env.example`
- `apps/web/next.config.mjs`
- `apps/admin/next.config.mjs`
- `apps/web/app/layout.tsx`
- `apps/web/app/robots.ts`
- `apps/web/app/sitemap.ts`
- `apps/api/src/server.ts`
- `APIs/API-06-openapi-public.yaml`
- `APIs/API-07-openapi-admin.yaml`
- `README.md`
- `Diagrama/DGM-05-deploy-vercel-render.mmd`
- `Diagrama/DGM-01-arquitetura-geral.mmd`

### 3.4 Evidências documentais internas do monorepo
- `Waterfall/DOC-10-arquitetura-tecnica.md`
- `Waterfall/DOC-15-seo-tecnico.md`
- `Waterfall/DOC-20-plano-de-deploy-ambientes-e-cicd.md`
- `Waterfall/DOC-22-operacao-runbooks-e-rotina-de-publicacao.md`
- `Waterfall/DOC-24-go-live-checklist-e-handover-final.md`

---

## 4. Regra de honestidade técnica deste documento

Este ponto é fundamental.

O acervo **comprova diretamente**:

- o domínio principal soberano: `willianalbarello.com.br`;
- o subdomínio soberano da API: `api.willianalbarello.com.br`;
- o consumo da API pelo frontend a partir de `https://api.willianalbarello.com.br`;
- a existência da superfície administrativa sob a lógica soberana de `/painel`;
- a política de SEO que bloqueia `/painel` em `robots`;
- o sitemap público em `https://willianalbarello.com.br/sitemap.xml`;
- o uso de Vercel para o frontend;
- o uso de Render para API e banco;
- a presença de `local`, `staging` e `production` como ambientes reconhecidos.

O acervo **não comprova diretamente**:

- o provedor nominal do domínio e da zona DNS;
- os records exatos atualmente criados no painel do provedor;
- a existência de `www.willianalbarello.com.br`;
- a existência de subdomínios customizados de staging;
- prints reais do painel do registrador, da Vercel ou da Render.

Portanto, este documento trabalha com duas camadas de verdade:

### 4.1 Verdade comprovada
Tudo o que está explicitamente materializado nos arquivos do projeto.

### 4.2 Materialização operacional coerente
A forma mais consistente de representar o desenho de DNS necessário para que a arquitetura já documentada funcione corretamente.

Essa distinção deve ser preservada.

---

## 5. Tese central do domínio e do DNS

A tese central deste documento é a seguinte:

> o projeto William Albarello deve possuir uma fachada digital única e institucional no domínio principal, mantendo a camada de aplicação separada em subdomínio próprio de API, enquanto a superfície administrativa continua pertencendo ao mesmo domínio institucional por rota protegida, e não como presença pública autônoma indexável.

Em linguagem simples:

- o **domínio principal** representa a instituição;
- o **subdomínio de API** representa a camada de aplicação;
- o **painel** é parte do mesmo sistema, mas não é superfície pública indexável;
- o **DNS** existe para costurar com clareza essa separação;
- qualquer erro de DNS afeta diretamente reputação, disponibilidade e operação.

---

## 6. Estrutura nominal soberana do projeto

## 6.1 Domínio principal
`willianalbarello.com.br`

É a fachada institucional principal do projeto.

Responsabilidades:
- presença pública;
- autoridade institucional;
- páginas principais;
- publicações;
- SEO técnico;
- sitemap;
- metadata pública;
- rota lógica do painel.

## 6.2 Subdomínio da API
`api.willianalbarello.com.br`

É a fachada nominal da camada de aplicação.

Responsabilidades:
- servir a API pública e administrativa;
- receber chamadas do frontend público e do painel;
- concentrar autenticação, sessão, regras e persistência;
- separar claramente apresentação e aplicação.

## 6.3 Superfície administrativa
`willianalbarello.com.br/painel`

É a superfície lógica e soberana do painel interno.

Responsabilidades:
- login administrativo;
- acesso interno protegido;
- edição e gestão de conteúdo;
- operação institucional.

### Regra crítica
O painel **não é tratado como subdomínio público independente comprovado pelo acervo**.  
Ele deve ser compreendido como rota protegida pertencente ao domínio institucional.

---

## 7. Leitura correta da fronteira pública

O projeto possui uma distinção muito importante entre:

### 7.1 O que é público e indexável
- home;
- páginas institucionais;
- páginas públicas de conteúdo;
- listagem de publicações;
- publicações individuais;
- arquivos públicos de SEO, como `robots.txt` e `sitemap.xml`.

### 7.2 O que é interno e não deve ser tratado como público indexável
- `/painel`
- `/painel/login`
- `/painel/publicacoes`
- demais rotas internas do painel

Essa distinção é reforçada pelos artefatos reais do projeto, que já trazem a política de `robots` bloqueando `/painel`.

---

## 8. Diagrama principal de domínio, DNS e subdomínios

```mermaid
flowchart TB

    U1[Visitante publico]
    U2[Administrador interno]

    DNS[Zona DNS autoritativa\nprovedor nao explicitado no acervo]

    ROOT[willianalbarello.com.br]
    APIHOST[api.willianalbarello.com.br]

    subgraph FRONT["Camada web"]
        VERCEL[Vercel\nfrontend publico + superficie administrativa]
        SEO[robots.txt + sitemap.xml + metadata]
        PAINEL[/painel\nrota protegida]
    end

    subgraph APP["Camada de aplicacao"]
        RENDER[Render API]
        API[/v1\nAPI publica + administrativa]
        AUTH[auth + sessao + csrf + cors]
        DB[(PostgreSQL)]
    end

    U1 --> DNS
    U2 --> DNS

    DNS --> ROOT
    DNS --> APIHOST

    ROOT --> VERCEL
    VERCEL --> SEO
    VERCEL --> PAINEL

    VERCEL --> APIHOST
    APIHOST --> RENDER
    RENDER --> API
    API --> AUTH
    API --> DB
````

---

## 9. Diagrama de fronteiras públicas e internas

```mermaid
flowchart LR

    subgraph PUBLICO["Fronteira publica"]
        D1[willianalbarello.com.br]
        D2[/]
        D3[/publicacoes]
        D4[/publicacoes/[slug]]
        D5[/sitemap.xml]
        D6[/robots.txt]
    end

    subgraph INTERNO["Fronteira interna protegida"]
        A1[/painel]
        A2[/painel/login]
        A3[/painel/publicacoes]
        A4[/painel/categorias]
        A5[/painel/tags]
        A6[/painel/auditoria]
    end

    subgraph API["Fronteira de aplicacao"]
        B1[api.willianalbarello.com.br]
        B2[/v1/public/*]
        B3[/v1/admin/*]
        B4[/health]
    end
```

---

## 10. Significado arquitetural do domínio principal

O domínio principal não é apenas endereço de acesso.

Ele é:

* identidade pública do projeto;
* referência de SEO;
* base de canonical;
* base de metadata;
* base do sitemap;
* referência de reputação;
* superfície de relacionamento com o usuário comum.

Tudo o que representa institucionalmente o sistema deve gravitar em torno do domínio principal.

Por isso, a decisão soberana correta é:

> o domínio principal concentra a presença institucional; a API vive separada em subdomínio; o painel permanece subordinado ao domínio principal como rota protegida.

---

## 11. Significado arquitetural do subdomínio da API

O subdomínio `api.willianalbarello.com.br` existe para evitar mistura indevida entre:

* camada de apresentação;
* camada de aplicação;
* camada de autenticação;
* camada de integração.

Sua existência traz vantagens estruturais importantes:

### 11.1 Clareza de fronteira

Fica evidente onde termina o site e onde começa a API.

### 11.2 Governança técnica melhor

Fica mais simples:

* versionar contratos;
* aplicar políticas de CORS;
* controlar headers;
* monitorar saúde do backend;
* proteger superfícies de administração.

### 11.3 Escalabilidade de operação

A API pode evoluir operacionalmente sem deformar a fachada institucional do site.

### 11.4 Observabilidade mais limpa

Separar o host de aplicação facilita leitura de erros, disponibilidade e incidentes.

---

## 12. Papel da rota `/painel` dentro do DNS

Este é um ponto sensível e precisa ficar cristalino.

O projeto possui dois fatos coexistindo:

### 12.1 Fato soberano documental

A camada administrativa é apresentada como rota protegida sob:

* `/painel`
* `/painel/login`
* `/painel/publicacoes`
* e demais rotas internas

### 12.2 Fato físico do monorepo

Existe separação de implementação em:

* `apps/web`
* `apps/admin`

### 12.3 Conclusão correta para DNS

O DNS soberano **não precisa expor isso ao usuário final**.

A leitura correta é:

* o usuário público conhece `willianalbarello.com.br`;
* o administrador conhece `willianalbarello.com.br/painel`;
* a costura física entre apps pertence à infraestrutura interna;
* a fronteira nominal continua institucional e unificada.

Isso protege a coerência do sistema.

---

## 13. Diagrama de resolução nominal por responsabilidade

```mermaid
flowchart TD

    R1[willianalbarello.com.br] --> S1[Site institucional]
    R1 --> S2[Paginas publicas]
    R1 --> S3[Publicacoes]
    R1 --> S4[SEO tecnico]
    R1 --> S5[Painel como rota protegida]

    R2[api.willianalbarello.com.br] --> T1[API publica]
    R2 --> T2[API administrativa]
    R2 --> T3[Auth + sessao]
    R2 --> T4[Healthcheck]
    R2 --> T5[Regras de negocio]
```

---

## 14. Política de indexação e SEO aplicada ao domínio

O desenho de DNS precisa respeitar a política de indexação do projeto.

## 14.1 O que deve ser indexável

Sob o domínio principal:

* home;
* páginas institucionais;
* listagem de publicações;
* páginas de publicações públicas;
* assets e páginas necessárias à descoberta legítima.

## 14.2 O que não deve ser indexável

Sob a rota administrativa:

* `/painel`
* `/painel/*`

## 14.3 Evidência arquitetural já materializada

O projeto já contém:

* `robots` com bloqueio de `/painel`;
* `sitemap.xml` apontando para o domínio principal;
* `metadataBase` associada ao domínio principal;
* política de canonical centrada em `willianalbarello.com.br`.

## 14.4 Consequência operacional

A política de DNS e domínio não pode contradizer o SEO.
Se o sistema expuser subdomínios ou rotas internas erradas ao público, poderá:

* gerar indexação indevida;
* criar páginas duplicadas;
* degradar canonical;
* enfraquecer reputação do domínio;
* expor superfícies administrativas em rastreamento.

---

## 15. Apontamentos lógicos de produção

Sem inventar records exatos de painel, a topologia lógica de produção é esta:

### 15.1 Apontamento do domínio principal

`willianalbarello.com.br`
deve apontar para a camada web publicada na **Vercel**.

Responsabilidade efetiva:

* servir o site institucional;
* servir os arquivos de SEO técnico;
* servir a superfície administrativa por rota protegida;
* sustentar a navegação pública.

### 15.2 Apontamento do subdomínio de API

`api.willianalbarello.com.br`
deve apontar para a camada de aplicação publicada na **Render**.

Responsabilidade efetiva:

* servir a API versionada;
* responder chamadas públicas e administrativas;
* concentrar autenticação e integração com banco.

### 15.3 Banco

O banco **não recebe apontamento público de DNS no desenho soberano do projeto**.
Ele é infraestrutura interna de backend.

---

## 16. Diagrama lógico de apontamentos de produção

```mermaid
flowchart LR

    Z[Zona DNS]

    Z --> APEX[willianalbarello.com.br]
    Z --> API[api.willianalbarello.com.br]

    APEX --> WEB[Vercel production]
    API --> APP[Render production API]

    WEB --> PUBLICO[site + conteudo + SEO]
    WEB --> PAINEL[painel /painel]

    APP --> AUTH[auth + sessao]
    APP --> DB[(PostgreSQL)]
```

---

## 17. Ambientes e presença nominal

O projeto reconhece três ambientes:

* `local`
* `staging`
* `production`

Mas esses ambientes **não possuem, no acervo analisado, nomes DNS soberanos todos já formalizados**.

---

## 18. Leitura correta de cada ambiente

## 18.1 Local

É ambiente de desenvolvimento.

Forma de acesso comprovada:

* `web` em `:3000`
* `admin` em `:3001`
* `api` em `:3002`

No local, a resolução é técnica e não institucional.
Não há papel de DNS público real.

## 18.2 Staging

Existe como ambiente arquitetural reconhecido, mas **não há comprovação de subdomínios customizados soberanos de staging**.

A leitura mais correta, com base no acervo, é:

* staging pode viver em previews da Vercel;
* staging pode viver em serviços de staging na Render;
* o nome público exato de staging ainda não foi soberanamente fixado no material anexado.

### Consequência importante

Neste estágio, staging deve ser compreendido mais como **ambiente operacional e de validação** do que como presença nominal pública final já fixada por DNS.

## 18.3 Production

É o ambiente plenamente soberano e nominalmente comprovado:

* `https://willianalbarello.com.br`
* `https://api.willianalbarello.com.br`

---

## 19. Diagrama de ambientes e nomes

```mermaid
flowchart TB

    subgraph LOCAL["local"]
        L1[localhost:3000\nweb]
        L2[localhost:3001\nadmin]
        L3[localhost:3002\napi]
    end

    subgraph STAGING["staging"]
        S1[Vercel preview / staging URL]
        S2[Render staging URL]
        S3[Subdominios customizados nao comprovados]
    end

    subgraph PROD["production"]
        P1[willianalbarello.com.br]
        P2[api.willianalbarello.com.br]
    end
```

---

## 20. Impactos operacionais de um erro de DNS

DNS errado não causa apenas “site fora do ar”.
Ele pode quebrar a arquitetura inteira.

### 20.1 Se o domínio principal apontar errado

Impactos possíveis:

* site indisponível;
* páginas públicas inacessíveis;
* SEO degradado;
* canonical inconsistente;
* falha de confiança do usuário;
* quebra de acesso ao painel se este depender do mesmo host institucional.

### 20.2 Se o subdomínio da API apontar errado

Impactos possíveis:

* frontend carrega, mas sem dados;
* painel carrega, mas sem autenticação funcional;
* chamadas de API falham;
* sessão e rotas administrativas deixam de operar;
* healthcheck pode parar de responder.

### 20.3 Se houver falha de TLS/certificado

Impactos possíveis:

* bloqueio de navegação;
* erros de navegador;
* quebra de confiança;
* falha em chamadas cross-origin;
* risco de inutilização prática do ambiente produtivo.

### 20.4 Se o DNS propagar parcialmente

Impactos possíveis:

* alguns usuários veem a versão correta;
* outros veem a incorreta;
* incidentes intermitentes ficam mais difíceis de diagnosticar;
* rollback operacional se torna mais confuso.

---

## 21. Responsabilidades por fronteira nominal

## 21.1 Domínio principal

Responsável por:

* imagem institucional;
* experiência pública;
* indexação legítima;
* conteúdo;
* relacionamento inicial;
* acesso administrativo por rota protegida.

## 21.2 Subdomínio de API

Responsável por:

* contratos de aplicação;
* integrações frontend-backend;
* autenticação;
* sessão;
* dados;
* operações administrativas e públicas.

## 21.3 Rotas protegidas sob o domínio principal

Responsáveis por:

* entrada administrativa;
* edição;
* operação;
* navegação interna controlada.

### Regra importante

A rota protegida faz parte da fachada institucional, mas não deve ser tratada como superfície pública de descoberta.

---

## 22. Política de segurança aplicada ao DNS e aos hosts

O DNS deve respeitar a política de segurança do projeto.

### 22.1 Separação de host para API

Ajuda a:

* aplicar CORS com mais clareza;
* isolar a camada de aplicação;
* reduzir acoplamento indevido;
* melhorar diagnóstico de falhas.

### 22.2 Não exposição do banco

O banco não deve possuir presença pública soberana no mapa do usuário final.

### 22.3 Não publicização do painel como subdomínio externo sem necessidade

Como a política soberana é `/painel`, criar exposição paralela desnecessária aumentaria:

* superfície de confusão;
* risco de duplicação;
* risco de rastreamento;
* risco de desalinhamento SEO.

### 22.4 `robots` e DNS devem cooperar

Não basta bloquear `/painel` em `robots` se a infraestrutura começar a expor caminhos alternativos indevidos.

---

## 23. Situação do `www`

O acervo analisado **não comprova explicitamente** o uso de `www.willianalbarello.com.br`.

Portanto, a posição correta deste documento é:

* o host soberano comprovado é **sem `www`**;
* se o `www` existir no futuro, ele deverá ser tratado como alias controlado e redirecionado para o host canônico;
* este documento não deve afirmar `www` como verdade já configurada.

Essa cautela evita erro documental.

---

## 24. Situação de subdomínios adicionais

Também **não há comprovação soberana**, no acervo anexado, de subdomínios públicos adicionais como:

* `admin.willianalbarello.com.br`
* `staging.willianalbarello.com.br`
* `cms.willianalbarello.com.br`
* `docs.willianalbarello.com.br`

Portanto, a leitura correta é:

* o domínio soberano comprovado é `willianalbarello.com.br`;
* o subdomínio soberano comprovado é `api.willianalbarello.com.br`;
* qualquer outro nome adicional deve ser tratado como hipótese futura, não como fato já consolidado.

---

## 25. Relação entre DNS e implantação

Este documento se conecta diretamente ao plano de implantação.

O DNS participa da implantação porque:

* define o endereço efetivo de produção;
* condiciona a transição entre staging e produção;
* impacta validade de smoke tests;
* interfere em TLS;
* interfere em SEO;
* interfere em disponibilidade;
* interfere em rollback e recuperação.

### Regra operacional soberana

Não existe go-live saudável se:

* o domínio principal não resolve corretamente;
* o subdomínio da API não resolve corretamente;
* a certificação HTTPS não estiver íntegra;
* os apontamentos contradisserem a arquitetura de deploy.

---

## 26. Relação entre DNS e rollback

Em incidentes relevantes, o DNS pode participar do problema ou da contenção.

### 26.1 Quando DNS pode ser causa do incidente

* apontamento incorreto;
* troca indevida de alvo;
* erro de certificado associado;
* propagação inconsistente;
* configuração divergente entre host principal e API.

### 26.2 Quando DNS pode influenciar rollback

* se o incidente for apenas de aplicação, rollback pode acontecer na Vercel/Render sem mexer em DNS;
* se o incidente estiver no apontamento, DNS entra no plano de correção;
* se houver troca de domínio ou host incorretos, rollback pode exigir reversão nominal.

### 26.3 Conclusão

DNS deve ser tratado como parte do plano de contingência, e não como detalhe “fora do deploy”.

---

## 27. Critérios de saúde nominal do projeto

O projeto será considerado nominalmente saudável quando, simultaneamente:

1. `willianalbarello.com.br` responder corretamente;
2. `api.willianalbarello.com.br` responder corretamente;
3. o frontend conseguir consumir a API;
4. `/painel` estiver coerente com a política de acesso;
5. `robots.txt` estiver publicado e bloqueando `/painel`;
6. `sitemap.xml` estiver acessível no domínio principal;
7. HTTPS estiver válido em todos os hosts públicos relevantes.

---

## 28. Riscos específicos do desenho nominal

## 28.1 Risco de contradição entre rota `/painel` e implementação física em `apps/admin`

Mitigação:

* manter a soberania do `/painel` como verdade institucional;
* resolver a costura técnica sem romper a fachada nominal.

## 28.2 Risco de indexação indevida de área interna

Mitigação:

* manter bloqueio de `/painel` em `robots`;
* evitar exposição paralela desnecessária de hosts administrativos.

## 28.3 Risco de ambiente de staging confundir produção

Mitigação:

* não tratar preview/staging como host público soberano;
* deixar produção claramente identificada pelos dois nomes oficiais.

## 28.4 Risco de dependência excessiva de configuração manual invisível

Mitigação:

* documentar apontamentos efetivos quando os prints/painéis forem consolidados;
* reduzir conhecimento implícito.

---

## 29. Decisões arquiteturais firmadas por este documento

1. O host institucional soberano do projeto é `willianalbarello.com.br`.
2. O host soberano da camada de aplicação é `api.willianalbarello.com.br`.
3. A área administrativa continua soberanamente representada como rota protegida em `/painel`.
4. O painel não deve ser tratado, neste estágio, como subdomínio público independente já comprovado.
5. O domínio principal deve apontar para a camada web em Vercel.
6. O subdomínio da API deve apontar para a camada de aplicação em Render.
7. O banco não integra a superfície nominal pública do sistema.
8. O staging existe como ambiente real, mas seus nomes DNS customizados não estão comprovados no acervo.
9. A política de DNS deve cooperar com SEO, segurança, implantação, rollback e operação.
10. O host canônico comprovado é sem `www`, salvo futura formalização em contrário.

---

## 30. O que este documento resolve

Este documento resolve:

* a leitura clara do domínio principal;
* a leitura clara do subdomínio da API;
* a fronteira entre público, interno e aplicação;
* a relação entre DNS e arquitetura;
* os impactos operacionais de apontamentos errados;
* a leitura correta dos ambientes sob a ótica nominal;
* a integração entre DNS, SEO, deploy e operação.

---

## 31. O que este documento ainda não resolve

Este documento ainda não resolve, em detalhe fino:

* records concretos do provedor de DNS;
* TTLs;
* configuração exata do apex no registrador;
* políticas de proxy/CDN do provedor, se existirem;
* redirects de `www`, se vierem a existir;
* desenho fino de preview URLs;
* costura final da superfície `/painel` no nível de roteamento interno.

Esses pontos podem ser aprofundados em documentação operacional complementar ou runbook específico de publicação.

---

## 32. Critérios de aceite do documento

Este documento será considerado aceito quando cumprir simultaneamente os seguintes critérios:

1. identificar corretamente o domínio e o subdomínio soberanos já comprovados;
2. explicar claramente a função de cada host;
3. manter coerência com a política de SEO e de bloqueio do painel;
4. explicar a diferença entre produção comprovada e staging não nominalmente fixado;
5. reconhecer honestamente o que o acervo prova e o que ele não prova;
6. servir como base confiável para operação, deploy e contingência.

---

## 33. Conclusão arquitetural

O desenho nominal do projeto William Albarello já está suficientemente maduro para ser compreendido de forma clara e disciplinada:

* o domínio principal representa a instituição;
* o subdomínio da API representa a aplicação;
* o painel pertence à mesma instituição por rota protegida;
* o DNS costura frontend, backend e reputação pública;
* SEO, segurança, deploy e rollback dependem dessa coerência.

Em linguagem simples:

> o projeto deve aparecer para o mundo como uma única instituição digital, mas operar internamente com separação técnica suficiente entre presença web, aplicação e dados.

---

