
# 037_Diagrama_de_Disponibilidade_e_Recuperacao

## 1. Identificação do documento

- **Projeto:** William Albarello
- **Diretório:** `02-Diagramas`
- **Caminho oficial:** `/home/user/Documents/Softwares/Willian Albarello/William Albarello/02-Diagramas/05-Infra_Deploy_e_Operacao/037_Diagrama_de_Disponibilidade_e_Recuperacao.md`
- **Natureza do documento:** Diagrama e contrato lógico de disponibilidade, contingência, recuperação e retomada operacional
- **Função sistêmica:** Modelar continuidade operacional, falhas, mitigação, recuperação, retomada segura de serviço e critérios de restauração
- **Posição no bloco:** Sexto e último documento do bloco `05-Infra_Deploy_e_Operacao`
- **Dependências principais:** `007_Requisitos_Nao_Funcionais.md`, `019_Riscos_Premissas_Restricoes_e_Mitigacoes.md`, `022_Plano_de_Implantacao_Rollback_e_Suporte.md`, `024_Registro_de_Decisoes_Arquiteturais.md`, `032_Diagrama_de_Deploy_Vercel_Render.md`, `033_Diagrama_de_Infraestrutura_Geral.md`, `034_Diagrama_de_DNS_Dominio_e_Subdominios.md`, `035_Diagrama_de_CI_CD.md`, `036_Diagrama_de_Observabilidade_e_Logs.md`
- **Status:** ATIVO
- **Versão:** v1.0
- **Autoridade:** Alta

---

## 2. Objetivo

Este documento existe para formalizar **como o projeto William Albarello deve permanecer operável, reagir a falhas e retornar ao estado saudável com o menor dano possível**.

Ele responde às seguintes perguntas:

1. quais componentes precisam permanecer disponíveis;
2. quais tipos de indisponibilidade são relevantes;
3. quais contingências devem existir;
4. quando usar contenção, fallback, rollback ou restauração;
5. como o sistema deve voltar ao ar de forma segura;
6. quais alvos de recuperação fazem sentido para este projeto;
7. o que está comprovado no acervo técnico;
8. o que ainda é diretriz arquitetural soberana.

Este documento trata disponibilidade e recuperação como parte da arquitetura, e não como reação improvisada.

---

## 3. Fontes reais utilizadas

Este documento foi construído com base em artefatos efetivamente presentes no acervo do projeto.

### 3.1 Documentos soberanos do projeto principal
- `01-Waterfall/01-Obrigatorios/007_Requisitos_Nao_Funcionais.md`
- `01-Waterfall/01-Obrigatorios/019_Riscos_Premissas_Restricoes_e_Mitigacoes.md`
- `01-Waterfall/01-Obrigatorios/022_Plano_de_Implantacao_Rollback_e_Suporte.md`
- `01-Waterfall/01-Obrigatorios/024_Registro_de_Decisoes_Arquiteturais.md`

### 3.2 Documentação complementar real do monorepo
- `Waterfall/DOC-20-plano-de-deploy-ambientes-e-cicd.md`
- `Waterfall/DOC-21-observabilidade-logs-e-incidentes.md`
- `Waterfall/DOC-22-operacao-runbooks-e-rotina-de-publicacao.md`
- `Waterfall/DOC-24-go-live-checklist-e-handover-final.md`
- `Execucao/EXEC-05-checklist-de-gates-tecnicos.md`
- `Execucao/EXEC-11-runbook-evidencias-release-real.md`

### 3.3 Infraestrutura real comprovada
- `apps/api/src/server.ts`
- `apps/api/src/routes/health.ts`
- `.env.example`
- `Diagrama/DGM-05-deploy-vercel-render.mmd`

### 3.4 Diagramas já consolidados
- `032_Diagrama_de_Deploy_Vercel_Render.md`
- `033_Diagrama_de_Infraestrutura_Geral.md`
- `034_Diagrama_de_DNS_Dominio_e_Subdominios.md`
- `035_Diagrama_de_CI_CD.md`
- `036_Diagrama_de_Observabilidade_e_Logs.md`

---

## 4. Regra de honestidade técnica deste documento

Este ponto é obrigatório.

O acervo **comprova diretamente**:

- uso arquitetural de **Vercel** para a camada web;
- uso arquitetural de **Render** para API e banco;
- domínio principal `willianalbarello.com.br`;
- subdomínio da API `api.willianalbarello.com.br`;
- existência de ambientes `local`, `staging` e `production`;
- presença de endpoint `/health`;
- política soberana de deploy com validação, rollback e suporte;
- preocupação formal com riscos, observabilidade, incidentes e continuidade operacional;
- distinção entre produção, staging, smoke pós-release e rollback.

O acervo **não comprova diretamente**:

- arquitetura multi-região já implementada;
- balanceador explícito adicional próprio;
- replicação ativa-ativa;
- runbook automatizado de disaster recovery em código;
- backup policy materializada em arquivo técnico do provedor;
- restauração automatizada do banco;
- failover automático entre provedores;
- secondary site completo pronto para produção.

Portanto, este documento distingue:

### 4.1 Estado comprovado
A infraestrutura mínima e a governança que já existem no acervo.

### 4.2 Estado arquitetural soberano desejado
A forma correta como o sistema deve reagir a falhas e recuperar serviço.

Essa distinção precisa permanecer explícita.

---

## 5. Tese central de disponibilidade e recuperação

A tese central deste documento é a seguinte:

> o projeto William Albarello deve priorizar continuidade institucional do serviço, com separação clara entre indisponibilidade detectável, contenção rápida, rollback quando aplicável, restauração quando necessária e retomada segura com evidência de saúde.

Em linguagem simples:

- primeiro se detecta;
- depois se contém;
- depois se decide entre corrigir, degradar, rollback ou restaurar;
- só então se retoma operação plena;
- e a retomada só é válida quando houver evidência de saúde.

---

## 6. O que “disponibilidade” significa neste projeto

Disponibilidade, aqui, não é apenas “o servidor responde”.

Ela significa que os fluxos essenciais permanecem utilizáveis:

### 6.1 Disponibilidade pública mínima
- o domínio principal responde;
- páginas públicas principais carregam;
- publicações podem ser lidas;
- assets críticos não estão quebrados;
- SEO técnico essencial continua íntegro.

### 6.2 Disponibilidade administrativa mínima
- `/painel/login` responde;
- autenticação administrativa funciona;
- fluxos principais do painel não estão bloqueados;
- operações críticas não falham sistemicamente.

### 6.3 Disponibilidade de aplicação mínima
- `api.willianalbarello.com.br` responde;
- `/health` responde com estado saudável;
- endpoints críticos essenciais não estão em colapso;
- a API consegue acessar a persistência quando necessário.

### 6.4 Disponibilidade de dados mínima
- o banco aceita operações críticas;
- não há perda não controlada de integridade;
- consultas e gravações centrais seguem possíveis;
- recuperação é possível quando houver falha grave.

---

## 7. Serviços e componentes cuja continuidade importa

## 7.1 Camada pública
- `willianalbarello.com.br`
- home
- páginas públicas
- publicações
- `robots.txt`
- `sitemap.xml`

## 7.2 Camada administrativa
- `/painel`
- `/painel/login`
- fluxos editoriais críticos
- leitura e edição administrativas

## 7.3 Camada de aplicação
- `api.willianalbarello.com.br`
- endpoints públicos
- endpoints administrativos
- autenticação e sessão
- `/health`

## 7.4 Camada de dados
- PostgreSQL
- integridade de dados editoriais
- integridade de auditoria
- continuidade de persistência

## 7.5 Camada de controle
- pipelines de release
- rollback operacional
- logs, métricas e alertas
- runbooks

---

## 8. Diagrama principal de disponibilidade e recuperação

```mermaid
flowchart TB

    subgraph PUBLICO["Superficie publica"]
        DOM[willianalbarello.com.br]
        WEB[Vercel web]
        PUB[Paginas publicas + publicacoes]
    end

    subgraph INTERNO["Superficie administrativa"]
        PAINEL[/painel]
        LOGIN[/painel/login]
        ADMIN[Fluxos internos]
    end

    subgraph APP["Aplicacao"]
        API[Render API]
        HEALTH[/health]
        AUTH[Auth + sessao]
    end

    subgraph DADOS["Persistencia"]
        DB[(PostgreSQL)]
        AUD[(Auditoria/logica de trilha)]
    end

    subgraph CONTROLE["Deteccao e resposta"]
        OBS[Observabilidade + logs + alertas]
        TRI[Triage]
        DEC{Contem com rollback?}
        FIX[Correcao controlada]
        RB[Rollback]
        RES[Restauracao / recovery]
        VAL[Validacao de saude]
    end

    DOM --> WEB --> PUB
    DOM --> PAINEL --> LOGIN
    PAINEL --> ADMIN
    PUB --> API
    ADMIN --> API
    API --> HEALTH
    API --> AUTH
    API --> DB
    API --> AUD

    WEB --> OBS
    API --> OBS
    DB --> OBS
    PAINEL --> OBS

    OBS --> TRI
    TRI --> DEC
    DEC -->|Sim| RB
    DEC -->|Nao| FIX
    FIX --> RES
    RB --> VAL
    RES --> VAL
````

---

## 9. Princípios soberanos de continuidade operacional

A continuidade do projeto deve obedecer aos seguintes princípios:

### 9.1 Detectar cedo

Uma falha grave não deve ser descoberta apenas por reclamação tardia do usuário.

### 9.2 Conter rápido

Antes de “resolver perfeitamente”, o sistema deve reduzir o dano.

### 9.3 Priorizar fluxos essenciais

Nem toda indisponibilidade tem o mesmo peso.
O que é P0 deve ser restaurado primeiro.

### 9.4 Favorecer rollback quando a causa for release ruim

Quando a indisponibilidade nasce de regressão recém-publicada, rollback tende a ser mais seguro do que correção improvisada em produção.

### 9.5 Tratar banco como camada mais sensível

Frontend e backend podem aceitar rollback mais simples.
Banco exige cautela superior.

### 9.6 Recuperar com evidência

Serviço “tecnicamente de pé” mas sem smoke, sem logs e sem validação ainda não é retorno confiável.

---

## 10. Categorias de falha relevantes

## 10.1 Falhas de borda e entrega web

Exemplos:

* site fora do ar;
* rota pública indisponível;
* assets críticos quebrados;
* regressão visual severa;
* erro estrutural no painel.

### Resposta preferencial

* rollback da camada web;
* correção de configuração;
* validação pós-recuperação.

---

## 10.2 Falhas de API

Exemplos:

* `/health` falhando;
* alta taxa de 5xx;
* endpoints críticos indisponíveis;
* falha generalizada de autenticação;
* erro sistêmico em publicação.

### Resposta preferencial

* rollback da release da API se ligado a deploy recente;
* correção controlada se causa operacional/configuracional;
* validação de conectividade com banco.

---

## 10.3 Falhas de banco

Exemplos:

* indisponibilidade do PostgreSQL;
* erro de conexão persistente;
* saturação crítica;
* corrupção lógica detectada;
* migration problemática.

### Resposta preferencial

* conter gravações quando necessário;
* avaliar rollback da aplicação se causado por release;
* restaurar backup/estado quando indispensável;
* só retomar após validação forte.

---

## 10.4 Falhas de DNS/TLS

Exemplos:

* domínio principal apontando errado;
* subdomínio da API apontando errado;
* certificado inválido;
* propagação inconsistente.

### Resposta preferencial

* corrigir apontamento;
* restaurar configuração nominal válida;
* revalidar hosts públicos;
* repetir smoke de domínio + API.

---

## 10.5 Falhas de segurança operacional

Exemplos:

* pico de falhas de login;
* falha de CSRF;
* comportamento suspeito de sessão;
* exposição indevida de rota administrativa.

### Resposta preferencial

* contenção imediata;
* eventualmente bloqueio temporário ou endurecimento de rota;
* revisão de segredos/configuração;
* investigação com logs e auditoria.

---

## 11. Diagrama de classes de falha e resposta

```mermaid id="m3wd2k"
flowchart LR

    F1[Falha web] --> R1[Rollback web ou correcao de config]
    F2[Falha API] --> R2[Rollback API ou correcao controlada]
    F3[Falha banco] --> R3[Contencao + restauracao cautelosa]
    F4[Falha DNS/TLS] --> R4[Reversao nominal e revalidacao]
    F5[Falha seguranca] --> R5[Contencao imediata + investigacao]

    R1 --> V[Validacao de saude]
    R2 --> V
    R3 --> V
    R4 --> V
    R5 --> V
```

---

## 12. Continuidade por severidade

A disponibilidade deve ser lida conforme impacto.

## 12.1 SEV-1

Afeta operação central ou imagem institucional de forma imediata.

Exemplos:

* site indisponível;
* API indisponível;
* login administrativo totalmente quebrado;
* banco indisponível;
* falha severa de segurança.

### Conduta

* atuação imediata;
* triage curto;
* contenção rápida;
* rollback ou recovery;
* janela reforçada de observação após retorno.

---

## 12.2 SEV-2

Afeta fortemente função importante, mas com alguma operação ainda preservada.

Exemplos:

* parte da leitura pública falhando;
* erro editorial crítico com workaround;
* degradação severa de performance.

### Conduta

* resposta rápida;
* correção ou rollback priorizados;
* restabelecimento antes de estabilização plena.

---

## 12.3 SEV-3

Afeta função parcial ou secundária sem bloqueio total.

## 12.4 SEV-4

Afetação limitada, sem urgência de restauração imediata.

---

## 13. Modos de resposta: contenção, fallback, rollback e restauração

Esse ponto precisa ser cristalino.

## 13.1 Contenção

É a primeira resposta para limitar o dano.

Exemplos:

* pausar promoção;
* bloquear ação problemática;
* degradar temporariamente uma função administrativa;
* impedir novas gravações críticas.

## 13.2 Fallback

É uma forma degradada mas ainda funcional do sistema.

Exemplos coerentes com este projeto:

* manter leitura pública enquanto recurso administrativo específico é temporariamente restringido;
* priorizar páginas públicas essenciais enquanto uma função menos central é ajustada.

### Observação

O acervo não comprova uma malha sofisticada de fallback automatizado.
Aqui ele aparece como estratégia arquitetural de degradação controlada.

## 13.3 Rollback

É o retorno à versão anterior estável quando a falha foi introduzida por release recente.

## 13.4 Restauração

É a reconstrução do estado operacional a partir de backup, configuração válida ou recomposição mais profunda.

### Regra soberana

Sempre que o rollback resolver com menor risco, ele é preferível à restauração complexa.

---

## 14. Diagrama de decisão operacional

```mermaid id="8u4eqs"
flowchart TD

    INC[Incidente detectado] --> TRI[Triage]
    TRI --> IMP{Impacto P0/P1?}
    IMP -->|Nao| FIX[Correcao planejada]
    IMP -->|Sim| REL{Relacionado a release recente?}
    REL -->|Sim| RB[Rollback]
    REL -->|Nao| CFG{Configuracao / DNS / segredo / infraestrutura?}
    CFG -->|Sim| CORR[Correcao controlada]
    CFG -->|Nao| DATA{Banco ou integridade afetados?}
    DATA -->|Sim| RES[Restauracao cautelosa]
    DATA -->|Nao| DEG[Degradacao + mitigacao]

    RB --> VAL[Validacao]
    CORR --> VAL
    RES --> VAL
    DEG --> VAL
    FIX --> VAL
```

---

## 15. Critérios de saúde para considerar o serviço “recuperado”

Uma recuperação só deve ser considerada válida quando os critérios abaixo forem atendidos, conforme a severidade do incidente.

## 15.1 Critérios mínimos P0

* domínio principal responde;
* API responde;
* `/health` responde saudável;
* fluxo público principal funciona;
* login admin crítico funciona, quando aplicável;
* erros 5xx saem do estado anômalo;
* logs e alertas deixam de indicar falha sistêmica.

## 15.2 Critérios mínimos P1

* smoke tests principais aprovados;
* regressão central não reaparece;
* estabilidade inicial observada por janela curta controlada;
* equipe consegue explicar a causa provável e a correção aplicada.

## 15.3 Critério de confiança

Não basta “parar de quebrar”.
É necessário comprovar que o serviço retomou de modo coerente.

---

## 16. Estratégia soberana de rollback

O rollback é peça central do desenho de disponibilidade.

## 16.1 Rollback de frontend

Aplicável quando:

* regressão visual severa;
* rota pública ou administrativa quebra após deploy;
* assets ou build recente causam indisponibilidade.

### Estratégia preferencial

* retornar à build anterior estável;
* validar home, páginas públicas e `/painel/login`;
* reabrir tráfego normal após confirmação.

---

## 16.2 Rollback de backend

Aplicável quando:

* autenticação quebra após deploy;
* endpoints críticos falham após release;
* erros 5xx sobem anormalmente após promoção.

### Estratégia preferencial

* reverter a release da API;
* validar `/health`;
* validar login e rota crítica;
* observar logs pós-retorno.

---

## 16.3 Rollback e banco

Este é o caso mais delicado.

### Regra soberana

Banco não deve ser tratado como “mais um componente simples de rollback”.

### Ordem prudente

1. verificar se rollback da aplicação resolve sem tocar dados;
2. se houve migration problemática, avaliar reversão segura;
3. usar restauração como último recurso;
4. validar consistência antes de abrir operação total.

---

## 17. Estratégia soberana de restauração

A restauração entra quando rollback simples não basta.

## 17.1 Casos típicos

* corrupção lógica;
* migration danosa;
* perda de configuração crítica;
* falha persistente de banco;
* estado inconsistente após incidente grave.

## 17.2 Etapas corretas

1. conter novas alterações danosas;
2. identificar ponto de restauração confiável;
3. restaurar ambiente ou dados;
4. revalidar conectividade;
5. executar smoke de rotas críticas;
6. reabrir operação gradualmente;
7. acompanhar janela reforçada.

## 17.3 Regra de ouro

Restaurar sem validação forte é trocar um dano conhecido por outro oculto.

---

## 18. Recuperação por componente

## 18.1 Recuperação da camada web

Passos típicos:

1. detectar erro público;
2. validar se é regressão recente;
3. executar rollback ou correção de configuração;
4. testar home, páginas e assets críticos;
5. confirmar integridade de `robots` e `sitemap` quando afetados.

## 18.2 Recuperação da camada admin

Passos típicos:

1. validar `/painel/login`;
2. validar autenticação;
3. validar fluxo editorial mínimo;
4. liberar operação interna somente após confirmação.

## 18.3 Recuperação da API

Passos típicos:

1. validar `/health`;
2. validar autenticação;
3. validar endpoint público crítico;
4. validar endpoint admin crítico;
5. observar logs, erros e latência após retorno.

## 18.4 Recuperação do banco

Passos típicos:

1. confirmar disponibilidade;
2. validar conexão pela API;
3. validar leitura e escrita controladas;
4. validar integridade mínima de dados críticos;
5. somente então retomar operação plena.

---

## 19. Diagrama de retomada de serviço

```mermaid id="o1mv8r"
flowchart LR

    D[Deteccao] --> C[Contencao]
    C --> A[Acao principal\nrollback, correcao ou restauracao]
    A --> S[Smoke tests]
    S --> H{Saude comprovada?}
    H -->|Nao| R[Reabrir investigacao]
    H -->|Sim| O[Observacao reforcada]
    O --> T{Estavel?}
    T -->|Nao| X[Nova acao de contencao]
    T -->|Sim| N[Normalizacao]
```

---

## 20. Disponibilidade por camada: alvos e leitura correta

Com base na trilha documental já consolidada, ficam reconhecidos como referências operacionais:

### 20.1 Frontend público

* alvo de referência: **99,5% mensal**

### 20.2 API

* alvo de referência: **99,0% mensal**

### 20.3 Leitura correta

Esses números funcionam como **meta arquitetural de serviço**, não como prova de monitoração plenamente madura já implementada no runtime atual.

---

## 21. RTO e RPO de referência

Este projeto ainda não apresenta no acervo uma tabela formal fechada de RTO/RPO por componente.
Para não deixar o desenho sem direção, ficam estabelecidos **valores de referência arquitetural**, sujeitos a refinamento posterior.

## 21.1 Definições

* **RTO:** tempo-alvo para restaurar operação aceitável
* **RPO:** ponto-alvo máximo de perda aceitável de dados

## 21.2 Referência por componente

### Camada web pública

* **RTO de referência:** até **30 minutos**
* **RPO de referência:** irrelevante/baixo, pois a camada é majoritariamente de entrega e não de persistência primária

### Camada administrativa

* **RTO de referência:** até **60 minutos**
* **RPO de referência:** baixo, condicionado à integridade da camada de dados

### API

* **RTO de referência:** até **60 minutos**
* **RPO de referência:** baixo, condicionado à integridade do banco e à natureza do incidente

### Banco de dados

* **RTO de referência:** até **4 horas**
* **RPO de referência:** até **15 minutos** como objetivo arquitetural prudencial de futuro, a depender da política real de backup e restauração do provedor

### Observação de honestidade

Esses valores são **alvos arquiteturais de referência**, não comprovação de SLA/SLO ou backup real já configurado na plataforma.

---

## 22. Indisponibilidade parcial e operação degradada

Nem todo incidente exige “apagão total”.

Este projeto deve admitir operação degradada quando isso reduzir dano com segurança.

## 22.1 Exemplos aceitáveis de degradação controlada

* leitura pública preservada enquanto função editorial específica é temporariamente suspensa;
* login admin preservado enquanto uma função não essencial é bloqueada;
* promoção pausada enquanto a produção existente é mantida estável.

## 22.2 Exemplos não aceitáveis

* manter operação aparentemente normal com integridade de dados duvidosa;
* abrir painel sem autenticação confiável;
* manter API instável servindo respostas erráticas;
* mascarar falha crítica sem visibilidade operacional.

---

## 23. Relação entre disponibilidade e observabilidade

Disponibilidade sem observabilidade é suposição.

Para este projeto, a recuperação correta depende de:

* logs estruturados;
* métrica de erro/latência;
* healthcheck;
* alerta acionável;
* correlação temporal e por release;
* `traceId` quando aplicável;
* evidência pós-ação.

### Conclusão

A camada de observabilidade não é apenas suporte à recuperação.
Ela é parte da própria capacidade de recuperar.

---

## 24. Relação entre disponibilidade e CI/CD

A esteira de entrega influencia diretamente a disponibilidade.

## 24.1 Antes do deploy

* gates reduzem risco de regressão;
* staging reduz experimentação indevida em produção.

## 24.2 Depois do deploy

* smoke pós-release ajuda a detectar falha cedo;
* janela reforçada de observação reduz tempo de exposição;
* rollback rápido reduz MTTR prático.

## 24.3 Conclusão

Uma pipeline madura aumenta disponibilidade porque reduz falhas evitáveis e acelera recuperação.

---

## 25. Relação entre disponibilidade e riscos

O documento de riscos já aponta a necessidade de mitigação para:

* erro operacional;
* regressão de release;
* dependência de configuração;
* falhas de infraestrutura;
* risco de desalinhamento entre arquitetura e runtime.

Este documento traduz essa visão de risco em comportamento operacional:

* detectar;
* conter;
* decidir;
* recuperar;
* validar;
* aprender.

---

## 26. Runbook soberano mínimo de resposta

Fica definido o seguinte esqueleto mínimo de runbook para incidentes relevantes:

1. registrar horário de detecção;
2. classificar severidade;
3. identificar camada afetada;
4. verificar se há release recente correlacionada;
5. decidir entre rollback, correção ou restauração;
6. executar ação principal;
7. validar com smoke;
8. observar por janela curta;
9. registrar causa provável;
10. abrir RCA quando aplicável.

---

## 27. Riscos específicos do desenho atual

## 27.1 Risco de dependência forte de componentes gerenciados sem runbook plenamente materializado

Há clareza de arquitetura, mas parte da contingência ainda depende de consolidação operacional fina.

### Mitigação

* formalizar runbooks por componente;
* registrar passos de rollback e restauração com mais granularidade.

## 27.2 Risco de banco ser o elo mais sensível

Frontend e API podem retornar mais rápido; banco é o maior ponto de cautela.

### Mitigação

* não improvisar restore;
* validar integridade antes de reabrir;
* priorizar rollback de aplicação quando suficiente.

## 27.3 Risco de diferença entre “serviço voltou” e “serviço está confiável”

Retorno prematuro pode produzir incidente recorrente.

### Mitigação

* exigir smoke e janela de observação;
* cruzar logs, healthcheck e fluxo crítico.

## 27.4 Risco de ausência de automação completa de DR

O acervo não comprova DR automatizado completo.

### Mitigação

* manter metas claras;
* reduzir dependência de memória operacional;
* transformar estratégia documental em execução operacional progressiva.

---

## 28. Decisões arquiteturais firmadas por este documento

1. Disponibilidade é definida pelos fluxos essenciais, não apenas por ping ou resposta superficial.
2. A resposta a incidente deve passar por detecção, contenção, decisão, recuperação e validação.
3. Rollback é a estratégia preferencial quando a falha vier de release recente e a integridade de dados não exigir restauração profunda.
4. Restauração é operação mais sensível e deve ser usada com cautela superior.
5. Banco de dados é a camada mais delicada do desenho de recuperação.
6. Serviço só é considerado recuperado após evidência objetiva de saúde.
7. Operação degradada é aceitável quando reduz dano sem comprometer integridade.
8. Disponibilidade depende diretamente de observabilidade e disciplina de CI/CD.
9. O projeto deve trabalhar com metas de referência para RTO/RPO, ainda que a implementação operacional completa precise ser consolidada.
10. O desenho arquitetural de continuidade está mais maduro documentalmente do que tecnicamente automatizado, e isso deve permanecer explícito.

---

## 29. O que este documento resolve

Este documento resolve:

* a visão macro de continuidade operacional;
* as categorias principais de falha;
* a decisão entre contenção, rollback, fallback e restauração;
* critérios de retorno saudável;
* referências de RTO/RPO;
* fluxo de retomada;
* relação entre disponibilidade, observabilidade, CI/CD e riscos.

---

## 30. O que este documento ainda não resolve

Este documento ainda não resolve, em detalhe fino:

* políticas reais de backup do provedor;
* scripts automatizados de restauração;
* replicação entre regiões;
* secondary site operacional;
* failover automático;
* tabelas completas de dependências por incidente;
* cronograma detalhado de exercícios de disaster recovery.

Esses pontos pertencem a documentação operacional futura e à evolução da implementação real.

---

## 31. Critérios de aceite do documento

Este documento será considerado aceito quando cumprir simultaneamente os seguintes critérios:

1. representar claramente indisponibilidade, contingência, restauração e retomada;
2. distinguir com honestidade o que é comprovado e o que é diretriz arquitetural;
3. tratar rollback e restauração como estratégias diferentes;
4. reconhecer o banco como camada mais sensível;
5. definir critérios de recuperação válidos;
6. servir como base utilizável para operação, suporte e endurecimento do ambiente real.

---

## 32. Conclusão arquitetural

O projeto William Albarello já possui base documental suficiente para tratar disponibilidade e recuperação de forma séria e não improvisada.

A leitura correta do momento atual é esta:

* a arquitetura já sabe **quais componentes precisam continuar de pé**;
* já sabe **quais falhas importam mais**;
* já sabe **que rollback é diferente de restauração**;
* já sabe **que banco exige cautela superior**;
* e já sabe **que recuperação sem evidência não é recuperação confiável**.

Em linguagem simples:

> o projeto já tem uma doutrina clara de sobrevivência operacional; o próximo passo, fora deste bloco, é endurecer essa doutrina na implementação real e nos runbooks finos.

---

## 33. Fechamento do bloco 05

Com este documento, o bloco `05-Infra_Deploy_e_Operacao` fica logicamente fechado com a seguinte sequência:

* `032_Diagrama_de_Deploy_Vercel_Render.md`
* `033_Diagrama_de_Infraestrutura_Geral.md`
* `034_Diagrama_de_DNS_Dominio_e_Subdominios.md`
* `035_Diagrama_de_CI_CD.md`
* `036_Diagrama_de_Observabilidade_e_Logs.md`
* `037_Diagrama_de_Disponibilidade_e_Recuperacao.md`

---

