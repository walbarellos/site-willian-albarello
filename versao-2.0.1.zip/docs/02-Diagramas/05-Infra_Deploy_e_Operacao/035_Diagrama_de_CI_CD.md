
# 035_Diagrama_de_CI_CD

## 1. Identificação do documento

- **Projeto:** William Albarello
- **Diretório:** `02-Diagramas`
- **Caminho oficial:** `/home/user/Documents/Softwares/Willian Albarello/William Albarello/02-Diagramas/05-Infra_Deploy_e_Operacao/035_Diagrama_de_CI_CD.md`
- **Natureza do documento:** Diagrama e contrato lógico de CI/CD
- **Função sistêmica:** Mostrar build, testes, integração, validações, promoção, entrega, deploy e rollback do projeto
- **Posição no bloco:** Quarto documento do bloco `05-Infra_Deploy_e_Operacao`
- **Dependências principais:** `014_Integracoes_e_Sistemas_Externos.md`, `018_Plano_de_Testes_Homologacao_e_Qualidade.md`, `022_Plano_de_Implantacao_Rollback_e_Suporte.md`, `024_Registro_de_Decisoes_Arquiteturais.md`, `032_Diagrama_de_Deploy_Vercel_Render.md`, `033_Diagrama_de_Infraestrutura_Geral.md`, `034_Diagrama_de_DNS_Dominio_e_Subdominios.md`
- **Status:** ATIVO
- **Versão:** v1.0
- **Autoridade:** Alta

---

## 2. Objetivo

Este documento existe para formalizar, em uma visão única, **como o projeto William Albarello integra, valida, promove e entrega mudanças**.

Ele responde, com clareza, às seguintes perguntas:

1. quais gatilhos iniciam a pipeline;
2. quais validações realmente existem hoje;
3. quais testes e verificações bloqueiam avanço;
4. quais artefatos são gerados;
5. como a promoção para `staging` e `production` deve acontecer;
6. o que já está materializado em GitHub Actions;
7. o que ainda está apenas documentado como regra de governança;
8. como rollback se encaixa no fluxo de entrega.

Este documento trata CI/CD como **mecanismo de governança operacional**, e não apenas como automação técnica.

---

## 3. Fontes reais utilizadas

Este documento foi construído a partir de artefatos efetivamente encontrados no acervo técnico do projeto.

### 3.1 Documentos soberanos
- `01-Waterfall/01-Obrigatorios/014_Integracoes_e_Sistemas_Externos.md`
- `01-Waterfall/01-Obrigatorios/018_Plano_de_Testes_Homologacao_e_Qualidade.md`
- `01-Waterfall/01-Obrigatorios/022_Plano_de_Implantacao_Rollback_e_Suporte.md`
- `01-Waterfall/01-Obrigatorios/024_Registro_de_Decisoes_Arquiteturais.md`

### 3.2 Base técnica do monorepo
- `personal-site/package.json`
- `personal-site/README.md`
- `personal-site/.env.example`

### 3.3 Pipelines reais encontrados no repositório
- `.github/workflows/scaffold-bootstrap.yml`
- `.github/workflows/api-contract.yml`
- `.github/workflows/api-breaking-change.yml`
- `.github/workflows/api-docs.yml`

### 3.4 Documentação operacional complementar do monorepo
- `Waterfall/DOC-20-plano-de-deploy-ambientes-e-cicd.md`
- `Waterfall/DOC-22-operacao-runbooks-e-rotina-de-publicacao.md`
- `Execucao/EXEC-05-checklist-de-gates-tecnicos.md`
- `Execucao/EXEC-11-runbook-evidencias-release-real.md`

---

## 4. Regra de honestidade técnica deste documento

Este ponto é decisivo.

O acervo **comprova diretamente** que o projeto possui hoje:

- repositório GitHub;
- monorepo PNPM com `apps/web`, `apps/admin`, `apps/api`, `packages/contracts` e `packages/ui`;
- scripts raiz de:
  - `pnpm lint`
  - `pnpm typecheck`
  - `pnpm test:smoke`
  - `pnpm check:contracts`
- workflows reais no GitHub Actions para:
  - validação de scaffold e checks gerais;
  - lint e validação OpenAPI;
  - breaking change check com `oasdiff`;
  - build de documentação estática da API com `redoc-cli`;
- estratégia documental de ambientes `local`, `staging` e `production`;
- política documental de deploy com rollback e gates.

O acervo **não comprova diretamente** que já exista, dentro do repositório:

- workflow YAML de deploy para Vercel;
- workflow YAML de deploy para Render;
- workflow YAML de promoção explícita para `staging`;
- workflow YAML de promoção explícita para `production`;
- orquestração automatizada de migrations em pipeline;
- step de release tagging formalmente materializado no GitHub Actions;
- pipeline única “end-to-end” já fechada em um só arquivo.

Portanto, este documento distingue:

### 4.1 CI materializado
O que já está implementado em workflows reais.

### 4.2 CD governado e arquiteturalmente definido
O que está formalizado na documentação como processo soberano de release, promoção e rollback, mesmo sem workflow completo materializado no acervo anexado.

Essa distinção é obrigatória.

---

## 5. Tese central de CI/CD do projeto

A tese central deste documento é a seguinte:

> o projeto William Albarello adota CI/CD como mecanismo de controle de qualidade, integridade contratual e promoção disciplinada de release, em que toda mudança passa por gates técnicos explícitos antes de chegar à superfície pública ou administrativa.

Em linguagem simples:

- o código não deve ir direto para produção;
- o contrato da API não pode quebrar silenciosamente;
- o monorepo deve provar integridade mínima em cada mudança relevante;
- a entrega deve respeitar ambiente, aprovação e capacidade de rollback;
- a pipeline é parte da arquitetura, não apêndice.

---

## 6. Inventário real da pipeline encontrada

## 6.1 Workflow `scaffold-bootstrap.yml`
### Gatilhos
- `push`
- `pull_request`

### Paths observados
- `apps/**`
- `packages/**`
- `package.json`
- `pnpm-workspace.yaml`
- `.github/workflows/scaffold-bootstrap.yml`

### Função
Validar a integridade mínima do monorepo técnico.

### Etapas reais
1. checkout
2. setup Node 20
3. setup pnpm 9
4. `pnpm install --no-frozen-lockfile`
5. validação das pastas:
   - `apps/web`
   - `apps/admin`
   - `apps/api`
   - `packages/contracts`
   - `packages/ui`
6. execução de:
   - `pnpm lint`
   - `pnpm typecheck`
   - `pnpm test:smoke`
   - `pnpm check:contracts`

### Papel na governança
É o workflow mais próximo de uma esteira geral de CI do projeto.

---

## 6.2 Workflow `api-contract.yml`
### Gatilhos
- `pull_request` com mudanças em `APIs/**`
- `push` na branch `main` com mudanças em `APIs/**`

### Função
Validar a qualidade estrutural dos contratos OpenAPI.

### Etapas reais
1. checkout
2. setup Node 20
3. lint com `@redocly/cli`
4. validação estrutural com `swagger-cli`
5. verificação de referências a `Deprecation` e `Sunset` no documento de versionamento

### Papel na governança
É o gate específico de qualidade contratual.

---

## 6.3 Workflow `api-breaking-change.yml`
### Gatilho
- `pull_request` com mudanças em:
  - `APIs/API-06-openapi-public.yaml`
  - `APIs/API-07-openapi-admin.yaml`
  - `APIs/openapi/components/**`

### Função
Impedir breaking changes silenciosas nos contratos da API.

### Etapas reais
1. checkout com histórico
2. preparação dos specs-base da branch de origem
3. comparação com `oasdiff` via container Docker
4. checagem separada para:
   - API pública
   - API administrativa

### Papel na governança
É o guardião de compatibilidade entre versões de contrato.

---

## 6.4 Workflow `api-docs.yml`
### Gatilhos
- `push` na `main` para mudanças nos specs OpenAPI
- `workflow_dispatch`

### Função
Gerar documentação estática de APIs.

### Etapas reais
1. checkout
2. setup Node 20
3. build de HTML estático com `redoc-cli`
4. upload de artefato `api-docs`

### Papel na governança
Transforma o contrato em artefato consultável e rastreável.

---

## 7. Scripts reais usados pela pipeline

O `package.json` raiz materializa os seguintes scripts relevantes:

### 7.1 `dev`
Executa, em paralelo:
- `@personal-site/web`
- `@personal-site/admin`
- `@personal-site/api`

### 7.2 `build`
Executa build recursivo para:
- web
- admin
- api

### 7.3 `lint`
Executa lint recursivo nos workspaces.

### 7.4 `typecheck`
Executa checagem de tipos recursiva nos workspaces.

### 7.5 `test:smoke`
Executa smoke tests recursivos onde existirem.

### 7.6 `check:contracts`
Executa validação dos dois specs OpenAPI com `swagger-cli`.

---

## 8. Leitura correta do estágio atual de CI/CD

O projeto **já possui CI real e funcional em partes críticas**.

Mas a leitura correta é:

### 8.1 O CI está mais materializado que o CD
Há evidências concretas de integração contínua:
- scaffold checks;
- quality checks;
- contract validation;
- breaking-change guard;
- docs build.

### 8.2 O CD está mais documentado que automatizado no repositório
A promoção para `staging` e `production` aparece com clareza em:
- `DOC-20`
- `022_Plano_de_Implantacao_Rollback_e_Suporte.md`

Porém essa esteira completa **não aparece materializada integralmente em YAML** no acervo anexado.

### 8.3 Conclusão arquitetural correta
O projeto já tem:
- **CI real**
- **CD definido como governança**
- **CD parcial/inferido por plataforma**
- **necessidade futura de consolidação da automação de promoção**

---

## 9. Diagrama principal de CI/CD

```mermaid
flowchart TB

    DEV[Desenvolvedor]
    FB[Feature Branch]
    PR[Pull Request]
    MAIN[Branch main]

    subgraph CI["CI - GitHub Actions"]
        SCF[scaffold-bootstrap.yml]
        CT[api-contract.yml]
        BC[api-breaking-change.yml]
        DOCS[api-docs.yml]

        QC[lint + typecheck + smoke + contracts]
        OALINT[Redocly lint + swagger validate]
        OABREAK[oasdiff breaking check]
        HTML[Build docs HTML + upload artifact]
    end

    subgraph GATES["Gates"]
        G1{Monorepo integro?}
        G2{Contrato valido?}
        G3{Sem breaking change?}
        G4{Criticos aprovados?}
    end

    subgraph CD["Entrega e promocao"]
        STG[Deploy elegivel em staging]
        VAL[Homologacao + smoke pos-deploy]
        PROD[Promocao para production]
        OBS[Janela de observacao reforcada]
        RB[Rollback se necessario]
    end

    DEV --> FB
    FB --> PR

    PR --> SCF
    PR --> CT
    PR --> BC

    SCF --> QC --> G1
    CT --> OALINT --> G2
    BC --> OABREAK --> G3

    G1 --> G4
    G2 --> G4
    G3 --> G4

    G4 -->|Nao| BLOCK[Merge / promocao bloqueados]
    G4 -->|Sim| MAIN

    MAIN --> DOCS
    DOCS --> HTML

    MAIN --> STG
    STG --> VAL
    VAL -->|Aprovado| PROD
    VAL -->|Reprovado| FIX[Corrigir e reenfileirar]
    PROD --> OBS
    OBS -->|Incidente critico| RB
````

---

## 10. Diagrama da camada de CI materializada

```mermaid id="5jv9ah"
flowchart LR

    PR[Pull Request] --> W1[scaffold-bootstrap]
    PR --> W2[api-contract]
    PR --> W3[api-breaking-change]

    W1 --> A1[pnpm install]
    W1 --> A2[validar estrutura apps/packages]
    W1 --> A3[pnpm lint]
    W1 --> A4[pnpm typecheck]
    W1 --> A5[pnpm test:smoke]
    W1 --> A6[pnpm check:contracts]

    W2 --> B1[redocly lint]
    W2 --> B2[swagger-cli validate]
    W2 --> B3[politica de deprecacao e sunset]

    W3 --> C1[gerar specs base]
    W3 --> C2[oasdiff public]
    W3 --> C3[oasdiff admin]
```

---

## 11. Diagrama da camada de CD governada

```mermaid id="r2q8zs"
flowchart LR

    M[Merge elegivel em main] --> S[Staging]
    S --> H[Homologacao integrada]
    H --> Q{Gates funcionais + operacionais aprovados?}
    Q -->|Nao| X[Corrigir / bloquear promocao]
    Q -->|Sim| P[Production]
    P --> O[Observacao pos-release]
    O --> I{Incidente grave?}
    I -->|Sim| R[Rollback]
    I -->|Nao| E[Estabilizacao]
```

---

## 12. Gatilhos da pipeline

## 12.1 Gatilhos por Pull Request

Usados para impedir integração imprudente.

### Casos reais

* mudança em `apps/**` e `packages/**`
* mudança em `package.json`
* mudança em `pnpm-workspace.yaml`
* mudança em arquivos de APIs OpenAPI

### Objetivo

Bloquear merge quando:

* a estrutura do monorepo quebra;
* o contrato OpenAPI fica inválido;
* a mudança introduz breaking change não permitido;
* a base mínima de qualidade falha.

---

## 12.2 Gatilhos por Push

Usados para validação e produção de artefatos em estado mais consolidado.

### Casos reais

* push na `main` com mudanças em `APIs/**`

### Objetivo

* validar o contrato em branch soberana;
* gerar documentação estática de API.

---

## 12.3 Gatilhos manuais

Atualmente comprovado:

* `workflow_dispatch` em `api-docs.yml`

### Objetivo

* regenerar docs de API de forma controlada;
* permitir execução manual operacional.

---

## 13. Gates técnicos reais e gates soberanos

## 13.1 Gates técnicos reais materializados

Já existem, no acervo, estes gates reais:

1. instalação das dependências;
2. validação de estrutura do monorepo;
3. lint;
4. typecheck;
5. smoke test;
6. validação estrutural de OpenAPI;
7. checagem de breaking changes;
8. build de documentação estática da API.

---

## 13.2 Gates soberanos documentais

Os documentos do projeto exigem ainda, como lógica de promoção:

1. testes críticos aprovados;
2. segurança P0 validada;
3. compatibilidade contratual confirmada;
4. SEO técnico sem falha estrutural;
5. aprovação do responsável técnico;
6. capacidade de rollback previamente conhecida;
7. validação pós-deploy em `staging`.

### Leitura correta

Esses gates soberanos **nem sempre estão todos automatizados**, mas fazem parte da política obrigatória de entrega.

---

## 14. Papel do build na pipeline

Build não é detalhe cosmético.
Ele serve para provar que os artefatos podem ser montados com consistência.

## 14.1 Build comprovado no monorepo

Script raiz:

* `pnpm build`

### Escopo

* `apps/web`
* `apps/admin`
* `apps/api`

## 14.2 Papel arquitetural do build

* validar integridade mínima do código;
* detectar falhas de compilação antes da promoção;
* confirmar que frontend, painel e backend continuam montáveis.

## 14.3 Situação atual

O script existe e integra o desenho do projeto, mas **não foi visto explicitamente dentro dos workflows anexados** como step formal de CI global.

### Consequência

O build está arquiteturalmente previsto, porém sua incorporação total à esteira principal ainda deve ser consolidada como automação soberana.

---

## 15. Papel dos testes na pipeline

## 15.1 Testes comprovadamente acionados

Na esteira `scaffold-bootstrap`, o projeto já aciona:

* `pnpm test:smoke`

## 15.2 Testes exigidos pelos documentos

A documentação soberana do projeto exige, além disso:

* testes unitários;
* testes de integração essenciais;
* validações fim a fim críticas;
* homologação funcional;
* smoke tests pós-deploy;
* checklist de aceite.

## 15.3 Leitura correta

Hoje a pipeline materializa parte do plano de testes, mas o plano documental é mais amplo que a automação encontrada.

---

## 16. Papel do contrato de API na pipeline

Este é um dos pontos mais fortes do projeto.

## 16.1 O contrato é tratado como artefato soberano

O repositório possui:

* `API-06-openapi-public.yaml`
* `API-07-openapi-admin.yaml`

## 16.2 O contrato passa por múltiplas camadas de validação

1. lint semântico/documental;
2. validação estrutural;
3. checagem de breaking changes;
4. geração de docs HTML.

## 16.3 Conclusão

A pipeline já reconhece a API como **contrato governado**, e não apenas como implementação.

---

## 17. Papel do staging no CI/CD

A documentação soberana do projeto coloca `staging` como camada obrigatória de homologação integrada.

## 17.1 Função do staging

* receber release elegível;
* validar integração real entre frontend, painel e API;
* verificar comportamento pós-build;
* executar smoke tests;
* impedir que produção vire ambiente de descoberta.

## 17.2 Situação atual do acervo

`staging` está:

* **fortemente documentado**
* **arquiteturalmente previsto**
* **não materializado integralmente em workflow YAML no acervo anexado**

## 17.3 Consequência

O diagrama de CI/CD deve representar `staging` como etapa obrigatória do fluxo soberano, ainda que a automação completa ainda precise ser consolidada no repositório.

---

## 18. Papel de production no CI/CD

Produção é o ambiente final e institucional do projeto.

### Hosts soberanos já consolidados

* `willianalbarello.com.br`
* `api.willianalbarello.com.br`

### Regras soberanas para promoção

1. merge elegível;
2. gates técnicos aprovados;
3. staging validado;
4. aprovação do responsável técnico;
5. plano de rollback conhecido;
6. observação reforçada pós-release.

Produção, portanto, é **resultado de decisão e evidência**, não de impulso.

---

## 19. Diagrama de release operacional

```mermaid id="8xm7cp"
flowchart TD

    CHG[Mudanca aprovada em codigo] --> CI1[CI tecnica]
    CI1 --> CI2[Contrato + compatibilidade + smoke]
    CI2 --> G{Apta para staging?}
    G -->|Nao| FAIL[Corrigir]
    G -->|Sim| STAGING[Deploy em staging]

    STAGING --> POSTSTG[Homologacao + smoke + verificacao operacional]
    POSTSTG --> GO{Apta para producao?}
    GO -->|Nao| HOLD[Segurar release]
    GO -->|Sim| PROD[Deploy em producao]

    PROD --> CHECK[Smoke pos-deploy + monitoracao reforcada]
    CHECK --> OK[Estabilizacao]
    CHECK --> INCIDENT[Incidente]
    INCIDENT --> RB[Rollback + registro + postmortem]
```

---

## 20. Papel do rollback dentro do CI/CD

Rollback não é fluxo externo.
Ele faz parte da esteira completa de entrega.

## 20.1 Rollback de frontend

Deve permitir retorno para build anterior estável.

## 20.2 Rollback de backend

Deve permitir retorno para release anterior estável.

## 20.3 Banco

É o caso mais sensível.

A ordem documental soberana é:

1. backup;
2. migration;
3. validação;
4. restore apenas como último recurso.

## 20.4 Conclusão

Um CI/CD maduro não termina no deploy.
Ele termina quando:

* o release estabiliza, ou
* o rollback contém o dano.

---

## 21. Artefatos produzidos ou governados pela pipeline

## 21.1 Artefatos de validação

* resultado de lint;
* resultado de typecheck;
* resultado de smoke;
* resultado de validação de contrato;
* resultado de breaking-change check.

## 21.2 Artefatos documentais

* docs HTML geradas com `redoc-cli`;
* artifact `api-docs` no GitHub Actions.

## 21.3 Artefatos de release esperados pela governança

Mesmo não totalmente materializados no YAML anexado, a governança documental exige:

* evidência de release;
* checklist de go-live;
* changelog ou registro equivalente;
* referência de rollback.

---

## 22. Riscos do desenho atual de CI/CD

## 22.1 Risco de CI mais maduro que CD

O projeto já valida bastante bem a integração e o contrato, mas a promoção automatizada completa ainda não aparece toda no repositório.

### Mitigação

* consolidar workflows de deploy/promoção;
* tornar staging/prod explicitamente rastreáveis em pipeline.

## 22.2 Risco de build não estar no centro da esteira principal

O script `pnpm build` existe, mas não apareceu como gate central explícito em todos os workflows.

### Mitigação

* incorporar build da tríade `web/admin/api` como gate formal.

## 22.3 Risco de automação parcial mascarar governança documental

A documentação exige mais do que os workflows atuais implementam.

### Mitigação

* alinhar YAML e governança soberana;
* reduzir diferença entre “documentado” e “automatizado”.

## 22.4 Risco de migrations não estarem explicitadas na esteira técnica

As regras de migration existem documentalmente, mas não foram vistas automatizadas no pipeline anexado.

### Mitigação

* formalizar etapa de migration controlada;
* separar claramente migration segura de migration crítica.

---

## 23. Decisões arquiteturais firmadas por este documento

1. CI/CD é parte estrutural da arquitetura do projeto.
2. O projeto já possui CI real materializado em GitHub Actions.
3. O CD existe como governança documental clara, ainda que não totalmente materializado no acervo YAML.
4. Toda mudança relevante deve passar por gates antes de chegar à produção.
5. Contratos OpenAPI são artefatos soberanos e passam por lint, validação, comparação de compatibilidade e build de docs.
6. `staging` é etapa obrigatória da promoção, mesmo quando a automação completa ainda não estiver toda consolidada no repositório.
7. Produção depende de evidência técnica, homologação e capacidade de rollback.
8. Rollback faz parte da esteira de entrega, não é procedimento externo desconectado.
9. O build completo do monorepo deve ser tratado como gate central da evolução futura da pipeline.
10. A diferença entre pipeline real e pipeline soberana deve ser mantida explícita, nunca escondida.

---

## 24. O que este documento resolve

Este documento resolve:

* a visão macro do fluxo CI/CD;
* os workflows reais já existentes;
* os gatilhos atuais da pipeline;
* os gates técnicos já materializados;
* a relação entre CI real e CD governado;
* o papel de staging, produção e rollback;
* a posição do contrato de API dentro da esteira.

---

## 25. O que este documento ainda não resolve

Este documento ainda não resolve, em detalhamento fino:

* YAML completo de deploy para Vercel;
* YAML completo de deploy para Render;
* política exata de tagging/releases;
* estratégia final de migrations automatizadas;
* detalhamento fino de aprovações manuais;
* mecanismo específico de promoção entre preview, staging e production nas plataformas.

Esses pontos podem ser refinados em documentação operacional complementar ou em futura consolidação de pipeline técnica.

---

## 26. Critérios de aceite do documento

Este documento será considerado aceito quando cumprir simultaneamente os seguintes critérios:

1. representar corretamente os workflows reais encontrados;
2. distinguir com honestidade CI materializado e CD documentado;
3. mostrar gatilhos, build, validações, testes e promoção;
4. incluir rollback como parte do fluxo de entrega;
5. manter coerência com os documentos de testes, implantação e decisões arquiteturais;
6. servir como base confiável para evolução futura da automação completa.

---

## 27. Conclusão arquitetural

O projeto William Albarello já possui um núcleo de CI maduro o suficiente para proteger a integridade do monorepo e dos contratos de API, especialmente no que diz respeito a estrutura, validação OpenAPI e breaking changes.

Ao mesmo tempo, a entrega contínua ainda aparece, no acervo analisado, mais como **governança soberana claramente definida** do que como automação YAML completa.

A leitura correta é esta:

* o projeto já sabe **como deve validar**;
* já sabe **o que deve bloquear**;
* já sabe **como deve promover**;
* e já sabe **que não pode entregar sem rollback**.

Em linguagem simples:

> a esteira do projeto já tem cérebro e coluna vertebral; o próximo passo natural é continuar consolidando braços e pernas operacionais da automação de deploy.

---

