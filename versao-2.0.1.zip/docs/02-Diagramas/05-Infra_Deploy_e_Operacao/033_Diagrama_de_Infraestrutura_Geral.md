
# 033_Diagrama_de_Infraestrutura_Geral

## 1. Identificação do documento

- **Projeto:** William Albarello
- **Diretório:** `02-Diagramas`
- **Caminho oficial:** `/home/user/Documents/Softwares/Willian Albarello/William Albarello/02-Diagramas/05-Infra_Deploy_e_Operacao/033_Diagrama_de_Infraestrutura_Geral.md`
- **Natureza do documento:** Diagrama macro de infraestrutura
- **Função sistêmica:** Apresentar a infraestrutura completa do projeto em visão macro, incluindo domínio, DNS, frontend, painel, API, banco, pipelines, ambientes e serviços externos efetivamente usados
- **Posição no bloco:** Segundo documento do bloco `05-Infra_Deploy_e_Operacao`
- **Dependência imediata:** `032_Diagrama_de_Deploy_Vercel_Render.md`
- **Status:** ATIVO
- **Versão:** v1.0
- **Autoridade:** Alta

---

## 2. Objetivo

Este documento existe para consolidar, em uma única visão arquitetural macro, a infraestrutura do projeto **William Albarello**.

Sua finalidade é responder, com clareza operacional, às seguintes perguntas:

1. quais são as camadas reais da solução;
2. quais serviços externos efetivamente participam da infraestrutura;
3. como o domínio institucional se conecta à aplicação;
4. como frontend, painel, API e banco se distribuem;
5. como `local`, `staging` e `production` se organizam;
6. como o GitHub e os pipelines entram no ciclo de infraestrutura;
7. como segurança, publicação, rollback e operação se apoiam nessa base.

Este documento não entra em detalhe fino de:
- records DNS isolados;
- pipeline CI/CD em profundidade;
- observabilidade detalhada;
- recuperação e continuidade em cenário de falha grave.

Esses pontos serão aprofundados nos documentos seguintes do bloco 05.

---

## 3. Fontes reais utilizadas

Este documento foi construído a partir de artefatos efetivamente encontrados no acervo técnico do projeto.

### 3.1 Waterfall soberano
- `01-Waterfall/01-Obrigatorios/007_Requisitos_Nao_Funcionais.md`
- `01-Waterfall/01-Obrigatorios/011_Arquitetura_Geral_do_Sistema.md`
- `01-Waterfall/01-Obrigatorios/014_Integracoes_e_Sistemas_Externos.md`
- `01-Waterfall/01-Obrigatorios/015_Seguranca_Privacidade_Auditoria_e_Permissoes.md`
- `01-Waterfall/01-Obrigatorios/022_Plano_de_Implantacao_Rollback_e_Suporte.md`
- `01-Waterfall/01-Obrigatorios/024_Registro_de_Decisoes_Arquiteturais.md`

### 3.2 Diagramas já consolidados
- `006_Diagrama_C4_Nivel_2_Containers.md`
- `025_Diagrama_de_Arquitetura_do_Frontend.md`
- `027_Diagrama_de_Rotas_e_Paginas.md`
- `031_Diagrama_de_Fluxo_do_Painel_Interno.md`
- `032_Diagrama_de_Deploy_Vercel_Render.md` (base lógica do bloco)

### 3.3 Monorepo real `personal-site`
- `README.md`
- `.env.example`
- `package.json`
- `pnpm-workspace.yaml`
- `apps/web/next.config.mjs`
- `apps/admin/next.config.mjs`
- `apps/web/app/layout.tsx`
- `apps/web/app/sitemap.ts`
- `apps/web/app/robots.ts`
- `apps/api/src/server.ts`
- `apps/api/src/lib/env.ts`
- `apps/api/src/routes/auth.ts`
- `apps/api/src/routes/health.ts`

### 3.4 Pipelines reais encontrados
- `.github/workflows/scaffold-bootstrap.yml`
- `.github/workflows/api-contract.yml`
- `.github/workflows/api-breaking-change.yml`
- `.github/workflows/api-docs.yml`

### 3.5 Artefatos diagramáticos auxiliares do próprio monorepo
- `Diagrama/DGM-01-arquitetura-geral.mmd`
- `Diagrama/DGM-05-deploy-vercel-render.mmd`

---

## 4. Regra de honestidade técnica deste documento

Este documento foi construído com uma disciplina importante: **distinguir o que está comprovado no acervo daquilo que é apenas interpretação operacional coerente**.

### 4.1 Está comprovado no acervo
- domínio principal: `willianalbarello.com.br`
- subdomínio de API: `api.willianalbarello.com.br`
- frontend/presença web pensado para **Vercel**
- backend/API pensado para **Render**
- banco relacional pensado para **PostgreSQL no Render**
- existência de três ambientes: `local`, `staging`, `production`
- monorepo com:
  - `apps/web`
  - `apps/admin`
  - `apps/api`
  - `packages/contracts`
  - `packages/ui`
- pipelines reais em GitHub Actions para scaffold, contratos, breaking changes e docs
- headers de segurança no `web` e no `admin`
- API Fastify com `cors`, `cookie`, `csrf`, `rate-limit`, `/health` e login inicial administrativo

### 4.2 Não está comprovado diretamente no acervo
- `vercel.json`
- `render.yaml`
- nome real dos serviços na Vercel/Render
- records DNS exatos já configurados no provedor
- screenshots dos painéis de plataforma
- fornecedor nominal do DNS/domínio
- vendor específico de observabilidade
- provedor de analytics efetivamente instalado em produção

### 4.3 Consequência metodológica
Este diagrama:
- **afirma como fato** apenas o que o acervo sustenta;
- **representa como topologia coerente** o que é necessário para a infraestrutura funcionar segundo os artefatos encontrados.

---

## 5. Tese central da infraestrutura

A tese central deste documento é a seguinte:

> o projeto William Albarello opera como uma infraestrutura web institucional moderna, separando camada de apresentação e camada de aplicação, usando domínio próprio como fachada soberana, Vercel como plano de experiência web, Render como plano de aplicação e dados, GitHub como eixo de governança do código e GitHub Actions como eixo de gates e promoção.

Em linguagem simples, a infraestrutura macro é:

- **domínio institucional** como fachada pública;
- **provedor DNS** como plano de resolução e roteamento nominal;
- **Vercel** como plano da experiência web;
- **Render** como plano da aplicação e da persistência;
- **GitHub + Actions** como plano de governança, validação e promoção;
- **ambientes separados** para reduzir risco operacional;
- **segurança e operação** atravessando todas as camadas.

---

## 6. Premissas de leitura

Antes do diagrama principal, ficam estabelecidas as seguintes premissas:

### 6.1 A infraestrutura é lida em camadas
Este documento organiza a solução em camadas:

1. clientes/consumidores
2. domínio e DNS
3. apresentação web
4. aplicação/backend
5. dados/persistência
6. governança/pipeline
7. operação/segurança

### 6.2 Painel administrativo é parte da mesma infraestrutura institucional
Mesmo existindo, no monorepo, a separação física entre `apps/web` e `apps/admin`, o painel permanece pertencendo à mesma infraestrutura soberana do projeto.

### 6.3 Banco é infraestrutura interna
O banco de dados não faz parte da superfície pública. Ele só deve ser acessado pela API.

### 6.4 GitHub Actions participa da infraestrutura
Embora não seja runtime da aplicação, os workflows do GitHub Actions participam diretamente da infraestrutura macro, porque influenciam:
- qualidade;
- liberação;
- bloqueio de promoção;
- governança de contrato.

---

## 7. Inventário macro da infraestrutura real

## 7.1 Camada de clientes
A infraestrutura é consumida por dois grandes perfis de cliente:

### Público externo
- visitantes do site institucional
- leitores de páginas e publicações
- usuários que consomem o conteúdo público

### Operação interna
- administrador
- editor/operador do painel interno
- responsável por autenticação e gestão do conteúdo

---

## 7.2 Camada de domínio e DNS
O acervo comprova as seguintes fachadas nominais:

- `https://willianalbarello.com.br`
- `https://api.willianalbarello.com.br`

A existência de domínio próprio e subdomínio próprio implica uma camada de:
- resolução DNS
- associação do domínio ao frontend
- associação do subdomínio à API
- suporte a HTTPS/TLS nas plataformas

O fornecedor exato do DNS **não está materializado no acervo**, então este documento o representa genericamente como **provedor de domínio/DNS**.

---

## 7.3 Camada de apresentação web
A camada de apresentação é comprovada pelo monorepo e pelos arquivos de frontend.

### Elementos reais encontrados
- `apps/web`
- `apps/admin`
- `next.config.mjs` com headers de segurança
- `layout.tsx` com `metadataBase`
- `sitemap.ts`
- `robots.ts`

### Funções da camada
- renderização do site público
- renderização da experiência administrativa
- metadata SEO
- sitemap
- robots
- consumo da API via `https://api.willianalbarello.com.br`

### Provedor previsto e coerente
- **Vercel**

---

## 7.4 Camada de aplicação
A camada de aplicação é comprovada pela API Fastify existente no monorepo.

### Elementos reais encontrados
- `apps/api/src/server.ts`
- `apps/api/src/lib/env.ts`
- `apps/api/src/routes/auth.ts`
- `apps/api/src/routes/health.ts`

### Capacidades reais já presentes
- servidor Fastify com logger
- CORS com origem restrita a `*.willianalbarello.com.br`
- cookies
- proteção CSRF
- rate limiting
- endpoint `/health`
- login administrativo inicial

### Provedor previsto e coerente
- **Render**

---

## 7.5 Camada de dados
A documentação e os diagramas internos convergem para banco relacional PostgreSQL.

### Papel do banco
- persistência de conteúdo
- persistência de usuários internos
- suporte a autenticação/sessão
- suporte a taxonomias e publicações
- suporte a auditoria
- integridade relacional

### Provedor previsto e coerente
- **PostgreSQL gerenciado no Render**

---

## 7.6 Camada de governança e pipelines
A infraestrutura não é apenas runtime. Ela também inclui o plano de controle do código.

### Elementos reais encontrados
- repositório GitHub
- GitHub Actions para:
  - scaffold bootstrap
  - contrato de API
  - breaking changes
  - build de docs de API

### Função dessa camada
- validar estrutura do monorepo
- validar OpenAPI
- bloquear breaking changes
- gerar docs estáticas de APIs
- sustentar promoção para staging/production com gates

---

## 7.7 Camada de segurança transversal
A segurança aparece como preocupação transversal, não como bloco isolado.

### Evidências reais já materializadas
- `Content-Security-Policy-Report-Only`
- `X-Content-Type-Options`
- `Referrer-Policy`
- `Permissions-Policy`
- `X-Frame-Options`
- `HttpOnly` / `Secure` / `SameSite` em sessão
- CSRF
- CORS restrito
- rate limit em pontos sensíveis

---

## 8. Diagrama principal da infraestrutura geral

```mermaid
flowchart TB

    subgraph CLIENTES["Camada 1 — Clientes"]
        PUB[Visitante / Leitor]
        ADM[Administrador / Operador]
    end

    subgraph EDGE["Camada 2 — Domínio e DNS"]
        DNS[Provedor de dominio + DNS\nfornecedor nao explicitado no acervo]
        DOM[willianalbarello.com.br]
        API_DOM[api.willianalbarello.com.br]
    end

    subgraph VERCEL["Camada 3 — Apresentacao Web (Vercel)"]
        WEB[apps/web\nNext.js\nsite publico]
        ADMIN[apps/admin ou superficie admin\n/painel\nNext.js]
        SEO[metadata + sitemap + robots]
        PREVIEW[preview / staging frontend]
    end

    subgraph RENDER["Camada 4 — Aplicacao e Dados (Render)"]
        API[apps/api\nFastify API]
        AUTH[auth + sessao + cookie + csrf]
        HEALTH[/health]
        DB[(PostgreSQL)]
        API_STG[staging API]
        DB_STG[(PostgreSQL staging)]
    end

    subgraph GITHUB["Camada 5 — Governanca e Pipeline"]
        REPO[GitHub Repo]
        ACT[GitHub Actions]
        WF1[scaffold-bootstrap]
        WF2[api-contract]
        WF3[api-breaking-change]
        WF4[api-docs]
    end

    subgraph OPS["Camada 6 — Operacao e Controle"]
        REL[release + promocao]
        RB[rollback]
        MON[monitoracao / alertas\nvendor nao comprovado]
        SEC[politicas de seguranca]
    end

    PUB --> DNS
    ADM --> DNS

    DNS --> DOM
    DNS --> API_DOM

    DOM --> WEB
    DOM --> ADMIN
    WEB --> SEO
    ADMIN --> API
    WEB --> API

    API_DOM --> API

    API --> AUTH
    API --> HEALTH
    API --> DB

    REPO --> ACT
    ACT --> WF1
    ACT --> WF2
    ACT --> WF3
    ACT --> WF4

    WF1 --> PREVIEW
    WF2 --> REL
    WF3 --> REL
    WF4 --> REL

    REL --> PREVIEW
    REL --> API_STG
    API_STG --> DB_STG

    REL --> WEB
    REL --> ADMIN
    REL --> API

    WEB --> MON
    ADMIN --> MON
    API --> MON
    DB --> MON

    REL --> RB
    SEC --> WEB
    SEC --> ADMIN
    SEC --> API
    SEC --> DB
````

---

## 9. Leitura arquitetural do diagrama principal

## 9.1 Camada 1 — Clientes

A infraestrutura começa pelos consumidores.

Há dois perfis de entrada:

* o visitante/leitor
* o administrador/operador

Esses perfis acessam a solução por nomes institucionais, não por hosts técnicos internos.

---

## 9.2 Camada 2 — Domínio e DNS

O domínio próprio é a fachada institucional.

A função desta camada é:

* resolver o domínio principal do site;
* resolver o subdomínio da API;
* separar apresentação e aplicação por nomes coerentes;
* permitir certificação TLS nas plataformas.

Esta camada é crítica porque um erro nela afeta simultaneamente:

* acesso público;
* acesso administrativo;
* API;
* integração entre frontend e backend.

---

## 9.3 Camada 3 — Apresentação Web

A Vercel ocupa o plano da experiência web.

Ela concentra:

* o site público (`apps/web`);
* a superfície administrativa (`apps/admin` ou costura soberana do `/painel`);
* os artefatos técnicos de SEO;
* os ambientes de preview/staging do frontend.

Esta camada existe para:

* renderizar páginas públicas;
* renderizar a experiência de painel;
* sustentar a fachada institucional;
* servir metadata, robots e sitemap.

---

## 9.4 Camada 4 — Aplicação e Dados

A Render ocupa o plano da aplicação e da persistência.

Ela concentra:

* API Fastify
* autenticação e sessão
* healthcheck
* PostgreSQL
* ambiente de staging da API e do banco

Essa camada sustenta:

* regras de negócio
* segurança de operação
* persistência
* integridade editorial
* consumo do painel e do site público

---

## 9.5 Camada 5 — Governança e Pipeline

GitHub e GitHub Actions formam o plano de controle.

Eles não são “apenas repositório”.

Eles exercem influência direta sobre a infraestrutura porque:

* validam a estrutura do repositório;
* validam contratos OpenAPI;
* detectam breaking changes;
* geram artefatos de documentação;
* condicionam a promoção de release.

---

## 9.6 Camada 6 — Operação e Controle

A operação não é um detalhe pós-deploy.

Ela é parte da infraestrutura macro, pois envolve:

* release
* promoção
* rollback
* monitoramento
* políticas de segurança

Esta camada existe para transformar “aplicação hospedada” em “serviço operável”.

---

## 10. Diagrama de runtime operacional

```mermaid
flowchart LR
    U[Usuario] --> SITE[Site / Painel na Vercel]
    SITE --> API[API Fastify na Render]
    API --> DB[(PostgreSQL na Render)]

    SITE --> SEO[Metadata / Sitemap / Robots]
    API --> AUTH[Sessao + CSRF + CORS + Rate Limit]
    API --> HC[/health]
```

---

## 11. Diagrama de ambientes

```mermaid
flowchart LR
    subgraph LOCAL["local"]
        LWEB[web :3000]
        LADM[admin :3001]
        LAPI[api :3002]
    end

    subgraph STAGING["staging"]
        VSTG[Vercel preview / staging]
        ASTG[Render staging API]
        PSTG[(PostgreSQL staging)]
    end

    subgraph PROD["production"]
        VPRD[willianalbarello.com.br]
        APRD[api.willianalbarello.com.br]
        PPRD[(PostgreSQL production)]
    end

    LWEB --> LAPI
    LADM --> LAPI

    VSTG --> ASTG
    ASTG --> PSTG

    VPRD --> APRD
    APRD --> PPRD
```

---

## 12. Visão por camadas de responsabilidade

## 12.1 Camada pública

Responsável por:

* home
* páginas institucionais
* publicações
* SEO técnico
* navegação pública

## 12.2 Camada administrativa

Responsável por:

* login
* sessão administrativa
* gestão de publicações
* dashboard interno
* taxonomia
* auditoria operacional via backend

## 12.3 Camada de aplicação

Responsável por:

* validações
* autenticação
* autorização
* sessão
* endpoints públicos e administrativos
* regras de domínio
* padronização de erros

## 12.4 Camada de dados

Responsável por:

* persistência
* integridade
* histórico mínimo
* estrutura editorial
* suporte a auditoria

## 12.5 Camada de governança

Responsável por:

* qualidade pré-promoção
* integridade do contrato
* documentação técnica
* rastreabilidade de release

---

## 13. Serviços externos efetivamente usados ou comprovadamente previstos

Este bloco só lista o que o acervo sustenta com segurança.

## 13.1 GitHub

Função:

* hospedar o código-fonte
* centralizar o versionamento
* servir de gatilho para workflows

## 13.2 GitHub Actions

Função:

* validar scaffold
* validar contratos OpenAPI
* detectar breaking changes
* gerar docs técnicas de API

## 13.3 Vercel

Função:

* hospedar a camada web
* servir o site institucional
* sustentar previews/staging do frontend

## 13.4 Render

Função:

* hospedar a API
* hospedar o PostgreSQL
* suportar staging e production da camada de aplicação

## 13.5 PostgreSQL gerenciado

Função:

* persistência relacional
* integridade do domínio
* base editorial e operacional

## 13.6 Provedor de domínio e DNS

Função:

* resolver o domínio institucional
* apontar o domínio principal
* apontar o subdomínio de API

### Observação importante

O **nome do fornecedor DNS** não está explicitado no acervo analisado. Portanto, neste documento ele permanece representado genericamente.

---

## 14. Componentes técnicos efetivamente comprovados

## 14.1 No frontend

Comprovados:

* Next.js
* metadata base do domínio
* `robots`
* `sitemap`
* headers de segurança
* consumo da API institucional

## 14.2 No backend

Comprovados:

* Fastify
* logger
* `@fastify/cookie`
* `@fastify/csrf-protection`
* `@fastify/rate-limit`
* `@fastify/cors`
* endpoint `/health`
* rota inicial de login

## 14.3 No contrato público

Comprovado pelo OpenAPI:

* API pública versionada em `/v1`
* API administrativa versionada em `/v1`
* contratos públicos e administrativos separados

---

## 15. Fluxos de infraestrutura mais importantes

## 15.1 Fluxo público

1. visitante acessa `willianalbarello.com.br`;
2. DNS resolve a fachada institucional;
3. Vercel entrega a camada web;
4. frontend, quando necessário, consome a API em `api.willianalbarello.com.br`;
5. API consulta o PostgreSQL e devolve dados;
6. frontend renderiza a experiência pública.

## 15.2 Fluxo administrativo

1. administrador acessa a superfície de painel;
2. frontend administrativo é servido pela camada web;
3. o painel chama a API administrativa;
4. a API valida credenciais e sessão;
5. a API persiste dados e rastros no banco;
6. a operação administrativa impacta o conteúdo servido ao público.

## 15.3 Fluxo de release

1. código sobe ao GitHub;
2. GitHub Actions executa gates;
3. staging é alimentado com a release elegível;
4. validação operacional ocorre;
5. release aprovada promove a produção;
6. monitoramento reforçado acompanha a janela pós-release.

---

## 16. Segurança aplicada à infraestrutura

A segurança da infraestrutura não está restrita ao login.

Ela atravessa as camadas.

## 16.1 Na apresentação web

Já existem evidências de:

* CSP em modo report-only
* negação de embedding por `X-Frame-Options`
* políticas de referrer
* políticas de permissões
* mitigação de content sniffing

## 16.2 Na aplicação

Já existem evidências de:

* cookie de sessão
* `HttpOnly`
* `Secure`
* `SameSite`
* proteção CSRF
* CORS restrito ao domínio institucional
* rate limiting em pontos sensíveis

## 16.3 Na organização da infraestrutura

A própria topologia já ajuda na segurança ao:

* separar domínio principal e subdomínio de API;
* impedir acesso direto do frontend ao banco;
* manter banco fora da superfície pública;
* isolar ambientes.

---

## 17. Operação e observabilidade em nível macro

O acervo comprova preocupação operacional, mas **não comprova vendor nominal de observabilidade**.

Portanto, a leitura correta aqui é:

### 17.1 O que está comprovado

* o projeto prevê monitoramento e alertas
* há preocupação com healthcheck
* há preocupação com pós-deploy e suporte
* o diagrama interno `DGM-05` já representa observabilidade + alertas

### 17.2 O que este documento afirma com segurança

A infraestrutura deve comportar:

* monitoramento de frontend
* monitoramento de API
* monitoramento de banco
* alertas operacionais
* smoke tests pós-release

### 17.3 O que este documento não afirma como fato

* Sentry
* Datadog
* Grafana
* GA4
* Vercel Analytics ativo
* qualquer outro vendor específico

Sem artefato real, isso não deve ser tratado como fato.

---

## 18. Riscos macro da infraestrutura

## 18.1 Risco de divergência entre soberania documental e implementação física

Há soberania documental forte sobre:

* domínio principal
* API em subdomínio
* painel em `/painel`

Mas há também separação física de apps no monorepo.

### Mitigação

* manter a costura infra coerente;
* documentar DNS e roteamento com precisão;
* não deixar a implementação física romper a experiência institucional.

## 18.2 Risco de configuração invisível em painel

Como não há `vercel.json` nem `render.yaml`, parte da infraestrutura pode estar apenas em configuração manual.

### Mitigação

* reduzir dependência de configuração implícita;
* formalizar o que estiver apenas em painel;
* manter runbook e checklist de ambiente.

## 18.3 Risco de quebra entre frontend e API

Como a solução depende de domínio principal e subdomínio distintos, qualquer erro em:

* CORS
* TLS
* DNS
* variável de ambiente
* contrato

pode quebrar a operação.

### Mitigação

* staging obrigatório;
* smoke tests;
* validação de contrato;
* checklist de promoção.

## 18.4 Risco de banco tratado como detalhe

Banco relacional é parte central da infraestrutura.

### Mitigação

* ambiente isolado por estágio;
* migrações controladas;
* rollback planejado;
* restore tratado como último recurso.

---

## 19. Decisões arquiteturais firmadas por este documento

1. A infraestrutura macro do projeto é composta por **domínio/DNS + Vercel + Render + GitHub/GitHub Actions + operação**.
2. O domínio principal soberano é `willianalbarello.com.br`.
3. O subdomínio soberano da API é `api.willianalbarello.com.br`.
4. A camada de apresentação pertence à **Vercel**.
5. A camada de aplicação e dados pertence à **Render**.
6. O banco relacional é **PostgreSQL**.
7. O frontend e o painel pertencem à mesma infraestrutura institucional, ainda que a implementação física esteja separada em `apps/web` e `apps/admin`.
8. O banco não participa da superfície pública e só deve ser acessado pela API.
9. GitHub Actions é parte da infraestrutura de controle e promoção, não mero detalhe de repositório.
10. Toda leitura de observabilidade, DNS fino e CI/CD detalhado será refinada nos documentos subsequentes.

---

## 20. O que este documento resolve

Este documento resolve, em nível macro:

* a visão completa da infraestrutura;
* a relação entre clientes, domínio, frontend, API e banco;
* o lugar do GitHub e dos pipelines;
* a separação de ambientes;
* a presença dos serviços externos efetivamente usados;
* a função transversal da segurança e da operação.

---

## 21. O que este documento ainda não resolve

Este documento ainda não resolve, em detalhe:

* records DNS exatos;
* mapping exato de rotas/subdomínios no painel;
* pipeline CI/CD passo a passo;
* vendor exato de observabilidade;
* runbook de incidente;
* estratégia de disponibilidade e recuperação;
* rollback detalhado por componente.

Esses temas pertencem aos próximos documentos do bloco.

---

## 22. Critérios de aceite do documento

Este documento será considerado aceito quando cumprir simultaneamente os seguintes critérios:

1. representar a infraestrutura macro completa do projeto;
2. refletir corretamente os serviços externos comprovados;
3. mostrar a separação entre apresentação, aplicação e dados;
4. manter coerência com os ambientes `local`, `staging` e `production`;
5. reconhecer a função do GitHub Actions como plano de governança;
6. não inventar vendors ou configurações não comprovadas;
7. servir como base sólida para `034`, `035`, `036` e `037`.

---

## 23. Conclusão arquitetural

A infraestrutura do projeto William Albarello já está madura o suficiente para ser lida como um sistema institucional moderno com separação clara entre fachada pública, aplicação e persistência.

A leitura correta do estado atual é:

* **domínio próprio** como identidade soberana;
* **DNS** como camada de resolução e costura;
* **Vercel** como plano da experiência web;
* **Render** como plano de aplicação e banco;
* **GitHub + GitHub Actions** como plano de governança técnica;
* **ambientes segregados** como mecanismo de segurança operacional;
* **segurança transversal** desde a borda até a aplicação.

Em linguagem simples:

> a infraestrutura já está claramente desenhada para sustentar um site institucional com painel interno, API dedicada, banco relacional, domínio soberano e promoção controlada de releases.

---

