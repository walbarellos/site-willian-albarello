
# 032_Diagrama_de_Deploy_Vercel_Render

## 1. Identificação do documento

- **Projeto:** William Albarello
- **Diretório:** `02-Diagramas`
- **Caminho oficial:** `/home/user/Documents/Softwares/Willian Albarello/William Albarello/02-Diagramas/05-Infra_Deploy_e_Operacao/032_Diagrama_de_Deploy_Vercel_Render.md`
- **Natureza do documento:** Diagrama e contrato lógico de deploy
- **Função sistêmica:** Mostrar a topologia de deploy entre frontend, painel administrativo, backend/API, banco de dados, DNS, ambientes e gates de promoção
- **Posição na trilha:** Primeiro documento do bloco `05-Infra_Deploy_e_Operacao`
- **Status:** ATIVO
- **Versão:** v1.0
- **Autoridade:** Alta
- **Dependências principais:** `011_Arquitetura_Geral_do_Sistema.md`, `014_Integracoes_e_Sistemas_Externos.md`, `022_Plano_de_Implantacao_Rollback_e_Suporte.md`, `024_Registro_de_Decisoes_Arquiteturais.md`, `006_Diagrama_C4_Nivel_2_Containers.md`, `025_Diagrama_de_Arquitetura_do_Frontend.md`, artefatos reais do monorepo `personal-site`

---

## 2. Objetivo

Este documento existe para formalizar, em linguagem arquitetural e operacional, **como o projeto William Albarello deve ser publicado e operado nos provedores Vercel e Render**.

Ele responde, de forma objetiva, às seguintes perguntas:

1. onde o frontend público vive;
2. onde a superfície administrativa vive;
3. onde a API vive;
4. onde o banco vive;
5. como domínio e subdomínio se conectam a esses serviços;
6. como `staging` e `production` se organizam;
7. como a promoção de release acontece;
8. como rollback e suporte entram na topologia.

Este documento **não** substitui:

- o diagrama de infraestrutura geral do bloco 05;
- o diagrama específico de DNS;
- o diagrama de CI/CD;
- o diagrama de observabilidade;
- o diagrama de recuperação/disponibilidade.

Ele é o **primeiro mapa de deploy**, isto é, a visão topológica principal.

---

## 3. Fontes reais utilizadas para construir este documento

Este diagrama foi construído com base em artefatos reais do projeto já encontrados no acervo técnico.

### 3.1 Documentos Waterfall e operacionais
- `01-Waterfall/01-Obrigatorios/011_Arquitetura_Geral_do_Sistema.md`
- `01-Waterfall/01-Obrigatorios/014_Integracoes_e_Sistemas_Externos.md`
- `01-Waterfall/01-Obrigatorios/022_Plano_de_Implantacao_Rollback_e_Suporte.md`
- `01-Waterfall/01-Obrigatorios/024_Registro_de_Decisoes_Arquiteturais.md`

### 3.2 Base técnica do monorepo
- `personal-site/README.md`
- `personal-site/.env.example`
- `personal-site/apps/web/next.config.mjs`
- `personal-site/apps/admin/next.config.mjs`
- `personal-site/apps/api/src/server.ts`
- `personal-site/apps/api/src/routes/auth.ts`
- `personal-site/apps/api/src/routes/health.ts`
- `personal-site/apps/api/src/lib/env.ts`
- `personal-site/package.json`

### 3.3 Evidências de pipeline
- `.github/workflows/scaffold-bootstrap.yml`
- `.github/workflows/api-contract.yml`
- `.github/workflows/api-breaking-change.yml`
- `.github/workflows/api-docs.yml`

### 3.4 Evidência diagramática já existente no acervo técnico
- `personal-site/Diagrama/DGM-05-deploy-vercel-render.mmd`

---

## 4. Regra de honestidade técnica deste documento

Este ponto é importante.

O acervo técnico **comprova** as seguintes coisas:

- o domínio principal soberano é `willianalbarello.com.br`;
- o subdomínio de API soberano é `api.willianalbarello.com.br`;
- o frontend foi desenhado para Vercel;
- a API e o PostgreSQL foram desenhados para Render;
- há ambientes `local`, `staging` e `production`;
- há CI com gates de contrato, validação e documentação;
- o frontend consome `https://api.willianalbarello.com.br`;
- há rota administrativa soberana em `/painel`;
- existem dois apps frontend no monorepo:
  - `apps/web`
  - `apps/admin`

O acervo técnico **não comprova diretamente**, por ausência de artefatos específicos de plataforma, os seguintes pontos finos:

- ID real do projeto na Vercel;
- nome real do serviço na Render;
- tipo exato dos records DNS já criados no provedor de DNS;
- existência de `render.yaml`;
- existência de `vercel.json`;
- configuração real de multi-zones ou reverse proxy entre `web` e `admin`;
- screenshots do painel da Vercel/Render.

Portanto, este documento trabalha com duas camadas de verdade:

### 4.1 Verdade comprovada
Tudo o que está explicitamente materializado no código e na documentação.

### 4.2 Materialização operacional coerente
A forma mais consistente de transformar essa verdade comprovada em topologia de deploy utilizável.

Essa distinção é saudável e deve ser mantida.

---

## 5. Estado real identificado no acervo

## 5.1 Domínios e URLs soberanas já definidos
Com base nos artefatos do projeto, o desenho soberano atual é:

- **Site público:** `https://willianalbarello.com.br`
- **API:** `https://api.willianalbarello.com.br`
- **Painel administrativo:** `https://willianalbarello.com.br/painel`

## 5.2 Estrutura real do monorepo
O monorepo atual comprova a existência de:

- `apps/web` -> site público em Next.js
- `apps/admin` -> painel interno em Next.js
- `apps/api` -> API em Fastify
- `packages/contracts` -> contratos compartilhados
- `packages/ui` -> base de UI compartilhada

## 5.3 Variáveis relevantes já materializadas
A base `.env.example` comprova:

- `NEXT_PUBLIC_SITE_URL=https://willianalbarello.com.br`
- `NEXT_PUBLIC_API_URL=https://api.willianalbarello.com.br`
- `NEXT_PUBLIC_ADMIN_URL=https://willianalbarello.com.br/painel`

## 5.4 Evidências de segurança e conectividade
Os `next.config.mjs` de `web` e `admin` já apontam `connect-src` para:

- `https://api.willianalbarello.com.br`

A API já tem:

- CORS preparado para origens em `*.willianalbarello.com.br`
- cookie e CSRF
- rate limit
- endpoint `/health`
- endpoint inicial `/v1/admin/auth/login`

## 5.5 Evidência de ambientes
Os documentos técnicos e o diagrama técnico auxiliar já reconhecem:

- `local`
- `staging`
- `production`

---

## 6. Tese central do deploy

A tese central deste documento é a seguinte:

> o projeto William Albarello deve operar com separação clara entre camada de apresentação e camada de aplicação, usando Vercel para a superfície web e Render para a camada de backend e dados, com DNS soberano apontando o domínio institucional para o frontend e o subdomínio de API para o backend.

Isso significa, em termos práticos:

- a **experiência pública** vive na Vercel;
- a **superfície administrativa** pertence à camada web e continua subordinada ao desenho soberano `/painel`;
- a **API** vive na Render;
- o **PostgreSQL** vive na Render;
- o **DNS** faz o acoplamento institucional entre domínio próprio e provedores;
- a **promoção entre ambientes** é controlada por pipeline e gates;
- o **rollback** não é improvisado: ele já nasce como parte do desenho.

---

## 7. Decisão arquitetural central deste diagrama

Há uma tensão legítima no acervo técnico:

- o monorepo possui dois apps frontend (`web` e `admin`);
- a soberania documental trata o painel como rota `/painel` no domínio principal.

A leitura arquitetural correta, neste estágio, é:

### 7.1 Verdade lógica soberana
O painel pertence ao domínio institucional e deve ser compreendido pelo usuário final como parte do mesmo sistema:

- site público
- área administrativa
- mesma identidade institucional
- mesma governança de acesso

### 7.2 Verdade física atual do código
A implementação foi separada em dois apps Next.js:

- `apps/web`
- `apps/admin`

### 7.3 Conclusão correta
Este diagrama trata o deploy da seguinte forma:

- **site público e painel** pertencem à **camada Vercel**;
- a separação entre `web` e `admin` é reconhecida como **decisão física de implementação**;
- a exposição soberana do painel continua sendo **`/painel`**;
- a amarração fina dessa convivência será detalhada depois em infraestrutura geral e DNS.

Em linguagem simples:

> o diagrama não nega a existência do `apps/admin`, mas também não rasga a soberania do `/painel`.

---

## 8. Diagrama principal de deploy

```mermaid
flowchart TB

    U1[Visitante publico]
    U2[Administrador interno]

    DNS[DNS autoritativo do dominio]
    GH[Repositorio GitHub]
    GHA[GitHub Actions\nlint + typecheck + smoke + contratos API + docs]
    GATE{Gates tecnicos aprovados?}

    subgraph VERCEL["Vercel"]
        VPRD[Projeto web production\nwillianalbarello.com.br]
        VSTG[Projeto/ambiente staging-preview]
        VADM[Superficie administrativa\n/painel\nlogica soberana]
    end

    subgraph RENDER["Render"]
        APRD[API production\napi.willianalbarello.com.br]
        ASTG[API staging]
        DBPRD[(PostgreSQL production)]
        DBSTG[(PostgreSQL staging)]
    end

    subgraph LOCAL["Ambiente local"]
        LWEB[apps/web\nNext.js :3000]
        LADM[apps/admin\nNext.js :3001]
        LAPI[apps/api\nFastify :3002]
    end

    U1 --> DNS
    U2 --> DNS

    DNS --> VPRD
    DNS --> APRD

    VPRD --> VADM
    VPRD --> APRD
    VADM --> APRD
    APRD --> DBPRD

    GH --> GHA
    GHA --> GATE
    GATE -->|Sim| VSTG
    GATE -->|Sim| ASTG
    ASTG --> DBSTG

    VSTG -->|aprovacao operacional| VPRD
    ASTG -->|aprovacao operacional| APRD

    GATE -->|Nao| BLOCK[Bloquear promocao]

    LWEB --> LAPI
    LADM --> LAPI
````

---

## 9. Leitura arquitetural do diagrama

## 9.1 Entrada do usuário

Existem dois grandes perfis de entrada:

* **visitante público**
* **administrador interno**

Ambos entram por DNS institucional, mas a navegação e o destino final diferem conforme a rota acessada.

## 9.2 Papel do DNS

O DNS faz a mediação institucional entre o domínio próprio e os provedores.

Neste desenho:

* o domínio principal resolve a superfície web na Vercel;
* o subdomínio `api` resolve a API na Render.

O detalhamento de record por record será aprofundado no `034_Diagrama_de_DNS_Dominio_e_Subdominios.md`.

## 9.3 Papel da Vercel

A Vercel hospeda a camada de apresentação.

Ela concentra:

* o site público;
* a camada de renderização SEO;
* a navegação institucional;
* a superfície lógica do painel em `/painel`;
* previews e/ou staging do frontend.

## 9.4 Papel da Render

A Render hospeda a camada de aplicação e dados.

Ela concentra:

* a API;
* a lógica de negócio;
* a autenticação e sessão;
* o PostgreSQL;
* os ambientes `staging` e `production` da API e banco.

## 9.5 Papel do GitHub Actions

O GitHub Actions não hospeda a aplicação, mas exerce papel de **barreira de qualidade**.

Ele governa:

* validação estrutural;
* lint;
* typecheck;
* smoke;
* validação de contratos OpenAPI;
* verificação de breaking changes;
* build de docs de API.

Ou seja:

> o release não sai do “código versionado” diretamente para “produção” sem passar por gates.

---

## 10. Topologia por ambiente

## 10.1 Ambiente local

O ambiente local é comprovado pelo monorepo e pelos scripts dos `package.json`.

### Portas já materializadas no acervo

* `apps/web` -> `3000`
* `apps/admin` -> `3001`
* `apps/api` -> `3002`

### Papel do local

* desenvolvimento;
* debug;
* ajuste de contrato;
* validação visual inicial;
* testes de integração local.

### Diagrama local

```mermaid
flowchart LR
    DEV[Desenvolvedor] --> WEBL[apps/web :3000]
    DEV --> ADML[apps/admin :3001]
    WEBL --> APIL[apps/api :3002]
    ADML --> APIL
```

---

## 10.2 Ambiente staging

O staging existe para:

* homologação integrada;
* validação de release;
* smoke tests;
* validação SEO e operacional;
* pré-aprovação de produção.

No material atual, a topologia coerente é:

* preview/staging de frontend na Vercel;
* API staging na Render;
* PostgreSQL staging na Render.

### Regra de uso do staging

`staging` não é ambiente ornamental.

Ele existe para responder:

* a release sobe?
* o frontend conversa com a API correta?
* o painel autentica?
* o fluxo editorial continua íntegro?
* a Home pública e as publicações funcionam?
* o SEO essencial não foi quebrado?

---

## 10.3 Ambiente production

A produção oficial é a superfície pública institucional.

### Produção soberana atual

* `https://willianalbarello.com.br`
* `https://api.willianalbarello.com.br`

### Função da produção

* servir o site oficial;
* servir o painel institucional;
* processar autenticação administrativa;
* persistir conteúdo, usuários, sessões e auditoria;
* sustentar operação real.

---

## 11. Relação entre Vercel, painel e rota `/painel`

Este é um dos pontos mais sensíveis e precisa ser explicado com clareza.

## 11.1 O que a documentação soberana manda

O painel administrativo deve viver em:

* `/painel`
* `/painel/login`
* `/painel/publicacoes`
* e demais rotas internas

## 11.2 O que o código real mostra

O monorepo separa o frontend em:

* app público (`apps/web`)
* app administrativo (`apps/admin`)

## 11.3 Interpretação arquitetural correta

Há duas formas tecnicamente legítimas de materializar isso no futuro:

### Opção A — consolidação em um único projeto frontend

* `web` expõe as rotas públicas e `/painel`
* `admin` deixa de ser projeto isolado
* a separação continua lógica, não física

### Opção B — manutenção de dois apps com costura de roteamento

* `web` continua como projeto público
* `admin` continua como projeto administrativo
* a exposição soberana `/painel` é mantida por composição de infraestrutura

### Decisão deste documento

Para o **032**, a decisão correta é:

> representar o painel como superfície lógica hospedada na camada Vercel, preservando o contrato soberano `/painel`, sem congelar ainda a estratégia final de costura física entre `apps/web` e `apps/admin`.

Isso evita um erro comum:

* ou reduzir demais o desenho ao scaffold atual;
* ou ignorar o scaffold e fingir uma infraestrutura que ainda não foi comprovada.

---

## 12. Diagrama de promoção entre ambientes

```mermaid
flowchart LR
    FB[Feature Branch] --> PR[Pull Request]
    PR --> CI[GitHub Actions]
    CI --> Q{Lint + Typecheck + Smoke + Contratos OK?}
    Q -->|Nao| STOP[Merge bloqueado]
    Q -->|Sim| STG[Deploy em staging]
    STG --> VAL[Validacao operacional\nsmoke + verificacao de rotas + auth + health]
    VAL -->|Aprovado| PROD[Promocao para production]
    VAL -->|Reprovado| FIX[Corrigir e reenfileirar]
```

---

## 13. Fluxo operacional do deploy

## 13.1 Fluxo padrão

1. alteração é criada em branch de trabalho;
2. mudança sobe por PR;
3. GitHub Actions executa gates;
4. release elegível sobe em `staging`;
5. validação operacional é feita;
6. após aprovação explícita, ocorre promoção para `production`;
7. smoke tests pós-deploy são executados;
8. monitoramento reforçado é mantido na janela inicial.

## 13.2 Gates mínimos comprovados no acervo

Pelo que existe hoje nos workflows, o projeto já reconhece como gates:

* scaffold bootstrap;
* validação estrutural do monorepo;
* lint;
* typecheck;
* smoke;
* validação de OpenAPI;
* verificação de breaking changes;
* build de documentação de APIs.

## 13.3 Leitura correta

A topologia do deploy não é apenas “onde hospeda”.

Ela também inclui:

* **como sobe**
* **quando sobe**
* **o que bloqueia a subida**
* **como a promoção é autorizada**

---

## 14. Papel do backend e do banco no deploy

## 14.1 API no Render

A API é a fronteira de aplicação do projeto.

Ela recebe:

* autenticação;
* leitura pública;
* operações administrativas;
* proteção de sessão;
* validações;
* auditoria;
* integração com o banco.

Ela deve viver atrás do subdomínio:

* `api.willianalbarello.com.br`

## 14.2 PostgreSQL no Render

O banco é o núcleo de persistência.

Ele sustenta:

* conteúdo;
* taxonomias;
* usuários internos;
* credenciais e sessões;
* rastros operacionais e auditoria;
* evolução futura do CMS.

## 14.3 Regra de isolamento

O banco **não** deve ser acessado diretamente pelo frontend.

A relação correta é sempre:

* frontend -> API
* API -> banco

---

## 15. DNS e topologia institucional

Este diagrama já antecipa a leitura institucional do DNS, mesmo que o detalhamento completo fique para o `034`.

## 15.1 Domínio principal

`willianalbarello.com.br`

Função:

* rosto público do projeto;
* superfície institucional principal;
* camada de apresentação e SEO;
* entrada pública e administrativa, conforme rota.

## 15.2 Subdomínio de API

`api.willianalbarello.com.br`

Função:

* separar claramente a camada de aplicação;
* proteger contrato e governança;
* permitir CORS e políticas de segurança mais nítidas;
* evitar mistura indevida entre frontend e backend.

## 15.3 Regra de desenho institucional

O usuário comum enxerga uma única instituição digital.

A infraestrutura, porém, mantém separação interna suficiente para:

* escalabilidade;
* segurança;
* manutenibilidade;
* observabilidade;
* rollback mais disciplinado.

---

## 16. Segurança aplicada ao deploy

O deploy não é neutro do ponto de vista de segurança.

A topologia atual já exige, no mínimo:

* HTTPS ponta a ponta;
* cookies seguros no ambiente real;
* `HttpOnly` e `SameSite` para sessão;
* CSRF em rotas mutáveis autenticadas;
* CORS restrito ao domínio institucional;
* headers de segurança na camada Next.js;
* separação entre site e API por domínio/subdomínio.

### Evidências já encontradas

Nos artefatos reais, já existem:

* `Content-Security-Policy-Report-Only`
* `X-Content-Type-Options`
* `Referrer-Policy`
* `Permissions-Policy`
* `X-Frame-Options`
* CORS baseado em `*.willianalbarello.com.br`
* cookie com `secure` no fluxo de auth

---

## 17. Rollback dentro da topologia

Este documento precisa dialogar diretamente com o `022_Plano_de_Implantacao_Rollback_e_Suporte.md`.

## 17.1 Rollback de frontend

Na Vercel, a camada web deve permitir retorno à build anterior estável.

A finalidade é conter rapidamente:

* regressão visual severa;
* quebra de rota;
* falha crítica em renderização;
* quebra de metadata técnica;
* regressão do painel.

## 17.2 Rollback de backend

Na Render, a API deve poder voltar à release anterior.

A finalidade é conter:

* quebra de autenticação;
* erro de contrato;
* regressão operacional;
* falha crítica de integração com o banco.

## 17.3 Banco de dados

No banco, rollback é a operação mais sensível.

A leitura correta é:

* preferir migration reversível quando possível;
* aplicar backup pré-mudança crítica;
* tratar restore como último recurso;
* jamais tratar banco como camada de rollback trivial.

## 17.4 Conclusão operacional

O diagrama de deploy só é saudável quando já nasce compatível com rollback.

E este projeto já foi desenhado nessa direção.

---

## 18. Suporte inicial e estabilização pós-release

A topologia de deploy também define como o suporte pensa.

## 18.1 Janela de atenção reforçada

Após promoção para produção, deve existir observação reforçada para:

* Home pública;
* rotas institucionais;
* `/painel/login`;
* `/painel/publicacoes`;
* `/health`;
* autenticação;
* publicação e leitura de conteúdo.

## 18.2 Sinais mínimos de saúde

O deploy é considerado estável quando:

* domínio principal responde;
* API responde;
* login não quebra;
* rotas críticas não devolvem erro estrutural;
* leitura pública funciona;
* incidentes não aparecem nos minutos iniciais.

## 18.3 Leitura correta

Deploy sem vigilância curta pós-release é meia operação.

---

## 19. Riscos topológicos identificados

## 19.1 Risco de ambiguidade entre `web` e `admin`

Como há dois apps frontend no monorepo e uma soberania documental em `/painel`, existe risco de ambiguidade na materialização final.

### Mitigação

* registrar a decisão final no `033` e no `034`;
* não permitir contradição entre domínio público e superfície administrativa;
* manter o contrato institucional claro.

## 19.2 Risco de divergência entre contrato e deploy real

A API pública e administrativa já possui governança documental robusta.

O risco é o deploy real não refletir isso integralmente.

### Mitigação

* usar os gates de contrato já existentes;
* promover somente após verificação de rotas reais;
* manter smoke tests pós-deploy.

## 19.3 Risco de configuração manual invisível

Como não há `vercel.json` ou `render.yaml` no acervo, parte da configuração pode estar apenas nos painéis dos provedores.

### Mitigação

* documentar tudo o que estiver só em painel;
* reduzir conhecimento implícito;
* consolidar runbook operacional.

## 19.4 Risco de DNS incorreto ou incompleto

Qualquer erro de DNS quebra:

* site,
* API,
* TLS,
* autenticação,
* integração entre camadas.

### Mitigação

* detalhamento explícito no documento 034;
* validação antes de produção;
* checklist de go-live.

---

## 20. Decisões arquiteturais firmadas por este documento

1. **Vercel** é a camada soberana de apresentação do projeto.
2. **Render** é a camada soberana de backend e dados do projeto.
3. O domínio principal é `willianalbarello.com.br`.
4. O subdomínio de API é `api.willianalbarello.com.br`.
5. O painel administrativo continua soberanamente representado como `/painel`.
6. O staging é obrigatório como camada de validação.
7. A promoção para produção depende de gates técnicos e validação operacional.
8. O deploy deve nascer compatível com rollback e suporte, não apenas com publicação.
9. O desenho de deploy deve reconhecer a separação física atual entre `apps/web`, `apps/admin` e `apps/api`, mas não permitir que essa separação destrua a coerência institucional do sistema.

---

## 21. Escopo do que este documento resolve e do que não resolve

## 21.1 Este documento resolve

* topologia macro de deploy;
* relação Vercel/Render;
* separação frontend/API/banco;
* noção de ambientes;
* lugar do DNS na topologia;
* papel do staging;
* relação entre deploy, rollback e suporte.

## 21.2 Este documento ainda não resolve

* detalhamento completo de infraestrutura;
* records DNS exatos;
* costura final entre `apps/web` e `apps/admin`;
* observabilidade detalhada;
* runbook fino de indisponibilidade;
* diagrama de recuperação.

Esses pontos pertencem aos próximos documentos do bloco 05.

---

## 22. Conclusão arquitetural

O projeto William Albarello já possui base suficiente para uma leitura clara de deploy:

* **camada web** na Vercel;
* **camada de aplicação** na Render;
* **banco de dados** na Render;
* **domínio institucional** como fachada única;
* **subdomínio de API** como fronteira de aplicação;
* **pipeline com gates** como mecanismo de promoção;
* **staging + production** como estrutura formal de release;
* **rollback e suporte** integrados ao próprio desenho.

A leitura correta do momento atual é esta:

> o deploy do projeto já está logicamente maduro o suficiente para ser diagramado com clareza, mesmo que alguns detalhes finos de plataforma ainda dependam de documentação complementar ou consolidação operacional.

---

## 23. Critérios de aceite do documento

Este documento será considerado aceito quando cumprir, simultaneamente, os seguintes critérios:

1. representar corretamente a relação entre Vercel, Render, API e banco;
2. refletir os domínios soberanos já definidos no projeto;
3. reconhecer a existência de `local`, `staging` e `production`;
4. mostrar a função dos gates de CI/CD na promoção de release;
5. manter coerência com o `022_Plano_de_Implantacao_Rollback_e_Suporte.md`;
6. reconhecer honestamente a diferença entre artefato comprovado e inferência operacional coerente;
7. servir como base sólida para os documentos `033`, `034`, `035`, `036` e `037`.

---

