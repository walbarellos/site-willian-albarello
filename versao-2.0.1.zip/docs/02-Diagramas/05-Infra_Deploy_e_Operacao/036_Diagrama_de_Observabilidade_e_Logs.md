
# 036_Diagrama_de_Observabilidade_e_Logs

## 1. Identificação do documento

- **Projeto:** William Albarello
- **Diretório:** `02-Diagramas`
- **Caminho oficial:** `/home/user/Documents/Softwares/Willian Albarello/William Albarello/02-Diagramas/05-Infra_Deploy_e_Operacao/036_Diagrama_de_Observabilidade_e_Logs.md`
- **Natureza do documento:** Diagrama e contrato lógico de observabilidade, logs, métricas, tracing e alertas
- **Função sistêmica:** Mostrar métricas, logs, tracing, visibilidade operacional, fontes de telemetria, eventos, alertas e rastreabilidade do sistema
- **Posição no bloco:** Quinto documento do bloco `05-Infra_Deploy_e_Operacao`
- **Dependências principais:** `007_Requisitos_Nao_Funcionais.md`, `015_Seguranca_Privacidade_Auditoria_e_Permissoes.md`, `018_Plano_de_Testes_Homologacao_e_Qualidade.md`, `022_Plano_de_Implantacao_Rollback_e_Suporte.md`, `024_Registro_de_Decisoes_Arquiteturais.md`, `032_Diagrama_de_Deploy_Vercel_Render.md`, `033_Diagrama_de_Infraestrutura_Geral.md`, `034_Diagrama_de_DNS_Dominio_e_Subdominios.md`, `035_Diagrama_de_CI_CD.md`
- **Status:** ATIVO
- **Versão:** v1.0
- **Autoridade:** Alta

---

## 2. Objetivo

Este documento existe para formalizar **como o projeto William Albarello enxerga, mede, registra e investiga o próprio comportamento operacional**.

Ele responde, com clareza, às seguintes perguntas:

1. quais eventos devem ser observados;
2. quais são as fontes de log do sistema;
3. quais métricas importam para operação e negócio;
4. como o `traceId` deve costurar investigação ponta a ponta;
5. quais alertas devem existir;
6. como logs, auditoria e incidentes se relacionam;
7. o que já está materializado no acervo técnico;
8. o que ainda é diretriz arquitetural soberana em fase de consolidação.

Este documento trata observabilidade não como “acessório técnico”, mas como **capacidade essencial de operação, diagnóstico, governança e reação**.

---

## 3. Fontes reais utilizadas

Este documento foi construído com base em artefatos efetivamente encontrados no acervo do projeto.

### 3.1 Documentos soberanos do projeto principal
- `01-Waterfall/01-Obrigatorios/007_Requisitos_Nao_Funcionais.md`
- `01-Waterfall/01-Obrigatorios/015_Seguranca_Privacidade_Auditoria_e_Permissoes.md`
- `01-Waterfall/01-Obrigatorios/018_Plano_de_Testes_Homologacao_e_Qualidade.md`
- `01-Waterfall/01-Obrigatorios/022_Plano_de_Implantacao_Rollback_e_Suporte.md`
- `01-Waterfall/01-Obrigatorios/024_Registro_de_Decisoes_Arquiteturais.md`

### 3.2 Documentação complementar real do monorepo
- `Waterfall/DOC-21-observabilidade-logs-e-incidentes.md`
- `Waterfall/DOC-22-operacao-runbooks-e-rotina-de-publicacao.md`
- `Waterfall/DOC-24-go-live-checklist-e-handover-final.md`
- `Execucao/EXEC-05-checklist-de-gates-tecnicos.md`
- `Execucao/EXEC-11-runbook-evidencias-release-real.md`

### 3.3 Backend e contratos reais
- `apps/api/src/server.ts`
- `apps/api/src/routes/health.ts`
- `apps/api/src/lib/env.ts`
- `APIs/API-06-openapi-public.yaml`
- `APIs/API-07-openapi-admin.yaml`
- `APIs/openapi/components/schemas.common.yaml`
- `APIs/openapi/components/responses.common.yaml`

### 3.4 Diagramas e infraestrutura já consolidados
- `032_Diagrama_de_Deploy_Vercel_Render.md`
- `033_Diagrama_de_Infraestrutura_Geral.md`
- `035_Diagrama_de_CI_CD.md`
- `Diagrama/DGM-05-deploy-vercel-render.mmd`

---

## 4. Regra de honestidade técnica deste documento

Este ponto é obrigatório.

O acervo **comprova diretamente** que o projeto já possui:

- preocupação formal com observabilidade, logs e incidentes;
- documento específico de observabilidade (`DOC-21`);
- runbooks operacionais que usam logs e `traceId` como base de investigação;
- requisito explícito de logs estruturados, métricas, tracing e alertas;
- contrato de API com presença de `traceId` em envelopes de sucesso e erro;
- endpoint `/health`;
- backend Fastify com `logger: true`;
- trilha documental de auditoria para eventos administrativos;
- exigência de evidência de observabilidade para promoção de release.

O acervo **não comprova diretamente** que já exista, no código atual:

- stack nominal de observabilidade em vendor específico;
- OpenTelemetry materializado;
- agente de tracing distribuído implementado;
- Prometheus/Grafana/Sentry/Datadog/New Relic configurados;
- dashboard versionado no repositório;
- exportador de métricas explícito;
- propagação efetiva de `traceId` implementada ponta a ponta no runtime atual;
- sistema de alertas já automatizado em arquivo de configuração próprio.

Portanto, este documento distingue com rigor:

### 4.1 Estado soberano desejado e documentado
A forma correta como o sistema **deve** observar a si mesmo.

### 4.2 Estado materializado comprovado
O que já existe **de fato** no acervo técnico atual.

Essa distinção é essencial para não confundir:
- arquitetura com implementação;
- intenção com realidade;
- governança com runtime já consolidado.

---

## 5. Tese central de observabilidade

A tese central deste documento é a seguinte:

> o projeto William Albarello deve operar com observabilidade orientada a diagnóstico rápido, investigação coerente por `traceId`, logs estruturados, métricas acionáveis, alertas com dono e rastreabilidade suficiente para sustentar operação diária, release seguro e resposta a incidentes.

Em linguagem simples:

- não basta saber que “deu erro”;
- é preciso saber **onde**, **quando**, **em qual fluxo**, **com qual impacto** e **como agir**;
- logs sem estrutura não bastam;
- alerta sem ação prevista não basta;
- evento crítico sem rastreabilidade enfraquece a governança;
- release sem visibilidade real não é release maduro.

---

## 6. Princípio operacional da observabilidade

A observabilidade deste projeto deve obedecer a cinco pilares permanentes:

1. **logs estruturados**
2. **métricas operacionais**
3. **correlação por `traceId`**
4. **alertas acionáveis**
5. **rastreabilidade operacional e de auditoria**

Esses pilares não são independentes.  
Eles se reforçam mutuamente.

Exemplo:
- a métrica detecta anomalia;
- o alerta aciona o time;
- o `traceId` permite seguir o caso;
- o log estruturado mostra o contexto;
- a auditoria revela a ação administrativa correlata.

---

## 7. Macrovisão de observabilidade do sistema

A observabilidade do projeto deve cobrir, de forma integrada, os seguintes planos:

### 7.1 Plano de experiência pública
- disponibilidade do site;
- latência percebida;
- falhas em leitura de páginas/publicações;
- integridade técnica de SEO.

### 7.2 Plano administrativo
- sucesso/falha de login;
- falhas em publicação e edição;
- erros em fluxos internos;
- rastreabilidade de ações sensíveis.

### 7.3 Plano de API e backend
- healthcheck;
- latência por endpoint;
- taxa de erro 4xx/5xx;
- segurança de sessão;
- saturação e falhas operacionais.

### 7.4 Plano de dados e persistência
- disponibilidade do banco;
- saturação de conexões;
- erros de persistência;
- integridade de eventos de auditoria.

### 7.5 Plano de release e operação
- falha de deploy;
- regressão pós-release;
- rollback;
- janela reforçada de observação após go-live.

---

## 8. Diagrama principal de observabilidade e logs

```mermaid
flowchart TB

    subgraph ORIGENS["Origens de Sinal"]
        WEB[Frontend publico]
        ADM[Frontend admin /painel]
        API[Backend API]
        DB[Banco de dados]
        CI[Pipeline / release]
        AUD[Trilha de auditoria admin]
    end

    subgraph TELEMETRIA["Telemetria e Coleta"]
        LOGS[Logs estruturados]
        MET[Metricas operacionais]
        TRACE[Correlacao por traceId]
        HC[Healthchecks]
    end

    subgraph LEITURA["Visibilidade Operacional"]
        DASH[Dashboards / leitura operacional]
        ALERT[Alertas acionaveis]
        RCA[Investigacao e RCA]
        RUN[Runbooks operacionais]
    end

    WEB --> LOGS
    WEB --> MET
    WEB --> TRACE

    ADM --> LOGS
    ADM --> MET
    ADM --> TRACE
    ADM --> AUD

    API --> LOGS
    API --> MET
    API --> TRACE
    API --> HC

    DB --> LOGS
    DB --> MET

    CI --> LOGS
    CI --> MET

    AUD --> LOGS
    AUD --> RCA

    LOGS --> DASH
    MET --> DASH
    TRACE --> DASH
    HC --> DASH

    DASH --> ALERT
    ALERT --> RUN
    ALERT --> RCA

    LOGS --> RCA
    TRACE --> RCA
    MET --> RCA
````

---

## 9. Camadas de observabilidade

## 9.1 Observabilidade de borda e frontend

Essa camada deve capturar:

* indisponibilidade do site;
* erro em carregamento de página;
* falha de consumo da API;
* degradação de performance percebida;
* erro em fluxos públicos e administrativos;
* regressão pós-publicação e pós-release.

### Fontes reais relacionadas

* `apps/web`
* `apps/admin`
* headers e metadata já materializados
* `robots.txt`
* `sitemap.xml`
* smoke tests documentados
* monitoramento esperado no go-live

### Situação atual

O acervo comprova a necessidade e a governança dessa camada, mas **não comprova vendor específico já integrado ao frontend**.

---

## 9.2 Observabilidade de backend/API

Essa camada é a mais explicitamente comprovada no runtime atual.

### Evidências reais

* `Fastify({ logger: true })`
* `/health`
* `cors`
* `cookie`
* `csrf`
* `rate-limit`

### Isso significa

O backend já nasce com:

* logging básico nativo do Fastify;
* ponto mínimo de saúde;
* eventos relevantes de segurança que devem ser observáveis;
* condições para futura evolução de logs estruturados mais ricos.

### Limitação atual

O acervo não comprova ainda:

* esquema completo de log customizado no runtime;
* middleware real de `traceId`;
* exportação formal de métricas;
* tracing distribuído materializado.

---

## 9.3 Observabilidade de banco

A documentação soberana exige observar:

* saturação de pool/conexões;
* lentidão;
* falhas de persistência;
* disponibilidade;
* impacto sobre rotas críticas.

### Situação real

O banco está fortemente previsto na arquitetura, mas os artefatos anexados **não mostram configuração concreta de coleta de telemetria do banco**.
Ainda assim, essa camada é obrigatória no desenho macro.

---

## 9.4 Observabilidade de release e deploy

O projeto explicitamente exige visibilidade sobre:

* falha de deploy;
* regressão pós-release;
* saúde de frontend e API após promoção;
* evidência de logs e alertas ativos para promoção real;
* rollback se necessário.

### Evidências reais

* `DOC-22`
* `DOC-24`
* `EXEC-11`
* `DGM-05`

---

## 10. Fontes de log do sistema

A estratégia correta de observabilidade exige distinguir claramente as fontes de log.

## 10.1 Logs de frontend público

Devem registrar, no mínimo:

* erro de carregamento crítico;
* falha de chamada à API;
* rota afetada;
* ambiente;
* `traceId` se disponível;
* contexto técnico suficiente para investigação.

### Finalidade

Descobrir:

* falha pública;
* quebra de experiência;
* regressão de release;
* problema de integração frontend-backend.

---

## 10.2 Logs de frontend administrativo

Devem registrar, no mínimo:

* falha de login;
* falha de submissão de conteúdo;
* erro de validação inesperado;
* falha de leitura de recursos administrativos;
* ação interrompida por erro;
* `traceId` correlacionável com a API.

### Finalidade

Descobrir:

* bloqueios do painel;
* falhas de autenticação;
* degradação editorial;
* incidentes operacionais.

---

## 10.3 Logs de backend/API

São a fonte operacional central.

Devem registrar, no mínimo:

* início e fim de requisição;
* rota;
* método;
* status code;
* latência;
* ambiente;
* serviço;
* `traceId`;
* mensagem;
* contexto adicional seguro;
* erro com stack/contexto adequado quando necessário.

### Campos mínimos soberanos

Conforme `DOC-21`, o padrão mínimo correto é:

* `timestamp`
* `level`
* `service`
* `env`
* `traceId`
* `route`
* `message`
* `context` (json)

### Observação importante

O backend atual comprova logging básico por Fastify, mas **esse padrão completo ainda deve ser consolidado como implementação soberana**.

---

## 10.4 Logs de banco

Devem registrar:

* indisponibilidade;
* erro de conexão;
* saturação;
* lentidão anormal;
* falhas de query críticas;
* impacto em rotas essenciais.

### Regra de prudência

Não transformar logs de banco em ruído massivo sem ação operacional clara.

---

## 10.5 Logs de segurança

Devem registrar, no mínimo:

* falha de login;
* sucesso de login;
* logout;
* bloqueio por rate limit;
* falha de CSRF;
* tentativa inválida em endpoints sensíveis;
* eventos suspeitos de sessão.

### Base documental real

* `DOC-13` e `DOC-14`
* `EXEC-05`
* `DOC-24`

---

## 10.6 Logs de auditoria administrativa

Essa é uma categoria especial: **não se confunde com log operacional bruto**.

Ela deve registrar eventos administrativos relevantes como:

* criação de publicação;
* edição;
* mudança de status;
* exclusão lógica;
* eventos de autenticação;
* ações sensíveis do painel.

### Diferença essencial

* **log operacional**: explica comportamento do sistema;
* **audit log**: explica ação humana/administrativa relevante.

Ambos devem coexistir.

---

## 11. Diagrama de fontes de log e rastreabilidade

```mermaid
flowchart LR

    subgraph FONTES["Fontes"]
        F1[Web publico]
        F2[Painel admin]
        F3[API]
        F4[Banco]
        F5[Deploy / CI]
        F6[Audit logs]
    end

    subgraph REGISTRO["Registro"]
        L1[Logs operacionais]
        L2[Eventos de seguranca]
        L3[Eventos de auditoria]
        L4[Healthcheck]
    end

    subgraph INVESTIGACAO["Investigacao"]
        T1[traceId]
        T2[Rota]
        T3[Usuario/admin]
        T4[Janela temporal]
        T5[Release / versao]
    end

    F1 --> L1
    F2 --> L1
    F2 --> L3
    F3 --> L1
    F3 --> L2
    F4 --> L1
    F5 --> L1
    F3 --> L4

    L1 --> T1
    L2 --> T1
    L3 --> T3
    L4 --> T2

    T1 --> T4
    T3 --> T4
    T2 --> T4
    T4 --> T5
```

---

## 12. Estratégia de `traceId` e correlação

O `traceId` é um dos eixos mais importantes do desenho observável do projeto.

## 12.1 O que o acervo comprova

Os contratos OpenAPI e a documentação arquitetural já reconhecem `traceId` como parte do envelope de resposta e investigação.

Há referência explícita a:

* `meta.traceId`
* `error.traceId`
* correlação por requisição
* investigação por `traceId`

## 12.2 O que o sistema deve fazer

Cada requisição relevante deve:

1. gerar ou receber um `traceId`;
2. propagar esse `traceId` pelo fluxo;
3. devolver esse `traceId` em respostas e erros;
4. registrar esse `traceId` nos logs;
5. associar esse `traceId` à investigação de incidente.

## 12.3 Fluxo soberano de correlação

* frontend chama API;
* API processa;
* erro ou sucesso retornam com `traceId`;
* operador procura o caso pelos logs;
* runbook usa `traceId` como chave central de leitura.

## 12.4 Honestidade técnica

O acervo prova a **intenção soberana** e o **contrato esperado** do `traceId`, mas não comprova a implementação completa disso no runtime atual.

---

## 13. Diagrama de correlação por `traceId`

```mermaid
sequenceDiagram
    participant U as Usuario/Admin
    participant FE as Frontend
    participant BE as API
    participant LG as Logs
    participant AU as Audit Trail

    U->>FE: acao / requisicao
    FE->>BE: chamada com contexto
    BE->>BE: gerar/propagar traceId
    BE->>LG: registrar traceId + rota + status + latencia
    BE->>AU: registrar evento auditavel quando aplicavel
    BE-->>FE: resposta com meta.traceId
    FE-->>U: sucesso ou erro
```

---

## 14. Estratégia de métricas

A observabilidade do projeto não pode depender só de logs.
Ela deve possuir métricas acionáveis.

## 14.1 Métricas de aplicação

Conforme `DOC-21`, devem existir no mínimo:

* requests por minuto;
* latência p50/p95/p99 por endpoint;
* taxa de erro 4xx/5xx;
* taxa de sucesso de login;
* sessões ativas e expiradas.

## 14.2 Métricas de negócio/operação

Também devem existir:

* publicações por período;
* tempo de ciclo editorial;
* taxa de falha de formulário de contato;
* taxa de publicações com checklist completo;
* taxa de incidentes por severidade.

## 14.3 Métricas de infraestrutura

Devem existir, no mínimo:

* CPU/memória da API;
* conexões/pool do banco;
* disponibilidade por serviço;
* falha de deploy;
* erro por release.

## 14.4 Métricas de experiência

Em coerência com os RNFs e SEO técnico:

* disponibilidade do site;
* falha em páginas estratégicas;
* latência percebida em rotas principais;
* regressão pós-publicação ou pós-release.

---

## 15. Métricas soberanas mínimas do projeto

Para efeito arquitetural, ficam definidas como métricas mínimas obrigatórias:

### 15.1 Métricas P0

* disponibilidade do frontend;
* disponibilidade da API;
* latência p95 da API;
* taxa de erro 5xx;
* sucesso de autenticação admin;
* falha de deploy em produção;
* resposta do `/health`.

### 15.2 Métricas P1

* taxa de falha no contato;
* tempo de ciclo editorial;
* lentidão em publicação;
* saturação de banco;
* latência pública em leitura de páginas;
* taxa de erro em endpoints admin.

### 15.3 Métricas P2

* cadência editorial;
* volume de publicações;
* cobertura técnica de checklist;
* ruído de alertas por janela.

---

## 16. SLIs e SLOs operacionais

Com base em `DOC-21`, ficam reconhecidos os seguintes SLIs/SLOs de referência P0:

### 16.1 SLIs

* disponibilidade do frontend;
* disponibilidade da API;
* latência p95 da API;
* taxa de erro 5xx;
* sucesso de autenticação admin.

### 16.2 SLOs de referência

* frontend >= **99,5%** mensal;
* API >= **99,0%** mensal;
* p95 leitura API <= **500ms**.

### 16.3 Interpretação correta

Esses valores funcionam como meta operacional de referência do desenho e do go-live.
Eles não significam que o projeto já possua, no runtime atual, medição madura em vendor específico.

---

## 17. Alertas operacionais

Observabilidade sem alerta acionável é leitura passiva.
Este projeto exige alertas com dono e ação inicial.

## 17.1 Alertas críticos P0

Devem disparar, no mínimo, para:

1. indisponibilidade do frontend;
2. indisponibilidade da API;
3. erro 5xx acima do limite definido;
4. falha repetida de deploy;
5. pico anormal de falha de login;
6. falha crítica de autenticação administrativa;
7. erro sistêmico em publicação;
8. regressão crítica pós-go-live.

## 17.2 Alertas importantes P1

Devem disparar, no mínimo, para:

1. degradação de latência p95;
2. aumento de falhas em contato;
3. saturação de conexões de banco;
4. crescimento anormal de erros em rota específica;
5. queda de taxa de sucesso editorial;
6. regressão SEO estrutural detectável.

## 17.3 Regras soberanas de alerta

Todo alerta deve:

1. ter um owner técnico;
2. apontar ação inicial esperada;
3. evitar ruído sem ação;
4. registrar sua resolução;
5. ser revisto periodicamente para evitar `alert fatigue`.

---

## 18. Diagrama de monitoramento e alertas

```mermaid
flowchart TB

    subgraph MONITOR["Monitoramento"]
        M1[Disponibilidade]
        M2[Latencia]
        M3[Erros 4xx/5xx]
        M4[Healthcheck]
        M5[Seguranca / login]
        M6[Publicacao / operacao]
    end

    subgraph ANALISE["Leitura"]
        A1[Dashboards]
        A2[Tendencias]
        A3[Correlacao por traceId]
    end

    subgraph ALERTAS["Alertas"]
        P0[Alertas P0]
        P1[Alertas P1]
    end

    subgraph RESPOSTA["Resposta"]
        R1[Runbook]
        R2[Triage de severidade]
        R3[Mitigacao / rollback]
        R4[RCA e acoes preventivas]
    end

    M1 --> A1
    M2 --> A1
    M3 --> A1
    M4 --> A2
    M5 --> A3
    M6 --> A3

    A1 --> P0
    A1 --> P1
    A2 --> P0
    A3 --> P0
    A3 --> P1

    P0 --> R1
    P1 --> R1
    R1 --> R2
    R2 --> R3
    R3 --> R4
```

---

## 19. Níveis de incidente e resposta

Com base em `DOC-21`, o sistema reconhece:

* `SEV-1`: crítico
* `SEV-2`: alto
* `SEV-3`: médio
* `SEV-4`: baixo

## 19.1 SEV-1

Exemplos:

* API fora do ar;
* falha total de login admin;
* risco de segurança imediato;
* indisponibilidade pública total.

Resposta esperada:

* contenção imediata;
* possível rollback;
* owner técnico envolvido;
* investigação por `traceId`, logs e contexto de release.

## 19.2 SEV-2

Exemplos:

* degradação severa de funcionalidade principal;
* publicação falhando com alto impacto;
* p95 fortemente degradado.

## 19.3 SEV-3

Exemplos:

* falha parcial com workaround;
* erro restrito a um fluxo menos central.

## 19.4 SEV-4

Exemplos:

* impacto limitado sem risco imediato;
* ruído técnico sem dano operacional amplo.

---

## 20. Fluxo soberano de resposta a incidente

1. detectar;
2. triar severidade e impacto;
3. correlacionar por `traceId`, rota, janela e release;
4. conter;
5. corrigir causa imediata;
6. validar recuperação com smoke tests;
7. registrar incidente;
8. produzir RCA e ação preventiva.

---

## 21. Diagrama de resposta a incidente

```mermaid
flowchart LR

    DET[Deteccao por alerta ou monitoramento]
    TRI[Triage de severidade]
    CORR[Correlacao por traceId + logs + release]
    CONT[Contencao]
    FIX[Correcao]
    VAL[Validacao com smoke tests]
    RCA[RCA + acoes preventivas]

    DET --> TRI
    TRI --> CORR
    CORR --> CONT
    CONT --> FIX
    FIX --> VAL
    VAL --> RCA
```

---

## 22. Rastreabilidade operacional

Observabilidade neste projeto não termina em métricas e logs.
Ela se integra com rastreabilidade operacional.

## 22.1 Eixos de rastreabilidade

Toda ocorrência relevante deve poder ser lida cruzando, quando aplicável:

* `traceId`
* rota
* ambiente
* serviço
* release/versão
* timestamp
* ator administrativo
* evento de auditoria
* severidade do incidente

## 22.2 Conclusão correta

A investigação madura não pergunta só “houve erro?”.
Ela pergunta:

* em qual rota?
* em qual release?
* para qual usuário/admin?
* com qual `traceId`?
* com qual evento administrativo associado?
* com qual impacto público ou interno?

---

## 23. Relação entre logs operacionais e audit logs

Esse ponto precisa ficar cristalino.

## 23.1 Logs operacionais

Servem para diagnosticar:

* falha técnica;
* erro de integração;
* latência;
* indisponibilidade;
* comportamento anormal do runtime.

## 23.2 Audit logs

Servem para registrar:

* quem fez;
* o que fez;
* quando fez;
* em qual entidade/ação sensível;
* com qual rastro administrativo.

## 23.3 Relação correta

Essas duas categorias devem ser correlacionáveis, mas **não são a mesma coisa**.

Exemplo:

* log operacional mostra erro 500 na rota de edição;
* audit log mostra tentativa de alteração em publicação específica;
* `traceId` permite costurar os dois planos.

---

## 24. Eventos mínimos que devem ser observados

Ficam definidos como eventos mínimos relevantes:

### 24.1 Eventos públicos

* falha em carregar home;
* falha em ler publicação;
* falha em sitemap/robots;
* erro em formulário de contato;
* picos de latência pública.

### 24.2 Eventos administrativos

* login com sucesso;
* login com falha;
* logout;
* publicação criada;
* publicação editada;
* mudança de status;
* erro de submissão;
* falha de leitura do painel.

### 24.3 Eventos de backend

* healthcheck falhando;
* rota 5xx;
* rota com latência fora do esperado;
* falha de autenticação/CSRF;
* rate limit acionado;
* erro de banco;
* deploy falhando.

### 24.4 Eventos de release

* promoção para staging;
* promoção para produção;
* smoke pós-deploy;
* rollback;
* incidente pós-release.

---

## 25. Retenção e acesso aos logs

Conforme a diretriz complementar de observabilidade:

### 25.1 Retenção mínima recomendada

* logs operacionais P0: **30 dias**;
* eventos de segurança/auditoria: **90+ dias**.

### 25.2 Acesso

O acesso aos logs deve ser:

* restrito por papel;
* proporcional à responsabilidade;
* rastreável quando sensível;
* nunca aberto indiscriminadamente.

### 25.3 Regra de segurança

Nunca registrar em claro:

* senha;
* segredo bruto;
* token bruto;
* dados pessoais sensíveis sem mascaramento.

---

## 26. Estado real materializado hoje

Este bloco é importante para honestidade operacional.

## 26.1 Já materializado de forma comprovada

* backend Fastify com `logger: true`;
* endpoint `/health`;
* diretriz documental forte de observabilidade;
* uso arquitetural de `traceId` em contratos;
* exigência de logs e alertas no go-live;
* runbooks que investigam por `traceId`;
* exigência de auditabilidade para ações críticas.

## 26.2 Ainda não comprovado como implementação fechada

* middleware real de `traceId` no backend;
* integração real de tracing distribuído;
* vendor específico de métricas/logs;
* dashboards definidos em código;
* alertas configurados em ferramenta nominal;
* esquema implementado de log estruturado completo;
* unificação automática entre logs operacionais e audit logs;
* monitoramento sintético materializado no repositório.

## 26.3 Leitura correta

A arquitetura de observabilidade está **madura no plano documental** e **parcialmente iniciada no plano técnico**.

---

## 27. Riscos observacionais do estágio atual

## 27.1 Risco de governança mais madura que runtime

A documentação exige `traceId`, logs estruturados, alertas e rastreabilidade, mas o runtime comprovado ainda é mais simples.

### Mitigação

* consolidar middleware de correlação;
* padronizar logs do backend;
* formalizar coleta e leitura operacional.

## 27.2 Risco de alertas sem implementação concreta

A política de alertas existe, mas o acervo não prova ainda a ferramenta ou regra executável final.

### Mitigação

* transformar alertas soberanos em configuração operacional real;
* amarrar cada alerta a owner e runbook.

## 27.3 Risco de audit log ficar desconectado do diagnóstico técnico

Sem correlação adequada, auditoria e log operacional podem virar trilhas paralelas.

### Mitigação

* usar `traceId`, timestamp, actor e entidade como pontos de costura;
* padronizar investigação.

## 27.4 Risco de ruído operacional

Logs excessivos sem hierarquia ou alerta demais sem ação geram cegueira operacional.

### Mitigação

* priorizar eventos P0/P1;
* revisar alertas ruidosos;
* manter dashboards orientados a decisão.

---

## 28. Decisões arquiteturais firmadas por este documento

1. Observabilidade é requisito estrutural do projeto, não acessório.
2. O sistema deve combinar logs, métricas, `traceId`, alertas e runbooks.
3. `traceId` é chave central de correlação operacional do projeto.
4. Logs operacionais e audit logs são distintos, mas devem poder ser correlacionados.
5. O backend/API é hoje a principal fonte comprovada de log técnico do runtime.
6. O endpoint `/health` é parte da base mínima de monitoramento.
7. Alertas devem ser acionáveis, com dono e sem ruído inútil.
8. Release sem evidência de observabilidade ativa não deve promover para produção.
9. O go-live exige logs estruturados, monitoramento de erro/latência e alertas críticos.
10. O desenho arquitetural de observabilidade está documentado com maturidade superior à implementação atual, e isso deve permanecer explícito.

---

## 29. O que este documento resolve

Este documento resolve:

* a visão macro de observabilidade do sistema;
* as fontes de log relevantes;
* a distinção entre logs operacionais e trilha de auditoria;
* o papel do `traceId`;
* as métricas mínimas obrigatórias;
* os alertas P0/P1;
* o fluxo de incidente;
* a relação entre observabilidade, release e rollback.

---

## 30. O que este documento ainda não resolve

Este documento ainda não resolve, em detalhe fino:

* vendor específico de observabilidade;
* sintaxe/configuração concreta de dashboards;
* implementação exata do middleware de `traceId`;
* formato final dos alertas por ferramenta;
* definição final de storage/consulta dos logs;
* tracing distribuído implementado;
* playbooks automáticos ou remediação automatizada.

Esses pontos pertencem a implementação técnica posterior e/ou documentação operacional complementar.

---

## 31. Critérios de aceite do documento

Este documento será considerado aceito quando cumprir simultaneamente os seguintes critérios:

1. representar corretamente a estratégia de logs, métricas e alertas;
2. distinguir honestamente arquitetura soberana e implementação comprovada;
3. formalizar o papel do `traceId`;
4. explicar a diferença entre log operacional e auditoria;
5. mostrar a relação entre observabilidade, incidentes e operação;
6. servir como base utilizável para go-live, suporte e evolução técnica.

---

## 32. Conclusão arquitetural

O projeto William Albarello já possui uma arquitetura de observabilidade documentalmente madura o suficiente para sustentar:

* leitura operacional séria;
* investigação por `traceId`;
* governança de release;
* detecção de incidentes;
* auditabilidade de ações críticas;
* evolução disciplinada do runtime.

A leitura correta do momento atual é esta:

* o projeto **já sabe o que precisa observar**;
* **já sabe quais sinais são críticos**;
* **já sabe que logs e auditoria não são a mesma coisa**;
* **já exige observabilidade como gate de produção**;
* mas **a implementação técnica integral dessa camada ainda precisa ser consolidada**.

Em linguagem simples:

> a visão do radar já está desenhada com clareza; o próximo trabalho é terminar de instalar todos os instrumentos no cockpit.

---

