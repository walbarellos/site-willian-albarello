
# 020_Diagrama_do_Modelo_de_Dados_do_Conteudo

## 1. Identificação do documento

- **Projeto:** William Albarello
- **Diretório:** `02-Diagramas`
- **Caminho oficial:** `/home/user/Documents/Softwares/Willian Albarello/William Albarello/02-Diagramas/03-Dados_e_Persistencia/020_Diagrama_do_Modelo_de_Dados_do_Conteudo.md`
- **Natureza do documento:** Diagrama especializado do modelo de dados editorial / CMS
- **Função sistêmica:** Detalhar a anatomia de dados da camada editorial do sistema, cobrindo postagens, rascunhos, categorias, tags, autores, slugs, status, metadata SEO, mídia e campos auxiliares
- **Posição na trilha:** Segundo documento do bloco `03-Dados_e_Persistencia`
- **Dependências principais:** `012_Estrategia_de_Conteudo_SEO_e_Publicacao.md`, `013_Modelo_de_Dados_Conceitual.md`, `017_UI_UX_Arquitetura_da_Informacao.md`, contratos de API e backend técnico disponível

---

## 2. Objetivo

Este documento existe para aprofundar o recorte editorial do modelo de dados do projeto.

Se o documento `019_Diagrama_ER_Entidade_Relacionamento.md` fixou o **ER macro do sistema**, este arquivo faz um zoom no núcleo que sustenta:

- criação de conteúdo;
- edição e revisão;
- classificação editorial;
- publicação e arquivamento;
- descoberta pública;
- SEO;
- apresentação de mídia;
- governança administrativa mínima.

A pergunta central aqui é:

> como o sistema deve estruturar os dados de uma publicação para que ela seja editável, encontrável, publicável, rastreável e evolutiva?

Este documento não substitui o banco físico final, nem congela a estratégia definitiva de ORM, mas estabelece a **anatomia editorial soberana** do projeto.

---

## 3. Fontes de referência

Este documento deriva principalmente das seguintes bases já consolidadas no projeto:

- `012_Estrategia_de_Conteudo_SEO_e_Publicacao.md`
- `013_Modelo_de_Dados_Conceitual.md`
- `017_UI_UX_Arquitetura_da_Informacao.md`
- `016_API_Contract_Mestre.md`
- contratos e documentos técnicos do acervo `personal-site`
- backend e frontend reais disponíveis no pacote técnico, quando houver

Também herda coerência com os diagramas já gerados de:

- backend e API;
- sequências de publicação e edição;
- fluxo de consulta pública;
- fluxo global de requisições.

---

## 4. Premissas e limites

## 4.1 Premissas adotadas

Para este documento, assumem-se as seguintes premissas arquiteturais:

- existe uma camada pública com listagem e detalhe de publicações;
- existe uma camada administrativa com CRUD editorial;
- a publicação pública depende de `slug`, `status`, taxonomia e SEO mínimo;
- categoria é vínculo singular dominante por publicação no ciclo atual;
- tag é vínculo múltiplo;
- o autor editorial pertence à camada interna do sistema;
- o projeto trabalha com estado editorial mínimo do tipo `draft`, `published` e `archived`;
- o modelo deve aceitar soft delete sem destruir rastreabilidade;
- a implementação atual pode materializar alguns subblocos como campos planos na mesma entidade principal.

## 4.2 Limites do documento

Este arquivo não fecha:

- DDL final;
- todos os tipos físicos de coluna;
- índices de performance finais;
- política de versionamento completo de conteúdo;
- biblioteca de mídia enterprise;
- editor rico final do painel;
- rotina final de redirects e histórico avançado de slug.

Ele fixa o **modelo editorial lógico e relacional**.

## 4.3 Regra metodológica importante

Este documento diferencia duas coisas:

1. **modelo editorial soberano do projeto**;
2. **implementação real atual**, que ainda está em estágio parcial.

Portanto:

- o modelo não deve ser empobrecido só porque o código ainda está parcial;
- mas também não deve inventar sofisticação desnecessária sem lastro no projeto.

---

## 5. Tese editorial do modelo de dados

A tese deste documento é a seguinte:

> o conteúdo do projeto William Albarello não deve ser tratado como texto solto, mas como objeto editorial governável, com identidade própria, estado, taxonomia, autoria, metadata de descoberta e possibilidade de evolução semântica.

Isso significa que uma publicação não é apenas:

- um título;
- um corpo;
- uma data.

Ela é um agregado composto por:

- estrutura editorial;
- estrutura de descoberta;
- estrutura de exposição pública;
- estrutura de governança interna.

---

## 6. Escopo editorial coberto por este documento

Este documento cobre, em especial:

- `publicação/postagem`
- `rascunho`
- `categoria`
- `tag`
- `autor`
- `status editorial`
- `slug`
- `SEO metadata`
- `mídia de apoio editorial`
- `campos auxiliares`
- `revisões`
- `histórico de status`

Ele se concentra no coração do CMS editorial do projeto.

---

## 7. Diagrama principal — modelo de dados editorial

```mermaid
erDiagram

    AUTOR_EDITORIAL ||--o{ PUBLICACAO : assina
    CATEGORIA_EDITORIAL ||--o{ PUBLICACAO : classifica
    PUBLICACAO ||--o{ PUBLICACAO_TAG : recebe
    TAG_EDITORIAL ||--o{ PUBLICACAO_TAG : compoe
    PUBLICACAO ||--o| SEO_PUBLICACAO : possui
    PUBLICACAO ||--o{ MIDIA_PUBLICACAO : referencia
    PUBLICACAO ||--o{ REVISAO_EDITORIAL : acumula
    PUBLICACAO ||--o{ HISTORICO_STATUS_EDITORIAL : registra

    AUTOR_EDITORIAL {
        uuid id
        string nome_exibicao
        string email
        string status
        datetime created_at
        datetime ultimo_acesso_em
    }

    CATEGORIA_EDITORIAL {
        uuid id
        string nome
        string slug
        text descricao
        int ordem
        string status
        datetime created_at
        datetime updated_at
        datetime deleted_at
    }

    TAG_EDITORIAL {
        uuid id
        string nome
        string slug
        text descricao
        string status
        datetime created_at
        datetime updated_at
        datetime deleted_at
    }

    PUBLICACAO {
        uuid id
        uuid autor_editorial_id
        uuid categoria_editorial_id
        string titulo
        string slug
        text resumo
        text conteudo
        string status_editorial
        string schema_type
        int tempo_leitura_min
        bool destaque
        datetime publicado_em
        datetime arquivado_em
        datetime deleted_at
        datetime created_at
        datetime updated_at
    }

    PUBLICACAO_TAG {
        uuid id
        uuid publicacao_id
        uuid tag_editorial_id
        datetime created_at
    }

    SEO_PUBLICACAO {
        uuid id
        uuid publicacao_id
        string meta_title
        string meta_description
        string canonical_url
        string og_title
        string og_description
        string og_image_url
        string robots_directive
        datetime updated_at
    }

    MIDIA_PUBLICACAO {
        uuid id
        uuid publicacao_id
        string tipo
        string url
        string alt_text
        string legenda
        string papel
        int ordem
        string status
        datetime created_at
    }

    REVISAO_EDITORIAL {
        uuid id
        uuid publicacao_id
        uuid autor_editorial_id
        string versao
        text resumo_alteracao
        text snapshot_resumido
        datetime created_at
    }

    HISTORICO_STATUS_EDITORIAL {
        uuid id
        uuid publicacao_id
        string status_anterior
        string status_novo
        uuid alterado_por_autor_id
        text motivo
        datetime created_at
    }
````

---

## 8. Leitura executiva do diagrama

O modelo editorial se organiza em torno da entidade soberana:

### `PUBLICACAO`

Tudo o mais existe para dar governança a ela.

A publicação é o objeto editorial principal, e ao seu redor orbitam:

* quem assina;
* como ela é classificada;
* quais tags a contextualizam;
* qual SEO a representa;
* quais mídias a apoiam;
* quais revisões registram sua evolução;
* quais mudanças de status documentam sua vida operacional.

Em linguagem simples:

* `AUTOR_EDITORIAL` responde **quem produz**
* `CATEGORIA_EDITORIAL` responde **onde ela se encaixa**
* `TAG_EDITORIAL` responde **como ela é descoberta e conectada**
* `SEO_PUBLICACAO` responde **como ela se apresenta à descoberta técnica**
* `MIDIA_PUBLICACAO` responde **como ela se apoia visualmente**
* `REVISAO_EDITORIAL` responde **como ela evolui**
* `HISTORICO_STATUS_EDITORIAL` responde **como ela transita operacionalmente**

---

## 9. Entidade central — PUBLICACAO

## 9.1 Finalidade

Representar o item editorial principal do sistema.

Ela deve suportar tanto:

* rascunho interno;
* quanto publicação pública.

## 9.2 Campos nucleares

Os campos nucleares da publicação são:

* `id`
* `autor_editorial_id`
* `categoria_editorial_id`
* `titulo`
* `slug`
* `resumo`
* `conteudo`
* `status_editorial`
* `schema_type`
* `tempo_leitura_min`
* `destaque`
* `publicado_em`
* `arquivado_em`
* `deleted_at`
* `created_at`
* `updated_at`

## 9.3 Papel de cada grupo de campos

### Identidade editorial

* `titulo`
* `slug`

### Corpo e substância

* `resumo`
* `conteudo`

### Governança

* `status_editorial`
* `publicado_em`
* `arquivado_em`
* `deleted_at`

### Descoberta e enriquecimento

* `schema_type`
* `tempo_leitura_min`
* `destaque`

### Auditoria temporal básica

* `created_at`
* `updated_at`

## 9.4 Observação importante

No estado atual do projeto, a publicação cumpre simultaneamente papel de:

* objeto CMS;
* objeto SEO;
* objeto de listagem pública;
* objeto administrativo.

Por isso ela é a entidade dominante da camada editorial.

---

## 10. Autor editorial

## 10.1 Entidade lógica

A entidade `AUTOR_EDITORIAL` representa, conceitualmente, o operador que assina, cria ou mantém a publicação.

## 10.2 Relação principal

* `AUTOR_EDITORIAL` 1:N `PUBLICACAO`

Um autor pode assinar múltiplas publicações.
Cada publicação, no ciclo atual, possui um autor dominante.

## 10.3 Observação de implementação

Na implementação real, este autor pode ser mapeado à entidade de usuário interno já existente, em vez de exigir uma tabela isolada com semântica inteiramente nova.

Ou seja:

* **conceitualmente:** `AUTOR_EDITORIAL`
* **fisicamente, no ciclo atual:** pode ser o próprio `USUARIO_INTERNO` / `users`

## 10.4 Justificativa funcional

Isso preserva:

* autoria explícita no detalhe público;
* responsabilidade editorial na camada interna;
* coerência com login administrativo.

---

## 11. Categoria editorial

## 11.1 Finalidade

Classificar a publicação em um eixo editorial dominante.

## 11.2 Relação principal

* `CATEGORIA_EDITORIAL` 1:N `PUBLICACAO`

No ciclo atual, a publicação trabalha com uma categoria dominante.

## 11.3 Campos principais

* `nome`
* `slug`
* `descricao`
* `ordem`
* `status`
* timestamps
* `deleted_at`

## 11.4 Regra funcional

Uma publicação pode existir em `draft` ainda sem categoria fechada, mas ao ser publicada a categoria tende a se tornar obrigatória.

## 11.5 Justificativa

Isso equilibra:

* flexibilidade durante edição;
* governança ao expor publicamente.

---

## 12. Tag editorial

## 12.1 Finalidade

Representar classificadores leves, múltiplos e relacionais.

## 12.2 Relação principal

* `PUBLICACAO` N:N `TAG_EDITORIAL` via `PUBLICACAO_TAG`

## 12.3 Papel estratégico

A tag existe para:

* descoberta;
* agrupamento fino;
* navegação temática;
* relacionados por afinidade;
* SEO semântico secundário.

## 12.4 Regra de prudência

Tags não devem substituir categorias.

Categoria organiza eixo dominante.
Tag organiza conexões transversais.

---

## 13. Entidade associativa — PUBLICACAO_TAG

## 13.1 Finalidade

Materializar a relação N:N entre publicação e tag.

## 13.2 Campos mínimos

* `publicacao_id`
* `tag_editorial_id`
* `created_at`

## 13.3 Regra obrigatória

Não deve existir duplicidade de vínculo entre a mesma publicação e a mesma tag.

## 13.4 Observação

Fisicamente, é aceitável que a chave primária seja:

* composta (`publicacao_id`, `tag_editorial_id`)

ou

* sintética com `id` próprio

desde que a unicidade lógica seja preservada.

---

## 14. SEO da publicação

## 14.1 Tese de modelagem

SEO deve ser tratado como subagregado editorial, e não como detalhe acidental.

## 14.2 Entidade lógica

`SEO_PUBLICACAO`

Campos centrais:

* `meta_title`
* `meta_description`
* `canonical_url`
* `og_title`
* `og_description`
* `og_image_url`
* `robots_directive`

## 14.3 Relação principal

* `PUBLICACAO` 1:0..1 `SEO_PUBLICACAO`

Uma publicação pode possuir um bloco SEO específico.

## 14.4 Observação de implementação importante

No estado atual do projeto, os campos de SEO podem ficar:

* **conceitualmente agrupados** como `SEO_PUBLICACAO`
* **fisicamente embutidos** na tabela principal `PUBLICACAO`

Essa decisão é legítima e compatível com o contrato atual.

Ou seja:

* o diagrama separa o subdomínio para legibilidade;
* a implementação pode achatá-lo na entidade principal sem quebrar a modelagem.

## 14.5 Regras mínimas de SEO

Para publicação efetiva, o sistema deve suportar no mínimo:

* `meta_title`
* `meta_description`
* `canonical_url`
* `og_image_url`

Os demais campos podem evoluir por ciclo.

---

## 15. Mídia editorial

## 15.1 Finalidade

Representar os ativos visuais ou de apoio associados à publicação.

## 15.2 Entidade lógica

`MIDIA_PUBLICACAO`

Campos principais:

* `tipo`
* `url`
* `alt_text`
* `legenda`
* `papel`
* `ordem`
* `status`

## 15.3 Relação principal

* `PUBLICACAO` 1:N `MIDIA_PUBLICACAO`

Uma publicação pode possuir:

* capa;
* imagem OG;
* imagem de corpo;
* anexos visuais futuros;
* mídia contextual.

## 15.4 Papel do campo `papel`

O campo `papel` é importante para distinguir semanticamente, por exemplo:

* `cover`
* `og`
* `inline`
* `gallery`
* `support`

## 15.5 Observação de implementação

No P0, parte disso pode ser simplificada para campos embutidos como:

* `cover_image_url`
* `og_image_url`

Mas o modelo lógico já deve reconhecer que mídia é um subdomínio próprio.

## 15.6 Regra de acessibilidade

Toda mídia editorial relevante deve aceitar:

* `alt_text`
* legenda quando cabível

Isso preserva acessibilidade e valor editorial.

---

## 16. Revisão editorial

## 16.1 Finalidade

Registrar evolução de conteúdo sem destruir inteligibilidade.

## 16.2 Entidade lógica

`REVISAO_EDITORIAL`

Campos principais:

* `publicacao_id`
* `autor_editorial_id`
* `versao`
* `resumo_alteracao`
* `snapshot_resumido`
* `created_at`

## 16.3 Relação principal

* `PUBLICACAO` 1:N `REVISAO_EDITORIAL`

## 16.4 Regra funcional

Nem toda alteração precisa ser um sistema de versionamento completo enterprise no P0.

Mas o modelo deve prever:

* existência de revisões;
* autoria da alteração;
* explicação resumida;
* memória mínima da mudança.

## 16.5 Justificativa

Isso ajuda a sustentar:

* auditoria;
* disciplina editorial;
* rastreabilidade evolutiva.

---

## 17. Histórico de status editorial

## 17.1 Finalidade

Registrar mudanças de estado sem colapsar o passado operacional.

## 17.2 Entidade lógica

`HISTORICO_STATUS_EDITORIAL`

Campos principais:

* `status_anterior`
* `status_novo`
* `alterado_por_autor_id`
* `motivo`
* `created_at`

## 17.3 Relação principal

* `PUBLICACAO` 1:N `HISTORICO_STATUS_EDITORIAL`

## 17.4 Justificativa

Uma coisa é o status atual da publicação.
Outra coisa é o histórico de transições que a trouxe até esse estado.

Essa separação dá clareza para:

* troubleshooting editorial;
* auditoria;
* métricas futuras de ciclo editorial.

---

## 18. Estados editoriais

## 18.1 Conjunto mínimo do ciclo atual

O conjunto mínimo de estados editoriais do projeto é:

* `draft`
* `published`
* `archived`

## 18.2 Leitura funcional de cada estado

### `draft`

Estado de edição, incompletude ou preparação.
Não aparece publicamente.

### `published`

Estado de exposição pública válida.
Exige campos mínimos coerentes.

### `archived`

Estado de preservação sem protagonismo público corrente.
Pode sair das listagens principais.

## 18.3 Soft delete

`deleted_at` não deve ser tratado como status editorial principal.
Ele representa remoção lógica / soft delete, não a semântica principal do ciclo editorial.

## 18.4 Regra importante

Uma publicação não deve transitar para `published` sem:

* `titulo`
* `slug`
* `resumo`
* `conteudo`
* categoria válida
* SEO mínimo coerente
* imagem ou fallback visual adequado quando exigido pela experiência

---

## 19. Regras de slug

## 19.1 Função do slug

O `slug` é o identificador público estável da publicação.

Ele serve para:

* URL pública;
* leitura humana;
* indexação;
* roteamento;
* referência cruzada.

## 19.2 Regras mínimas

O slug deve ser:

* único global no universo de publicações;
* legível;
* estável;
* livre de ruído desnecessário;
* semanticamente coerente com o título.

## 19.3 Regra operacional crítica

Slug duplicado deve bloquear persistência.

## 19.4 Regra evolutiva

Alteração de slug deve ser excepcional e, idealmente, acompanhada por política de redirect/legado em ciclo posterior.

---

## 20. Campos auxiliares importantes

Além do núcleo clássico, o modelo editorial deve prever campos auxiliares que melhoram operação e descoberta.

## 20.1 `tempo_leitura_min`

Ajuda em:

* card público;
* detalhe da publicação;
* percepção de esforço de leitura;
* componente editorial.

## 20.2 `schema_type`

Permite orientar dados estruturados e semântica de indexação.
Exemplo: `Article`.

## 20.3 `destaque`

Permite priorizar conteúdo em home, blocos de destaque e listagens editoriais.

## 20.4 `resumo`

Não é mero acessório.
É essencial para:

* cards;
* listagens;
* SEO contextual;
* compartilhamento;
* preview interno.

## 20.5 `arquivado_em`

Permite distinguir publicação arquivada de publicação apenas não atualizada.

## 20.6 `deleted_at`

Sustenta soft delete e governança de exclusão lógica.

---

## 21. Cardinalidades principais e justificativas

## 21.1 `AUTOR_EDITORIAL` 1:N `PUBLICACAO`

Um autor pode assinar várias publicações.
Cada publicação tem um autor dominante no ciclo atual.

## 21.2 `CATEGORIA_EDITORIAL` 1:N `PUBLICACAO`

Uma categoria agrupa várias publicações.
Cada publicação possui uma categoria dominante.

## 21.3 `PUBLICACAO` N:N `TAG_EDITORIAL` via `PUBLICACAO_TAG`

Uma publicação pode ter múltiplas tags.
Uma tag pode classificar múltiplas publicações.

## 21.4 `PUBLICACAO` 1:0..1 `SEO_PUBLICACAO`

Toda publicação pode possuir um bloco SEO próprio, ainda que fisicamente embutido na própria publicação.

## 21.5 `PUBLICACAO` 1:N `MIDIA_PUBLICACAO`

Uma publicação pode ter vários ativos de mídia.

## 21.6 `PUBLICACAO` 1:N `REVISAO_EDITORIAL`

Uma publicação pode passar por múltiplas revisões.

## 21.7 `PUBLICACAO` 1:N `HISTORICO_STATUS_EDITORIAL`

Uma publicação pode sofrer várias mudanças de estado ao longo do tempo.

---

## 22. Compatibilização com a API do projeto

O modelo proposto conversa diretamente com a anatomia contratual da API administrativa e pública.

### No eixo público:

* listagem de publicações
* filtro por categoria
* filtro por tag
* detalhe por slug
* relacionados
* metadados editoriais

### No eixo administrativo:

* CRUD de publicações
* CRUD de categorias
* CRUD de tags
* alteração de status
* edição de metadados
* leitura operacional do acervo editorial

Em especial, o contrato de criação/edição de publicação já sugere claramente os seguintes grupos de dados:

* `title`
* `slug`
* `summary`
* `content`
* `categoryId`
* `tagIds`
* bloco `seo`
* `status`

Este documento apenas organiza isso de forma arquiteturalmente mais explícita.

---

## 23. Compatibilização com a UI/UX do projeto

A arquitetura de informação e a UI já indicam telas e fluxos diretamente dependentes deste modelo:

### Público

* lista de publicações
* página individual de publicação
* filtros por categoria/tag
* relacionados
* metadata e compartilhamento

### Administrativo

* lista de publicações
* criação/edição de publicação
* governança de categorias
* governança de tags
* campos SEO
* estados de salvar rascunho e publicar

Portanto, o modelo de dados editorial precisa sustentar a experiência descrita pela UI, e não o contrário.

---

## 24. Regras macro de integridade editorial

## 24.1 RI-ED-01

`slug` de publicação deve ser único.

## 24.2 RI-ED-02

Relação publicação-tag não pode aceitar duplicidade.

## 24.3 RI-ED-03

Publicação `published` exige dados mínimos completos.

## 24.4 RI-ED-04

Categoria pode ser opcional no rascunho, mas tende a ser obrigatória na publicação efetiva.

## 24.5 RI-ED-05

Tags complementam classificação, mas não substituem categoria.

## 24.6 RI-ED-06

SEO mínimo deve existir para exposição pública qualificada.

## 24.7 RI-ED-07

Soft delete não pode fazer a camada pública enxergar registro excluído logicamente.

## 24.8 RI-ED-08

Toda alteração editorial relevante deve ser potencialmente auditável ou revisável.

## 24.9 RI-ED-09

Mídia associada à publicação deve permitir descrição acessível.

---

## 25. Decisões arquiteturais implícitas neste documento

Este diagrama fixa as seguintes decisões de projeto:

1. a publicação é o centro soberano do CMS;
2. autoria é explícita;
3. categoria é singular dominante no ciclo atual;
4. tag é múltipla e relacional;
5. SEO não é improviso, é parte do objeto editorial;
6. mídia não deve ser tratada apenas como string solta sem semântica;
7. revisão e histórico de status possuem valor arquitetural;
8. o modelo aceita começar simples sem impedir evolução futura.

---

## 26. O que este modelo evita

### 26.1 Blog simplista demais

Evita reduzir o editorial a `title + body + date`.

### 26.2 CMS sem governança

Evita conteúdo sem status, sem taxonomia e sem autoria clara.

### 26.3 SEO acidental

Evita depender de metadata improvisada no frontend.

### 26.4 Mídia desorganizada

Evita misturar capa, OG e mídia de apoio sem semântica.

### 26.5 Edição sem rastreio

Evita que o processo editorial fique opaco.

### 26.6 Dependência excessiva do scaffold atual

Evita que a parcialidade da implementação diminua o desenho correto do domínio.

---

## 27. Critérios de aceite deste documento

Este documento será considerado aceito quando:

* detalhar o modelo editorial do projeto com foco real em CMS;
* explicitar publicação, autor, categoria, tag, SEO, mídia, revisão e status;
* apresentar cardinalidades coerentes;
* refletir a UI administrativa e pública já definida;
* dialogar com a API contratada;
* preservar espaço para evolução progressiva;
* servir como base direta para modelagem física e contratos mais finos.

---

## 28. Conclusão executiva

O conteúdo editorial do projeto William Albarello exige um modelo de dados que una:

* substância editorial;
* legibilidade operacional;
* descoberta pública;
* governança administrativa.

A entidade `PUBLICACAO` é o centro dessa anatomia, mas ela só se torna realmente funcional quando acompanhada por:

* autoria,
* categoria,
* tags,
* SEO,
* mídia,
* revisões,
* histórico de status.

Este documento fixa esse núcleo.

Ele transforma o CMS do projeto de uma ideia abstrata em uma estrutura de dados clara, pronta para orientar:

* frontend,
* painel administrativo,
* contratos de API,
* persistência real,
* evolução futura do sistema.

---


