
# 021_Diagrama_do_Modelo_de_Dados_de_Usuarios_e_Papeis

## 1. Identificação do documento

- **Projeto:** William Albarello
- **Diretório:** `02-Diagramas`
- **Caminho oficial:** `/home/user/Documents/Softwares/Willian Albarello/William Albarello/02-Diagramas/03-Dados_e_Persistencia/021_Diagrama_do_Modelo_de_Dados_de_Usuarios_e_Papeis.md`
- **Natureza do documento:** Diagrama especializado do modelo de dados de usuários, credenciais, perfis, permissões e sessões
- **Função sistêmica:** Detalhar a camada de identidade e controle de acesso da área administrativa do sistema
- **Posição na trilha:** Terceiro documento do bloco `03-Dados_e_Persistencia`
- **Dependências principais:** `004_Requisitos_Funcionais_e_Nao_Funcionais.md`, `013_Modelo_de_Dados_Conceitual.md`, `015_Arquitetura_Tecnica_e_de_Software.md`, `016_API_Contract_Mestre.md` e backend real disponível no acervo técnico

---

## 2. Objetivo

Este documento existe para formalizar a anatomia de dados da camada de acesso do sistema, cobrindo:

- usuários internos;
- credenciais;
- perfis;
- permissões;
- sessões ou tokens;
- eventos relacionados à autenticação e ao controle de acesso.

Se o documento `019_Diagrama_ER_Entidade_Relacionamento.md` apresentou o ER macro do sistema e o `020_Diagrama_do_Modelo_de_Dados_do_Conteudo.md` aprofundou o eixo editorial, este arquivo faz o zoom sobre uma pergunta diferente:

> como o sistema deve representar, persistir e governar identidades administrativas de forma segura, auditável e evolutiva?

Este documento não fixa ainda:

- mecanismo criptográfico final em nível de implementação;
- estratégia definitiva entre sessão stateful e token puro stateless;
- provedor futuro de SSO/OAuth;
- política final de MFA;
- estrutura física final de índices e constraints SQL.

Seu foco é o **modelo lógico soberano de usuários e acesso**.

---

## 3. Fontes de referência

Este documento deriva principalmente das seguintes bases já consolidadas no projeto:

- `004_Requisitos_Funcionais_e_Nao_Funcionais.md`
- `013_Modelo_de_Dados_Conceitual.md`
- `015_Arquitetura_Tecnica_e_de_Software.md`
- `016_API_Contract_Mestre.md`

Também dialoga diretamente com:

- os diagramas já produzidos de backend e API;
- o fluxo de autenticação já documentado;
- os requisitos do painel administrativo;
- o backend real do acervo técnico, que já indica login administrativo, cookies e mecanismos de proteção como CSRF e rate limiting.

---

## 4. Premissas e limites

## 4.1 Premissas adotadas

Para este documento, adotam-se as seguintes premissas:

- o sistema possui **camada administrativa protegida**;
- o acesso administrativo é feito por **usuários internos**, e não por cadastro público aberto no ciclo atual;
- o login dominante do ciclo atual é baseado em **email + senha**;
- o sistema precisa suportar **perfis e permissões compostas**;
- o sistema precisa suportar **sessões revogáveis**;
- o sistema precisa registrar **eventos de autenticação e acesso sensível**;
- o backend real atual já sinaliza uso de sessão/cookie, ainda que parte esteja em scaffold inicial;
- o modelo deve suportar evolução futura para MFA e/ou provedores externos sem colapsar o desenho central.

## 4.2 Limites deste documento

Este arquivo não fecha:

- toda a política de rotação de senha;
- mecanismo final de refresh token;
- SSO com terceiros;
- dispositivos confiáveis;
- listas de IP permitidos;
- motores de autorização ABAC avançada;
- governança de segredos fora do banco.

Seu foco é a **estrutura relacional do controle de acesso**.

## 4.3 Regra de prudência arquitetural

Há uma diferença importante entre:

- o **modelo de acesso correto do projeto**; e
- a **implementação técnica atual**, que ainda está parcial.

Por isso, este documento não reduz a arquitetura ao scaffold já existente, mas também não inventa um IAM enterprise desnecessário para o estágio atual.

---

## 5. Tese estrutural do modelo de acesso

A tese deste documento é a seguinte:

> o sistema William Albarello não deve tratar autenticação como detalhe periférico, mas como subdomínio estruturado, composto por identidade interna, credencial, autorização, sessão e rastreabilidade operacional.

Isso significa que o controle de acesso do projeto não deve ser reduzido a:

- `users` com campo `role`;
- `password` solta na mesma tabela sem modelagem de ciclo de vida;
- sessão invisível sem trilha;
- autorização codificada de forma rígida e pouco auditável.

O sistema precisa distinguir claramente:

- **quem é o usuário**;
- **como ele prova identidade**;
- **o que ele pode fazer**;
- **em que sessão ele opera**;
- **o que aconteceu ao longo do ciclo de autenticação**.

---

## 6. Escopo coberto por este documento

Este documento cobre principalmente:

- `USUARIO_INTERNO`
- `CREDENCIAL_ACESSO`
- `PERFIL_ACESSO`
- `PERMISSAO_ACESSO`
- `USUARIO_PERFIL`
- `PERFIL_PERMISSAO`
- `SESSAO_ACESSO`
- `EVENTO_AUTENTICACAO`

Essas entidades formam o núcleo de identidade e autorização da camada administrativa.

---

## 7. Diagrama principal — modelo de dados de usuários e papéis

```mermaid
erDiagram

    USUARIO_INTERNO ||--|| CREDENCIAL_ACESSO : possui
    USUARIO_INTERNO ||--o{ USUARIO_PERFIL : recebe
    PERFIL_ACESSO ||--o{ USUARIO_PERFIL : compoe

    PERFIL_ACESSO ||--o{ PERFIL_PERMISSAO : concede
    PERMISSAO_ACESSO ||--o{ PERFIL_PERMISSAO : compoe

    USUARIO_INTERNO ||--o{ SESSAO_ACESSO : abre
    USUARIO_INTERNO ||--o{ EVENTO_AUTENTICACAO : gera
    SESSAO_ACESSO ||--o{ EVENTO_AUTENTICACAO : contextualiza

    USUARIO_INTERNO {
        uuid id
        string nome
        string email
        string status
        datetime ultimo_acesso_em
        datetime created_at
        datetime updated_at
        datetime deleted_at
    }

    CREDENCIAL_ACESSO {
        uuid id
        uuid usuario_interno_id
        string senha_hash
        string algoritmo_hash
        bool exige_rotacao
        bool mfa_habilitado
        datetime senha_atualizada_em
        datetime ultimo_login_bem_sucedido_em
        datetime ultimo_login_falhou_em
        int tentativas_falhas_recentes
        string status
        datetime created_at
        datetime updated_at
    }

    PERFIL_ACESSO {
        uuid id
        string nome
        string chave
        text descricao
        string escopo
        string status
        datetime created_at
        datetime updated_at
    }

    PERMISSAO_ACESSO {
        uuid id
        string recurso
        string acao
        text descricao
        string escopo
        string status
        datetime created_at
        datetime updated_at
    }

    USUARIO_PERFIL {
        uuid id
        uuid usuario_interno_id
        uuid perfil_acesso_id
        datetime concedido_em
        uuid concedido_por_usuario_id
        string status
    }

    PERFIL_PERMISSAO {
        uuid id
        uuid perfil_acesso_id
        uuid permissao_acesso_id
        datetime concedido_em
        string status
    }

    SESSAO_ACESSO {
        uuid id
        uuid usuario_interno_id
        string session_token_hash
        string refresh_token_hash
        string csrf_secret_hash
        string ip_origem
        string user_agent
        string tipo_sessao
        datetime emitida_em
        datetime expira_em
        datetime ultimo_uso_em
        datetime revogada_em
        string status
    }

    EVENTO_AUTENTICACAO {
        uuid id
        uuid usuario_interno_id
        uuid sessao_acesso_id
        string tipo_evento
        bool sucesso
        string motivo
        string ip_origem
        string user_agent
        json payload_resumido
        datetime created_at
    }
````

---

## 8. Leitura executiva do diagrama

O modelo se organiza em cinco blocos lógicos:

### 8.1 Identidade

Representada por `USUARIO_INTERNO`.

### 8.2 Prova de identidade

Representada por `CREDENCIAL_ACESSO`.

### 8.3 Autorização

Representada por `PERFIL_ACESSO`, `PERMISSAO_ACESSO`, `USUARIO_PERFIL` e `PERFIL_PERMISSAO`.

### 8.4 Sessão operacional

Representada por `SESSAO_ACESSO`.

### 8.5 Rastreabilidade de autenticação

Representada por `EVENTO_AUTENTICACAO`.

Em linguagem direta:

* `USUARIO_INTERNO` responde **quem é o agente**
* `CREDENCIAL_ACESSO` responde **como ele autentica**
* `PERFIL_ACESSO` e `PERMISSAO_ACESSO` respondem **o que ele pode fazer**
* `SESSAO_ACESSO` responde **em qual contexto ativo ele está operando**
* `EVENTO_AUTENTICACAO` responde **o que aconteceu na trilha de acesso**

---

## 9. Entidade central — USUARIO_INTERNO

## 9.1 Finalidade

Representar a pessoa ou identidade administrativa autorizada a operar a camada interna do sistema.

No ciclo atual, esta é a identidade soberana da área administrativa.

## 9.2 Campos nucleares

* `id`
* `nome`
* `email`
* `status`
* `ultimo_acesso_em`
* `created_at`
* `updated_at`
* `deleted_at`

## 9.3 Justificativa dos grupos de campos

### Identidade principal

* `nome`
* `email`

### Governança de vida útil

* `status`
* `deleted_at`

### Auditoria temporal

* `ultimo_acesso_em`
* `created_at`
* `updated_at`

## 9.4 Regra funcional

No ciclo atual, o email do usuário interno deve funcionar como identificador lógico de login e comunicação administrativa.

## 9.5 Observação importante

Conceitualmente, o `AUTOR_EDITORIAL` do documento `020` pode ser mapeado ao próprio `USUARIO_INTERNO`, evitando redundância física desnecessária no P0.

---

## 10. Credencial de acesso

## 10.1 Entidade lógica

`CREDENCIAL_ACESSO`

Ela existe para separar:

* a identidade do usuário;
* do mecanismo concreto de autenticação.

## 10.2 Relação principal

* `USUARIO_INTERNO` 1:1 `CREDENCIAL_ACESSO`

No ciclo atual, cada usuário interno possui uma credencial dominante.

## 10.3 Campos principais

* `senha_hash`
* `algoritmo_hash`
* `exige_rotacao`
* `mfa_habilitado`
* `senha_atualizada_em`
* `ultimo_login_bem_sucedido_em`
* `ultimo_login_falhou_em`
* `tentativas_falhas_recentes`
* `status`

## 10.4 Justificativa funcional

A separação de credencial é importante porque:

* evita misturar identidade e segredo no mesmo conceito semântico;
* facilita evolução futura para MFA, SSO ou múltiplos métodos;
* permite governar rotação, bloqueio e saúde da credencial sem poluir a entidade do usuário.

## 10.5 Observação de implementação

Fisicamente, no ciclo inicial, é admissível que parte desses campos esteja achatada na própria tabela de usuários.
Ainda assim, o modelo lógico deve reconhecer a existência do subdomínio `CREDENCIAL_ACESSO`.

---

## 11. Perfis de acesso

## 11.1 Entidade lógica

`PERFIL_ACESSO`

Ela representa agrupamentos de autorização com sentido operacional.

## 11.2 Finalidade

Permitir que o sistema trabalhe com perfis legíveis como, por exemplo:

* administrador;
* editor;
* operador;
* revisor;
* gestor de conteúdo;

ou outros equivalentes definidos pelo projeto.

## 11.3 Campos principais

* `nome`
* `chave`
* `descricao`
* `escopo`
* `status`

## 11.4 Justificativa

Perfis existem para evitar duas distorções:

* autorização codificada diretamente por campo único simplista;
* permissões atribuídas manualmente uma a uma sem estrutura.

## 11.5 Regra importante

Perfil é agrupador de autorização, não mero rótulo visual.

---

## 12. Permissões de acesso

## 12.1 Entidade lógica

`PERMISSAO_ACESSO`

Ela representa a menor unidade governável de autorização funcional.

## 12.2 Campos principais

* `recurso`
* `acao`
* `descricao`
* `escopo`
* `status`

## 12.3 Leitura recomendada

A modelagem mais saudável da permissão é do tipo:

* `resource:action`

Exemplos conceituais:

* `posts:create`
* `posts:update`
* `posts:publish`
* `categories:read`
* `users:manage`

## 12.4 Justificativa

Isso torna a autorização:

* auditável;
* componível;
* previsível;
* menos dependente de improviso no código.

---

## 13. Entidade associativa — USUARIO_PERFIL

## 13.1 Finalidade

Materializar a relação N:N entre usuários e perfis.

## 13.2 Relação principal

* `USUARIO_INTERNO` N:N `PERFIL_ACESSO` via `USUARIO_PERFIL`

## 13.3 Campos principais

* `usuario_interno_id`
* `perfil_acesso_id`
* `concedido_em`
* `concedido_por_usuario_id`
* `status`

## 13.4 Justificativa funcional

Um usuário pode acumular mais de um perfil.
Um perfil pode ser atribuído a múltiplos usuários.

Isso é especialmente útil para:

* evitar rigidez prematura;
* permitir perfis compostos;
* suportar transições operacionais graduais.

## 13.5 Regra obrigatória

Não deve haver duplicidade ativa do mesmo vínculo entre o mesmo usuário e o mesmo perfil.

---

## 14. Entidade associativa — PERFIL_PERMISSAO

## 14.1 Finalidade

Materializar a relação N:N entre perfis e permissões.

## 14.2 Relação principal

* `PERFIL_ACESSO` N:N `PERMISSAO_ACESSO` via `PERFIL_PERMISSAO`

## 14.3 Campos principais

* `perfil_acesso_id`
* `permissao_acesso_id`
* `concedido_em`
* `status`

## 14.4 Justificativa funcional

Isso permite compor perfis por conjunto de permissões, em vez de codificar lógica difusa dentro do backend.

## 14.5 Regra obrigatória

Não deve haver duplicidade ativa da mesma permissão dentro do mesmo perfil.

---

## 15. Sessão de acesso

## 15.1 Entidade lógica

`SESSAO_ACESSO`

Ela representa o contexto operacional ativo ou histórico de autenticação de um usuário.

## 15.2 Relação principal

* `USUARIO_INTERNO` 1:N `SESSAO_ACESSO`

Um usuário pode abrir múltiplas sessões ao longo do tempo.

## 15.3 Campos principais

* `session_token_hash`
* `refresh_token_hash`
* `csrf_secret_hash`
* `ip_origem`
* `user_agent`
* `tipo_sessao`
* `emitida_em`
* `expira_em`
* `ultimo_uso_em`
* `revogada_em`
* `status`

## 15.4 Justificativa dos campos

### Segurança de sessão

* `session_token_hash`
* `refresh_token_hash`
* `csrf_secret_hash`

### Contexto operacional

* `ip_origem`
* `user_agent`
* `tipo_sessao`

### Ciclo de vida

* `emitida_em`
* `expira_em`
* `ultimo_uso_em`
* `revogada_em`
* `status`

## 15.5 Observação de implementação

O backend técnico atual já sugere uso de cookie e proteção CSRF.
Por isso, este modelo foi desenhado para suportar uma abordagem híbrida e pragmática:

* sessão com token persistido de forma segura por hash;
* possibilidade de refresh token;
* vínculo com contexto CSRF;
* revogação explícita.

## 15.6 Regra importante

Token bruto não deve ser persistido em texto puro quando houver alternativa segura por hash.

---

## 16. Evento de autenticação

## 16.1 Entidade lógica

`EVENTO_AUTENTICACAO`

Ela registra acontecimentos relevantes do ciclo de acesso.

## 16.2 Relações principais

* `USUARIO_INTERNO` 1:N `EVENTO_AUTENTICACAO`
* `SESSAO_ACESSO` 1:N `EVENTO_AUTENTICACAO`

## 16.3 Campos principais

* `tipo_evento`
* `sucesso`
* `motivo`
* `ip_origem`
* `user_agent`
* `payload_resumido`
* `created_at`

## 16.4 Exemplos conceituais de evento

* login bem-sucedido
* login falho
* logout
* sessão revogada
* troca de senha
* redefinição de senha
* elevação de privilégio
* acesso negado

## 16.5 Justificativa

Essa entidade existe para preservar:

* auditoria;
* investigação;
* troubleshooting;
* inteligência operacional;
* governança mínima de segurança.

Ela não substitui todo o `LOG_AUDITORIA` global do sistema, mas cobre o recorte específico de autenticação e acesso.

---

## 17. Cardinalidades principais e justificativas

## 17.1 `USUARIO_INTERNO` 1:1 `CREDENCIAL_ACESSO`

Cada usuário possui uma credencial dominante no ciclo atual.
A separação é semântica e prepara o terreno para evolução futura.

## 17.2 `USUARIO_INTERNO` N:N `PERFIL_ACESSO` via `USUARIO_PERFIL`

Um usuário pode ter múltiplos perfis.
Um perfil pode ser atribuído a vários usuários.

## 17.3 `PERFIL_ACESSO` N:N `PERMISSAO_ACESSO` via `PERFIL_PERMISSAO`

Um perfil agrupa várias permissões.
Uma permissão pode compor múltiplos perfis.

## 17.4 `USUARIO_INTERNO` 1:N `SESSAO_ACESSO`

Um usuário pode possuir várias sessões ao longo do tempo.

## 17.5 `USUARIO_INTERNO` 1:N `EVENTO_AUTENTICACAO`

O histórico de autenticação de um usuário não se resume ao estado atual; ele precisa ser acumulável.

## 17.6 `SESSAO_ACESSO` 1:N `EVENTO_AUTENTICACAO`

Muitos eventos de autenticação podem ocorrer no contexto de uma mesma sessão.

---

## 18. Estados e governança de ciclo de vida

## 18.1 Usuário interno

Estados conceituais mínimos:

* `active`
* `inactive`
* `blocked`

## 18.2 Credencial

Estados conceituais mínimos:

* `active`
* `compromised`
* `revoked`

## 18.3 Sessão

Estados conceituais mínimos:

* `active`
* `expired`
* `revoked`

## 18.4 Vínculos associativos

Os vínculos `USUARIO_PERFIL` e `PERFIL_PERMISSAO` também devem aceitar estado, ao menos para suportar:

* ativação;
* desativação;
* revogação lógica sem perda histórica.

---

## 19. Compatibilização com a API do projeto

A modelagem proposta conversa diretamente com a camada contratual da API administrativa.

### 19.1 Login

O contrato de login administrativo exige entidade de usuário, mecanismo de credencial e produção de sessão.

### 19.2 Controle de acesso

As rotas administrativas exigem verificação de autorização, o que justifica a composição entre perfis e permissões.

### 19.3 Sessão protegida

O contexto atual sugere operação com cookie e CSRF, o que reforça a necessidade de uma entidade de sessão ou contexto equivalente.

### 19.4 Observabilidade e auditoria

Eventos de autenticação e acesso negado precisam ser rastreáveis, o que reforça `EVENTO_AUTENTICACAO`.

---

## 20. Compatibilização com o backend real atual

O backend técnico identificado no acervo já materializa parcialmente o subdomínio de acesso, ainda que de forma inicial.

Ele já indica:

* autenticação administrativa;
* uso de cookies;
* suporte a CSRF;
* rate limiting;
* health check e bootstrap de segurança na API.

Por isso, este diagrama foi desenhado para ser compatível com essa direção técnica.

Ao mesmo tempo, ele é mais maduro do que o scaffold atual e evita transformar placeholders temporários em verdade arquitetural definitiva.

---

## 21. Compatibilização com personas e operação do painel

As personas operacionais da camada administrativa precisam ser traduzidas em acesso controlado.

Este modelo suporta isso de forma adequada porque:

* distingue identidade de autorização;
* permite múltiplos perfis por pessoa;
* permite granularidade de permissão por recurso e ação;
* separa evento de autenticação de sessão e de usuário;
* preserva espaço para evolução sem reescrever tudo.

Na prática, isso é importante para perfis como:

* administrador geral;
* gestor/editor;
* operador interno;
* revisor editorial;

ou equivalentes definidos pelo projeto ao longo dos ciclos.

---

## 22. Regras macro de integridade do modelo

## 22.1 RI-AC-01

Email de `USUARIO_INTERNO` deve ser único entre usuários ativos ou não excluídos logicamente.

## 22.2 RI-AC-02

Cada usuário interno deve possuir no máximo uma credencial dominante ativa no ciclo atual.

## 22.3 RI-AC-03

Senha nunca deve ser persistida em texto puro.

## 22.4 RI-AC-04

Não deve haver duplicidade ativa do mesmo perfil para o mesmo usuário.

## 22.5 RI-AC-05

Não deve haver duplicidade ativa da mesma permissão no mesmo perfil.

## 22.6 RI-AC-06

Sessão revogada não pode continuar válida para operação.

## 22.7 RI-AC-07

Token bruto não deve ser armazenado de forma insegura quando houver alternativa por hash.

## 22.8 RI-AC-08

Evento de autenticação deve preservar contexto mínimo de origem e momento.

## 22.9 RI-AC-09

Usuário bloqueado ou inativo não deve abrir nova sessão válida.

## 22.10 RI-AC-10

Permissões devem ser compostas por perfil ou política equivalente, e não por improviso local não rastreável.

---

## 23. Decisões arquiteturais implícitas neste documento

Este documento fixa, em nível macro, as seguintes decisões:

1. o sistema possui **apenas usuários internos administrativos** como foco do subdomínio atual;
2. autenticação e autorização são subdomínios relacionados, mas distintos;
3. perfil não substitui permissão, ele a agrega;
4. sessão é entidade relevante, não ruído operacional invisível;
5. eventos de autenticação merecem persistência própria;
6. o modelo aceita cookie/session, tokens ou abordagem híbrida;
7. o desenho privilegia evolução progressiva sem sacrificar segurança mínima.

---

## 24. O que este modelo evita

### 24.1 Redução simplista a `user.role`

Evita um modelo frágil demais para governança real.

### 24.2 Autorização rígida no código

Evita espalhar decisões de permissão de modo pouco auditável.

### 24.3 Sessões invisíveis

Evita operar autenticação sem trilha de revogação, expiração e contexto.

### 24.4 Mistura entre identidade e segredo

Evita tratar senha e usuário como o mesmo conceito semântico.

### 24.5 Auditoria insuficiente

Evita que tentativas falhas, revogações e mudanças relevantes sumam do mapa.

### 24.6 Dependência do scaffold atual

Evita empobrecer a arquitetura por causa de uma implementação ainda parcial.

---

## 25. Critérios de aceite deste documento

Este documento será considerado aceito quando:

* explicitar claramente usuários, credenciais, perfis, permissões, sessões e eventos de autenticação;
* apresentar cardinalidades coerentes;
* refletir a necessidade de segurança e auditabilidade da camada administrativa;
* dialogar com a API e o backend existentes;
* preservar espaço para evolução futura sem inflar desnecessariamente o modelo;
* servir como base para implementação real do controle de acesso.

---

## 26. Conclusão executiva

O projeto William Albarello exige que a camada administrativa seja tratada com seriedade arquitetural.

Isso significa que o sistema precisa reconhecer, com clareza:

* quem é o usuário interno;
* qual é a sua credencial;
* quais perfis ele assume;
* quais permissões esses perfis concedem;
* em qual sessão ele está operando;
* quais eventos marcaram sua trilha de autenticação.

Este documento fixa essa estrutura.

Ele não encerra todas as decisões de segurança do projeto, mas estabelece o **núcleo relacional soberano do controle de acesso**, sobre o qual a implementação real do backend e da API administrativa deve se apoiar.

---


