
# 023_Diagrama_de_Versionamento_de_Conteudo

## 1. Identificação do documento

- **Projeto:** William Albarello
- **Diretório:** `02-Diagramas`
- **Caminho oficial:** `/home/user/Documents/Softwares/Willian Albarello/William Albarello/02-Diagramas/03-Dados_e_Persistencia/023_Diagrama_de_Versionamento_de_Conteudo.md`
- **Natureza do documento:** Diagrama e contrato lógico de versionamento editorial
- **Função sistêmica:** Explicar como o sistema deve tratar revisões, histórico, restauração, integridade e rastreabilidade do conteúdo
- **Posição na trilha:** Quinto documento do bloco `03-Dados_e_Persistencia`
- **Dependências principais:** `013_Modelo_de_Dados_Conceitual.md`, `017_UI_UX_Arquitetura_da_Informacao.md`, `018_Plano_de_Testes_Homologacao_e_Qualidade.md`, `024_Registro_de_Decisoes_Arquiteturais.md`, `020_Diagrama_do_Modelo_de_Dados_do_Conteudo.md`, `022_Diagrama_de_Estados_da_Postagem.md` e backend real disponível no acervo técnico

---

## 2. Objetivo

Este documento existe para formalizar o **modelo de versionamento de conteúdo** do projeto William Albarello.

Se o documento `020_Diagrama_do_Modelo_de_Dados_do_Conteudo.md` detalhou a anatomia editorial da publicação e o documento `022_Diagrama_de_Estados_da_Postagem.md` descreveu o seu ciclo de vida, este arquivo responde a outra pergunta essencial:

> como o sistema preserva memória editorial sem perder controle, sem apagar histórico e sem confundir edição atual com versão publicada?

Seu objetivo é explicitar:

- como revisões devem ser registradas;
- como o histórico editorial deve ser preservado;
- como restaurações devem funcionar;
- o que constitui uma versão autoritativa;
- quais dados entram no snapshot versionado;
- como evitar perda de integridade ao editar, publicar e restaurar.

Este documento não fixa:

- engine final de diff textual;
- interface final de comparação visual entre versões;
- política final de retenção de revisões antigas;
- compressão, deduplicação ou tuning físico do armazenamento.

Seu foco é o **modelo lógico soberano do versionamento editorial**.

---

## 3. Fontes de referência

Este documento deriva principalmente das seguintes bases do projeto:

- `013_Modelo_de_Dados_Conceitual.md`
- `017_UI_UX_Arquitetura_da_Informacao.md`
- `018_Plano_de_Testes_Homologacao_e_Qualidade.md`
- `024_Registro_de_Decisoes_Arquiteturais.md`

Também dialoga diretamente com:

- `020_Diagrama_do_Modelo_de_Dados_do_Conteudo.md`
- `021_Diagrama_do_Modelo_de_Dados_de_Usuarios_e_Papeis.md`
- `022_Diagrama_de_Estados_da_Postagem.md`
- contratos administrativos e editoriais da API
- backend real disponível no acervo técnico, quando houver

---

## 4. Premissas e limites

## 4.1 Premissas adotadas

Para este documento, adotam-se as seguintes premissas:

- o sistema possui uma entidade editorial principal (`PUBLICACAO`);
- a publicação pode ser criada, editada, revisada, publicada, arquivada e reativada;
- o projeto exige rastreabilidade mínima de mudanças relevantes;
- a restauração de conteúdo precisa preservar o passado, e não sobrescrevê-lo destrutivamente;
- o histórico editorial deve ser inteligível no painel administrativo;
- o backend real atual ainda está parcial, portanto o modelo de versionamento não pode ser limitado apenas pelo scaffold presente;
- nem todo autosave precisa virar versão autoritativa;
- mudanças relevantes de conteúdo, SEO, taxonomia, status e restauração devem gerar revisão histórica.

## 4.2 Limites deste documento

Este arquivo não fecha:

- algoritmo definitivo de diff entre versões;
- renderização final lado a lado no frontend administrativo;
- integração futura com armazenamento otimizado de blobs;
- retenção definitiva de revisões intermediárias;
- política final de versionamento de mídia pesada.

Seu papel é fixar a **lógica soberana de histórico editorial**.

## 4.3 Regra de prudência arquitetural

Há uma diferença importante entre:

- o **versionamento editorial correto do projeto**; e
- a **implementação técnica atual**, que ainda não materializa toda a riqueza desse desenho.

Por isso, este documento assume o desenho correto do domínio sem fingir que tudo já está implementado.

---

## 5. Tese central do versionamento

A tese deste documento é a seguinte:

> versionamento editorial não é “guardar o texto antigo de vez em quando”; é preservar, de forma íntegra e rastreável, a sucessão autoritativa de estados de uma publicação ao longo do tempo.

Isso implica cinco decisões centrais:

1. histórico não deve ser apagado por edição posterior;
2. restauração não deve reescrever o passado, mas criar novo presente a partir de uma versão anterior;
3. publicação pública precisa apontar para uma revisão historicamente identificável;
4. mudanças editoriais relevantes devem gerar revisão autoritativa;
5. autosave e rascunho efêmero não devem poluir o histórico principal sem critério.

---

## 6. Problema que o versionamento resolve

Sem um modelo correto de versionamento, o sistema corre riscos como:

- perda silenciosa de conteúdo anterior;
- impossibilidade de saber quem alterou o quê;
- publicação de texto novo sem trilha da versão anterior;
- restauração destrutiva que apaga memória editorial;
- divergência entre o que foi editado, o que foi publicado e o que foi arquivado;
- dificuldade para QA, homologação e auditoria editorial.

O versionamento existe justamente para impedir esses colapsos.

---

## 7. Estratégia geral adotada

O projeto deve adotar uma estratégia de versionamento com as seguintes características:

### 7.1 Revisão imutável
Cada revisão histórica relevante deve ser imutável depois de criada.

### 7.2 Snapshot autoritativo
Cada revisão deve registrar um snapshot suficientemente completo da publicação naquele momento.

### 7.3 Encadeamento
Cada revisão deve saber de qual revisão veio.

### 7.4 Cabeça atual
A publicação deve apontar para sua revisão atual.

### 7.5 Cabeça publicada
A publicação deve poder apontar separadamente para a última revisão efetivamente publicada.

### 7.6 Restauração não destrutiva
Restaurar uma versão antiga deve gerar uma nova revisão atual, e não “voltar o relógio apagando o meio do caminho”.

### 7.7 Eventos de versionamento
Ações como criação de revisão, publicação e restauração devem ser registradas como eventos.

---

## 8. Diagrama principal — modelo de versionamento de conteúdo

```mermaid
erDiagram

    PUBLICACAO ||--o{ REVISAO_CONTEUDO : acumula
    USUARIO_INTERNO ||--o{ REVISAO_CONTEUDO : gera
    REVISAO_CONTEUDO ||--o{ EVENTO_VERSIONAMENTO : origina
    USUARIO_INTERNO ||--o{ EVENTO_VERSIONAMENTO : executa

    REVISAO_CONTEUDO ||--o{ REVISAO_CONTEUDO : deriva_de
    REVISAO_CONTEUDO ||--o{ REVISAO_CONTEUDO : restaura_de

    PUBLICACAO {
        uuid id
        string titulo_corrente
        string slug_corrente
        string status_editorial_corrente
        uuid revisao_atual_id
        uuid ultima_revisao_publicada_id
        int versao_corrente_numero
        datetime published_at_corrente
        datetime updated_at
    }

    REVISAO_CONTEUDO {
        uuid id
        uuid publicacao_id
        uuid autor_id
        uuid parent_revision_id
        uuid restored_from_revision_id
        int numero_versao
        string tipo_origem
        string status_snapshot
        text resumo_alteracao
        json snapshot_conteudo
        string hash_integridade
        bool eh_publicada
        datetime published_at_snapshot
        datetime created_at
    }

    EVENTO_VERSIONAMENTO {
        uuid id
        uuid publicacao_id
        uuid revisao_conteudo_id
        uuid usuario_interno_id
        string tipo_evento
        string origem_acao
        text observacao
        json payload_resumido
        datetime created_at
    }

    USUARIO_INTERNO {
        uuid id
        string nome
        string email
        string status
        datetime created_at
    }
````

---

## 9. Leitura executiva do diagrama

O diagrama organiza o versionamento em quatro peças principais:

### 9.1 `PUBLICACAO`

É o objeto editorial vivo, aquele que o sistema enxerga como registro principal.

### 9.2 `REVISAO_CONTEUDO`

É a memória histórica imutável dos estados relevantes pelos quais a publicação passou.

### 9.3 `EVENTO_VERSIONAMENTO`

É a trilha operacional do que aconteceu no ciclo de revisão, publicação e restauração.

### 9.4 `USUARIO_INTERNO`

É o agente responsável pelas alterações e eventos.

Em termos práticos:

* a publicação vive no presente;
* a revisão preserva o passado;
* o evento explica o que ocorreu;
* o usuário identifica quem foi o agente.

---

## 10. Entidade central — PUBLICACAO

## 10.1 Finalidade

Representar o objeto editorial ativo no sistema.

Ela não guarda sozinha todo o histórico, mas aponta para ele.

## 10.2 Campos relevantes para versionamento

* `revisao_atual_id`
* `ultima_revisao_publicada_id`
* `versao_corrente_numero`
* `titulo_corrente`
* `slug_corrente`
* `status_editorial_corrente`
* `published_at_corrente`

## 10.3 Justificativa

A publicação precisa funcionar como um “ponteiro” para o presente operacional.

Isso evita duas distorções:

* ler o histórico inteiro para descobrir o estado atual;
* transformar a revisão histórica em substituta da publicação viva.

## 10.4 Regra funcional

A leitura corrente no painel e na API deve vir primariamente da publicação atual, enquanto o histórico detalhado deve vir das revisões.

---

## 11. Entidade histórica — REVISAO_CONTEUDO

## 11.1 Finalidade

Representar cada versão editorial autoritativa da publicação.

É o coração do versionamento.

## 11.2 Campos principais

* `publicacao_id`
* `autor_id`
* `parent_revision_id`
* `restored_from_revision_id`
* `numero_versao`
* `tipo_origem`
* `status_snapshot`
* `resumo_alteracao`
* `snapshot_conteudo`
* `hash_integridade`
* `eh_publicada`
* `published_at_snapshot`
* `created_at`

## 11.3 Justificativa dos grupos de campos

### Encadeamento

* `parent_revision_id`
* `restored_from_revision_id`

### Identidade da revisão

* `numero_versao`
* `tipo_origem`

### Conteúdo versionado

* `snapshot_conteudo`
* `status_snapshot`

### Integridade

* `hash_integridade`

### Publicação histórica

* `eh_publicada`
* `published_at_snapshot`

### Explicação humana

* `resumo_alteracao`

## 11.4 Regra central

Uma vez criada, a revisão histórica não deve ser editada in place.

---

## 12. O que entra no snapshot da revisão

O campo `snapshot_conteudo` deve conter, no mínimo, os elementos editoriais necessários para reconstruir com fidelidade a versão daquele momento.

No projeto William Albarello, isso tende a incluir:

* `titulo`
* `slug`
* `resumo`
* `conteudo`
* `categoria_id`
* `tag_ids`
* `status_editorial`
* `seo`

  * `meta_title`
  * `meta_description`
  * `canonical_url`
  * `og_title`
  * `og_description`
  * `og_image_url`
  * `robots_directive`
* `midias`
* `schema_type`
* `tempo_leitura_min`
* `destaque`
* `published_at`
* `scheduled_for`, se aplicável
* campos auxiliares relevantes do CMS

## 12.1 Justificativa

Uma revisão que guarda apenas o corpo do texto é insuficiente.

A publicação pública é resultado de um conjunto editorial, e não apenas de um bloco de texto.

---

## 13. O que não precisa, necessariamente, entrar como versão autoritativa

Nem tudo precisa virar revisão histórica principal.

Exemplos que podem ser tratados separadamente ou de forma efêmera:

* autosave de digitação a cada poucos segundos;
* estado de formulário temporário não confirmado;
* validações incompletas ainda não salvas;
* artefatos estritamente visuais da interface sem impacto editorial.

## 13.1 Regra prática

O histórico autoritativo deve nascer de **salvamento significativo**, não de ruído operacional.

---

## 14. Encadeamento entre revisões

## 14.1 `parent_revision_id`

Esse campo aponta para a revisão imediatamente anterior na linha histórica principal.

Ele existe para responder:

* de qual revisão esta nova revisão derivou?

## 14.2 `restored_from_revision_id`

Esse campo aponta para a revisão antiga que serviu de base para uma restauração.

Ele existe para responder:

* esta revisão atual nasceu por restauração de qual versão passada?

## 14.3 Por que os dois campos são importantes

Porque derivar de uma revisão imediatamente anterior e restaurar uma revisão antiga são coisas diferentes.

Exemplo:

* versão 5 deriva da versão 4;
* versão 8 pode derivar da versão 7, mas ter sido restaurada a partir da versão 3.

Isso preserva inteligibilidade histórica.

---

## 15. Número de versão

## 15.1 Função

O campo `numero_versao` deve identificar, de forma simples e humana, a ordem lógica das revisões da publicação.

## 15.2 Regra mínima

Cada nova revisão autoritativa incrementa o número da versão.

Exemplo:

* v1
* v2
* v3
* v4

## 15.3 Regra importante

Restauração não “rebaixa” o contador para a versão antiga.

Ao restaurar a versão 2, por exemplo, o sistema deve criar algo como a versão 8 baseada no conteúdo da 2.

Isso evita apagar a existência das versões 3 a 7.

---

## 16. Tipo de origem da revisão

O campo `tipo_origem` existe para informar o que gerou a revisão.

Valores conceituais possíveis:

* `create`
* `edit`
* `review_adjustment`
* `publish`
* `archive`
* `restore`
* `status_change`
* `scheduled_publish`

## 16.1 Justificativa

Isso facilita:

* leitura humana do histórico;
* debug editorial;
* auditoria;
* filtros administrativos por tipo de alteração.

---

## 17. Revisão publicada

## 17.1 Campo `eh_publicada`

Esse campo informa se aquela revisão foi efetivamente a base de uma publicação pública.

## 17.2 Campo `published_at_snapshot`

Esse campo registra o marco temporal de publicação daquela revisão específica.

## 17.3 Justificativa

Nem toda revisão histórica foi pública.
Algumas são internas, de draft ou revisão.
Outras foram efetivamente expostas ao público.

Separar isso é crucial para responder perguntas como:

* qual versão estava no ar em determinada data?
* qual revisão originou a publicação pública vigente?
* qual foi a última revisão publicada antes do arquivamento?

---

## 18. Evento de versionamento

## 18.1 Entidade lógica

`EVENTO_VERSIONAMENTO`

Ela existe para registrar a ação operacional ocorrida sobre a revisão ou publicação.

## 18.2 Campos principais

* `publicacao_id`
* `revisao_conteudo_id`
* `usuario_interno_id`
* `tipo_evento`
* `origem_acao`
* `observacao`
* `payload_resumido`
* `created_at`

## 18.3 Exemplos de evento

* criação da primeira revisão
* salvamento de nova revisão
* envio para revisão
* publicação
* agendamento
* arquivamento
* restauração
* reabertura de edição

## 18.4 Por que revisar e eventar ao mesmo tempo

Revisão e evento não são a mesma coisa.

* a **revisão** preserva o estado do conteúdo;
* o **evento** preserva o acontecimento operacional.

Ambos são úteis e não se substituem.

---

## 19. Diagrama operacional — fluxo de revisão e restauração

```mermaid
flowchart TD
    A[Publicação atual] --> B[Salvar alteração relevante]
    B --> C[Criar nova revisão imutável]
    C --> D[Atualizar revisao_atual_id da publicação]
    D --> E{Ação editorial}
    E -->|Publicar| F[Marcar revisão como publicada]
    F --> G[Atualizar ultima_revisao_publicada_id]
    E -->|Arquivar| H[Registrar evento de arquivamento]
    E -->|Restaurar revisão antiga| I[Selecionar revisão histórica]
    I --> J[Criar nova revisão a partir da antiga]
    J --> K[Preencher restored_from_revision_id]
    K --> L[Atualizar revisão atual da publicação]
```

---

## 20. Regra de restauração

## 20.1 Princípio central

Restaurar não deve significar:

* editar a revisão antiga;
* apagar revisões intermediárias;
* “voltar no tempo” de forma destrutiva.

## 20.2 O comportamento correto é:

1. o usuário escolhe uma revisão antiga;
2. o sistema lê o snapshot daquela revisão;
3. o sistema cria uma **nova revisão atual** com base nesse snapshot;
4. essa nova revisão aponta para:

   * a revisão imediatamente anterior como `parent_revision_id`;
   * a revisão restaurada como `restored_from_revision_id`;
5. a publicação passa a apontar para a nova revisão.

## 20.3 Resultado

O passado continua íntegro.
A restauração vira um novo capítulo da história, não uma borracha sobre os capítulos anteriores.

---

## 21. Integridade editorial

O versionamento precisa proteger a integridade editorial em quatro dimensões.

## 21.1 Integridade histórica

Nada relevante deve sumir sem trilha.

## 21.2 Integridade semântica

A versão restaurada deve reconstruir o conteúdo editorial de forma fiel.

## 21.3 Integridade de autoria

Cada revisão deve apontar para o agente responsável.

## 21.4 Integridade técnica

Cada revisão deve ter mecanismo de verificação mínima, como hash do snapshot.

---

## 22. Uso de hash de integridade

## 22.1 Função

O campo `hash_integridade` existe para permitir verificação básica de integridade do snapshot armazenado.

## 22.2 Não é objetivo aqui

Este documento não fixa o algoritmo final, mas exige o princípio de integridade verificável.

## 22.3 Justificativa

Isso ajuda a detectar:

* corrupção acidental;
* inconsistência de snapshot;
* divergência entre conteúdo reconstruído e conteúdo persistido.

---

## 23. Relação com estados editoriais

O versionamento dialoga diretamente com o documento `022_Diagrama_de_Estados_da_Postagem.md`.

Cada revisão deve preservar o `status_snapshot` correspondente ao estado editorial daquele momento.

Isso é importante porque:

* uma revisão pode ser de `draft`;
* outra de `review`;
* outra pode ser a revisão efetivamente `published`;
* outra pode registrar `archived`.

Sem isso, o histórico perderia contexto operacional.

---

## 24. Relação com UI/UX do painel

A UI administrativa deve conseguir mostrar, com base nesse modelo:

* lista de versões da publicação;
* número da versão;
* autor da alteração;
* data/hora;
* resumo da mudança;
* status editorial daquela revisão;
* marcador de revisão publicada;
* ação de restaurar;
* eventualmente, ação de comparar versões.

## 24.1 Regra de UX importante

O painel não deve comunicar restauração como “apagar tudo e voltar”.
Deve comunicar como:

* “restaurar esta versão e criar nova revisão atual”.

Isso é mais correto e evita erro humano.

---

## 25. Relação com o backend real atual

O backend real presente no acervo técnico ainda não materializa toda essa camada de versionamento.

Isso significa que:

* o desenho aqui é **alvo arquitetural correto**;
* a implementação atual pode estar em estágio mais simples;
* o sistema não deve ser rebaixado conceitualmente por causa disso.

O backend atual já permite inferir um fluxo editorial com edição e publicação.
Este documento organiza a camada histórica que deve sustentar esse fluxo quando aprofundado.

---

## 26. Estratégia mínima de implementação progressiva

Para evitar inflar o sistema cedo demais, o projeto pode implementar versionamento em camadas.

## 26.1 Camada mínima aceitável

* `PUBLICACAO`
* `REVISAO_CONTEUDO`
* criação de revisão a cada salvamento relevante
* restauração gerando nova revisão
* marcação da revisão publicada

## 26.2 Camada seguinte

* `EVENTO_VERSIONAMENTO`
* comparação entre revisões
* filtros por tipo de origem
* histórico mais rico no painel

## 26.3 Camada posterior

* diff visual avançado
* retenção configurável
* auditoria expandida
* cruzamento com workflow completo de aprovação

---

## 27. Regras macro de integridade do versionamento

## 27.1 RI-VC-01

Toda revisão autoritativa deve ser imutável após criada.

## 27.2 RI-VC-02

Toda publicação deve poder apontar para sua revisão atual.

## 27.3 RI-VC-03

Quando houver publicação pública, o sistema deve conseguir identificar qual revisão foi publicada.

## 27.4 RI-VC-04

Restauração deve criar nova revisão, não sobrescrever revisão antiga.

## 27.5 RI-VC-05

Toda revisão deve preservar autoria, data e contexto mínimo.

## 27.6 RI-VC-06

Toda revisão relevante deve carregar snapshot suficiente para reconstrução editorial.

## 27.7 RI-VC-07

O número da versão deve ser progressivo e não retroceder em restauração.

## 27.8 RI-VC-08

Mudanças significativas de conteúdo, taxonomia, SEO, status e restauração devem gerar revisão autoritativa.

## 27.9 RI-VC-09

Autosave efêmero não deve poluir a linha oficial de revisões sem critério.

## 27.10 RI-VC-10

Hash ou mecanismo equivalente de integridade deve ser suportado no modelo.

---

## 28. Decisões arquiteturais implícitas neste documento

Este documento fixa as seguintes decisões:

1. a publicação tem histórico autoritativo explícito;
2. revisão histórica é imutável;
3. restauração é criadora de nova revisão, não apagadora do passado;
4. o sistema distingue revisão de evento;
5. existe separação entre estado atual da publicação e memória histórica;
6. a última revisão publicada deve ser identificável;
7. o modelo aceita implementação progressiva sem perder coerência.

---

## 29. Riscos que este documento evita

### 29.1 Perda de histórico

Evita que versões antigas desapareçam ao salvar novo conteúdo.

### 29.2 Restauração destrutiva

Evita “rollback” que apaga o meio da história.

### 29.3 Confusão entre conteúdo atual e conteúdo publicado

Evita não saber qual versão foi ao ar.

### 29.4 Auditoria pobre

Evita que alterações relevantes fiquem sem autoria e sem explicação.

### 29.5 QA fraco

Evita homologação sem rastrear o que mudou entre versões.

### 29.6 UX enganosa

Evita que o painel trate restauração como viagem no tempo destrutiva.

---

## 30. Critérios de aceite deste documento

Este documento será considerado aceito quando:

* representar claramente a lógica de revisão/versionamento;
* distinguir publicação viva de revisão histórica;
* explicar restauração de forma não destrutiva;
* definir o papel de snapshot, autoria, encadeamento e integridade;
* dialogar com os documentos de conteúdo, estados, UX, testes e decisões arquiteturais;
* servir como base real para implementação progressiva do histórico editorial.

---

## 31. Conclusão executiva

O projeto William Albarello exige que o conteúdo tenha memória.

Essa memória não pode ser improvisada nem destrutiva.

O modelo correto é aquele em que:

* a `PUBLICACAO` representa o presente operacional;
* a `REVISAO_CONTEUDO` preserva versões históricas imutáveis;
* o `EVENTO_VERSIONAMENTO` explica o que aconteceu;
* a restauração cria novo presente sem apagar o passado;
* a revisão publicada permanece identificável na história editorial.

Este documento fixa essa lógica.

Ele transforma o versionamento de conteúdo de uma ideia vaga em um contrato arquitetural claro, apto a orientar backend, painel administrativo, testes, homologação e evolução futura do CMS.

---

