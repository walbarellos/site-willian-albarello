
# 019_Diagrama_ER_Entidade_Relacionamento

## 1. Identificação do documento

- **Projeto:** William Albarello
- **Diretório:** `02-Diagramas`
- **Caminho oficial:** `/home/user/Documents/Softwares/Willian Albarello/William Albarello/02-Diagramas/03-Dados_e_Persistencia/019_Diagrama_ER_Entidade_Relacionamento.md`
- **Natureza do documento:** Diagrama ER macro do sistema
- **Função sistêmica:** Formalizar o modelo entidade-relacionamento macro do projeto, conciliando a modelagem conceitual do Waterfall com a realidade do contrato de API e com a implementação técnica atualmente identificável
- **Posição no bloco:** Primeiro documento do bloco `03-Dados_e_Persistencia`
- **Dependência imediata:** `013_Modelo_de_Dados_Conceitual.md`, `014_Integracoes_e_Sistemas_Externos.md`, `016_API_Contract_Mestre.md` e backend real disponível no acervo técnico, quando houver

---

## 2. Objetivo

Este documento existe para transformar a modelagem conceitual já definida no projeto em uma **visão ER macro, legível e operável**.

Se o `013_Modelo_de_Dados_Conceitual.md` declarou **quais entidades o sistema precisa reconhecer semanticamente**, este arquivo responde a outra pergunta:

**“como essas entidades se organizam em relações persistíveis e governáveis?”**

Seu objetivo é explicitar:

- quais entidades compõem o núcleo de dados do sistema;
- quais relações são centrais para a operação pública e interna;
- onde há cardinalidade 1:1, 1:N e N:N;
- quais entidades são obrigatórias no núcleo atual;
- quais entidades são estruturais, mas podem permanecer prospectivas ou mais leves neste ciclo;
- como compatibilizar a visão documental com a API pública, a API administrativa e o backend real atualmente existente.

Este documento não fixa ainda:

- DDL final;
- tipos físicos de coluna;
- índices;
- migrations;
- estratégia final de ORM;
- engine definitiva de persistência.

Seu foco é o **ER macro soberano do sistema**.

---

## 3. Fontes de referência no Waterfall e no acervo técnico

Este documento deriva principalmente dos seguintes artefatos já consolidados:

- `01-Waterfall/01-Obrigatorios/013_Modelo_de_Dados_Conceitual.md`
- `01-Waterfall/01-Obrigatorios/014_Integracoes_e_Sistemas_Externos.md`
- `01-Waterfall/01-Obrigatorios/016_API_Contract_Mestre.md`

Também devem ser considerados como apoio:

- arquitetura geral do sistema;
- módulos, domínios e limites do software;
- diagramas já gerados de contexto, containers e backend/API;
- OpenAPI público e administrativo presentes no acervo técnico;
- backend real disponível no pacote, quando houver implementação material.

---

## 4. Premissas e limites

## 4.1 Premissas adotadas

Para a construção deste ER macro, adotam-se as seguintes premissas conservadoras:

- o sistema possui camada pública e camada administrativa;
- há persistência de páginas/áreas institucionais e de conteúdos/publicações;
- existe governança editorial mínima;
- existe taxonomia por categoria e tag;
- existe autenticação para operação interna;
- existe rastreabilidade por auditoria;
- o fluxo de contato pode exigir persistência de manifestações de interesse;
- o backend real disponível ainda está em estágio parcial/scaffold, portanto o ER não será refém do código incompleto;
- em caso de divergência entre código atual e documentação soberana, prevalece a lógica documental do projeto.

## 4.2 Limites deste documento

Este arquivo não detalha:

- nomes finais de tabelas;
- constraint SQL completa;
- convenções de indexação;
- política de partição;
- estratégia de retenção;
- schema de versionamento físico;
- tuning de banco;
- eventos assíncronos.

Seu escopo é **macroestrutural**.

## 4.3 Regra de prudência metodológica

Há uma diferença importante entre:

- **modelo conceitual soberano** do projeto; e
- **implementação real atual**, que ainda não materializa toda a riqueza da modelagem.

Por isso, este documento adota uma postura equilibrada:

- não inventa entidades sem aderência ao projeto;
- não empobrece o desenho apenas porque o backend real ainda está parcial;
- não transforma um scaffold técnico temporário em verdade arquitetural permanente.

---

## 5. Tese estrutural do ER do projeto

A tese estrutural deste ER é a seguinte:

> o sistema William Albarello deve possuir um núcleo de dados organizado em identidade institucional, estrutura pública, conteúdo/contextualização, relação/contato, operação interna e governança editorial, preservando separação entre o que é público, o que é administrativo e o que é estrutural.

Isso significa que o modelo de dados não deve nascer como:

- coleção solta de páginas;
- blog genérico sem governança;
- painel administrativo sem lastro de auditoria;
- estrutura de conteúdo sem contexto institucional;
- base técnica reduzida apenas a `users`, `posts` e `sessions`.

O ER do projeto deve refletir a identidade do sistema.

---

## 6. Estratégia de leitura do diagrama ER

Este documento trabalha em três camadas de interpretação:

### 6.1 Camada institucional e pública
Entidades que representam presença, áreas, páginas e blocos institucionais.

### 6.2 Camada editorial e relacional
Entidades que representam conteúdo, categorias, tags, publicações, revisões e contato.

### 6.3 Camada administrativa e estrutural
Entidades que representam usuários internos, perfis, permissões, sessões, auditoria, módulos e configurações.

---

## 7. Diagrama principal — ER macro do sistema

```mermaid
erDiagram

    IDENTIDADE_INSTITUCIONAL ||--o{ BLOCO_INSTITUCIONAL : possui
    AREA_PUBLICA ||--o{ PAGINA_INSTITUCIONAL : organiza
    AREA_PUBLICA ||--o{ CONTEUDO : contextualiza
    AREA_PUBLICA ||--o{ PROJETO_APRESENTADO : abriga

    CATEGORIA_CONTEUDO ||--o{ CONTEUDO : classifica
    CONTEUDO ||--o{ REVISAO_CONTEUDO : recebe
    CONTEUDO ||--o| PUBLICACAO : governa_publicacao
    CONTEUDO ||--o{ CONTEXTO_EDITORIAL : recebe
    PROJETO_APRESENTADO ||--o{ CONTEXTO_EDITORIAL : recebe

    TAG_CONTEUDO ||--o{ CONTEUDO_TAG : compoe
    CONTEUDO ||--o{ CONTEUDO_TAG : compoe

    CANAL_CONTATO ||--o{ MANIFESTACAO_INTERESSE : recebe
    TIPO_APROXIMACAO ||--o{ MANIFESTACAO_INTERESSE : enquadra

    PERFIL_INTERNO ||--o{ USUARIO_PERFIL : agrupa
    USUARIO_INTERNO ||--o{ USUARIO_PERFIL : assume

    PERFIL_INTERNO ||--o{ PERFIL_PERMISSAO : autoriza
    PERMISSAO_INTERNA ||--o{ PERFIL_PERMISSAO : compoe

    USUARIO_INTERNO ||--o{ SESSAO_INTERNA : abre
    USUARIO_INTERNO ||--o{ LOG_AUDITORIA : gera
    USUARIO_INTERNO ||--o{ REVISAO_CONTEUDO : revisa
    USUARIO_INTERNO ||--o{ PUBLICACAO : opera

    MODULO_ATIVO ||--o{ CONFIGURACAO_ESTRUTURAL : parametriza

    IDENTIDADE_INSTITUCIONAL {
        uuid id
        string nome_exibicao
        string titulo_institucional
        text resumo_institucional
        string status
        datetime created_at
        datetime updated_at
    }

    BLOCO_INSTITUCIONAL {
        uuid id
        uuid identidade_institucional_id
        string chave
        string titulo
        text conteudo
        int ordem
        string status
    }

    AREA_PUBLICA {
        uuid id
        string nome
        string slug
        text descricao
        int ordem
        string status
    }

    PAGINA_INSTITUCIONAL {
        uuid id
        uuid area_publica_id
        string chave
        string titulo
        json corpo_estruturado
        json seo
        string status
        datetime updated_at
    }

    CONTEUDO {
        uuid id
        uuid area_publica_id
        uuid categoria_conteudo_id
        string titulo
        string slug
        text resumo
        text corpo
        string tipo
        string status_editorial
        datetime created_at
        datetime updated_at
    }

    CATEGORIA_CONTEUDO {
        uuid id
        string nome
        string slug
        text descricao
        int ordem
        string status
    }

    TAG_CONTEUDO {
        uuid id
        string nome
        string slug
        text descricao
        string status
    }

    CONTEUDO_TAG {
        uuid id
        uuid conteudo_id
        uuid tag_conteudo_id
        datetime created_at
    }

    PROJETO_APRESENTADO {
        uuid id
        uuid area_publica_id
        string nome
        string slug
        text descricao
        string status
        int ordem
    }

    CONTEXTO_EDITORIAL {
        uuid id
        uuid conteudo_id
        uuid projeto_apresentado_id
        string tipo_contexto
        text texto_contextual
        int ordem
        string status
    }

    PUBLICACAO {
        uuid id
        uuid conteudo_id
        uuid operador_publicacao_id
        string status
        datetime publicado_em
        datetime despublicado_em
        text observacoes
    }

    REVISAO_CONTEUDO {
        uuid id
        uuid conteudo_id
        uuid usuario_interno_id
        string versao
        text resumo_alteracao
        text snapshot_resumido
        datetime created_at
    }

    CANAL_CONTATO {
        uuid id
        string tipo
        string rotulo_publico
        string destino
        text instrucao_uso
        int ordem
        string status
    }

    TIPO_APROXIMACAO {
        uuid id
        string nome
        text descricao
        int prioridade
        string status
    }

    MANIFESTACAO_INTERESSE {
        uuid id
        uuid canal_contato_id
        uuid tipo_aproximacao_id
        string nome
        string email
        string assunto
        text mensagem
        string origem
        string status_tratamento
        datetime created_at
    }

    USUARIO_INTERNO {
        uuid id
        string nome
        string email
        string senha_hash
        string status
        datetime ultimo_acesso_em
        datetime created_at
    }

    PERFIL_INTERNO {
        uuid id
        string nome
        text descricao
        string escopo
        string status
    }

    USUARIO_PERFIL {
        uuid id
        uuid usuario_interno_id
        uuid perfil_interno_id
        datetime created_at
    }

    PERMISSAO_INTERNA {
        uuid id
        string recurso
        string acao
        text descricao
        string status
    }

    PERFIL_PERMISSAO {
        uuid id
        uuid perfil_interno_id
        uuid permissao_interna_id
        datetime created_at
    }

    SESSAO_INTERNA {
        uuid id
        uuid usuario_interno_id
        string session_token_hash
        string ip
        string user_agent
        datetime expira_em
        datetime created_at
        datetime revogada_em
    }

    LOG_AUDITORIA {
        uuid id
        uuid usuario_interno_id
        string event_type
        string entity_type
        uuid entity_id
        json payload_resumido
        datetime created_at
    }

    MODULO_ATIVO {
        uuid id
        string nome
        string chave
        string status
        datetime ativado_em
    }

    CONFIGURACAO_ESTRUTURAL {
        uuid id
        uuid modulo_ativo_id
        string chave
        text valor
        string escopo
        string status
        datetime updated_at
    }
````

---

## 8. Leitura executiva do diagrama

## 8.1 Núcleo institucional

O sistema reconhece um núcleo de identidade representado por:

* `IDENTIDADE_INSTITUCIONAL`
* `BLOCO_INSTITUCIONAL`

A lógica aqui é simples:

* a identidade institucional representa a camada-mãe de presença;
* os blocos institucionais representam seções, trechos, painéis ou componentes narrativos associados a essa identidade.

Essa relação é naturalmente **1:N**.

## 8.2 Estrutura pública

A estrutura pública se organiza em torno de:

* `AREA_PUBLICA`
* `PAGINA_INSTITUCIONAL`

Uma área pública agrupa e contextualiza páginas e conteúdos.
Uma página institucional representa uma página estável, como home, sobre ou expertise.

A relação principal aqui também é **1:N**.

## 8.3 Núcleo editorial

O núcleo editorial é composto por:

* `CONTEUDO`
* `CATEGORIA_CONTEUDO`
* `TAG_CONTEUDO`
* `CONTEUDO_TAG`
* `CONTEXTO_EDITORIAL`
* `PUBLICACAO`
* `REVISAO_CONTEUDO`

Aqui está o coração do sistema.

### Leitura principal

* uma categoria classifica vários conteúdos;
* um conteúdo pode possuir várias tags;
* um conteúdo pode receber várias revisões;
* um conteúdo pode ter governança de publicação própria;
* um conteúdo pode receber camadas de contexto editorial;
* um projeto apresentado também pode receber contexto editorial.

---

## 9. Cardinalidades principais e sua justificativa

## 9.1 `IDENTIDADE_INSTITUCIONAL` 1:N `BLOCO_INSTITUCIONAL`

**Justificativa funcional:**
a identidade pública do projeto se desdobra em vários blocos institucionais, mas cada bloco pertence a uma identidade institucional principal.

---

## 9.2 `AREA_PUBLICA` 1:N `PAGINA_INSTITUCIONAL`

**Justificativa funcional:**
uma área pública pode conter mais de uma página institucional, enquanto cada página pertence a uma área contextual dominante.

---

## 9.3 `AREA_PUBLICA` 1:N `CONTEUDO`

**Justificativa funcional:**
o projeto exige que o conteúdo não exista órfão de contexto. Por isso, o conteúdo deve estar ligado a uma área pública ou eixo correspondente.

---

## 9.4 `CATEGORIA_CONTEUDO` 1:N `CONTEUDO`

**Justificativa funcional:**
o contrato administrativo identificado hoje trabalha, em nível macro, com um `categoryId` singular por item editorial. Portanto, neste ciclo, a cardinalidade principal é tratada como **uma categoria para muitos conteúdos**.

**Observação importante:**
o modelo conceitual anterior admitia possibilidade de N:N. Esta ampliação continua válida como possibilidade futura, mas não é necessária como desenho macro dominante do ciclo atual.

---

## 9.5 `CONTEUDO` N:N `TAG_CONTEUDO` via `CONTEUDO_TAG`

**Justificativa funcional:**
um conteúdo pode receber múltiplas tags, e uma tag pode ser aplicada a múltiplos conteúdos.
Essa é uma relação N:N clássica, materializada por entidade associativa.

---

## 9.6 `CONTEUDO` 1:N `REVISAO_CONTEUDO`

**Justificativa funcional:**
um mesmo conteúdo pode passar por múltiplas revisões ao longo do tempo, preservando memória editorial e auditabilidade mínima.

---

## 9.7 `CONTEUDO` 1:0..1 `PUBLICACAO`

**Justificativa funcional:**
conceitualmente, o conteúdo e sua governança de publicação são coisas distintas:

* conteúdo é o objeto editorial;
* publicação é o seu estado de exposição pública.

No ciclo atual, essa separação é útil para clareza arquitetural.

**Observação de implementação:**
na implementação real, é admissível que essa distinção seja colapsada temporariamente em uma única tabela/coleção de publicações com status. O ER, porém, preserva a separação semântica.

---

## 9.8 `CANAL_CONTATO` 1:N `MANIFESTACAO_INTERESSE`

**Justificativa funcional:**
um canal pode receber várias manifestações; cada manifestação nasce a partir de um canal dominante de entrada.

---

## 9.9 `TIPO_APROXIMACAO` 1:N `MANIFESTACAO_INTERESSE`

**Justificativa funcional:**
o tipo de aproximação qualifica a manifestação sem inflar a entidade principal.
Exemplos: contato comercial, convite, consulta, proposta, parceria.

---

## 9.10 `USUARIO_INTERNO` N:N `PERFIL_INTERNO` via `USUARIO_PERFIL`

**Justificativa funcional:**
um usuário pode acumular papéis; um perfil pode ser atribuído a vários usuários.
Essa relação evita rigidez prematura.

---

## 9.11 `PERFIL_INTERNO` N:N `PERMISSAO_INTERNA` via `PERFIL_PERMISSAO`

**Justificativa funcional:**
a governança de acesso precisa ser montada por composição, não por codificação rígida no perfil.

---

## 9.12 `USUARIO_INTERNO` 1:N `SESSAO_INTERNA`

**Justificativa funcional:**
um usuário pode abrir várias sessões ao longo do tempo, simultâneas ou históricas, conforme a política adotada.

---

## 9.13 `USUARIO_INTERNO` 1:N `LOG_AUDITORIA`

**Justificativa funcional:**
ações administrativas precisam ser rastreáveis.
Cada log aponta para um agente principal responsável.

---

## 9.14 `MODULO_ATIVO` 1:N `CONFIGURACAO_ESTRUTURAL`

**Justificativa funcional:**
as configurações podem ser escopadas por módulo, preservando clareza de ativação e governança de evolução.

---

## 10. Entidades centrais do ciclo atual

No estágio atual do projeto, as entidades mais centrais para implementação e rastreabilidade são:

* `AREA_PUBLICA`
* `PAGINA_INSTITUCIONAL`
* `CONTEUDO`
* `CATEGORIA_CONTEUDO`
* `TAG_CONTEUDO`
* `CONTEUDO_TAG`
* `USUARIO_INTERNO`
* `PERFIL_INTERNO`
* `PERMISSAO_INTERNA`
* `SESSAO_INTERNA`
* `LOG_AUDITORIA`
* `MANIFESTACAO_INTERESSE`

Estas entidades sustentam o mínimo necessário para:

* presença institucional;
* publicação editorial;
* taxonomia;
* operação interna;
* contato;
* auditoria.

---

## 11. Entidades de apoio e expansão controlada

As entidades abaixo são importantes, mas podem ser implementadas de forma progressiva:

* `IDENTIDADE_INSTITUCIONAL`
* `BLOCO_INSTITUCIONAL`
* `PROJETO_APRESENTADO`
* `CONTEXTO_EDITORIAL`
* `PUBLICACAO` como entidade separada
* `REVISAO_CONTEUDO` com snapshot mais rico
* `MODULO_ATIVO`
* `CONFIGURACAO_ESTRUTURAL`

Essas entidades não são “supérfluas”; apenas podem amadurecer por ciclos.

---

## 12. Compatibilização com o contrato de API identificado

Com base no acervo técnico já disponível, este ER macro conversa bem com a API identificada:

### 12.1 API pública

A API pública já aponta para necessidades de persistência ligadas a:

* páginas institucionais;
* publicações;
* filtros por categoria;
* filtros por tag;
* detalhe por slug;
* envio de contato.

Isso reforça diretamente as entidades:

* `PAGINA_INSTITUCIONAL`
* `CONTEUDO`
* `CATEGORIA_CONTEUDO`
* `TAG_CONTEUDO`
* `CONTEUDO_TAG`
* `MANIFESTACAO_INTERESSE`

### 12.2 API administrativa

A API administrativa já aponta para necessidades de persistência ligadas a:

* login/sessão;
* dashboard operacional;
* CRUD de publicações;
* atualização de status editorial;
* CRUD de categorias;
* CRUD de tags;
* listagem de logs de auditoria.

Isso reforça diretamente as entidades:

* `USUARIO_INTERNO`
* `SESSAO_INTERNA`
* `CONTEUDO`
* `PUBLICACAO`
* `CATEGORIA_CONTEUDO`
* `TAG_CONTEUDO`
* `LOG_AUDITORIA`

---

## 13. Compatibilização com o backend real atual

O backend real identificado no acervo técnico ainda é parcial.
Ele materializa apenas uma pequena parte do desenho completo, especialmente:

* health check;
* login administrativo simplificado;
* criação de cookie/sessão em modo placeholder.

Portanto, este documento **não deve ser lido como espelho do scaffold atual**, mas como:

* ER macro do sistema pretendido;
* compatível com a documentação soberana;
* compatível com os contratos de API mais maduros do acervo;
* pronto para orientar a persistência real quando a implementação for aprofundada.

---

## 14. Regras macro de integridade do modelo

## 14.1 Regra RI-01

Nenhum conteúdo editorial relevante deve existir sem área pública ou contexto equivalente.

## 14.2 Regra RI-02

Toda manifestação persistida deve possuir origem relacional reconhecível.

## 14.3 Regra RI-03

Toda operação administrativa sensível deve ser potencialmente auditável.

## 14.4 Regra RI-04

Sessão interna deve sempre apontar para usuário interno válido.

## 14.5 Regra RI-05

Tag N:N não deve ser modelada por arrays semânticos opacos quando o ciclo exigir governança mais madura.

## 14.6 Regra RI-06

O status editorial não deve destruir o objeto conteúdo; deve governar sua exposição.

## 14.7 Regra RI-07

Permissões devem ser atribuídas por composição controlada, não por improviso no código.

---

## 15. Decisões arquiteturais implícitas neste ER

Este diagrama fixa, em nível macro, as seguintes decisões:

1. o sistema não será reduzido a “posts e usuários”;
2. páginas institucionais e conteúdo editorial são próximos, mas não idênticos;
3. taxonomia por categoria e tag é parte estrutural do domínio;
4. contato e aproximação não devem ficar fora da modelagem;
5. operação interna exige perfis, permissões, sessões e auditoria;
6. publicação e revisão possuem valor arquitetural próprio;
7. há espaço controlado para expansão modular e configuracional.

---

## 16. Riscos que este ER evita

### 16.1 Empobrecimento do domínio

Evita reduzir o projeto a um CMS genérico sem identidade institucional.

### 16.2 Mistura indevida entre público e administrativo

Evita que usuários, sessões e auditoria se confundam com o domínio público.

### 16.3 Colapso da governança editorial

Evita tratar publicação, revisão e contexto como detalhes descartáveis.

### 16.4 Rigidez excessiva logo no início

Evita forçar modelagem física hipercomplexa antes da hora.

### 16.5 Dependência do scaffold técnico atual

Evita que a implementação parcial rebaixe a ambição correta do sistema.

---

## 17. Critérios de aceite deste documento

Este documento será considerado aceito quando:

* apresentar um diagrama ER macro coerente com o projeto;
* explicitar entidades principais e relações essenciais;
* indicar cardinalidades centrais com justificativa funcional;
* refletir o modelo conceitual já consolidado;
* dialogar com a API pública e administrativa disponível;
* reconhecer honestamente a parcialidade do backend real atual;
* servir como base para os próximos documentos de dados e persistência.

---

## 18. Conclusão executiva

O projeto William Albarello exige um modelo ER que vá além de um blog simples e além de um painel administrativo improvisado.

O núcleo correto do sistema combina:

* identidade institucional;
* áreas e páginas públicas;
* conteúdo e taxonomia;
* publicação e revisão;
* contato e aproximação;
* usuários internos, perfis, permissões, sessões e auditoria;
* capacidade futura de configuração e ativação modular.

Este documento fixa essa anatomia em nível macro.

Ele não encerra a modelagem de dados física, mas estabelece a **estrutura relacional soberana** sobre a qual os próximos documentos do bloco `03-Dados_e_Persistencia` deverão se apoiar.

---

