
# 022_Diagrama_de_Estados_da_Postagem

## 1. Identificação do documento

- **Projeto:** William Albarello
- **Diretório:** `02-Diagramas`
- **Caminho oficial:** `/home/user/Documents/Softwares/Willian Albarello/William Albarello/02-Diagramas/03-Dados_e_Persistencia/022_Diagrama_de_Estados_da_Postagem.md`
- **Natureza do documento:** Diagrama de estados do ciclo de vida editorial da postagem
- **Função sistêmica:** Representar os estados possíveis da postagem, suas transições válidas, gatilhos de mudança, regras de passagem, restrições de exposição pública e compatibilização entre o modelo editorial expandido e o backend/API atualmente identificados
- **Posição na trilha:** Quarto documento do bloco `03-Dados_e_Persistencia`
- **Dependências principais:** `012_Modulos_Dominios_e_Limites_do_Software.md`, `013_Modelo_de_Dados_Conceitual.md`, `018_Plano_de_Testes_Homologacao_e_Qualidade.md`, `021_Criterios_de_Aceite_Gerais.md`, `020_Diagrama_do_Modelo_de_Dados_do_Conteudo.md`, frontend e backend reais disponíveis no acervo técnico

---

## 2. Objetivo

Este documento existe para formalizar o **ciclo de vida editorial da postagem** no projeto William Albarello.

Se o documento `020_Diagrama_do_Modelo_de_Dados_do_Conteudo.md` fixou a anatomia de dados da publicação, este arquivo responde a outra pergunta essencial:

> por quais estados a postagem pode passar, em que condições ela muda de estado, e o que cada estado significa operacionalmente?

Seu objetivo é explicitar:

- os estados editoriais possíveis da postagem;
- as transições válidas entre esses estados;
- os gatilhos que disparam essas transições;
- as pré-condições mínimas para publicar;
- as diferenças entre o **workflow editorial desejado** e o **recorte já comprovado no contrato/API atual**;
- o que é estado editorial e o que é apenas atributo operacional;
- quais regras devem ser testadas e aceitas antes de considerar o fluxo correto.

Este documento não substitui:

- o modelo de dados físico;
- a matriz de permissões;
- o fluxo completo de publicação end-to-end;
- o versionamento aprofundado de conteúdo;
- a política detalhada de agendamento temporal.

Seu foco é a **máquina de estados editorial soberana**.

---

## 3. Fontes de referência

Este documento deriva principalmente das seguintes bases do projeto:

- `012_Modulos_Dominios_e_Limites_do_Software.md`
- `013_Modelo_de_Dados_Conceitual.md`
- `018_Plano_de_Testes_Homologacao_e_Qualidade.md`
- `021_Criterios_de_Aceite_Gerais.md`

Também dialoga diretamente com:

- `020_Diagrama_do_Modelo_de_Dados_do_Conteudo.md`
- os diagramas já gerados de publicação e edição de conteúdo;
- os contratos da API administrativa e pública;
- a estratégia editorial e de governança do acervo técnico;
- os requisitos funcionais do painel;
- o modelo de dados técnico do acervo `personal-site`.

---

## 4. Premissas e limites

## 4.1 Premissas adotadas

Para este documento, adotam-se as seguintes premissas:

- existe um CMS/painel administrativo com CRUD editorial;
- a postagem nasce como entidade editável e só depois pode ser exposta publicamente;
- o estado editorial governa a visibilidade e o comportamento operacional do conteúdo;
- o modelo expandido do projeto reconhece estados como `draft`, `review`, `ready_to_publish`, `scheduled`, `published` e `archived`;
- o contrato administrativo atualmente comprovado pela API já materializa, no mínimo, `draft`, `published` e `archived`;
- `deleted_at` é tratado como exclusão lógica/soft delete, e não como estado editorial principal;
- o fluxo real precisa ser desenhado de forma que aceite **compatibilidade com o presente** sem empobrecer a arquitetura futura.

## 4.2 Limites deste documento

Este arquivo não define:

- cron job final de agendamento;
- política exata de timezone para publicação agendada;
- política final de rollback de conteúdo;
- diferenciação entre revisão leve e revisão formal por múltiplos atores;
- fila/evento assíncrono obrigatório de publicação;
- moderação editorial multiaprovador enterprise.

Seu papel é fixar a **máquina de estados correta do domínio editorial**.

## 4.3 Regra de prudência arquitetural

Há uma diferença importante entre:

1. o **workflow editorial desejado e comprovado documentalmente**; e
2. o **recorte operacional já exposto no backend/API atual**.

Por isso, este documento trabalha com dois níveis ao mesmo tempo:

- **nível A — máquina editorial soberana expandida**
- **nível B — subconjunto já operacionalmente comprovado**

Isso evita dois erros:

- desenhar pouco demais só porque o scaffold atual é menor;
- desenhar demais como se tudo já estivesse implementado.

---

## 5. Tese central do ciclo editorial

A tese deste documento é a seguinte:

> uma postagem não deve sair de “texto em edição” diretamente para “conteúdo público” sem governança mínima; o estado editorial existe justamente para separar elaboração, revisão, prontidão, exposição e retirada de circulação.

Em outras palavras:

- `draft` não é igual a `review`;
- `review` não é igual a `published`;
- `scheduled` não é apenas um campo de data;
- `archived` não é exclusão;
- `deleted` não é estado editorial principal.

O ciclo editorial precisa preservar inteligibilidade operacional.

---

## 6. Estratégia de leitura do modelo de estados

Este documento propõe leitura em duas camadas.

## 6.1 Camada 1 — workflow editorial soberano expandido

Estados reconhecidos como arquiteturalmente válidos:

- `draft`
- `review`
- `ready_to_publish`
- `scheduled`
- `published`
- `archived`

## 6.2 Camada 2 — workflow mínimo já comprovado no contrato/API atual

Estados já claramente sustentados pelos contratos e artefatos técnicos atuais:

- `draft`
- `published`
- `archived`

## 6.3 Conciliação entre as camadas

A leitura correta do projeto é:

- o **modelo soberano** já deve prever `review`, `ready_to_publish` e `scheduled`;
- a **implementação inicial** pode operar com um subconjunto menor;
- o desenho da máquina de estados precisa aceitar evolução futura sem quebrar compatibilidade.

---

## 7. Estados reconhecidos no ciclo editorial

## 7.1 `draft`

Estado inicial e dominante de trabalho.

Representa postagem:

- em elaboração;
- incompleta;
- ainda não pronta para validação final;
- não visível publicamente.

É o estado natural de criação e edição contínua.

## 7.2 `review`

Estado de revisão.

Representa postagem:

- com conteúdo mínimo já preenchido;
- em verificação técnica/editorial/SEO;
- ainda não exposta ao público;
- dependente de conferência antes de avançar.

No ciclo inicial, esse estado pode ser operacionalmente simplificado, mas **deve existir no modelo**.

## 7.3 `ready_to_publish`

Estado de prontidão editorial.

Representa postagem:

- revisada;
- validada tecnicamente;
- com SEO mínimo consistente;
- aguardando aprovação final ou ação de publicação.

Esse estado separa “em revisão” de “pronta para ir ao ar”.

## 7.4 `scheduled`

Estado de publicação agendada.

Representa postagem:

- pronta para publicação;
- já autorizada;
- vinculada a uma data/hora futura de exposição;
- ainda não visível publicamente até o momento programado.

Esse estado é importante porque “pronta” e “já pública” não são a mesma coisa.

## 7.5 `published`

Estado de exposição pública válida.

Representa postagem:

- publicamente disponível;
- elegível à indexação;
- compatível com listagens públicas;
- sujeita a atualização, reedição ou arquivamento.

Este é o estado de produção/publicação efetiva.

## 7.6 `archived`

Estado de preservação sem protagonismo público corrente.

Representa postagem:

- retirada da circulação principal;
- fora das listagens públicas dominantes;
- preservada internamente para histórico, eventual reutilização ou rastreabilidade.

Arquivar não significa destruir.

---

## 8. O que **não** é estado editorial principal

Para evitar confusão, os itens abaixo **não** devem ser tratados como estados editoriais soberanos, embora influenciem o comportamento do conteúdo.

## 8.1 `deleted` / `deleted_at`

Isso representa:

- exclusão lógica;
- remoção operacional;
- soft delete.

Não é etapa do ciclo editorial semântico.  
É mecanismo de governança de persistência.

## 8.2 `preview`

Preview é capacidade de visualização, não estado editorial.

## 8.3 `updated`

Atualização é evento/resultado de edição, não estado.

## 8.4 `invalid`

Inválido descreve falha de regra ou de preenchimento, não estado persistível dominante do ciclo editorial.

---

## 9. Diagrama principal — máquina de estados editorial soberana

```mermaid
stateDiagram-v2
    [*] --> Draft: criar postagem

    Draft --> Draft: salvar rascunho / editar
    Draft --> Review: enviar para revisão
    Draft --> Archived: arquivar sem publicar
    Draft --> Deleted: soft delete operacional

    Review --> Draft: solicitar ajustes / devolver edição
    Review --> ReadyToPublish: revisão técnica e SEO concluídas
    Review --> Archived: cancelar pauta / arquivar
    Review --> Deleted: soft delete operacional

    ReadyToPublish --> Draft: reabrir edição
    ReadyToPublish --> Scheduled: definir data futura
    ReadyToPublish --> Published: publicar imediatamente
    ReadyToPublish --> Archived: arquivar antes de publicar
    ReadyToPublish --> Deleted: soft delete operacional

    Scheduled --> Draft: reabrir edição antes da publicação
    Scheduled --> ReadyToPublish: remover agendamento e manter pronto
    Scheduled --> Published: atingir data/hora programada
    Scheduled --> Archived: cancelar publicação futura
    Scheduled --> Deleted: soft delete operacional

    Published --> Draft: reabrir para retrabalho controlado
    Published --> Archived: retirar de circulação
    Published --> Deleted: soft delete operacional

    Archived --> Draft: reativar para nova edição
    Archived --> ReadyToPublish: reativar conteúdo já validado
    Archived --> Deleted: soft delete operacional

    state Deleted {
        [*] --> SoftDeleted
    }
````

---

## 10. Leitura executiva do diagrama

A máquina de estados mostra uma lógica editorial madura:

1. toda postagem nasce em `Draft`;
2. pode evoluir para `Review`;
3. depois pode alcançar `ReadyToPublish`;
4. a partir daí pode:

   * publicar imediatamente; ou
   * entrar em `Scheduled`;
5. quando publicada, pode ser arquivada;
6. estados anteriores podem reabrir a edição quando necessário;
7. exclusão lógica existe como saída operacional, mas não é a espinha dorsal editorial.

Esse desenho é importante porque impede o colapso conceitual entre:

* criar;
* revisar;
* aprovar;
* agendar;
* publicar;
* arquivar.

---

## 11. Subconjunto mínimo atualmente comprovado

Embora a máquina soberana acima seja a referência correta, o recorte mínimo já comprovado pelo contrato/API atual é menor.

Esse subconjunto pode ser representado assim:

```mermaid
stateDiagram-v2
    [*] --> Draft: criar
    Draft --> Draft: salvar alterações
    Draft --> Published: publicar
    Draft --> Archived: arquivar

    Published --> Draft: reabrir edição controlada
    Published --> Archived: arquivar

    Archived --> Draft: reativar para edição
```

---

## 12. Conciliação entre modelo expandido e implementação atual

A leitura correta do projeto é a seguinte:

## 12.1 O que já está comprovado hoje

O contrato técnico atual sustenta claramente:

* `draft`
* `published`
* `archived`

Também sustenta regras como:

* publicar registra `published_at` quando necessário;
* conteúdo `archived` não aparece no público;
* público só exibe conteúdo `published`.

## 12.2 O que já está comprovado documentalmente, mesmo que ainda não totalmente implementado

Os artefatos editoriais e arquiteturais já comprovam a legitimidade de:

* `review`
* `ready_to_publish`
* `scheduled`

## 12.3 Decisão arquitetural resultante

O projeto deve adotar a seguinte interpretação:

* **máquina soberana do domínio:** expandida;
* **subconjunto mínimo inicial de implementação:** compatível com o contrato atual;
* **evolução posterior:** sem ruptura conceitual.

---

## 13. Descrição funcional das transições principais

## 13.1 `Draft -> Draft`

**Gatilho:** salvar rascunho, autosave ou edição contínua.
**Sentido:** manter o conteúdo em elaboração.

## 13.2 `Draft -> Review`

**Gatilho:** envio para revisão.
**Pré-condição:** conteúdo mínimo preenchido.
**Sentido:** sair da fase livre de escrita e entrar em verificação.

## 13.3 `Review -> Draft`

**Gatilho:** revisão solicita ajustes.
**Pré-condição:** foram identificadas lacunas de conteúdo, clareza, taxonomia ou SEO.
**Sentido:** devolver a peça à edição.

## 13.4 `Review -> ReadyToPublish`

**Gatilho:** aprovação técnica/editorial.
**Pré-condição:** revisão concluída, SEO mínimo coerente, estrutura aceita.
**Sentido:** peça pronta para publicação, mas ainda não publicada.

## 13.5 `ReadyToPublish -> Published`

**Gatilho:** publicar agora.
**Pré-condição:** aprovação final e campos mínimos válidos.
**Sentido:** tornar a postagem pública imediatamente.

## 13.6 `ReadyToPublish -> Scheduled`

**Gatilho:** definir data/hora futura.
**Pré-condição:** peça pronta e data válida.
**Sentido:** preservar prontidão sem liberar exposição antes do momento certo.

## 13.7 `Scheduled -> Published`

**Gatilho:** chegada da data/hora agendada.
**Pré-condição:** agendamento ainda válido, peça não revogada, condições mínimas mantidas.
**Sentido:** publicação automática efetiva.

## 13.8 `Published -> Archived`

**Gatilho:** retirada de circulação.
**Pré-condição:** decisão editorial ou obsolescência estratégica.
**Sentido:** preservar histórico e remover protagonismo público.

## 13.9 `Archived -> Draft`

**Gatilho:** reativação para retrabalho.
**Pré-condição:** decisão editorial de reaproveitamento.
**Sentido:** retornar a peça ao ciclo vivo de edição.

## 13.10 `Published -> Draft`

**Gatilho:** reabertura controlada de edição.
**Pré-condição:** política operacional permite edição posterior.
**Sentido:** conteúdo já público volta a um estado de trabalho interno antes de eventual republicação.

---

## 14. Regras de passagem por estado

## 14.1 Regras para sair de `Draft`

Uma postagem só deve sair de `Draft` quando tiver, no mínimo:

* título coerente;
* slug válido ou gerável;
* resumo mínimo;
* corpo suficientemente preenchido;
* autoria definida;
* estrutura editorial inteligível.

## 14.2 Regras para sair de `Review`

Uma postagem só deve sair de `Review` quando tiver:

* revisão técnica/editorial concluída;
* taxonomia aceitável;
* metadados SEO mínimos validados;
* ausência de ambiguidade relevante;
* legibilidade suficiente.

## 14.3 Regras para sair de `ReadyToPublish`

Uma postagem só deve ir para `Published` ou `Scheduled` quando tiver:

* categoria válida para publicação;
* tags coerentes, quando aplicável;
* metadata SEO mínima;
* imagem/fallback visual quando exigido pela experiência;
* checklist final atendido;
* autorização final do responsável.

## 14.4 Regras para permanecer em `Scheduled`

Uma postagem agendada deve manter:

* integridade do conteúdo;
* validade da data programada;
* autorização não revogada;
* compatibilidade com a estratégia vigente.

## 14.5 Regras para `Published`

Uma postagem publicada deve:

* possuir `published_at`;
* ser elegível à listagem pública;
* ser retornada apenas se o status público permitir;
* refletir metadata e estrutura indexável coerentes.

## 14.6 Regras para `Archived`

Uma postagem arquivada:

* não deve aparecer nas listagens públicas principais;
* pode continuar rastreável internamente;
* não deve ser tratada como apagada;
* pode ser reativada sob decisão editorial.

---

## 15. Guardas de validação por transição

## 15.1 Guarda G-01 — valores de estado válidos

O sistema só deve aceitar estados previstos pela máquina aplicável ao ciclo.

## 15.2 Guarda G-02 — `published_at` ao publicar

Ao entrar em `Published`, o sistema deve registrar `published_at` quando inexistente.

## 15.3 Guarda G-03 — categoria obrigatória para publicação

Categoria pode ser opcional no rascunho, mas tende a ser obrigatória para publicar.

## 15.4 Guarda G-04 — visibilidade pública restrita

A camada pública não deve expor conteúdo fora de `Published`, salvo preview autenticado e controlado.

## 15.5 Guarda G-05 — agendamento coerente

`Scheduled` exige data/hora futura válida.

## 15.6 Guarda G-06 — arquivamento sem perda histórica

Arquivar não deve destruir a postagem nem seu histórico.

## 15.7 Guarda G-07 — exclusão lógica não é publicação

`deleted_at` não deve ser confundido com estado editorial.

---

## 16. Efeitos operacionais de cada estado

## 16.1 `Draft`

* editável;
* não público;
* pode ser incompleto;
* não indexável;
* ideal para criação e retrabalho.

## 16.2 `Review`

* editável sob fluxo controlado;
* não público;
* foco em conferência e ajuste;
* pode retornar a `Draft`.

## 16.3 `ReadyToPublish`

* internamente pronto;
* ainda não público;
* pode seguir para publicação imediata ou agendamento;
* ideal para checklist final.

## 16.4 `Scheduled`

* não público até o horário programado;
* já autorizado;
* exige mecanismo de ativação temporal;
* pode ser cancelado ou reaberto.

## 16.5 `Published`

* público;
* indexável;
* aparece nas listagens e detalhes;
* conta para métricas de acervo ativo;
* pode ser arquivado ou reaberto.

## 16.6 `Archived`

* interno/histórico;
* fora da circulação pública dominante;
* preserva rastreabilidade;
* apto a reativação.

---

## 17. Relação entre estado editorial e modelo de dados

Este diagrama conversa diretamente com o documento `020_Diagrama_do_Modelo_de_Dados_do_Conteudo.md`.

Campos diretamente impactados pela máquina de estados:

* `status_editorial` / `status`
* `published_at`
* `archived_at`
* `updated_at`
* `deleted_at`
* histórico de status editorial
* revisão editorial

Leitura correta:

* `status` guarda o estado atual;
* `published_at` e `archived_at` registram marcos temporais;
* histórico de status registra a trajetória;
* revisão editorial sustenta a passagem madura entre estados.

---

## 18. Compatibilização com frontend, backend e API

## 18.1 Frontend administrativo

O painel precisa refletir:

* estado atual da peça;
* ações disponíveis conforme o estado;
* mensagens de bloqueio quando a transição não for válida;
* sinalização clara entre salvar rascunho, enviar para revisão, publicar, agendar e arquivar.

## 18.2 Backend/API atual

O backend/API já comprovam, no mínimo:

* criação/edição em `draft`;
* atualização de status editorial;
* publicação com registro de `published_at`;
* arquivamento com exclusão da superfície pública.

## 18.3 Evolução esperada

O backend deve poder evoluir para suportar explicitamente:

* `review`;
* `ready_to_publish`;
* `scheduled`;

sem precisar reinventar o domínio.

---

## 19. Relação com testes e critérios de aceite

O plano de testes e os critérios gerais de aceite exigem que a passagem de estado não seja tratada por impressão subjetiva.

Por isso, o fluxo editorial deve ser validado com cenários como:

* criação em `draft`;
* atualização persistida sem sair de `draft`;
* `draft -> published`;
* `published -> archived`;
* bloqueio de publicação com campos mínimos inválidos;
* ocultação pública de conteúdos não publicados;
* reativação controlada de conteúdo arquivado;
* quando implementado, `draft -> review -> ready_to_publish -> published`;
* quando implementado, `ready_to_publish -> scheduled -> published`.

---

## 20. Regras macro de integridade do estado editorial

## 20.1 RI-ST-01

Estado editorial deve aceitar apenas valores previstos pela política vigente do ciclo.

## 20.2 RI-ST-02

Conteúdo público só pode ser exposto em `Published`.

## 20.3 RI-ST-03

Transição para `Published` exige campos mínimos válidos.

## 20.4 RI-ST-04

`published_at` deve ser coerente com a entrada em `Published`.

## 20.5 RI-ST-05

`archived` remove protagonismo público, mas não apaga histórico.

## 20.6 RI-ST-06

`deleted_at` não substitui estado editorial.

## 20.7 RI-ST-07

Quando houver `Scheduled`, a publicação automática deve respeitar o horário programado e o estado ainda válido da peça.

## 20.8 RI-ST-08

Transições inválidas devem ser bloqueadas pela API e refletidas com clareza no painel.

---

## 21. Decisões arquiteturais implícitas neste documento

Este documento fixa as seguintes decisões:

1. a postagem possui ciclo de vida editorial explícito;
2. publicar não é apenas trocar um campo sem governança;
3. o modelo expandido reconhece revisão, prontidão e agendamento;
4. o contrato inicial pode operar com subconjunto menor sem invalidar a arquitetura;
5. conteúdo arquivado continua existindo;
6. exclusão lógica é governança de persistência, não etapa do fluxo editorial;
7. a máquina de estados deve orientar frontend, API, testes e critérios de aceite.

---

## 22. Riscos que este documento evita

### 22.1 Publicação prematura

Evita que qualquer rascunho vire conteúdo público sem gate mínimo.

### 22.2 Colapso entre revisão e publicação

Evita confundir “em conferência” com “pronto” ou “já no ar”.

### 22.3 Agendamento improvisado

Evita tratar data futura como detalhe solto, sem estado próprio.

### 22.4 Arquivamento confundido com exclusão

Evita perder histórico ou governança por má modelagem semântica.

### 22.5 Divergência entre painel, API e público

Evita que cada camada interprete o status de forma diferente.

### 22.6 Testes insuficientes

Evita que o fluxo editorial seja aceito sem cenários objetivos de validação.

---

## 23. Critérios de aceite deste documento

Este documento será considerado aceito quando:

* representar claramente os estados editoriais da postagem;
* distinguir o modelo soberano expandido do subconjunto já comprovado;
* explicitar transições válidas e seus gatilhos;
* declarar guardas mínimas para publicar, agendar e arquivar;
* alinhar o fluxo aos contratos, testes e critérios de aceite;
* servir como base para frontend, backend, API e QA do fluxo editorial.

---

## 24. Conclusão executiva

O projeto William Albarello não deve tratar a postagem como objeto binário entre “existe” e “não existe”.

Ela possui vida editorial.

Essa vida editorial passa, de forma madura, por:

* elaboração (`Draft`);
* revisão (`Review`);
* prontidão (`ReadyToPublish`);
* eventual agendamento (`Scheduled`);
* exposição (`Published`);
* preservação sem protagonismo (`Archived`).

Ao mesmo tempo, o projeto reconhece honestamente que o recorte atualmente mais comprovado da implementação trabalha, no mínimo, com:

* `draft`
* `published`
* `archived`

Este documento resolve essa tensão de forma correta:

* preserva o desenho soberano do domínio;
* respeita o estágio atual da implementação;
* prepara o terreno para evolução sem retrabalho conceitual.

---

