
# 024_Diagrama_de_Backup_e_Restauracao

## 1. Identificação do documento

- **Projeto:** William Albarello
- **Diretório:** `02-Diagramas`
- **Caminho oficial:** `/home/user/Documents/Softwares/Willian Albarello/William Albarello/02-Diagramas/03-Dados_e_Persistencia/024_Diagrama_de_Backup_e_Restauracao.md`
- **Natureza do documento:** Diagrama e contrato lógico de backup e restauração
- **Função sistêmica:** Explicar como o projeto deve proteger dados, conteúdos, configurações e capacidade de recuperação operacional em caso de falha, corrupção, exclusão indevida ou incidente de infraestrutura
- **Posição na trilha:** Sexto documento do bloco `03-Dados_e_Persistencia`
- **Dependências principais:** `007_Requisitos_Nao_Funcionais.md`, `018_Plano_de_Testes_Homologacao_e_Qualidade.md`, `019_Riscos_Premissas_Restricoes_e_Mitigacoes.md`, `022_Plano_de_Implantacao_Rollback_e_Suporte.md`, `024_Registro_de_Decisoes_Arquiteturais.md` e artefatos reais de deploy/infraestrutura quando disponíveis

---

## 2. Objetivo

Este documento existe para formalizar a estratégia de **backup e restauração** do projeto William Albarello.

Se os documentos anteriores do bloco `03-Dados_e_Persistencia` fixaram:

- o ER macro;
- o modelo editorial;
- usuários e papéis;
- estados da postagem;
- versionamento de conteúdo;

este arquivo responde a outra pergunta essencial:

> como o sistema evita perda de dados relevantes e como se recupera quando algo dá errado?

Seu objetivo é explicitar:

- quais ativos precisam ser protegidos;
- o que deve ou não entrar em backup;
- quais camadas exigem restauração distinta;
- como diferenciar restauração editorial de restauração técnica;
- como desenhar fluxo de recuperação coerente com o projeto;
- quais metas de continuidade são recomendáveis para o contexto atual;
- quais testes de restauração precisam existir.

Este documento não substitui:

- runbook operacional final de produção;
- playbook de incidente completo;
- política jurídica de retenção;
- especificação final do provedor de armazenamento;
- scripts reais de automação de backup.

Seu foco é o **modelo lógico soberano de proteção e recuperação**.

---

## 3. Fontes de referência

Este documento deriva principalmente das seguintes bases do projeto:

- `007_Requisitos_Nao_Funcionais.md`
- `018_Plano_de_Testes_Homologacao_e_Qualidade.md`
- `019_Riscos_Premissas_Restricoes_e_Mitigacoes.md`
- `022_Plano_de_Implantacao_Rollback_e_Suporte.md`
- `024_Registro_de_Decisoes_Arquiteturais.md`

Também dialoga diretamente com:

- `020_Diagrama_do_Modelo_de_Dados_do_Conteudo.md`
- `021_Diagrama_do_Modelo_de_Dados_de_Usuarios_e_Papeis.md`
- `023_Diagrama_de_Versionamento_de_Conteudo.md`
- arquitetura técnica e containers já definidos no Diretório 02;
- contratos de API administrativa e pública;
- artefatos reais de deploy/infraestrutura identificáveis no acervo técnico, quando existirem.

---

## 4. Premissas e limites

## 4.1 Premissas adotadas

Para este documento, adotam-se as seguintes premissas:

- o projeto possui uma camada pública e uma camada administrativa;
- há persistência de dados editoriais, identidades internas e trilhas de auditoria;
- há separação entre **conteúdo vivo**, **histórico editorial** e **infraestrutura técnica**;
- falhas podem ocorrer por erro humano, bug, deploy problemático, exclusão indevida, corrupção lógica ou incidente no provedor;
- backup útil não é apenas cópia de banco, mas proteção do conjunto operacional mínimo;
- restauração editorial e restauração de infraestrutura são problemas relacionados, mas distintos;
- versionamento de conteúdo reduz parte do risco editorial, mas não substitui backup sistêmico;
- o acervo técnico atual não fixa de forma definitiva toda a infraestrutura de produção, portanto o documento precisa ser prudente e portável.

## 4.2 Limites deste documento

Este arquivo não fecha:

- vendor final de banco;
- provedor definitivo de object storage;
- cron exato de cada rotina;
- política jurídica formal de retenção de logs;
- estratégia completa de DR multi-região;
- scripts shell/CI/CD reais de restauração.

Seu papel é fixar a **arquitetura de continuidade operacional**.

## 4.3 Regra de prudência arquitetural

Há uma diferença importante entre:

- a **estratégia correta de backup/restauração do projeto**; e
- a **infraestrutura atualmente implementada ou parcialmente visível**.

Por isso, este documento:

- não assume um stack de produção além do que é razoavelmente compatível com o acervo;
- não se limita ao scaffold técnico atual;
- propõe uma estratégia coerente para um site editorial/institucional com painel administrativo e base de conteúdo.

---

## 5. Tese central de continuidade

A tese deste documento é a seguinte:

> o projeto William Albarello não pode depender apenas de versionamento editorial, repositório Git ou redeploy do frontend; ele precisa de uma estratégia explícita para recuperar banco, conteúdo, arquivos, configuração e capacidade operacional mínima.

Isso significa que:

- Git não substitui backup de dados;
- revisão editorial não substitui backup de banco;
- rollback de deploy não substitui restauração de dados;
- cópia manual eventual não substitui política de recuperação;
- restore só é real quando é testado.

---

## 6. O que precisa ser protegido

A estratégia de backup precisa cobrir, no mínimo, cinco grupos de ativos.

## 6.1 Dados transacionais/editoriais

Incluem:

- publicações;
- categorias;
- tags;
- SEO;
- mídia referenciada;
- usuários internos;
- perfis e permissões;
- sessões, quando aplicável;
- logs/auditoria;
- histórico de versionamento editorial.

## 6.2 Arquivos e mídias

Incluem:

- imagens de capa;
- imagens OG;
- mídias auxiliares de conteúdo;
- assets operacionais eventualmente geridos fora do código;
- anexos editoriais, se existirem.

## 6.3 Configuração e segredos não sensíveis ao backup bruto

Incluem:

- estrutura de variáveis de ambiente;
- templates/configurações de aplicação;
- manifestos de deploy;
- configurações de DNS, domínios e integrações documentáveis.

**Observação importante:** segredos em texto puro exigem tratamento especial e não devem ser copiados de forma insegura.

## 6.4 Código e contratos

Incluem:

- código da API;
- código do site público;
- código do painel;
- contratos OpenAPI;
- documentação soberana do projeto.

## 6.5 Evidências operacionais mínimas

Incluem:

- logs essenciais de aplicação;
- eventos de autenticação críticos;
- indicadores mínimos de incidente;
- snapshots operacionais úteis para troubleshooting.

---

## 7. O que não deve ser tratado como backup principal

Para evitar falsa sensação de segurança, os itens abaixo **não** devem ser tratados como backup soberano do sistema.

## 7.1 Redeploy do frontend

Reimplantar o site não restaura banco, mídia nem histórico editorial.

## 7.2 Repositório Git sozinho

Git protege código e parte da documentação, mas não substitui backup de dados vivos.

## 7.3 Versionamento de conteúdo sozinho

Ele ajuda a restaurar texto e estado editorial, mas não resolve:

- perda de banco inteiro;
- corrupção ampla;
- perda de usuários;
- perda de sessões, permissões e auditoria;
- perda de mídia externa.

## 7.4 Exportação manual ocasional

Pode ser útil como apoio, mas não substitui estratégia contínua, automatizada e verificável.

---

## 8. Camadas de recuperação do projeto

O projeto precisa reconhecer quatro níveis de recuperação.

## 8.1 Nível 1 — restauração editorial

Voltada para recuperar:

- revisão anterior de uma postagem;
- versão publicada anterior;
- estado editorial de um conteúdo.

Esse nível dialoga diretamente com o documento `023_Diagrama_de_Versionamento_de_Conteudo.md`.

## 8.2 Nível 2 — restauração lógica de dados

Voltada para recuperar:

- tabelas/coleções;
- registros corrompidos;
- base editorial e administrativa;
- integridade relacional do domínio.

## 8.3 Nível 3 — restauração de mídia e ativos externos

Voltada para recuperar:

- imagens;
- arquivos associados;
- referências externas necessárias ao conteúdo.

## 8.4 Nível 4 — restauração de capacidade operacional

Voltada para recuperar:

- infraestrutura mínima;
- serviço da API;
- superfície pública;
- painel administrativo;
- conectividade entre componentes.

---

## 9. Diagrama principal — arquitetura de backup e restauração

```mermaid
flowchart TD
    A[Aplicação pública + painel + API] --> B[Camada de dados viva]
    A --> C[Camada de mídia/arquivos]
    A --> D[Camada de código e contratos]
    A --> E[Camada de configuração e operação]

    B --> F[Backup lógico recorrente]
    B --> G[Snapshot periódico de banco]
    C --> H[Backup/replicação de mídia]
    D --> I[Repositório versionado]
    E --> J[Documentação operacional + manifests + inventário]

    F --> K[Armazenamento seguro de backup]
    G --> K
    H --> K
    I --> L[Repositório remoto confiável]
    J --> M[Base documental protegida]

    K --> N{Incidente}
    L --> N
    M --> N

    N -->|Erro editorial| O[Restaurar por versionamento de conteúdo]
    N -->|Perda lógica de dados| P[Restaurar banco/objetos selecionados]
    N -->|Falha ampla de ambiente| Q[Restaurar stack mínima e depois dados]
    N -->|Falha de mídia| R[Restaurar storage e revalidar referências]

    O --> S[Validação funcional]
    P --> S
    Q --> S
    R --> S

    S --> T[Reabertura controlada do sistema]
````

---

## 10. Leitura executiva do diagrama

O diagrama mostra uma ideia central:

1. o sistema gera valor por meio de dados, mídia, código e configuração;
2. cada camada precisa de proteção compatível com sua natureza;
3. o armazenamento de backup deve ser separado do ambiente vivo;
4. cada tipo de incidente pede um caminho diferente de restauração;
5. toda recuperação precisa terminar em **validação funcional**, e não apenas em “restore concluiu sem erro”.

Em linguagem simples:

* conteúdo editorial perdido não se trata igual a banco corrompido;
* banco corrompido não se trata igual a deploy quebrado;
* mídia ausente não se trata igual a falha total do ambiente;
* por isso o projeto precisa de recuperação por camadas.

---

## 11. Estratégia de backup por camada

## 11.1 Banco de dados / dados vivos

Estratégia recomendada:

* backup lógico recorrente;
* snapshots periódicos adicionais, quando o provedor suportar;
* retenção mínima em janelas múltiplas;
* armazenamento fora do ambiente de runtime principal.

Isso deve cobrir, no mínimo:

* domínio editorial;
* usuários internos;
* perfis/permissões;
* histórico/versionamento;
* logs essenciais;
* metadados de mídia.

## 11.2 Mídia e arquivos

Estratégia recomendada:

* replicação ou backup periódico dos objetos;
* armazenamento com versionamento ou retenção mínima, quando viável;
* validação de existência das referências mais críticas.

Importante:

* banco sem mídia restaurada gera conteúdo quebrado;
* mídia sem banco restaurado gera ativos órfãos.

## 11.3 Código e contratos

Estratégia recomendada:

* repositório remoto confiável;
* branches protegidas conforme maturidade do projeto;
* documentação soberana armazenada de forma persistente e auditável.

## 11.4 Configuração e deploy

Estratégia recomendada:

* backup de manifests e inventário operacional;
* documentação de env vars por nome/finalidade;
* registro de integrações e dependências externas;
* runbook de rebuild mínimo do ambiente.

## 11.5 Logs e auditoria

Estratégia recomendada:

* retenção mínima de eventos relevantes;
* exportação/centralização de logs críticos;
* separação entre logs úteis e ruído excessivo.

---

## 12. Estratégia de retenção

Sem amarrar o projeto a um vendor específico, a estratégia recomendada é trabalhar com retenção em camadas.

## 12.1 Curto prazo

Voltado para recuperação rápida de incidentes recentes.

Exemplo de alvo recomendável:

* cópias diárias ou mais frequentes;
* retenção curta para uso operacional imediato.

## 12.2 Médio prazo

Voltado para erros percebidos tardiamente.

Exemplo de alvo recomendável:

* cópias semanais preservadas por janela intermediária.

## 12.3 Longo prazo

Voltado para reconstrução histórica e contingência mais severa.

Exemplo de alvo recomendável:

* cópias mensais preservadas por janela mais longa.

## 12.4 Regra importante

A retenção não deve depender de uma única cópia sobreescrita continuamente.
Sem múltiplos pontos no tempo, o sistema fica vulnerável a corrupção silenciosa.

---

## 13. RPO e RTO

## 13.1 Observação de honestidade metodológica

Os anexos e artefatos atuais permitem inferir a **criticidade relativa** do projeto, mas **não fixam formalmente** metas de RPO/RTO em nível contratual.

Por isso, o que segue deve ser lido como **meta arquitetural recomendada**, e não como SLA já homologado.

## 13.2 Leitura de criticidade do projeto

O projeto William Albarello, no estado atual, se comporta mais como:

* plataforma institucional/editorial com área administrativa;
* sensível à perda de conteúdo e de configuração;
* importante para continuidade de operação e reputação;
* porém não tipicamente equivalente a sistema financeiro transacional de altíssima criticidade por segundo.

## 13.3 RPO recomendado

**RPO recomendado para dados editoriais e administrativos:** até **24 horas** como piso aceitável de maturidade inicial.

**RPO desejável em estágio mais maduro:** até **1 hora** para dados vivos do CMS/painel, caso a frequência editorial e o risco operacional justifiquem.

Leitura prática:

* perder mais de um dia inteiro de edição já é um risco ruim;
* perder até uma hora pode ser aceitável como meta madura, mas depende do provedor e da automação real.

## 13.4 RTO recomendado

**RTO recomendado para recuperação mínima do serviço:** até **4 horas** como alvo operacional razoável no estágio atual.

**RTO desejável em cenário mais maduro:** entre **1 e 2 horas** para restaurar superfície pública mínima e painel essencial.

Leitura prática:

* o sistema não deve ficar dependente de recuperação artesanal de dias;
* mas também não se deve prometer minutos sem que a infraestrutura real suporte isso.

---

## 14. Distinção crítica: restauração editorial x restauração técnica

Este é um dos pontos mais importantes do documento.

## 14.1 Restauração editorial

Aplica-se quando:

* uma postagem foi alterada indevidamente;
* uma versão melhor precisa ser retomada;
* houve erro de conteúdo, SEO ou estado editorial.

Ferramenta principal:

* versionamento de conteúdo e histórico editorial.

## 14.2 Restauração técnica

Aplica-se quando:

* o banco foi corrompido;
* dados foram apagados indevidamente em escala;
* storage falhou;
* o ambiente foi comprometido ou perdido.

Ferramentas principais:

* backup lógico;
* snapshot;
* restauração de mídia;
* rebuild de stack.

## 14.3 Regra arquitetural

Nunca confundir:

* “restaurar uma postagem”
  com
* “restaurar o sistema”.

São problemas diferentes, com impacto, tempo e risco distintos.

---

## 15. Fluxo de restauração por cenário

## 15.1 Cenário A — erro editorial pontual

Exemplos:

* texto publicado com alteração indevida;
* SEO quebrado em uma única postagem;
* arquivamento indevido de um conteúdo.

Fluxo correto:

1. identificar a publicação afetada;
2. localizar revisão válida;
3. restaurar editorialmente por versionamento;
4. validar visualmente e funcionalmente;
5. registrar evento de restauração.

**Não exige** restore de banco inteiro.

## 15.2 Cenário B — perda lógica parcial de dados

Exemplos:

* categoria apagada por erro;
* lote de registros editoriais corrompido;
* tabela específica afetada.

Fluxo correto:

1. conter novas escritas;
2. identificar escopo do dano;
3. escolher ponto de recuperação;
4. restaurar seletivamente, quando viável;
5. reconciliar integridade relacional;
6. validar aplicação e painel.

## 15.3 Cenário C — falha de mídia/storage

Exemplos:

* imagens indisponíveis;
* arquivos perdidos;
* referências quebradas em massa.

Fluxo correto:

1. identificar alcance da perda;
2. restaurar objetos do backup/replicação;
3. revalidar links críticos;
4. reprocessar cache/CDN, se aplicável;
5. homologar páginas e cards.

## 15.4 Cenário D — falha ampla de ambiente

Exemplos:

* indisponibilidade grave do ambiente;
* perda de banco e aplicação;
* incidente severo no provedor.

Fluxo correto:

1. reconstruir stack mínima;
2. restaurar banco;
3. restaurar mídia;
4. reaplicar configuração controlada;
5. subir API;
6. validar painel;
7. validar superfície pública;
8. liberar retorno gradual.

---

## 16. Diagrama operacional — fluxo de recuperação

```mermaid
flowchart TD
    A[Incidente detectado] --> B{Tipo de incidente}

    B -->|Editorial pontual| C[Usar versionamento editorial]
    B -->|Dados parciais| D[Conter escrita e avaliar escopo]
    B -->|Mídia/arquivos| E[Restaurar storage/objetos]
    B -->|Ambiente amplo| F[Reconstruir stack mínima]

    C --> G[Validar conteúdo restaurado]
    D --> H[Selecionar ponto de recuperação]
    H --> I[Restaurar dados necessários]
    I --> J[Reconciliar integridade]
    E --> K[Revalidar referências e cache]
    F --> L[Restaurar banco]
    L --> M[Restaurar mídia]
    M --> N[Reaplicar configuração]

    G --> O[Teste funcional]
    J --> O
    K --> O
    N --> O

    O --> P{Sistema íntegro?}
    P -->|Sim| Q[Reabrir operação controlada]
    P -->|Não| R[Escalonar diagnóstico e repetir ciclo]
```

---

## 17. Ordem de restauração recomendada

Em falha ampla, a ordem recomendada de restauração é:

1. **infraestrutura mínima e conectividade**
2. **banco/dados**
3. **mídia/objetos**
4. **configuração e integrações**
5. **API administrativa**
6. **painel interno**
7. **superfície pública**
8. **validação funcional e homologação**
9. **reabertura controlada**

A lógica é simples:

* sem ambiente, não há onde restaurar;
* sem banco, o app sobe oco;
* sem mídia, o conteúdo sobe quebrado;
* sem validação, restore não é confiável.

---

## 18. Relação com rollback de deploy

Rollback de deploy e restauração de backup são coisas diferentes.

## 18.1 Rollback de deploy

Serve para:

* desfazer versão ruim de código/config;
* restaurar binário/build anterior;
* conter regressão introduzida por release.

## 18.2 Restauração de backup

Serve para:

* recuperar dados;
* recuperar mídia;
* recuperar integridade após perda/corrupção;
* reconstruir capacidade operacional.

## 18.3 Regra importante

Em muitos incidentes reais, pode ser necessário combinar os dois:

* rollback do código;
* restore do dado.

---

## 19. Relação com versionamento de conteúdo

O documento `023_Diagrama_de_Versionamento_de_Conteudo.md` já definiu como restaurar revisões editoriais.

Este documento complementa aquela lógica da seguinte forma:

* **versionamento** protege a memória editorial;
* **backup** protege o sistema como um todo.

Leitura correta:

* restaurar uma postagem antiga não substitui restauração de banco;
* restaurar banco não elimina a necessidade de histórico editorial fino.

As duas estratégias coexistem e se reforçam.

---

## 20. Estratégia mínima de testes de backup/restauração

Não basta ter cópia; é preciso validar recuperabilidade.

## 20.1 Testes mínimos recomendados

### Teste T-BR-01 — restauração editorial pontual

Validar restauração de uma versão antiga de publicação sem perda do histórico.

### Teste T-BR-02 — restauração de base de homologação

Restaurar cópia de dados em ambiente não produtivo e validar consistência mínima.

### Teste T-BR-03 — restauração de mídia crítica

Validar recuperação de imagens/capas/OG essenciais.

### Teste T-BR-04 — rebuild mínimo do serviço

Validar que a stack mínima consegue voltar a operar com dados restaurados.

### Teste T-BR-05 — validação pós-restore

Confirmar:

* login administrativo;
* leitura de publicações;
* detalhe por slug;
* listagens;
* integridade de SEO básico;
* integridade de permissões.

## 20.2 Regra crítica

Backup sem teste periódico de restore é apenas hipótese de segurança.

---

## 21. Segurança do backup

Backups precisam ser protegidos, porque frequentemente concentram o ativo mais sensível do sistema.

## 21.1 Requisitos mínimos

* armazenamento segregado do ambiente vivo;
* acesso restrito;
* criptografia em repouso, quando viável;
* criptografia em trânsito, quando aplicável;
* trilha mínima de acesso/uso;
* não exposição pública inadvertida.

## 21.2 Segredos e credenciais

Segredos não devem ser incluídos em backup de forma descuidada.

O projeto deve preferir:

* inventário de segredos por nome/finalidade;
* mecanismo seguro de reidratação;
* documentação operacional sem vazar segredo bruto.

---

## 22. Regras macro de integridade da estratégia

## 22.1 RI-BR-01

O sistema deve proteger banco, mídia, código e configuração de forma coordenada.

## 22.2 RI-BR-02

A restauração editorial não substitui restauração técnica.

## 22.3 RI-BR-03

Backups devem ser mantidos fora do ambiente operacional principal.

## 22.4 RI-BR-04

A retenção deve preservar múltiplos pontos no tempo.

## 22.5 RI-BR-05

Toda restauração deve terminar em validação funcional.

## 22.6 RI-BR-06

Rollback de deploy não deve ser confundido com restore de dados.

## 22.7 RI-BR-07

Backups precisam de controle de acesso e tratamento seguro.

## 22.8 RI-BR-08

Metas de RPO/RTO devem ser lidas como compromisso apenas quando sustentadas pela infraestrutura real.

## 22.9 RI-BR-09

A perda de mídia deve ter caminho de recuperação próprio.

## 22.10 RI-BR-10

Rotina de teste de restauração deve existir como disciplina contínua.

---

## 23. Decisões arquiteturais implícitas neste documento

Este documento fixa as seguintes decisões:

1. o projeto exige estratégia explícita de continuidade;
2. backup é multicamada, não apenas dump de banco;
3. restore deve ser orientado por tipo de incidente;
4. versionamento editorial e backup sistêmico coexistem;
5. validação funcional pós-restore é parte obrigatória do processo;
6. metas de RPO/RTO são propostas prudentes, não promessa vazia;
7. rebuild do ambiente deve ser documentável e repetível.

---

## 24. Riscos que este documento evita

### 24.1 Falsa sensação de segurança

Evita achar que Git, deploy e CMS versionado bastam.

### 24.2 Recuperação artesanal demais

Evita depender de memória humana em incidente sério.

### 24.3 Colapso entre problema editorial e problema sistêmico

Evita usar ferramenta errada para incidente errado.

### 24.4 Perda silenciosa de mídia

Evita restaurar banco e esquecer ativos visuais.

### 24.5 Restore sem comprovação

Evita considerar recuperação concluída sem validação funcional.

### 24.6 Promessas irreais

Evita declarar RPO/RTO agressivos sem base técnica real.

---

## 25. Critérios de aceite deste documento

Este documento será considerado aceito quando:

* distinguir claramente backup de versionamento editorial;
* distinguir restauração editorial de restauração técnica;
* representar o fluxo de backup e recuperação em diagrama coerente;
* identificar os principais ativos protegidos;
* propor metas prudentes de RPO/RTO como alvo arquitetural;
* dialogar com riscos, testes, implantação, rollback e ADRs do projeto;
* servir como base para runbook técnico e evolução operacional futura.

---

## 26. Conclusão executiva

O projeto William Albarello exige proteção real contra perda de conteúdo, perda de dados e perda de capacidade operacional.

A estratégia correta não é única nem simplista.

Ela combina:

* versionamento editorial para recuperar conteúdo;
* backup lógico e snapshots para recuperar dados;
* proteção de mídia para evitar páginas quebradas;
* preservação de código e contratos;
* documentação operacional para reconstrução do ambiente;
* testes periódicos de restauração para transformar hipótese em confiança.

Este documento fixa essa lógica.

Ele transforma “backup e restore” de uma preocupação genérica em um contrato arquitetural claro, coerente com o estágio atual do projeto e pronto para orientar infraestrutura, homologação, suporte e continuidade operacional.

---

## 27. Fechamento do bloco atual

Com este documento, o bloco `03-Dados_e_Persistencia` fica logicamente fechado com a seguinte sequência:

* `019_Diagrama_ER_Entidade_Relacionamento.md`
* `020_Diagrama_do_Modelo_de_Dados_do_Conteudo.md`
* `021_Diagrama_do_Modelo_de_Dados_de_Usuarios_e_Papeis.md`
* `022_Diagrama_de_Estados_da_Postagem.md`
* `023_Diagrama_de_Versionamento_de_Conteudo.md`
* `024_Diagrama_de_Backup_e_Restauracao.md`

---
