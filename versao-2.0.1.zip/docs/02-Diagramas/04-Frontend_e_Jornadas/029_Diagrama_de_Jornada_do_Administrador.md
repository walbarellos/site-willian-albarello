
# 029_Diagrama_de_Jornada_do_Administrador

## 1. Identificação do documento

- **Projeto:** William Albarello
- **Diretório:** `02-Diagramas`
- **Caminho oficial:** `/home/user/Documents/Softwares/Willian Albarello/William Albarello/02-Diagramas/04-Frontend_e_Jornadas/029_Diagrama_de_Jornada_do_Administrador.md`
- **Natureza do documento:** Diagrama e contrato lógico da jornada operacional do administrador
- **Função sistêmica:** Explicar a experiência do operador interno no painel administrativo, cobrindo login, validação de sessão, navegação, gestão de conteúdo, revisão, publicação, arquivamento e observação de status
- **Posição na trilha:** Quinto documento do bloco `04-Frontend_e_Jornadas`
- **Dependências principais:** `004_Requisitos_Funcionais_e_Nao_Funcionais.md`, `009_Personas_Perfis_e_Usuarios.md`, `013_Modelo_de_Dados_Conceitual.md`, `015_Arquitetura_Tecnica_e_de_Software.md`, `017_UI_UX_Arquitetura_da_Informacao.md`, frontend e backend reais disponíveis no acervo técnico

---

## 2. Objetivo

Este documento existe para formalizar a **jornada do administrador** no projeto William Albarello.

Se o documento `028_Diagrama_de_Jornada_do_Visitante.md` tratou da experiência pública, este arquivo responde à pergunta complementar:

> como o operador interno entra no sistema, valida sua sessão, localiza o conteúdo, executa ações editoriais e conclui tarefas com segurança e clareza operacional?

Seu objetivo é explicitar:

- o ponto de entrada do administrador;
- a sequência entre login, acesso ao painel e operação editorial;
- os caminhos de criação, edição, revisão, publicação e arquivamento;
- o papel dos estados e feedbacks da interface;
- os principais pontos de atrito do fluxo administrativo;
- a relação entre jornada, segurança, CMS e backend.

Este documento não fecha:

- matriz completa de permissões por perfil;
- wireframe final de cada tela do painel;
- fluxos futuros de analytics administrativos;
- operação avançada de taxonomias e auditoria em profundidade;
- orquestração detalhada de jobs assíncronos.

Seu foco é a **jornada operacional central do administrador**.

---

## 3. Fontes de referência

Este documento deriva principalmente das seguintes bases do projeto:

- `01-Waterfall/01-Obrigatorios/004_Requisitos_Funcionais_e_Nao_Funcionais.md`
- `01-Waterfall/01-Obrigatorios/009_Personas_Perfis_e_Usuarios.md`
- `01-Waterfall/01-Obrigatorios/013_Modelo_de_Dados_Conceitual.md`
- `01-Waterfall/01-Obrigatorios/015_Arquitetura_Tecnica_e_de_Software.md`
- `01-Waterfall/01-Obrigatorios/017_UI_UX_Arquitetura_da_Informacao.md`

Também dialoga diretamente com:

- `021_Diagrama_do_Modelo_de_Dados_de_Usuarios_e_Papeis.md`
- `022_Diagrama_de_Estados_da_Postagem.md`
- `023_Diagrama_de_Versionamento_de_Conteudo.md`
- `025_Diagrama_de_Arquitetura_do_Frontend.md`
- `026_Diagrama_de_Componentes_da_UI.md`
- `027_Diagrama_de_Rotas_e_Paginas.md`
- frontend administrativo real do monorepo
- backend/API administrativa real disponível no acervo técnico

---

## 4. Premissas e limites

## 4.1 Premissas adotadas

Para este documento, adotam-se as seguintes premissas:

- a área administrativa do projeto é protegida;
- não existe cadastro público aberto de administrador no ciclo atual;
- o acesso dominante do operador ocorre por login com email e senha;
- o backend real já sinaliza:
  - rota de login administrativo;
  - sessão por cookie;
  - proteção CSRF;
  - rate limit;
- o frontend real já comprova rotas administrativas mínimas como:
  - `/painel/login`
  - `/painel/publicacoes`
  - `/painel/publicacoes/[id]/editar`
- o núcleo operacional do admin é a gestão de publicações;
- o fluxo editorial pode crescer para revisão, agendamento, taxonomia e auditoria, mas o núcleo atual já exige clareza em:
  - entrar;
  - autenticar;
  - localizar;
  - editar;
  - salvar;
  - publicar;
  - arquivar.

## 4.2 Limites deste documento

Este arquivo não define:

- toda a árvore de navegação futura do painel;
- todos os perfis administrativos possíveis;
- automações futuras de aprovação;
- política detalhada de multiusuário concorrente;
- runbook completo de incidentes de autenticação.

Seu papel é fixar a **jornada principal do operador interno**.

## 4.3 Regra de prudência arquitetural

Há uma diferença importante entre:

- a **jornada administrativa correta do projeto**; e
- o **estado atual do código**, ainda parcial em várias telas e ações.

Por isso, este documento:

- reconhece o fluxo já comprovado no frontend e no backend;
- não trata placeholders como jornada madura completa;
- também não reduz a jornada correta somente ao mínimo já implementado.

---

## 5. Tese central da jornada do administrador

A tese deste documento é a seguinte:

> a jornada do administrador deve ser curta para entrar, clara para operar e segura para decidir, permitindo que o operador transforme intenção editorial em ação controlada sem ambiguidade de estado, sem perda de contexto e sem insegurança de sessão.

Isso significa que a experiência administrativa não deve ser tratada como simples coleção de telas de formulário.

Ela deve operar como percurso objetivo:

1. **autenticar**
2. **validar contexto de acesso**
3. **entrar no núcleo operacional**
4. **localizar ou iniciar conteúdo**
5. **editar e observar estados**
6. **executar ação editorial**
7. **receber retorno claro**
8. **continuar operando ou encerrar sessão**

---

## 6. Quem é o administrador desta jornada

Com base nos documentos de personas e na arquitetura do painel, o administrador deve ser entendido como um usuário interno com responsabilidade editorial e/ou operacional.

No ciclo atual, esse perfil tende a compartilhar algumas características:

- precisa entrar rapidamente no sistema;
- já sabe o que quer fazer com mais frequência do que o visitante público;
- depende de feedback claro e confiável;
- não quer “descobrir” a interface; quer **operar**;
- precisa perceber com segurança:
  - se está autenticado;
  - em que tela está;
  - qual conteúdo está manipulando;
  - qual é o estado atual da postagem;
  - se a ação foi salva, publicada, arquivada ou falhou.

---

## 7. Objetivos do administrador

## 7.1 Objetivos primários

- autenticar com segurança;
- acessar o painel sem fricção desnecessária;
- listar conteúdos;
- encontrar uma publicação existente;
- criar nova publicação quando necessário;
- editar conteúdo, SEO, taxonomia e status;
- salvar rascunho;
- publicar ou arquivar;
- entender o resultado da operação.

## 7.2 Objetivos secundários

- confirmar se a sessão continua válida;
- voltar rapidamente à listagem;
- retomar uma postagem em andamento;
- reduzir risco de erro operacional;
- entender o que precisa ser corrigido quando uma ação falha.

---

## 8. Pontos de entrada da jornada administrativa

A jornada administrativa possui poucas entradas, mas muito mais críticas do que a superfície pública.

## 8.1 Entrada pelo login

**Rota comprovada:** `/painel/login`

É a porta principal da área interna.

Função:
- capturar credenciais;
- iniciar sessão;
- encaminhar o operador para a área autenticada.

Risco:
- falha de feedback;
- mensagens vagas;
- inconsistência entre sucesso visual e sessão real.

## 8.2 Entrada por sessão já existente

**Fluxo soberano esperado:** acesso direto a rota protegida com sessão válida

Exemplo:
- operador volta ao painel e o sistema valida a sessão existente.

Função:
- reduzir atrito para uso recorrente;
- permitir continuidade operacional.

Risco:
- sessão expirada mal tratada;
- redirecionamentos confusos;
- UI desatualizada em relação ao backend.

## 8.3 Entrada por link interno de edição

**Fluxo comprovado/esperado:** da listagem para edição

Exemplo:
- `/painel/publicacoes/[id]/editar`

Função:
- levar o operador diretamente ao item que precisa de ação.

Risco:
- acesso sem contexto;
- ausência de status claro da publicação.

---

## 9. Macroetapas da jornada do administrador

A jornada administrativa pode ser lida em sete macroetapas.

## 9.1 Autenticação

O operador informa credenciais e tenta abrir uma sessão válida.

## 9.2 Validação de acesso

O sistema confirma:

- identidade;
- sessão;
- autorização mínima para operar a rota.

## 9.3 Entrada no painel

O operador chega à superfície administrativa autenticada.

## 9.4 Localização da tarefa

O operador decide se vai:

- listar publicações;
- criar nova publicação;
- editar publicação existente.

## 9.5 Operação editorial

O operador edita campos, observa status, faz ajustes e toma decisão de fluxo.

## 9.6 Ação editorial

O operador executa uma ação como:

- salvar rascunho;
- publicar;
- arquivar;
- reabrir para edição;
- eventualmente enviar para revisão, quando o fluxo for aprofundado.

## 9.7 Feedback e continuidade

O sistema devolve resultado claro, e o operador decide se:

- continua na mesma peça;
- volta à listagem;
- inicia nova tarefa;
- encerra a sessão.

---

## 10. Diagrama principal — jornada do administrador

```mermaid
flowchart TD
    A[Administrador tenta acessar o painel] --> B{Ja possui sessao valida?}

    B -->|Nao| C[Ir para /painel/login]
    B -->|Sim| D[Validar sessao atual]

    C --> E[Preencher email e senha]
    E --> F[Enviar login]
    F --> G{Credenciais validas?}

    G -->|Nao| H[Exibir erro de autenticacao]
    H --> E

    G -->|Sim| I[Criar sessao segura]
    D --> J{Sessao valida?}

    J -->|Nao| C
    J -->|Sim| K[Entrar na area autenticada]
    I --> K

    K --> L[Painel / area inicial]
    L --> M{Tarefa desejada}

    M -->|Gerir publicacoes| N[Listagem de publicacoes]
    M -->|Criar nova| O[Nova publicacao]
    M -->|Editar existente| P[Editar publicacao]
    M -->|Outras areas futuras| Q[Taxonomia / auditoria / configuracoes]

    N --> P
    N --> O

    O --> R[Preencher dados editoriais]
    P --> R

    R --> S[Editar conteudo, SEO, taxonomia e status]
    S --> T{Acao editorial}

    T -->|Salvar rascunho| U[Persistir em draft]
    T -->|Publicar| V[Validar requisitos e publicar]
    T -->|Arquivar| W[Arquivar conteudo]
    T -->|Reabrir / continuar edicao| X[Manter fluxo interno]

    U --> Y[Feedback de sucesso ou erro]
    V --> Y
    W --> Y
    X --> Y

    Y --> Z{Proxima decisao}
    Z -->|Continuar na mesma| S
    Z -->|Voltar para listagem| N
    Z -->|Encerrar| AA[Logout / fim da sessao]
````

---

## 11. Leitura executiva do diagrama

O diagrama mostra uma jornada administrativa orientada à tarefa.

O operador:

1. tenta acessar a área interna;
2. autentica ou reaproveita sessão;
3. entra no painel;
4. escolhe uma tarefa editorial;
5. edita ou cria conteúdo;
6. executa uma ação;
7. recebe feedback;
8. continua ou encerra.

A leitura correta é:

* a jornada não precisa ser “emocional” como a do visitante;
* ela precisa ser **rápida, previsível e segura**.

---

## 12. Etapa de login

## 12.1 Papel do login

O login é a primeira barreira operacional do painel.

Ele deve confirmar:

* identidade do operador;
* capacidade de abrir sessão válida;
* acesso ao ambiente administrativo.

## 12.2 O que o administrador precisa perceber nessa etapa

* o formulário está claro;
* os campos são inequívocos;
* o envio está em progresso quando necessário;
* falhas de autenticação aparecem com retorno compreensível;
* sucesso leva a uma área autenticada real, e não apenas a uma ilusão visual.

## 12.3 Riscos da etapa de login

* mensagem genérica demais;
* spinner sem conclusão clara;
* sucesso visual sem sessão persistida;
* expiração de sessão mal tratada;
* retorno ambíguo após erro.

---

## 13. Etapa de validação de sessão

## 13.1 Papel desta etapa

Depois do login, ou quando o usuário retorna ao painel, o sistema precisa validar se a sessão continua apta.

## 13.2 O que isso protege

* evita acesso indevido;
* evita UI carregada com estado falso de autenticação;
* impede que o usuário opere em rota protegida com sessão inválida.

## 13.3 Comportamento esperado

* sessão válida: prossegue para o painel;
* sessão inválida ou expirada: redireciona de volta ao login com clareza.

## 13.4 Regra importante

O frontend administrativo deve refletir a sessão **real**, não apenas um estado local otimista e solto.

---

## 14. Etapa de entrada no painel

## 14.1 Papel do painel inicial

A rota raiz autenticada do painel deve funcionar como hub operacional.

Mesmo que o código atual ainda esteja inicial, a arquitetura do projeto exige que essa tela responda rapidamente:

* o que está disponível para operar;
* qual o principal caminho editorial;
* como acessar listagens e áreas de gestão.

## 14.2 Saídas principais do painel

* publicações;
* nova publicação;
* taxonomias;
* auditoria;
* outras áreas futuras.

---

## 15. Etapa de listagem de publicações

## 15.1 Papel da listagem

A listagem administrativa é o núcleo operacional central do CMS.

Ela deve permitir:

* localizar rapidamente conteúdo existente;
* reconhecer título e estado;
* escolher entre editar, criar novo ou voltar;
* ter noção do acervo em operação.

## 15.2 O que o administrador procura na listagem

* clareza dos registros;
* estado editorial visível;
* ações rápidas;
* baixa ambiguidade;
* caminho evidente para edição.

## 15.3 Riscos da listagem

* tabela sem hierarquia;
* status pouco claros;
* ausência de caminho para criação;
* sobrecarga visual;
* ações perigosas sem confirmação.

---

## 16. Etapa de criação ou edição de publicação

## 16.1 Rotas envolvidas

**Comprovada:**

* `/painel/publicacoes/[id]/editar`

**Soberana esperada:**

* `/painel/publicacoes/nova`

## 16.2 Papel desta etapa

Aqui o administrador transforma intenção editorial em registro persistido.

## 16.3 O que a tela de edição precisa sustentar

* conteúdo principal;
* resumo;
* slug;
* categoria;
* tags;
* SEO;
* estado editorial;
* feedback de salvamento;
* percepção do status atual da peça.

## 16.4 O que o administrador precisa sentir

* controle;
* previsibilidade;
* feedback;
* segurança para editar sem perder contexto;
* clareza sobre o que está em rascunho, publicado ou arquivado.

---

## 17. Etapa de ação editorial

## 17.1 Ações centrais do fluxo atual

* salvar rascunho;
* publicar;
* arquivar;
* continuar edição.

## 17.2 Ações soberanas de maturidade futura

* enviar para revisão;
* marcar como pronto para publicar;
* agendar;
* restaurar revisão;
* reabrir após arquivamento.

## 17.3 Regra central

A UI não deve tratar essas ações como botões equivalentes e opacos.

Cada ação precisa deixar claro:

* o que ela faz;
* em que estado a postagem ficará;
* se há validações prévias;
* qual foi o resultado da tentativa.

---

## 18. Etapa de feedback e observação de status

## 18.1 Papel do feedback

Depois de qualquer ação, o sistema deve devolver ao operador:

* sucesso;
* falha;
* pendência;
* bloqueio;
* estado atual da peça.

## 18.2 Papel da observação de status

O administrador precisa enxergar claramente:

* se a postagem está em `draft`;
* se foi `published`;
* se está `archived`;
* futuramente, se está em `review` ou `scheduled`.

## 18.3 Regra importante

Status não pode ser implícito nem deduzido por detalhes invisíveis.
Ele deve ser **explícito na UI**.

---

## 19. Jornada ideal resumida do administrador

A jornada ideal do administrador pode ser resumida assim:

1. entra com segurança;
2. valida sessão;
3. chega rapidamente à área útil;
4. encontra ou cria a publicação;
5. edita com clareza;
6. executa ação editorial;
7. recebe retorno confiável;
8. prossegue para a próxima tarefa sem ruído desnecessário.

---

## 20. Diagrama complementar — fluxo operacional resumido

```mermaid id="4r3pjy"
flowchart LR
    L[Login] --> S[Sessao valida]
    S --> P[Painel]
    P --> G[Gestao de publicacoes]
    G --> E[Edicao / criacao]
    E --> A[Acao editorial]
    A --> F[Feedback + status]
    F --> C[Continuidade operacional]
```

---

## 21. Leitura do diagrama complementar

Esse fluxo resume a essência da jornada admin:

* sem login confiável, não há jornada;
* sem sessão válida, não há operação segura;
* sem gestão de publicações, não há núcleo editorial;
* sem feedback, não há confiança operacional;
* sem continuidade, o painel não escala no uso diário.

---

## 22. Pontos de atrito da jornada administrativa

A jornada do administrador tende a falhar em atritos diferentes dos da jornada pública.

## 22.1 Atrito de autenticação

* erro pouco claro;
* sessão criada de forma inconsistente;
* retorno ambíguo após login;
* expiração mal tratada.

## 22.2 Atrito de localização

* dificuldade de achar a publicação certa;
* listagem confusa;
* ausência de ações evidentes.

## 22.3 Atrito de edição

* campos sem agrupamento lógico;
* falta de distinção entre conteúdo, taxonomia e SEO;
* perda de contexto durante salvamento.

## 22.4 Atrito de estado

* não saber se a peça está em rascunho, publicada ou arquivada;
* não entender o efeito do botão clicado;
* publicação bloqueada sem feedback suficiente.

## 22.5 Atrito de confiança operacional

* ação salva mas a interface não mostra claramente;
* sucesso visual sem persistência real;
* erro técnico exibido de modo incompreensível.

## 22.6 Atrito de continuidade

* dificuldade de voltar à listagem;
* perda de foco após concluir uma ação;
* necessidade de repetição manual excessiva.

---

## 23. Elementos que reduzem atrito

A jornada do administrador melhora quando o sistema oferece:

* login limpo e com feedback explícito;
* validação de sessão coerente;
* listagem clara com status visível;
* edição agrupada por blocos;
* ações editoriais bem nomeadas;
* feedback imediato e compreensível;
* caminho simples para voltar ao fluxo;
* distinção clara entre erro do usuário, erro de validação e erro técnico.

---

## 24. Relação com modelo de dados e CMS

A jornada administrativa é fortemente sustentada pelos documentos de dados e CMS do projeto.

Ela depende diretamente de estruturas como:

* `PUBLICACAO`
* `CATEGORIA_EDITORIAL`
* `TAG_EDITORIAL`
* `SEO_PUBLICACAO`
* `HISTORICO_STATUS_EDITORIAL`
* `REVISAO_CONTEUDO`
* `USUARIO_INTERNO`
* `SESSAO_ACESSO`

Leitura correta:

* a jornada do administrador não é só frontend;
* ela é a manifestação operacional da modelagem editorial e de acesso já definida.

---

## 25. Relação com segurança

A jornada do administrador também é uma jornada de segurança.

Ela depende de:

* autenticação válida;
* sessão persistida com segurança;
* rotas protegidas;
* expiração controlada;
* logout claro;
* coerência entre frontend e backend.

Regra importante:

**o admin não pode operar com segurança “simulada”.**

---

## 26. Relação com UI/UX do painel

A jornada administrativa depende da arquitetura da informação interna e da UI do painel.

Ela exige:

* hierarquia clara;
* componentes operacionais previsíveis;
* formulários agrupados por função;
* badges de status;
* mensagens de sucesso e erro;
* fluxo entre listagem e edição sem confusão.

Ou seja:
a jornada administrativa emerge da UI corretamente desenhada para operação.

---

## 27. Sinais de sucesso da jornada administrativa

Mesmo sem fechar aqui uma camada analítica completa, a jornada do administrador pode ser considerada saudável quando:

* o login funciona com retorno claro;
* a sessão é validada sem comportamento estranho;
* a listagem leva à edição sem ruído;
* o operador entende o estado atual da publicação;
* as ações editoriais têm efeito observável;
* o retorno de sucesso/erro é inequívoco;
* o fluxo de trabalho pode ser repetido com consistência.

---

## 28. Regras macro de integridade da jornada do administrador

## 28.1 RI-JA-01

Toda entrada administrativa deve passar por autenticação ou validação coerente de sessão.

## 28.2 RI-JA-02

O painel deve oferecer caminho claro para o núcleo operacional do CMS.

## 28.3 RI-JA-03

A listagem de publicações deve permitir localização e ação com baixa ambiguidade.

## 28.4 RI-JA-04

A tela de edição deve organizar conteúdo, SEO, taxonomia e status de forma legível.

## 28.5 RI-JA-05

Toda ação editorial relevante deve devolver feedback explícito.

## 28.6 RI-JA-06

O estado atual da postagem deve ser sempre visível ao operador.

## 28.7 RI-JA-07

Erros de autenticação, validação e persistência devem ser distinguíveis.

## 28.8 RI-JA-08

A jornada administrativa deve minimizar fricção repetitiva para uso cotidiano.

---

## 29. Decisões arquiteturais implícitas neste documento

Este documento fixa, em nível macro, as seguintes decisões:

1. a jornada do administrador começa na autenticação;
2. sessão válida é pré-condição estrutural da operação;
3. o núcleo operacional do painel é a gestão de publicações;
4. a edição precisa combinar conteúdo, SEO, taxonomia e status;
5. feedback explícito é parte essencial da jornada;
6. status editorial visível é indispensável;
7. a jornada administrativa deve ser desenhada para repetição eficiente, não apenas para demonstração funcional.

---

## 30. Riscos que este documento evita

### 30.1 Painel com login apenas “decorativo”

Evita fluxo que parece autenticado mas não sustenta sessão real.

### 30.2 Operação sem contexto

Evita que o administrador edite sem entender estado e efeito.

### 30.3 CMS confuso

Evita mistura entre conteúdo, SEO e taxonomia sem estrutura.

### 30.4 Feedback insuficiente

Evita ações sem retorno claro de sucesso ou erro.

### 30.5 Segurança superficial

Evita painel cuja proteção existe só na aparência da UI.

### 30.6 Jornada administrativa cansativa

Evita excesso de passos e fricção para tarefas cotidianas.

---

## 31. Critérios de aceite deste documento

Este documento será considerado aceito quando:

* representar claramente a jornada do administrador no painel;
* explicitar login, validação de sessão, listagem, criação/edição e ação editorial;
* identificar o papel do status e do feedback;
* dialogar com CMS, segurança, UI/UX e código real;
* servir como base para decisões de layout, componentes, estados e fluxos internos.

---

## 32. Conclusão executiva

O administrador do projeto William Albarello não precisa de uma experiência ornamental.

Ele precisa de uma experiência operacional confiável.

Essa jornada, quando corretamente desenhada, começa no login, passa por validação de sessão, entra no núcleo editorial do painel, permite localizar ou criar conteúdo, executar ações com clareza e receber retorno explícito do sistema.

O frontend e o backend reais já comprovam partes importantes dessa direção, ainda que em estágio inicial.

Este documento fixa essa lógica e transforma a ideia genérica de “painel administrativo” em um percurso operacional claro, seguro e repetível.

---

