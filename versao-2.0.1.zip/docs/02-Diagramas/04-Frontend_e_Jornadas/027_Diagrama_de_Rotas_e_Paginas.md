
# 027_Diagrama_de_Rotas_e_Paginas

## 1. Identificação do documento

- **Projeto:** William Albarello
- **Diretório:** `02-Diagramas`
- **Caminho oficial:** `/home/user/Documents/Softwares/Willian Albarello/William Albarello/02-Diagramas/04-Frontend_e_Jornadas/027_Diagrama_de_Rotas_e_Paginas.md`
- **Natureza do documento:** Diagrama e contrato lógico de rotas, páginas e vínculos de navegação
- **Função sistêmica:** Mapear páginas públicas e privadas, rotas, hierarquias de navegação, vínculos entre páginas e coerência entre arquitetura da informação, jornadas e frontend real
- **Posição na trilha:** Terceiro documento do bloco `04-Frontend_e_Jornadas`
- **Dependências principais:** `008_Regras_de_Negocio.md`, `009_Personas_Perfis_e_Usuarios.md`, `010_Jornadas_do_Usuario_e_Fluxos_Principais.md`, `012_Estrategia_de_Conteudo_SEO_e_Publicacao.md`, `017_UI_UX_Arquitetura_da_Informacao.md` e frontend real disponível no acervo técnico

---

## 2. Objetivo

Este documento existe para formalizar o **mapa de rotas e páginas** do projeto William Albarello.

Se os documentos anteriores deste bloco já fixaram:

- a arquitetura macro do frontend;
- o mapa de componentes da UI;

este arquivo responde a outra pergunta essencial:

> por onde o usuário circula, quais páginas existem, como elas se relacionam e como a navegação pública e administrativa se organizam?

Seu objetivo é explicitar:

- as rotas públicas do sistema;
- as rotas administrativas do sistema;
- a hierarquia entre páginas;
- os vínculos de navegação entre entradas, listagens, detalhes e ações;
- a diferença entre rotas já comprovadas no frontend real e rotas soberanas esperadas pelo projeto;
- a relação entre rotas, páginas, SEO e jornadas.

Este documento não fecha:

- microinterações de navegação;
- regras finas de breadcrumbs;
- política final de redirects e aliases;
- paginação detalhada;
- comportamento exato de filtros combinados;
- controle fino de cache por rota.

Seu foco é a **estrutura navegacional soberana** do frontend.

---

## 3. Fontes de referência

Este documento deriva principalmente das seguintes bases do projeto:

- `01-Waterfall/01-Obrigatorios/008_Regras_de_Negocio.md`
- `01-Waterfall/01-Obrigatorios/009_Personas_Perfis_e_Usuarios.md`
- `01-Waterfall/01-Obrigatorios/010_Jornadas_do_Usuario_e_Fluxos_Principais.md`
- `01-Waterfall/01-Obrigatorios/012_Estrategia_de_Conteudo_SEO_e_Publicacao.md`
- `01-Waterfall/01-Obrigatorios/017_UI_UX_Arquitetura_da_Informacao.md`

Também dialoga diretamente com:

- `025_Diagrama_de_Arquitetura_do_Frontend.md`
- `026_Diagrama_de_Componentes_da_UI.md`
- o frontend real do monorepo `personal-site`
- os contratos OpenAPI público e administrativo
- os diagramas de conteúdo, estados editoriais e modelo de dados

---

## 4. Premissas e limites

## 4.1 Premissas adotadas

Para este documento, adotam-se as seguintes premissas:

- o projeto possui duas grandes superfícies de navegação:
  - **área pública**
  - **área administrativa**
- a área pública deve ser orientada por descoberta, leitura, autoridade e aproximação;
- a área administrativa deve ser orientada por autenticação, operação editorial e controle de acesso;
- o frontend real atual já comprova a existência de rotas públicas e administrativas mínimas;
- a arquitetura de informação do projeto exige páginas institucionais, editoriais e operacionais;
- nem toda página soberana do projeto já está implementada no frontend real atual;
- páginas públicas indexáveis têm responsabilidade estrutural de SEO;
- páginas administrativas têm responsabilidade estrutural de segurança e sessão.

## 4.2 Limites deste documento

Este arquivo não define:

- todas as query strings possíveis;
- árvore exata de breadcrumbs;
- regras finais de internacionalização;
- navegação por teclado em detalhe fino;
- política final de canonicalização de URLs duplicadas;
- comportamento de estados vazios em cada rota.

Seu papel é fixar o **mapa estrutural de rotas e páginas**.

## 4.3 Regra de prudência arquitetural

Há uma diferença importante entre:

- a **arquitetura de rotas correta do projeto**; e
- o **estado atual do código**, ainda parcial.

Por isso, este documento:

- reconhece as rotas reais já encontradas no frontend;
- não trata bootstrap como mapa final completo;
- também não empobrece a navegação do sistema por causa do estágio atual da implementação.

---

## 5. Tese central da navegação

A tese deste documento é a seguinte:

> o projeto William Albarello deve possuir uma navegação clara, hierárquica e semanticamente coerente, separando superfície pública de superfície administrativa e conectando páginas por intenção de uso, não apenas por conveniência técnica.

Isso significa que as rotas do sistema não devem ser tratadas como:

- arquivos soltos de página;
- caminhos sem hierarquia;
- mistura confusa entre público e admin;
- coleção de URLs sem relação clara com jornadas e conteúdos.

As rotas devem refletir a arquitetura da informação do projeto.

---

## 6. Estado real identificado no frontend

O frontend real atual já comprova fisicamente as seguintes rotas.

## 6.1 Rotas públicas comprovadas

- `/`
- `/publicacoes`
- `/publicacoes/[slug]`

Também existem rotas técnicas associadas à indexação:

- `robots.ts`
- `sitemap.ts`

## 6.2 Rotas administrativas comprovadas

- `/`
- `/painel/login`
- `/painel/publicacoes`
- `/painel/publicacoes/[id]/editar`

## 6.3 Leitura correta do estado atual

Isso comprova que o sistema já tem:

- home pública;
- listagem editorial pública;
- detalhe de publicação;
- entrada administrativa;
- login administrativo;
- listagem de publicações no painel;
- edição de publicação no painel.

Ao mesmo tempo, isso também mostra que o mapa de páginas ainda está **em estágio inicial de implementação física** quando comparado ao desenho soberano do projeto.

---

## 7. Superfícies de navegação do sistema

O mapa de rotas deve ser lido em duas superfícies principais.

## 7.1 Área pública

A área pública existe para:

- apresentar a identidade profissional;
- expor páginas institucionais;
- organizar e distribuir conteúdo;
- sustentar descoberta via busca e indexação;
- conduzir o usuário até aproximação e contato.

## 7.2 Área administrativa

A área administrativa existe para:

- autenticar operadores internos;
- governar o conteúdo;
- editar, publicar, arquivar e organizar postagens;
- administrar taxonomias;
- futuramente sustentar métricas e auditoria.

## 7.3 Regra central

As duas superfícies pertencem ao mesmo sistema, mas **não devem compartilhar a mesma navegação primária nem a mesma lógica de acesso**.

---

## 8. Mapa soberano das páginas públicas

Com base no Waterfall, na arquitetura da informação, na estratégia de conteúdo e na leitura do frontend real, o sistema deve reconhecer as seguintes famílias de páginas públicas.

## 8.1 Home

**Rota:** `/`

Função:
- ponto de entrada principal do site;
- síntese de autoridade, proposta, posicionamento e condução;
- distribuição de acesso às áreas institucionais e editoriais.

## 8.2 Página institucional “Sobre”

**Rota soberana esperada:** `/sobre`

Função:
- apresentar identidade, trajetória, contexto e legitimidade;
- aprofundar confiança e posicionamento.

## 8.3 Página institucional de atuação / expertise

**Rotas soberanas esperadas:**
- `/atuacao`
- ou `/expertise`

Função:
- organizar frentes de trabalho, competências e recortes de atuação;
- servir como ponte entre autoridade e conversão.

## 8.4 Listagem de publicações

**Rota comprovada:** `/publicacoes`

Função:
- listar o acervo editorial;
- permitir descoberta por navegação;
- futuramente sustentar filtro e refinamento.

## 8.5 Detalhe de publicação

**Rota comprovada:** `/publicacoes/[slug]`

Função:
- exibir a peça editorial individual;
- sustentar leitura longa;
- carregar metadata SEO e Open Graph por item;
- eventualmente mostrar relacionados.

## 8.6 Página de contato / aproximação

**Rota soberana esperada:** `/contato`

Função:
- converter interesse em manifestação formal;
- consolidar canais de aproximação.

## 8.7 Páginas institucionais auxiliares

Rotas soberanas possíveis, conforme evolução do projeto:

- `/projetos`
- `/cases`
- `/politica-de-privacidade`
- `/termos`
- páginas estáticas por chave de CMS institucional

---

## 9. Mapa soberano das páginas administrativas

Com base no contrato da API, no backend e no frontend real, o sistema deve reconhecer as seguintes famílias de páginas administrativas.

## 9.1 Entrada do painel

**Rota de agrupamento:** `/painel`

Função:
- raiz semântica do domínio administrativo;
- fronteira clara entre área pública e área interna.

## 9.2 Login do painel

**Rota comprovada:** `/painel/login`

Função:
- autenticar operador interno;
- criar sessão válida;
- servir como porta de entrada controlada.

## 9.3 Dashboard administrativo

**Rota soberana esperada:** `/painel`

Função:
- landing autenticada do operador;
- visão resumida do estado do sistema;
- atalhos operacionais.

**Observação:** no estágio atual do código, essa home ainda não está madura como dashboard consolidado.

## 9.4 Listagem de publicações do painel

**Rota comprovada:** `/painel/publicacoes`

Função:
- listar conteúdos editoriais;
- filtrar, buscar e acionar fluxos de edição;
- servir como centro operacional do CMS.

## 9.5 Nova publicação

**Rota soberana esperada:** `/painel/publicacoes/nova`

Função:
- iniciar a criação de nova postagem;
- abrir fluxo de edição a partir de registro novo.

## 9.6 Edição de publicação

**Rota comprovada:** `/painel/publicacoes/[id]/editar`

Função:
- editar conteúdo, taxonomia, SEO e estado editorial;
- sustentar ações como salvar, publicar, arquivar e restaurar.

## 9.7 Taxonomias administrativas

Rotas soberanas esperadas:

- `/painel/categorias`
- `/painel/tags`

Função:
- governar categorias e tags do CMS.

## 9.8 Logs / auditoria

Rota soberana esperada:

- `/painel/auditoria`

Função:
- visualizar trilha de eventos relevantes;
- sustentar governança e inspeção operacional.

## 9.9 Sessão / perfil / configuração básica

Rotas soberanas futuras possíveis:

- `/painel/perfil`
- `/painel/configuracoes`

Função:
- governar identidade do operador e preferências básicas do painel.

---

## 10. Diagrama principal — mapa macro de rotas e páginas

```mermaid
flowchart TD
    ROOT[Dominio do Sistema]

    ROOT --> PUB[Area Publica]
    ROOT --> ADM[Area Administrativa]

    PUB --> HOME[/]
    PUB --> SOBRE[/sobre]
    PUB --> ATUACAO[/atuacao ou /expertise]
    PUB --> PUBS[/publicacoes]
    PUB --> PUBDET[/publicacoes/[slug]]
    PUB --> CONTATO[/contato]
    PUB --> AUXPAGES[Paginas institucionais auxiliares]

    HOME --> PUBS
    HOME --> SOBRE
    HOME --> ATUACAO
    HOME --> CONTATO

    PUBS --> PUBDET
    PUBDET --> PUBS
    PUBDET --> RELATED[Publicacoes relacionadas]

    ADM --> PAINEL[/painel]
    ADM --> LOGIN[/painel/login]
    ADM --> APUBS[/painel/publicacoes]
    ADM --> ANOVA[/painel/publicacoes/nova]
    ADM --> AEDIT[/painel/publicacoes/[id]/editar]
    ADM --> ACAT[/painel/categorias]
    ADM --> ATAG[/painel/tags]
    ADM --> AAUD[/painel/auditoria]

    LOGIN --> PAINEL
    PAINEL --> APUBS
    APUBS --> ANOVA
    APUBS --> AEDIT
    PAINEL --> ACAT
    PAINEL --> ATAG
    PAINEL --> AAUD
````

---

## 11. Leitura executiva do diagrama

O diagrama mostra que:

1. o sistema se divide em área pública e administrativa;
2. a área pública gira em torno de:

   * home;
   * páginas institucionais;
   * listagem editorial;
   * detalhe de conteúdo;
   * contato;
3. a área administrativa gira em torno de:

   * login;
   * dashboard/entrada;
   * gestão de publicações;
   * gestão de taxonomia;
   * auditoria;
4. a listagem pública leva ao detalhe;
5. a listagem administrativa leva à criação e edição;
6. a raiz `/painel` funciona como fronteira semântica de segurança e operação.

---

## 12. Hierarquia de navegação pública

A navegação pública do projeto deve ser lida em níveis.

## 12.1 Nível 1 — entrada e reconhecimento

Páginas:

* `/`
* `/sobre`
* `/atuacao` ou equivalente

Função:

* posicionar;
* construir confiança;
* orientar o usuário.

## 12.2 Nível 2 — exploração de conteúdo

Páginas:

* `/publicacoes`
* `/publicacoes/[slug]`

Função:

* distribuir e aprofundar a leitura;
* sustentar descoberta;
* materializar autoridade editorial.

## 12.3 Nível 3 — aproximação

Páginas:

* `/contato`
* CTAs espalhados ao longo da navegação

Função:

* transformar interesse em ação.

## 12.4 Regra de navegação pública

O usuário público deve conseguir, com baixa fricção:

* entender quem é o projeto;
* navegar pelo acervo;
* mergulhar em um conteúdo;
* encontrar caminho de contato.

---

## 13. Hierarquia de navegação administrativa

A navegação administrativa do projeto também deve ser lida em níveis.

## 13.1 Nível 1 — autenticação

Páginas:

* `/painel/login`

Função:

* estabelecer identidade válida;
* proteger a operação.

## 13.2 Nível 2 — entrada operacional

Páginas:

* `/painel`

Função:

* concentrar visão inicial do painel;
* servir como hub autenticado.

## 13.3 Nível 3 — gestão editorial

Páginas:

* `/painel/publicacoes`
* `/painel/publicacoes/nova`
* `/painel/publicacoes/[id]/editar`

Função:

* sustentar o núcleo operacional do CMS.

## 13.4 Nível 4 — governança

Páginas:

* `/painel/categorias`
* `/painel/tags`
* `/painel/auditoria`

Função:

* organizar taxonomia;
* sustentar rastreabilidade;
* ampliar maturidade de operação.

---

## 14. Rotas técnicas e rotas de suporte à indexação

Além das páginas visíveis ao usuário, o projeto já possui e deve preservar rotas técnicas importantes.

## 14.1 `robots`

Função:

* orientar crawlers;
* estruturar comportamento de indexação.

## 14.2 `sitemap`

Função:

* estruturar descoberta programática das páginas públicas;
* apoiar SEO técnico.

## 14.3 Metadata dinâmica por página

Função:

* atribuir título, descrição, canonical, Open Graph e demais metadados por rota.

## 14.4 Regra importante

Esses artefatos técnicos não são páginas de navegação humana, mas **fazem parte da arquitetura de rotas do frontend público**.

---

## 15. Relação entre rotas e SEO

A área pública do projeto depende fortemente de rotas semanticamente corretas.

Isso significa que:

* `/publicacoes/[slug]` precisa ser estável e legível;
* páginas institucionais devem ter paths limpos;
* listagens precisam ser rastreáveis;
* metadata por rota precisa refletir o conteúdo daquela página;
* rotas canônicas devem ser preferidas a aliases dispersos.

## 15.1 Regra central

Em páginas públicas indexáveis, URL é parte do produto editorial.

---

## 16. Relação entre rotas e personas

O documento de personas e jornadas implica uma correspondência direta entre perfil de usuário e superfície navegada.

## 16.1 Visitante público

Principais entradas:

* home;
* publicações;
* detalhe de publicação;
* contato.

## 16.2 Operador/admin

Principais entradas:

* login;
* painel;
* publicações;
* edição;
* taxonomia;
* auditoria.

## 16.3 Regra importante

O sistema deve reduzir ao máximo o cruzamento indevido entre jornada pública e jornada administrativa.

---

## 17. Relação entre rotas e estados de acesso

As páginas do sistema não são todas equivalentes em termos de acesso.

## 17.1 Rotas públicas

Devem ser:

* abertas;
* indexáveis quando apropriado;
* acessíveis sem autenticação.

## 17.2 Rotas administrativas autenticadas

Devem ser:

* protegidas por sessão válida;
* não indexáveis;
* inacessíveis ao usuário não autenticado.

## 17.3 Rota administrativa de login

É pública em nível de acesso de rede, mas funcionalmente pertence à superfície privada.

## 17.4 Regra de fronteira

Toda rota abaixo de `/painel`, exceto login e eventuais páginas técnicas equivalentes, deve ser tratada como **rota protegida**.

---

## 18. Compatibilização com o frontend real atual

O frontend real atual já sustenta parte importante deste mapa:

### Comprovado fisicamente

* `/`
* `/publicacoes`
* `/publicacoes/[slug]`
* `/painel/login`
* `/painel/publicacoes`
* `/painel/publicacoes/[id]/editar`

### Soberano, mas ainda não plenamente materializado

* `/sobre`
* `/atuacao`
* `/contato`
* `/painel`
* `/painel/publicacoes/nova`
* `/painel/categorias`
* `/painel/tags`
* `/painel/auditoria`

Essa leitura é importante porque evita dois erros:

* dizer que tudo já existe no código;
* reduzir o projeto apenas ao que já foi codificado.

---

## 19. Diagrama complementar — navegação pública detalhada

```mermaid
flowchart LR
    H[Home /] --> S[Sobre]
    H --> A[Atuacao]
    H --> L[Listagem de Publicacoes]
    H --> C[Contato]

    L --> D[Detalhe da Publicacao]
    D --> R[Relacionadas]
    R --> D2[Outro detalhe]
    D --> L
    S --> C
    A --> C
```

---

## 20. Leitura da navegação pública detalhada

Esse fluxo mostra a jornada pública principal:

1. a home distribui o usuário;
2. páginas institucionais aprofundam confiança;
3. a listagem editorial abre exploração;
4. o detalhe editorial sustenta leitura;
5. a navegação pode seguir para conteúdos relacionados;
6. o contato funciona como destino de aproximação.

---

## 21. Diagrama complementar — navegação administrativa detalhada

```mermaid
flowchart LR
    LG[Login /painel/login] --> DB[Painel /painel]
    DB --> LP[Listagem /painel/publicacoes]
    LP --> NP[Nova publicacao]
    LP --> EP[Editar publicacao]
    DB --> CAT[Categorias]
    DB --> TAG[Tags]
    DB --> AUD[Auditoria]
    EP --> LP
    NP --> EP
```

---

## 22. Leitura da navegação administrativa detalhada

Esse fluxo mostra a jornada administrativa principal:

1. o operador entra por login;
2. chega ao painel autenticado;
3. do painel, entra no núcleo editorial;
4. da listagem, pode:

   * criar nova publicação;
   * editar publicação existente;
5. o painel também deve centralizar taxonomia e auditoria.

---

## 23. Regras macro de integridade do mapa de rotas

## 23.1 RI-RT-01

A área pública e a área administrativa devem manter separação clara de paths e propósito.

## 23.2 RI-RT-02

Rotas públicas indexáveis devem possuir URLs semânticas, estáveis e legíveis.

## 23.3 RI-RT-03

Rotas administrativas protegidas devem estar subordinadas a uma raiz semântica explícita, preferencialmente `/painel`.

## 23.4 RI-RT-04

A listagem pública de publicações deve levar ao detalhe por slug.

## 23.5 RI-RT-05

A listagem administrativa de publicações deve levar a criação e edição.

## 23.6 RI-RT-06

Rotas técnicas de SEO, como `robots` e `sitemap`, fazem parte da arquitetura de páginas do frontend público.

## 23.7 RI-RT-07

Rotas soberanas do projeto podem existir documentalmente antes de sua implementação física, desde que estejam coerentes com a arquitetura da informação.

## 23.8 RI-RT-08

Toda rota administrativa sensível deve pressupor autenticação válida e comportamento seguro de sessão.

---

## 24. Decisões arquiteturais implícitas neste documento

Este documento fixa, em nível macro, as seguintes decisões:

1. o sistema possui duas árvores navegacionais principais;
2. a raiz pública é orientada por identidade, conteúdo e aproximação;
3. a raiz administrativa é orientada por autenticação e CMS;
4. `/publicacoes` e `/publicacoes/[slug]` são eixos centrais da navegação editorial pública;
5. `/painel/publicacoes` e `/painel/publicacoes/[id]/editar` são eixos centrais da navegação editorial administrativa;
6. o projeto admite rotas soberanas ainda não plenamente implementadas;
7. a navegação é subordinada à arquitetura da informação, não apenas à existência atual dos arquivos no código.

---

## 25. Riscos que este documento evita

### 25.1 Mistura entre público e admin

Evita navegação confusa entre área aberta e área protegida.

### 25.2 Crescimento caótico de URLs

Evita rotas surgindo sem hierarquia clara.

### 25.3 Jornada pública quebrada

Evita site em que o usuário entra, lê algo e não sabe para onde seguir.

### 25.4 Jornada administrativa incompleta

Evita painel sem fluxo inteligível entre login, listagem, criação e edição.

### 25.5 SEO prejudicado

Evita rotas públicas sem semântica, sem estabilidade e sem legibilidade editorial.

### 25.6 Documentação refém do código incompleto

Evita empobrecer o mapa do sistema ao estágio atual do scaffold.

---

## 26. Critérios de aceite deste documento

Este documento será considerado aceito quando:

* mapear claramente as páginas e rotas públicas e administrativas;
* distinguir rotas comprovadas das rotas soberanas esperadas;
* explicitar hierarquia de navegação;
* alinhar o mapa à arquitetura da informação, jornadas e conteúdo/SEO;
* dialogar com o frontend real existente;
* servir como base para os próximos documentos de jornadas detalhadas e fluxos do frontend.

---

## 27. Conclusão executiva

O projeto William Albarello exige um mapa de páginas e rotas que seja:

* claro para o usuário;
* coerente para a arquitetura;
* útil para SEO;
* seguro para a operação administrativa.

Esse mapa, no estado correto do projeto, se organiza em:

* **área pública**, com home, páginas institucionais, listagem editorial, detalhe de publicação e contato;
* **área administrativa**, com login, painel, gestão de publicações, taxonomia e auditoria;
* **rotas técnicas**, que sustentam indexação e governança de descoberta.

O frontend real já comprova parte importante desse desenho, ainda que de forma inicial.

Este documento fixa esse mapa e prepara o terreno para aprofundar, nos próximos arquivos, as jornadas detalhadas dos usuários e os fluxos de navegação por intenção de uso.

---

