
# 026_Diagrama_de_Componentes_da_UI

## 1. Identificação do documento

- **Projeto:** William Albarello
- **Diretório:** `02-Diagramas`
- **Caminho oficial:** `/home/user/Documents/Softwares/Willian Albarello/William Albarello/02-Diagramas/04-Frontend_e_Jornadas/026_Diagrama_de_Componentes_da_UI.md`
- **Natureza do documento:** Diagrama e contrato lógico dos componentes da interface
- **Função sistêmica:** Mapear os componentes visuais e funcionais da UI, sua hierarquia, agrupamentos, reuso, composição e responsabilidades nas superfícies pública e administrativa
- **Posição na trilha:** Segundo documento do bloco `04-Frontend_e_Jornadas`
- **Dependências principais:** `010_Jornadas_do_Usuario_e_Fluxos_Principais.md`, `011_Arquitetura_Geral_do_Sistema.md`, `017_UI_UX_Arquitetura_da_Informacao.md`, frontend real disponível no acervo técnico e eventuais prints de telas

---

## 2. Objetivo

Este documento existe para formalizar o **mapa de componentes da UI** do projeto William Albarello.

Se o documento `025_Diagrama_de_Arquitetura_do_Frontend.md` fixou a arquitetura macro do frontend, este arquivo responde a outra pergunta essencial:

> de quais componentes a interface é feita, como eles se agrupam e quais responsabilidades cabem a cada camada visual/funcional?

Seu objetivo é explicitar:

- as famílias de componentes da superfície pública;
- as famílias de componentes da superfície administrativa;
- os componentes compartilháveis entre ambas;
- a hierarquia entre layout, seção, bloco e primitive;
- as regras de composição;
- os limites de reuso;
- as responsabilidades visuais e funcionais de cada agrupamento.

Este documento não fecha:

- design final de cada componente;
- biblioteca visual definitiva;
- tokens completos de design system;
- especificação final de espaçamento, motion e responsividade fina;
- regras completas de theming.

Seu foco é a **anatomia estrutural da UI**.

---

## 3. Fontes de referência

Este documento deriva principalmente das seguintes bases do projeto:

- `01-Waterfall/01-Obrigatorios/010_Jornadas_do_Usuario_e_Fluxos_Principais.md`
- `01-Waterfall/01-Obrigatorios/011_Arquitetura_Geral_do_Sistema.md`
- `01-Waterfall/01-Obrigatorios/017_UI_UX_Arquitetura_da_Informacao.md`

Também dialoga diretamente com:

- `025_Diagrama_de_Arquitetura_do_Frontend.md`
- frontend real do monorepo `personal-site`
- `apps/web`
- `apps/admin`
- `packages/ui`
- eventuais prints e wireframes anexados ao projeto, quando existirem

---

## 4. Premissas e limites

## 4.1 Premissas adotadas

Para este documento, adotam-se as seguintes premissas:

- o projeto possui duas superfícies principais de UI:
  - pública;
  - administrativa;
- a camada pública exige componentes orientados a leitura, autoridade, escaneabilidade e descoberta;
- a camada administrativa exige componentes orientados a operação, edição, feedback, status e segurança;
- o acervo técnico atual já comprova a existência de:
  - layouts base;
  - páginas públicas mínimas;
  - telas administrativas iniciais;
  - pacote compartilhado `packages/ui`, ainda embrionário;
- o sistema deve caminhar para reuso consistente, mas **sem forçar reuso artificial** entre contextos muito diferentes;
- a UI deve ser pensada em camadas, e não como páginas monolíticas.

## 4.2 Limites deste documento

Este arquivo não define:

- todas as props de cada componente;
- convenção final de nomes em código;
- padrão final de composição server/client component;
- biblioteca de ícones;
- grid system detalhado;
- microestados de hover/focus/active em nível pixel.

Seu papel é fixar o **modelo organizacional dos componentes**.

## 4.3 Regra de prudência arquitetural

Há uma diferença importante entre:

- a **UI soberana do projeto**; e
- o **estado atual do frontend real**, que ainda está em implementação inicial.

Por isso, este documento:

- reconhece o que já existe fisicamente no código;
- não trata placeholders como se fossem UI madura;
- também não empobrece a modelagem só porque a implementação ainda está começando.

---

## 5. Tese central da UI do projeto

A tese deste documento é a seguinte:

> a UI do projeto William Albarello deve ser construída como um sistema de componentes em camadas, no qual layouts, blocos, componentes compostos e primitives se organizam de modo claro, reutilizável e semanticamente coerente com cada superfície de uso.

Isso significa que a interface não deve ser tratada como:

- páginas independentes sem padrão;
- componentes duplicados por conveniência;
- reuso excessivo que destrói clareza de contexto;
- blocos visuais sem responsabilidade funcional explícita.

A UI deve operar como um **sistema**, não como coleção de trechos soltos.

---

## 6. Leitura do estado real encontrado no frontend

O frontend real atual já mostra os seguintes sinais importantes:

### 6.1 No `apps/web`
Já existem páginas base para:

- home;
- listagem de publicações;
- detalhe de publicação;
- layout público;
- metadata base;
- `robots.ts`;
- `sitemap.ts`.

### 6.2 No `apps/admin`
Já existem páginas base para:

- home administrativa mínima;
- login do painel;
- listagem de publicações;
- edição de publicação;
- layout administrativo.

### 6.3 No `packages/ui`
Hoje existe apenas um núcleo mínimo, ainda sem biblioteca visual expandida.

Isso significa que:

- a **arquitetura de UI existe em intenção**;
- o **pacote compartilhado existe fisicamente**;
- a **biblioteca visual ainda não está madura**.

Essa leitura reforça a necessidade deste documento.

---

## 7. Camadas de componentes da UI

A organização correta dos componentes da UI do projeto deve ser lida em cinco níveis.

## 7.1 Nível 1 — primitives

São os menores blocos reutilizáveis.

Exemplos esperados:

- `Button`
- `Input`
- `Textarea`
- `Select`
- `Checkbox`
- `Badge`
- `Card`
- `Table`
- `Modal`
- `Alert`
- `EmptyState`
- `LoadingState`
- `ErrorState`

Função:
fornecer base visual e semântica consistente.

## 7.2 Nível 2 — componentes de formulário e feedback

São composições pequenas orientadas a interação.

Exemplos esperados:

- `LoginForm`
- `FieldGroup`
- `SeoFieldset`
- `CategorySelect`
- `TagMultiSelect`
- `StatusBadge`
- `ActionBar`
- `ToastFeedback`
- `ConfirmDialog`

Função:
encapsular padrões recorrentes de input, validação e retorno ao usuário.

## 7.3 Nível 3 — componentes de bloco

São blocos de UI com significado funcional claro dentro de uma tela.

Exemplos esperados:

- `HeroInstitucional`
- `PublicationList`
- `PublicationCard`
- `PublicationHeader`
- `PublicationBody`
- `ContactSection`
- `AdminPublicationsTable`
- `PublicationEditorPanel`
- `PublicationMetadataPanel`
- `SeoPanel`
- `SidebarPainel`

Função:
agrupar primitives e subcomponentes em blocos compreensíveis.

## 7.4 Nível 4 — seções e shells

São estruturas maiores que organizam a experiência de uma rota ou área.

Exemplos esperados:

- `PublicSiteShell`
- `AdminShell`
- `HomeSections`
- `PublicacoesPageSection`
- `PublicationDetailSection`
- `LoginPageShell`
- `PainelPublicacoesSection`
- `EditarPublicacaoSection`

Função:
definir o esqueleto da experiência.

## 7.5 Nível 5 — páginas

São os destinos navegáveis finais.

Exemplos já comprovados no código:

- `/`
- `/publicacoes`
- `/publicacoes/[slug]`
- `/painel/login`
- `/painel/publicacoes`
- `/painel/publicacoes/[id]/editar`

Função:
orquestrar tudo o que está abaixo.

---

## 8. Diagrama principal — mapa macro de componentes da UI

```mermaid
flowchart TD
    UI[UI do Sistema]

    UI --> PUB[Superficie Publica]
    UI --> ADM[Superficie Administrativa]
    UI --> SHR[Camada Compartilhada]

    PUB --> PSL[PublicSiteLayout]
    PSL --> PH[PublicHeader]
    PSL --> PM[PublicMain]
    PSL --> PF[PublicFooter]

    PM --> HOME[HomePage]
    PM --> PLIST[PublicacoesPage]
    PM --> PDETAIL[PublicacaoDetalhePage]
    PM --> PCONTACT[ContatoSection]

    HOME --> HERO[HeroInstitucional]
    HOME --> HIGHLIGHTS[HighlightsSection]
    HOME --> CTA[CTASection]

    PLIST --> FILTERS[FiltrosPublicacoes]
    PLIST --> PUBLIST[PublicationList]
    PUBLIST --> PUBCARD[PublicationCard]

    PDETAIL --> PHEADER[PublicationHeader]
    PDETAIL --> PBODY[PublicationBody]
    PDETAIL --> PRELATED[RelatedPublications]

    ADM --> ASL[AdminLayout]
    ASL --> AHEAD[AdminHeader]
    ASL --> ASIDEBAR[AdminSidebar]
    ASL --> AMAIN[AdminMain]

    AMAIN --> LOGIN[LoginPage]
    AMAIN --> APUBS[PainelPublicacoesPage]
    AMAIN --> AEDIT[EditarPublicacaoPage]

    LOGIN --> LOGINFORM[LoginForm]

    APUBS --> TOOLBAR[ToolbarPublicacoes]
    APUBS --> TABLE[AdminPublicationsTable]
    APUBS --> STATUSBADGE[StatusBadge]

    AEDIT --> EDITFORM[PublicationEditorForm]
    AEDIT --> METAPANEL[PublicationMetadataPanel]
    AEDIT --> SEOPANEL[SeoPanel]
    AEDIT --> TAXPANEL[TaxonomyPanel]
    AEDIT --> ACTIONBAR[ActionBar]

    SHR --> PRIMS[Primitives]
    SHR --> FEEDBACK[Feedback e Estados]
    SHR --> FORM[Inputs e Form Controls]

    PRIMS --> BTN[Button]
    PRIMS --> CARD[Card]
    PRIMS --> BADGE[Badge]
    PRIMS --> TABLEBASE[Table]
    PRIMS --> MODAL[Modal]

    FORM --> INPUT[Input]
    FORM --> TEXTAREA[Textarea]
    FORM --> SELECT[Select]
    FORM --> CHECKBOX[Checkbox]

    FEEDBACK --> EMPTY[EmptyState]
    FEEDBACK --> LOADING[LoadingState]
    FEEDBACK --> ERROR[ErrorState]
    FEEDBACK --> ALERT[Alert/Toast]
````

---

## 9. Leitura executiva do diagrama

O diagrama mostra que a UI do sistema se organiza em três grandes domínios:

### 9.1 Superfície pública

Voltada para leitura, descoberta, autoridade e aproximação.

### 9.2 Superfície administrativa

Voltada para login, operação editorial, edição e governança.

### 9.3 Camada compartilhada

Voltada para primitives, inputs e estados reutilizáveis.

A leitura correta é:

* páginas não devem construir tudo do zero;
* blocos maiores devem compor subblocos menores;
* o reuso saudável deve acontecer principalmente nas camadas compartilhadas e nos padrões recorrentes;
* componentes de contexto específico devem permanecer especializados.

---

## 10. Componentes da superfície pública

## 10.1 Natureza da UI pública

A UI pública deve privilegiar:

* legibilidade;
* hierarquia visual clara;
* escaneabilidade;
* autoridade;
* densidade sem ruído;
* consistência editorial.

## 10.2 Famílias macro de componentes públicos

### Estruturais

* `PublicSiteLayout`
* `PublicHeader`
* `PublicFooter`
* `PublicMain`

### Institucionais

* `HeroInstitucional`
* `HighlightsSection`
* `CTASection`
* `ContactSection`

### Editoriais

* `PublicationList`
* `PublicationCard`
* `PublicationHeader`
* `PublicationBody`
* `RelatedPublications`
* `Breadcrumb`, quando aplicável

### Técnicos/SEO

* metadata por página
* Open Graph helpers
* sitemap/robots generators
* componentes auxiliares de schema, quando aplicável

## 10.3 Regra de composição da camada pública

A camada pública deve ser construída de fora para dentro:

* layout;
* seções;
* blocos editoriais/institucionais;
* primitives.

Não ao contrário.

---

## 11. Componentes da superfície administrativa

## 11.1 Natureza da UI administrativa

A UI administrativa deve privilegiar:

* clareza operacional;
* leitura rápida;
* baixa ambiguidade;
* estados explícitos;
* feedback confiável;
* consistência entre listagem e edição.

## 11.2 Famílias macro de componentes administrativos

### Estruturais

* `AdminLayout`
* `AdminHeader`
* `AdminSidebar`
* `AdminMain`

### Autenticação

* `LoginForm`
* `SessionGuard`, quando aplicável
* `LogoutAction`

### Operação editorial

* `AdminPublicationsTable`
* `PublicationRow`
* `StatusBadge`
* `ToolbarPublicacoes`
* `FiltersPanel`

### Edição de conteúdo

* `PublicationEditorForm`
* `PublicationMetadataPanel`
* `SeoPanel`
* `TaxonomyPanel`
* `ActionBar`

### Feedback operacional

* `ToastFeedback`
* `ConfirmDialog`
* `LoadingState`
* `EmptyState`
* `ErrorState`

## 11.3 Regra de composição da camada admin

No painel, componentes precisam mostrar:

* o que está acontecendo;
* o que pode ser feito;
* o que deu certo;
* o que deu errado;
* o que está bloqueado.

UI administrativa sem feedback explícito é UI fraca.

---

## 12. Camada compartilhada de UI

## 12.1 Função da camada compartilhada

A camada compartilhada existe para consolidar base visual e semântica comum, sem forçar identidade visual idêntica em tudo.

Ela deve concentrar principalmente:

* primitives;
* inputs;
* estados vazios/carregamento/erro;
* feedback genérico;
* eventualmente helpers de composição simples.

## 12.2 O que deve ir para `packages/ui`

É inteligente que `packages/ui` concentre, prioritariamente:

* `Button`
* `Input`
* `Textarea`
* `Select`
* `Checkbox`
* `Badge`
* `Card`
* `Table`
* `Modal`
* `Alert`
* `EmptyState`
* `LoadingState`
* `ErrorState`

## 12.3 O que não deve ir cedo demais para `packages/ui`

Não é inteligente empacotar cedo demais componentes excessivamente específicos, como:

* `HeroInstitucional` completo;
* `PublicationEditorForm` inteiro;
* `PainelPublicacoesSection` inteiro.

Esses blocos pertencem mais ao domínio de cada app do que ao núcleo compartilhado.

---

## 13. Hierarquia e regra de responsabilidade

A UI deve obedecer à seguinte hierarquia de responsabilidade:

## 13.1 Páginas

Responsáveis por orquestrar.

Não devem concentrar lógica visual repetitiva.

## 13.2 Seções e shells

Responsáveis por estruturar a experiência.

Não devem carregar excesso de detalhe de primitive.

## 13.3 Blocos compostos

Responsáveis por resolver uma necessidade clara de interface.

Exemplo:

* card de publicação;
* formulário de login;
* tabela de publicações;
* painel SEO.

## 13.4 Primitives

Responsáveis por consistência visual e semântica.

Não devem carregar regras de negócio pesadas.

---

## 14. Reuso saudável x reuso tóxico

## 14.1 Reuso saudável

Acontece quando o componente é:

* semanticamente genérico;
* visualmente consistente;
* reutilizável sem perder clareza;
* pouco dependente de contexto.

Exemplos:

* `Button`
* `Input`
* `Badge`
* `Card`
* `LoadingState`

## 14.2 Reuso tóxico

Acontece quando se tenta reutilizar o que deveria continuar especializado.

Exemplos de risco:

* usar o mesmo “card” para comunicação institucional e para linha de administração sem adaptação;
* tentar transformar todo formulário do admin em componente global compartilhado;
* misturar shells públicos e administrativos.

## 14.3 Regra do projeto

Compartilhar o que é base.
Especializar o que é contexto.

---

## 15. Estados visuais e componentes de feedback

A UI do projeto precisa tratar estado como parte estrutural da interface.

## 15.1 Estados mínimos da UI

O próprio acervo técnico já sugere uma taxonomia mínima válida:

* `idle`
* `loading`
* `success`
* `error`

## 15.2 Componentes correspondentes

Essa taxonomia deve se refletir em componentes como:

* `LoadingState`
* `EmptyState`
* `ErrorState`
* `Alert/Toast`
* `InlineValidationMessage`

## 15.3 Regra importante

Estado não deve ser espalhado como texto improvisado em cada tela.

Ele deve ser representado por padrões de UI reconhecíveis.

---

## 16. Componentes de formulário

## 16.1 Papel dos formulários no projeto

Formulários são centrais em dois pontos:

* login administrativo;
* edição/publicação de conteúdo.

## 16.2 Famílias de componentes de formulário

### Base

* `Input`
* `Textarea`
* `Select`
* `Checkbox`

### Compostas

* `FieldGroup`
* `FieldLabel`
* `FieldHint`
* `FieldError`
* `FormSection`
* `SeoFieldset`
* `TaxonomyFieldset`

### Contextuais

* `LoginForm`
* `PublicationEditorForm`

## 16.3 Regra arquitetural

Campos base podem ser compartilhados.
Formulários completos devem permanecer contextuais.

---

## 17. Componentes editoriais

A camada editorial pública e administrativa exige componentes próprios.

## 17.1 No público

* `PublicationCard`
* `PublicationList`
* `PublicationHeader`
* `PublicationBody`
* `RelatedPublications`

## 17.2 No admin

* `AdminPublicationsTable`
* `PublicationRow`
* `StatusBadge`
* `PublicationEditorForm`
* `PublicationMetadataPanel`
* `SeoPanel`
* `TaxonomyPanel`

## 17.3 Justificativa

O domínio “publicação” é central no projeto.
Logo, ele precisa de uma família de componentes explícita, não dispersa.

---

## 18. Componentes institucionais

Além do editorial, o projeto possui componente institucional forte.

Famílias esperadas:

* `HeroInstitucional`
* `HighlightsSection`
* `AuthoritySection`
* `CTASection`
* `ContactSection`

Esses componentes têm função de:

* posicionamento;
* confiança;
* condução;
* narrativa da autoridade profissional.

Eles pertencem principalmente à camada pública.

---

## 19. Componentes de shell e navegação

## 19.1 Público

Componentes esperados:

* `PublicHeader`
* `PublicFooter`
* `NavPrincipal`
* `Breadcrumb`, quando aplicável

## 19.2 Admin

Componentes esperados:

* `AdminHeader`
* `AdminSidebar`
* `AdminNav`
* `SessionStatusIndicator`

## 19.3 Regra importante

Navegação pública e navegação administrativa não devem compartilhar o mesmo shell principal.

---

## 20. Compatibilização com o frontend real atual

O frontend real atual ainda está em fase inicial, mas ele já comprova coerência com este documento:

### No público

* `layout.tsx`
* `page.tsx`
* `publicacoes/page.tsx`
* `publicacoes/[slug]/page.tsx`

### No admin

* `layout.tsx`
* `painel/login/page.tsx`
* `painel/publicacoes/page.tsx`
* `painel/publicacoes/[id]/editar/page.tsx`

Esses arquivos já indicam claramente a necessidade de famílias de componentes como:

* layout público;
* layout admin;
* formulário de login;
* listagem de publicações;
* editor de publicação;
* componentes editoriais de leitura.

Ou seja:
a implementação ainda está rala, mas a estrutura certa do sistema já está visível.

---

## 21. Diagrama complementar — hierarquia de composição

```mermaid
flowchart TD
    PAGE[Page] --> SHELL[Shell / Section]
    SHELL --> BLOCK[Blocos Compostos]
    BLOCK --> SUB[Subcomponentes]
    SUB --> PRIM[Primitives]

    PAGE --> STATE[Estados de pagina]
    BLOCK --> FEED[Feedback / Validacao]
    SUB --> FORM[Inputs / Controls]
```

---

## 22. Leitura do diagrama complementar

Esse fluxo mostra a regra correta de construção:

1. a página orquestra;
2. o shell organiza;
3. os blocos resolvem necessidades funcionais;
4. subcomponentes quebram complexidade;
5. primitives sustentam consistência;
6. estados e feedback atravessam toda a composição.

---

## 23. Regras macro de integridade da camada de componentes

## 23.1 RI-UI-01

Todo componente deve ter responsabilidade clara.

## 23.2 RI-UI-02

Primitives compartilhadas não devem carregar regra de negócio pesada.

## 23.3 RI-UI-03

Componentes contextuais não devem ser empacotados como genéricos sem necessidade real.

## 23.4 RI-UI-04

A camada pública e a administrativa devem ter famílias próprias de componentes.

## 23.5 RI-UI-05

Estados de carregamento, vazio, erro e sucesso devem possuir representação visual consistente.

## 23.6 RI-UI-06

Formulários complexos devem ser compostos a partir de campos base e fieldsets contextuais.

## 23.7 RI-UI-07

A hierarquia página > shell > bloco > primitive deve ser preservada.

## 23.8 RI-UI-08

Reuso só é válido quando não destrói legibilidade de contexto.

---

## 24. Decisões arquiteturais implícitas neste documento

Este documento fixa, em nível macro, as seguintes decisões:

1. a UI do projeto será organizada como sistema de componentes;
2. haverá distinção clara entre primitives, blocos compostos, shells e páginas;
3. a superfície pública e a administrativa terão famílias próprias de componentes;
4. `packages/ui` deve concentrar base compartilhável, não tudo indiscriminadamente;
5. o domínio editorial exige família explícita de componentes;
6. feedback e estados fazem parte da arquitetura visual, não são detalhes tardios;
7. a composição deve ser previsível, escalável e compatível com a evolução do monorepo.

---

## 25. Riscos que este documento evita

### 25.1 Duplicação caótica

Evita reescrever os mesmos componentes em múltiplos apps.

### 25.2 Reuso artificial

Evita transformar tudo em “componente genérico” sem sentido.

### 25.3 Páginas monolíticas

Evita telas enormes com markup e lógica misturados.

### 25.4 Admin fraco visualmente

Evita painel sem feedback, sem badges e sem estados legíveis.

### 25.5 Público sem hierarquia

Evita site institucional montado como texto solto sem blocos claros.

### 25.6 Biblioteca compartilhada mal desenhada

Evita inflar `packages/ui` com componentes contextuais cedo demais.

---

## 26. Critérios de aceite deste documento

Este documento será considerado aceito quando:

* representar claramente as famílias de componentes da UI;
* distinguir componentes públicos, administrativos e compartilhados;
* explicar hierarquia, composição e responsabilidade;
* dialogar com o frontend real já existente;
* estabelecer regra de reuso saudável;
* servir como base para implementação progressiva da biblioteca visual e das telas.

---

## 27. Conclusão executiva

A UI do projeto William Albarello não deve crescer por improviso página a página.

Ela precisa de uma gramática visual e funcional.

Essa gramática, no estado correto do projeto, se organiza em:

* **primitives**, para base consistente;
* **componentes compostos**, para interação e blocos funcionais;
* **seções e shells**, para estruturar a experiência;
* **páginas**, para orquestrar rotas e jornadas;
* **famílias especializadas**, para o público e para o admin.

O frontend real já aponta nessa direção, ainda que de forma inicial.

Este documento fixa esse mapa e prepara o terreno para aprofundar, nos próximos arquivos, a navegação, as rotas, as jornadas e os fluxos detalhados do frontend.

---

