
# 025_Diagrama_de_Arquitetura_do_Frontend

## 1. Identificação do documento

- **Projeto:** William Albarello
- **Diretório:** `02-Diagramas`
- **Caminho oficial:** `/home/user/Documents/Softwares/Willian Albarello/William Albarello/02-Diagramas/04-Frontend_e_Jornadas/025_Diagrama_de_Arquitetura_do_Frontend.md`
- **Natureza do documento:** Diagrama e contrato lógico da arquitetura do frontend
- **Função sistêmica:** Mostrar a organização macro do frontend, suas superfícies pública e administrativa, blocos de páginas, camadas de UI, rotas, estado, consumo de dados e integração com o backend
- **Posição na trilha:** Primeiro documento do bloco `04-Frontend_e_Jornadas`
- **Dependências principais:** `008_Regras_de_Negocio.md`, `010_Jornadas_do_Usuario_e_Fluxos_Principais.md`, `011_Arquitetura_Geral_do_Sistema.md`, `014_Integracoes_e_Sistemas_Externos.md`, `017_UI_UX_Arquitetura_da_Informacao.md` e frontend real disponível no acervo técnico

---

## 2. Objetivo

Este documento existe para formalizar a **arquitetura macro do frontend** do projeto William Albarello.

Se os blocos anteriores do Diretório 02 já fixaram:

- contexto e arquitetura geral;
- backend e API;
- dados e persistência;

este arquivo responde a outra pergunta essencial:

> como a camada de frontend se organiza para transformar conteúdo, rotas, estados, contratos e jornadas em experiência pública e administrativa coerente?

Seu objetivo é explicitar:

- quais superfícies compõem o frontend;
- como páginas, layouts e componentes se organizam;
- como o frontend consome a API pública e a API administrativa;
- onde vivem estado, navegação e renderização;
- como a arquitetura atual do monorepo conversa com a arquitetura soberana do projeto;
- quais são as responsabilidades do frontend público e do frontend administrativo.

Este documento não fecha:

- pixel perfect final;
- biblioteca completa de componentes;
- implementação final de estado global;
- comportamento detalhado de cada tela;
- performance budget fino por rota;
- motion design e microinterações.

Seu foco é a **arquitetura estrutural do frontend**.

---

## 3. Fontes de referência

Este documento deriva principalmente das seguintes bases já consolidadas no projeto:

- `01-Waterfall/01-Obrigatorios/008_Regras_de_Negocio.md`
- `01-Waterfall/01-Obrigatorios/010_Jornadas_do_Usuario_e_Fluxos_Principais.md`
- `01-Waterfall/01-Obrigatorios/011_Arquitetura_Geral_do_Sistema.md`
- `01-Waterfall/01-Obrigatorios/014_Integracoes_e_Sistemas_Externos.md`
- `01-Waterfall/01-Obrigatorios/017_UI_UX_Arquitetura_da_Informacao.md`

Também dialoga diretamente com:

- contratos OpenAPI público e administrativo;
- frontend real do monorepo `personal-site`;
- packages compartilhados `ui` e `contracts`;
- backend Fastify atual;
- diagramas já gerados de backend, API e persistência.

---

## 4. Premissas e limites

## 4.1 Premissas adotadas

Para este documento, adotam-se as seguintes premissas:

- o projeto possui uma **superfície pública** e uma **superfície administrativa**;
- a experiência pública é orientada por conteúdo, autoridade e descoberta;
- a experiência administrativa é orientada por operação editorial, autenticação e governança;
- o acervo técnico atual já materializa essa separação em dois apps frontend:
  - `apps/web`
  - `apps/admin`
- ambos os apps usam **Next.js + TypeScript + App Router**;
- o frontend deve conversar com uma API externa dedicada;
- o frontend público deve privilegiar renderização favorável a SEO e leitura;
- o frontend administrativo deve privilegiar clareza operacional, segurança e baixa ambiguidade;
- o monorepo já prevê pacotes compartilhados para contratos e UI.

## 4.2 Limites deste documento

Este arquivo não congela:

- se a separação física entre `web` e `admin` permanecerá definitiva em todos os ciclos;
- se haverá BFF adicional no futuro;
- se a camada de estado global será local, contextual ou por biblioteca externa;
- a estratégia final de cache por rota;
- a biblioteca final de componentes visuais.

Seu papel é fixar a **arquitetura lógica soberana**, não todos os detalhes finos de implementação.

## 4.3 Regra de prudência arquitetural

Há uma diferença importante entre:

- a **arquitetura correta do frontend**; e
- o **estado atual do código**, que ainda está em bootstrap em várias telas.

Por isso, este documento:

- reconhece honestamente o código real existente;
- não trata placeholder como produto final;
- também não reduz o desenho correto do frontend ao scaffold atual.

---

## 5. Tese central da arquitetura de frontend

A tese deste documento é a seguinte:

> o frontend do projeto William Albarello deve operar como um ecossistema de duas superfícies especializadas — pública e administrativa — apoiadas por contratos compartilhados, navegação previsível, renderização orientada ao contexto e integração disciplinada com a API.

Isso significa que a camada frontend não deve ser tratada como:

- conjunto solto de páginas;
- coleção improvisada de componentes;
- acoplamento direto e desorganizado ao backend;
- mistura confusa entre experiência pública e operação interna.

Ela deve funcionar como uma arquitetura em camadas.

---

## 6. Estado real identificado no acervo técnico

O frontend real atual já mostra, fisicamente, a seguinte estrutura:

### 6.1 App público
`apps/web`

Rotas e artefatos já encontrados:

- `/`
- `/publicacoes`
- `/publicacoes/[slug]`
- `robots.ts`
- `sitemap.ts`
- `layout.tsx`

### 6.2 App administrativo
`apps/admin`

Rotas e artefatos já encontrados:

- `/`
- `/painel/login`
- `/painel/publicacoes`
- `layout.tsx`

### 6.3 Pacotes compartilhados
- `packages/ui`
- `packages/contracts`

### 6.4 Leitura correta do estado atual

O código real atual comprova:

- duas superfícies frontend separadas;
- Next.js App Router em ambas;
- layouts base;
- rotas iniciais;
- metadata inicial;
- base para indexação técnica (`robots` e `sitemap`);
- scaffold administrativo inicial.

Também comprova que o frontend ainda está em fase inicial de implementação visual e operacional.

---

## 7. Superfícies do frontend

## 7.1 Superfície pública

A superfície pública existe para:

- apresentar identidade profissional;
- organizar páginas institucionais;
- expor publicações;
- favorecer descoberta orgânica;
- conduzir aproximação profissional;
- sustentar leitura longa e navegação editorial.

Ela é **content-first**.

## 7.2 Superfície administrativa

A superfície administrativa existe para:

- autenticar operadores;
- listar e editar publicações;
- sustentar o CMS;
- governar estados editoriais;
- operar taxonomias;
- futuramente sustentar logs e auditoria.

Ela é **operation-first**.

## 7.3 Regra central

As duas superfícies pertencem ao mesmo sistema, mas **não devem colapsar em uma experiência única sem fronteira clara**.

---

## 8. Camadas da arquitetura do frontend

A arquitetura do frontend deve ser lida em sete camadas.

## 8.1 Camada de entrada e roteamento

Responsável por:

- resolução de rotas;
- segmentação por superfície;
- params dinâmicos;
- metadata por rota;
- `robots` e `sitemap` quando aplicável.

## 8.2 Camada de layout e composição

Responsável por:

- `layout.tsx`;
- estrutura persistente de página;
- shell visual;
- hierarquia entre header, main, footer e áreas internas.

## 8.3 Camada de página

Responsável por:

- representar cada destino navegável;
- orquestrar composição de seções;
- solicitar dados necessários;
- decidir estados vazios, erro e carregamento.

## 8.4 Camada de componentes

Responsável por:

- blocos reutilizáveis;
- componentes institucionais;
- componentes editoriais;
- componentes administrativos;
- primitives visuais compartilháveis.

## 8.5 Camada de estado e interação

Responsável por:

- estado de sessão;
- estado de formulários;
- estado de filtros;
- estado de carregamento;
- estado de erro;
- estado de feedback de ação.

## 8.6 Camada de integração e dados

Responsável por:

- consumir contratos compartilhados;
- falar com API pública;
- falar com API administrativa;
- serializar payloads;
- traduzir resposta em estado de UI.

## 8.7 Camada transversal de SEO, acessibilidade e observabilidade

Responsável por:

- metadata;
- Open Graph;
- sitemap;
- robots;
- semântica HTML;
- acessibilidade base;
- telemetria frontend quando aplicável.

---

## 9. Diagrama principal — arquitetura macro do frontend

```mermaid
flowchart TD
    U1[Visitante público] --> W[apps/web]
    U2[Administrador interno] --> A[apps/admin]

    W --> WR[Camada de rotas públicas]
    A --> AR[Camada de rotas administrativas]

    WR --> WL[Layouts e shells públicos]
    AR --> AL[Layouts e shells administrativos]

    WL --> WP[Paginas publicas]
    AL --> AP[Paginas administrativas]

    WP --> WC[Componentes de UI publica]
    AP --> AC[Componentes de UI administrativa]

    WC --> SH[Packages compartilhados]
    AC --> SH

    SH --> UI[packages/ui]
    SH --> CT[packages/contracts]

    WP --> DS[Camada de dados publica]
    AP --> DA[Camada de dados admin]

    DS --> PUBAPI[API publica]
    DA --> ADMAPI[API administrativa]

    PUBAPI --> BE[Backend/API]
    ADMAPI --> BE

    WP --> SEO[Metadata / robots / sitemap / SEO]
    AP --> SES[Autenticacao / sessao / protecoes]

    SES --> ADMAPI
````

---

## 10. Leitura executiva do diagrama

O diagrama mostra uma arquitetura clara:

1. existem **dois pontos de entrada humanos**:

   * visitante;
   * administrador;

2. cada um entra em uma **superfície frontend distinta**;

3. cada superfície possui:

   * rotas;
   * layouts;
   * páginas;
   * componentes;

4. ambas podem consumir uma base compartilhada de:

   * contratos;
   * UI reutilizável;

5. a superfície pública conversa com a **API pública**;

6. a superfície administrativa conversa com a **API administrativa**;

7. há camadas transversais diferentes:

   * SEO e descoberta, no público;
   * sessão e segurança, no admin.

---

## 11. Arquitetura física atual x arquitetura lógica do projeto

## 11.1 Arquitetura física atual

No acervo técnico atual, o frontend já está fisicamente separado em:

* `apps/web`
* `apps/admin`

Essa decisão é válida e coerente com a clareza operacional do estágio atual.

## 11.2 Arquitetura lógica soberana

Mesmo com dois apps físicos, a leitura correta é que o projeto possui um único **ecossistema frontend**, composto por duas superfícies.

Ou seja:

* fisicamente: dois apps;
* logicamente: um frontend com dois domínios de experiência.

## 11.3 Vantagem dessa leitura

Ela evita dois erros:

* tratar o admin como projeto independente sem raiz no sistema principal;
* tratar o público e o admin como se fossem a mesma experiência, apenas com cores diferentes.

---

## 12. Organização macro das rotas

## 12.1 Rotas públicas comprovadas no código atual

* `/`
* `/publicacoes`
* `/publicacoes/[slug]`

Além disso, já existem artefatos transversais de SEO:

* `/robots.txt` via `robots.ts`
* `/sitemap.xml` via `sitemap.ts`

## 12.2 Rotas públicas soberanas esperadas

Com base no Waterfall e na arquitetura do projeto, a superfície pública deve sustentar, ao menos, famílias como:

* home;
* sobre;
* expertise/atuação;
* projetos/estudos;
* publicações;
* detalhe de publicação;
* contato;
* páginas institucionais auxiliares.

## 12.3 Rotas administrativas comprovadas no código atual

* `/`
* `/painel/login`
* `/painel/publicacoes`

## 12.4 Rotas administrativas soberanas esperadas

Com base no contrato administrativo e no desenho do projeto, o admin deve evoluir para suportar famílias como:

* login;
* validação de sessão;
* dashboard;
* listagem de publicações;
* criação/edição de publicação;
* categorias;
* tags;
* auditoria/logs;
* eventualmente configurações editoriais.

---

## 13. Camada pública do frontend

## 13.1 Natureza

A camada pública deve ser orientada por:

* legibilidade;
* autoridade;
* escaneabilidade;
* indexação;
* navegação editorial.

## 13.2 Papel do `apps/web`

O `apps/web` é o recipiente atual dessa superfície.

Hoje ele já demonstra:

* layout global;
* metadata base;
* homepage inicial;
* listagem de publicações inicial;
* detalhe por slug inicial;
* geração de `robots` e `sitemap`.

## 13.3 Responsabilidades centrais da camada pública

* exibir páginas institucionais;
* listar publicações;
* renderizar detalhe de publicação;
* lidar com busca/filtro futuros;
* sustentar SEO técnico;
* manter experiência leve e sem ruído.

## 13.4 Estratégia recomendada de renderização

A camada pública deve privilegiar uma estratégia híbrida com viés **server-first** para rotas indexáveis, porque isso favorece:

* SEO;
* metadata por rota;
* previsibilidade de renderização;
* legibilidade do conteúdo;
* menor dependência de hidratação desnecessária em páginas editoriais.

---

## 14. Camada administrativa do frontend

## 14.1 Natureza

A camada administrativa deve ser orientada por:

* clareza de operação;
* feedback explícito;
* estados legíveis;
* segurança;
* baixa ambiguidade.

## 14.2 Papel do `apps/admin`

O `apps/admin` é o recipiente atual dessa superfície.

Hoje ele já demonstra:

* layout administrativo inicial;
* home administrativa mínima;
* tela de login;
* tela inicial de publicações no painel.

## 14.3 Responsabilidades centrais da camada administrativa

* autenticar o operador;
* manter sessão válida;
* listar e manipular publicações;
* lidar com formulários administrativos;
* refletir respostas da API com clareza;
* bloquear operações inválidas;
* futuramente sustentar dashboard, taxonomia e logs.

## 14.4 Estratégia recomendada de renderização

A camada administrativa tende a exigir mais interatividade e estados de formulário, portanto ela pode combinar:

* shell e layout previsíveis;
* renderização orientada a aplicação;
* componentes client-side quando a interação exigir;
* validação e feedback rigorosos por ação.

---

## 15. Pacotes compartilhados

## 15.1 `packages/ui`

O pacote `ui` já existe no monorepo e hoje está mínimo, mas sua função arquitetural é clara:

* concentrar primitives e contratos visuais compartilháveis;
* evitar duplicação de base visual entre `web` e `admin`;
* permitir consistência sem acoplar os dois apps de forma caótica.

## 15.2 `packages/contracts`

O pacote `contracts` já existe e hoje também está mínimo, mas sua função arquitetural é ainda mais importante:

* centralizar tipos compartilhados;
* alinhar frontend e backend;
* reduzir drift entre UI e API;
* apoiar consumo disciplinado dos contratos.

## 15.3 Regra arquitetural

O compartilhamento deve ocorrer em **camadas estáveis**, não em acoplamento desorganizado entre apps.

---

## 16. Integração do frontend com backend e API

## 16.1 API pública

A camada pública deve conversar com rotas como:

* `GET /public/pages/{key}`
* `GET /public/publications`
* `GET /public/publications/{slug}`
* `GET /public/publications/{slug}/related`
* `POST /public/contact`

## 16.2 API administrativa

A camada administrativa deve conversar com rotas como:

* `POST /admin/auth/login`
* `POST /admin/auth/logout`
* `GET /admin/auth/session`
* `GET /admin/dashboard`
* `GET/POST /admin/publications`
* `GET/PUT /admin/publications/{id}`
* `PATCH /admin/publications/{id}/status`
* rotas de categorias, tags e auditoria

## 16.3 Regra importante de integração

O frontend **não deve conhecer detalhes internos arbitrários do backend**.
Ele deve consumir a API por contratos claros, com tipagem e tratamento disciplinado de erro.

---

## 17. Estado do frontend

A camada de estado do frontend deve ser lida em cinco grupos.

## 17.1 Estado de rota

Inclui:

* params dinâmicos;
* query params;
* contexto de navegação;
* rota atual.

## 17.2 Estado de dados

Inclui:

* payloads carregados da API;
* paginação;
* filtros;
* relacionados;
* detalhe da publicação;
* sessão do admin.

## 17.3 Estado de interação

Inclui:

* campos de formulário;
* foco;
* validação;
* envio;
* feedback.

## 17.4 Estado de interface

Inclui:

* `idle`
* `loading`
* `success`
* `error`

Essa taxonomia, inclusive, já aparece insinuada no pacote `ui`.

## 17.5 Estado de segurança/sessão

Inclui:

* usuário autenticado;
* sessão válida;
* sessão expirada;
* acesso negado;
* logout.

---

## 18. Componentes macro esperados

Embora o detalhamento fino pertença ao documento seguinte, a arquitetura do frontend já permite reconhecer famílias de componentes.

## 18.1 Componentes públicos macro

* layout institucional;
* header;
* footer;
* hero institucional;
* cards de publicação;
* lista de publicações;
* breadcrumb, quando aplicável;
* bloco de CTA;
* bloco de conteúdo longo;
* formulário de contato.

## 18.2 Componentes administrativos macro

* shell do painel;
* cabeçalho administrativo;
* formulário de login;
* listagem/tabulação de publicações;
* formulário de publicação;
* seletor de categoria;
* seletor de tags;
* badges de status;
* feedback de ação;
* estados de vazio/erro/carregamento.

---

## 19. SEO e rotas técnicas do frontend público

A arquitetura real já comprova uma direção correta ao possuir:

* `metadata` base no layout;
* `robots.ts`;
* `sitemap.ts`.

Isso confirma que o frontend público deve assumir, como responsabilidade estrutural:

* metadata por página;
* title e description por rota;
* sitemap;
* robots;
* base para Open Graph;
* base para páginas indexáveis orientadas por slug.

Regra importante:

**SEO aqui não é apêndice; é parte da arquitetura do frontend público.**

---

## 20. Segurança no frontend administrativo

A camada administrativa já nasce acoplada a exigências de segurança.

O acervo atual comprova, do lado da API, direção para:

* cookie de sessão;
* CSRF;
* rate limit;
* CORS controlado.

Por isso, o frontend admin deve ser desenhado para operar corretamente com:

* login por formulário;
* sessão baseada em cookie seguro;
* validação de sessão atual;
* logout explícito;
* tratamento de expiração de sessão;
* rotas e ações protegidas.

Regra importante:

**o frontend admin não deve simular segurança só na interface; ele deve refletir o contrato real de sessão e autorização.**

---

## 21. Diagrama complementar — fluxo de dados do frontend

```mermaid
flowchart LR
    R[Route / Page] --> L[Layout / Shell]
    L --> P[Page Composition]
    P --> C[Componentes]
    P --> S[Estado de interface]
    P --> F[Camada de fetch / client API]
    F --> T[Contracts compartilhados]
    F --> API[API publica ou admin]
    API --> F
    F --> S
    S --> C
```

---

## 22. Leitura do fluxo complementar

Esse fluxo mostra o comportamento desejado:

1. a rota resolve o destino;
2. o layout fornece o contexto persistente;
3. a página orquestra a composição;
4. os componentes exibem o resultado;
5. a camada de dados busca e devolve informação;
6. o estado governa carregamento, sucesso e erro;
7. contratos compartilhados reduzem inconsistência entre frontend e backend.

---

## 23. Regras macro de integridade da arquitetura frontend

## 23.1 RI-FE-01

A superfície pública e a administrativa devem manter separação clara de responsabilidades.

## 23.2 RI-FE-02

O frontend deve consumir a API por contratos definidos, e não por improviso local.

## 23.3 RI-FE-03

Rotas públicas indexáveis devem privilegiar renderização favorável a SEO e leitura.

## 23.4 RI-FE-04

A camada administrativa deve explicitar estados de autenticação, carregamento, erro e sucesso.

## 23.5 RI-FE-05

Componentes compartilhados devem viver em camada apropriada, sem duplicação caótica entre apps.

## 23.6 RI-FE-06

A interface não deve misturar lógica pública e lógica interna de forma opaca ao usuário.

## 23.7 RI-FE-07

SEO técnico da superfície pública é parte estrutural da arquitetura, não detalhe tardio.

## 23.8 RI-FE-08

O frontend deve estar preparado para evoluir sem romper a coerência entre páginas, rotas, componentes e contratos.

---

## 24. Decisões arquiteturais implícitas neste documento

Este documento fixa, em nível macro, as seguintes decisões:

1. o frontend do projeto possui duas superfícies especializadas;
2. o acervo técnico atual já materializa essa separação em dois apps Next.js;
3. o frontend público é orientado por conteúdo, indexação e autoridade;
4. o frontend administrativo é orientado por operação editorial e segurança;
5. packages compartilhados devem sustentar UI e contratos comuns;
6. a API é a fronteira correta entre frontend e backend;
7. SEO, sessão e estados de interface são partes estruturais da arquitetura frontend.

---

## 25. Riscos que este documento evita

### 25.1 Mistura entre site público e painel

Evita confusão de propósito, navegação e linguagem de interface.

### 25.2 Frontend sem camada

Evita páginas acopladas diretamente ao backend de forma desorganizada.

### 25.3 Drift entre frontend e API

Evita inconsistência crescente entre payloads, contratos e consumo de dados.

### 25.4 SEO tratado tarde demais

Evita que páginas públicas nasçam sem base semântica e de indexação.

### 25.5 Admin inseguro ou opaco

Evita painel com sessão mal refletida e feedback insuficiente.

### 25.6 Escalabilidade ruim do monorepo

Evita duplicação desnecessária entre `web` e `admin`.

---

## 26. Critérios de aceite deste documento

Este documento será considerado aceito quando:

* representar claramente a arquitetura macro do frontend;
* distinguir superfície pública e administrativa;
* reconhecer o estado real do monorepo atual;
* explicar rotas, layouts, páginas, componentes, estado e dados;
* alinhar o frontend ao contrato de API e à arquitetura do sistema;
* servir como base para os próximos documentos de UI, rotas e jornadas.

---

## 27. Conclusão executiva

O frontend do projeto William Albarello não deve ser tratado como conjunto solto de telas.

Ele é uma arquitetura.

Essa arquitetura, no estado atual e no desenho soberano do projeto, se organiza em:

* **superfície pública**, para autoridade, leitura, indexação e aproximação;
* **superfície administrativa**, para autenticação, CMS e operação editorial;
* **camadas compartilhadas**, para contratos e UI;
* **integração disciplinada com API**, como fronteira de dados;
* **camadas transversais**, como SEO, sessão e estados de interface.

O acervo técnico já comprova essa direção, ainda que em estágio inicial de implementação.

Este documento fixa essa anatomia e estabelece a base correta para aprofundar, nos próximos arquivos, os componentes da UI, as rotas, as jornadas e os fluxos de navegação.

---

