
# 030_Diagrama_de_Fluxo_de_Navegacao_Publica

## 1. Identificação do documento

- **Projeto:** William Albarello
- **Diretório:** `02-Diagramas`
- **Caminho oficial:** `/home/user/Documents/Softwares/Willian Albarello/William Albarello/02-Diagramas/04-Frontend_e_Jornadas/030_Diagrama_de_Fluxo_de_Navegacao_Publica.md`
- **Natureza do documento:** Diagrama e contrato lógico do fluxo de navegação pública
- **Função sistêmica:** Desenhar o fluxo de navegação pública do site, explicando caminhos principais, caminhos secundários, loops de exploração, pontos de aprofundamento e pontos de saída
- **Posição na trilha:** Sexto documento do bloco `04-Frontend_e_Jornadas`
- **Dependências principais:** `008_Regras_de_Negocio.md`, `009_Personas_Perfis_e_Usuarios.md`, `010_Jornadas_do_Usuario_e_Fluxos_Principais.md`, `012_Estrategia_de_Conteudo_SEO_e_Publicacao.md`, `017_UI_UX_Arquitetura_da_Informacao.md` e frontend público real disponível no acervo técnico

---

## 2. Objetivo

Este documento existe para formalizar o **fluxo de navegação pública** do projeto William Albarello.

Se os documentos anteriores deste bloco já fixaram:

- a arquitetura macro do frontend;
- os componentes da UI;
- o mapa de rotas e páginas;
- a jornada do visitante;
- a jornada do administrador;

este arquivo responde a outra pergunta essencial:

> como a navegação pública se comporta na prática, quais caminhos o visitante percorre, onde ele aprofunda, onde ele retorna, e em que pontos a experiência termina, se interrompe ou avança para aproximação?

Seu objetivo é explicitar:

- o fluxo principal da navegação pública;
- os caminhos institucionais e editoriais;
- os loops naturais de leitura e exploração;
- os desvios secundários;
- os pontos de saída explícitos e implícitos;
- a relação entre navegação, SEO, conteúdo e conversão.

Este documento não fecha:

- microinterações de menu;
- comportamento fino de breadcrumbs;
- animações de transição;
- política final de paginação e filtros avançados;
- instrumentação analítica detalhada por clique.

Seu foco é o **desenho navegacional da superfície pública**.

---

## 3. Fontes de referência

Este documento deriva principalmente das seguintes bases do projeto:

- `01-Waterfall/01-Obrigatorios/008_Regras_de_Negocio.md`
- `01-Waterfall/01-Obrigatorios/009_Personas_Perfis_e_Usuarios.md`
- `01-Waterfall/01-Obrigatorios/010_Jornadas_do_Usuario_e_Fluxos_Principais.md`
- `01-Waterfall/01-Obrigatorios/012_Estrategia_de_Conteudo_SEO_e_Publicacao.md`
- `01-Waterfall/01-Obrigatorios/017_UI_UX_Arquitetura_da_Informacao.md`

Também dialoga diretamente com:

- `025_Diagrama_de_Arquitetura_do_Frontend.md`
- `026_Diagrama_de_Componentes_da_UI.md`
- `027_Diagrama_de_Rotas_e_Paginas.md`
- `028_Diagrama_de_Jornada_do_Visitante.md`
- frontend público real do monorepo `personal-site`
- rotas públicas já comprovadas:
  - `/`
  - `/publicacoes`
  - `/publicacoes/[slug]`

---

## 4. Premissas e limites

## 4.1 Premissas adotadas

Para este documento, adotam-se as seguintes premissas:

- a superfície pública do projeto é aberta e não depende de autenticação;
- a navegação pública precisa servir tanto:
  - ao visitante que chega pela home;
  - quanto ao visitante que entra diretamente por conteúdo indexado;
- a homepage funciona como distribuidora institucional;
- a listagem de publicações funciona como nó de exploração editorial;
- a página de detalhe da publicação funciona como nó de aprofundamento e redistribuição;
- páginas institucionais como `/sobre`, `/atuacao` e `/contato` são soberanamente esperadas, ainda que nem todas já estejam fisicamente implementadas no frontend atual;
- CTAs contextuais fazem parte do fluxo de navegação, e não apenas da camada de conversão;
- o visitante deve poder:
  - entender;
  - explorar;
  - aprofundar;
  - voltar;
  - sair;
  - converter.

## 4.2 Limites deste documento

Este arquivo não define:

- o texto final de menus e links;
- o posicionamento pixel a pixel de CTAs;
- o mapa final de paginação de listagens;
- o motor de busca interno do site;
- a orquestração de analytics de navegação.

Seu papel é fixar o **fluxo lógico da navegação pública**.

## 4.3 Regra de prudência arquitetural

Há uma diferença importante entre:

- o **fluxo de navegação correto do projeto**; e
- o **estado atual do frontend**, que ainda está em construção.

Por isso, este documento:

- reconhece a navegação já comprovada fisicamente;
- não limita o projeto ao bootstrap atual;
- também não inventa caminhos sem aderência à arquitetura da informação e às jornadas já consolidadas.

---

## 5. Tese central da navegação pública

A tese deste documento é a seguinte:

> a navegação pública do projeto William Albarello deve operar como um fluxo de orientação, aprofundamento e redistribuição, no qual cada página não é apenas um destino, mas um ponto de passagem para o próximo entendimento, para a próxima leitura ou para a próxima ação.

Isso significa que a navegação pública não deve ser tratada como:

- menu solto;
- coleção de links sem intenção;
- site em que cada página encerra a experiência em si mesma;
- acervo editorial sem retorno nem continuidade.

A navegação precisa formar um **circuito legível**.

---

## 6. Estrutura geral da navegação pública

A navegação pública do projeto se organiza em quatro zonas principais.

## 6.1 Zona de entrada

Composta por páginas e pontos que recebem o visitante inicialmente.

Exemplos:
- home;
- detalhe de publicação;
- listagem de publicações;
- páginas institucionais futuras.

## 6.2 Zona de orientação

Composta por páginas e blocos que ajudam o visitante a entender:

- quem é o projeto;
- o que está sendo oferecido;
- por onde ele deve seguir.

Exemplos:
- home;
- páginas institucionais;
- header/nav principal;
- CTAs de orientação.

## 6.3 Zona de aprofundamento

Composta por páginas e blocos que sustentam leitura mais densa e maior permanência.

Exemplos:
- listagem de publicações;
- detalhe da publicação;
- relacionados;
- páginas de atuação.

## 6.4 Zona de saída ou conversão

Composta pelos pontos em que o visitante:

- entra em contato;
- sai do site;
- retorna ao mecanismo de busca;
- guarda o conteúdo para depois;
- continua navegando para outra peça.

---

## 7. Nós principais da navegação pública

O fluxo público do projeto deve reconhecer os seguintes nós principais.

## 7.1 Home

**Rota:** `/`

Função:
- distribuir a navegação;
- construir entendimento inicial;
- apontar para páginas institucionais e editoriais;
- apresentar CTAs de aproximação.

## 7.2 Listagem de publicações

**Rota:** `/publicacoes`

Função:
- centralizar exploração do acervo;
- permitir escolha de leitura;
- servir como ponte entre visitante genérico e aprofundamento temático.

## 7.3 Detalhe de publicação

**Rota:** `/publicacoes/[slug]`

Função:
- aprofundar autoridade e valor;
- sustentar permanência;
- redistribuir navegação para:
  - relacionados;
  - outras páginas institucionais;
  - contato.

## 7.4 Páginas institucionais

**Rotas soberanas esperadas:**
- `/sobre`
- `/atuacao`
- `/contato`

Função:
- consolidar contexto;
- reduzir hesitação;
- responder dúvidas institucionais;
- servir de ponte para aproximação.

## 7.5 Saídas externas ou término de sessão pública

Exemplos:
- abandono;
- fechamento da aba;
- retorno ao buscador;
- clique em canal externo de contato, quando aplicável.

---

## 8. Caminhos principais da navegação

A navegação pública possui alguns caminhos dominantes.

## 8.1 Caminho A — entrada institucional

Fluxo típico:

`/` → páginas institucionais → listagem de publicações → detalhe → contato

É o fluxo mais completo e controlado.

## 8.2 Caminho B — entrada editorial por busca

Fluxo típico:

`/publicacoes/[slug]` → relacionados ou listagem → páginas institucionais → contato

É o fluxo típico de descoberta orgânica.

## 8.3 Caminho C — exploração do acervo

Fluxo típico:

`/publicacoes` → `/publicacoes/[slug]` → outra publicação → contato ou retorno

É o fluxo de visitante interessado em conteúdo.

## 8.4 Caminho D — entrada institucional direta

Fluxo típico:

`/sobre` ou `/atuacao` → home ou publicações → detalhe → contato

É o fluxo do visitante que busca legitimidade ou contexto antes do conteúdo.

---

## 9. Loops de navegação

A navegação pública saudável não é só linear.  
Ela precisa permitir loops úteis.

## 9.1 Loop editorial

`/publicacoes` → `/publicacoes/[slug]` → relacionados → outro detalhe → retorno à listagem

Função:
- aumentar profundidade de leitura;
- fortalecer autoridade;
- reduzir abandono após uma única leitura.

## 9.2 Loop institucional-editorial

home → página institucional → publicações → detalhe → home ou contato

Função:
- alternar entre legitimidade institucional e prova editorial.

## 9.3 Loop de reconsideração

detalhe de publicação → sobre/atuação → contato  
ou  
detalhe de publicação → listagem → novo detalhe

Função:
- permitir que o visitante amadureça decisão sem precisar reiniciar a experiência do zero.

---

## 10. Pontos de saída da navegação

Toda navegação pública possui pontos de saída.  
O projeto precisa reconhecê-los.

## 10.1 Saída por abandono precoce

O visitante entra e sai sem entender o valor.

Pode ocorrer em:
- home;
- listagem;
- detalhe;
- páginas institucionais fracas.

## 10.2 Saída por leitura satisfeita

O visitante consumiu uma publicação, obteve valor e encerrou.

Essa saída não é necessariamente ruim, mas precisa ser acompanhada por possibilidade de continuidade.

## 10.3 Saída por conversão

O visitante deixa a superfície pública para:
- contato;
- canal externo integrado;
- próximo passo de aproximação.

## 10.4 Saída por desorientação

O visitante:
- não entende onde clicar;
- não encontra continuidade;
- abandona por fricção.

Esse é o tipo de saída que a arquitetura deve reduzir.

---

## 11. Diagrama principal — fluxo de navegação pública

```mermaid
flowchart TD
    ENTRADA[Entrada do visitante] --> ORIGEM{Origem}

    ORIGEM --> HOME[Home /]
    ORIGEM --> LISTA[/publicacoes]
    ORIGEM --> DETALHE[/publicacoes/[slug]]
    ORIGEM --> INST[Pagina institucional]

    HOME --> H1[Entendimento inicial]
    H1 --> DEC1{Encontrou direcao?}
    DEC1 -->|Sim| SOBRE[/sobre]
    DEC1 -->|Sim| ATUACAO[/atuacao]
    DEC1 -->|Sim| LISTA
    DEC1 -->|Sim| CONTATO[/contato]
    DEC1 -->|Nao| SAIDA1[Saida / abandono]

    LISTA --> EXPLORA[Exploracao do acervo]
    EXPLORA --> DEC2{Encontrou conteudo relevante?}
    DEC2 -->|Sim| DETALHE
    DEC2 -->|Nao| HOME
    DEC2 -->|Nao| SAIDA2[Saida]

    DETALHE --> LEITURA[Leitura aprofundada]
    LEITURA --> DEC3{Deseja continuar?}
    DEC3 -->|Relacionados| REL[Publicacoes relacionadas]
    DEC3 -->|Voltar ao acervo| LISTA
    DEC3 -->|Entender projeto| SOBRE
    DEC3 -->|Buscar aproximacao| CONTATO
    DEC3 -->|Encerrar| SAIDA3[Saida]

    REL --> DETALHE2[Outro detalhe]
    DETALHE2 --> LEITURA2[Leitura adicional]
    LEITURA2 --> DEC4{Novo passo}
    DEC4 -->|Mais conteudo| LISTA
    DEC4 -->|Projeto / atuacao| ATUACAO
    DEC4 -->|Contato| CONTATO
    DEC4 -->|Sair| SAIDA4[Saida]

    SOBRE --> CONF1[Construcao de confianca]
    ATUACAO --> CONF2[Construcao de confianca]
    CONF1 --> CONTATO
    CONF2 --> CONTATO
    CONF1 --> LISTA
    CONF2 --> LISTA

    CONTATO --> CONV[Conversao / manifestacao de interesse]
````

---

## 12. Leitura executiva do diagrama

O diagrama mostra uma navegação pública orientada por redistribuição.

O visitante pode entrar por vários pontos, mas a estrutura correta do sistema faz com que ele seja continuamente redistribuído para alguns nós centrais:

* home;
* listagem de publicações;
* detalhe de publicação;
* páginas institucionais;
* contato.

A navegação saudável depende de duas capacidades:

1. **orientar quem entra**
2. **redistribuir quem aprofunda**

Sem isso, cada página vira beco sem saída.

---

## 13. Fluxo principal a partir da home

## 13.1 Papel da home no fluxo

A home é o principal distribuidor da navegação pública.

Ela deve permitir que o visitante escolha entre:

* entender o projeto;
* explorar o acervo;
* aproximar-se diretamente.

## 13.2 Saídas principais da home

* `/sobre`
* `/atuacao`
* `/publicacoes`
* `/contato`

## 13.3 Risco principal da home

Se ela falhar em orientar, o visitante não entra no fluxo.
Ele sai antes mesmo de começar a explorar.

---

## 14. Fluxo principal a partir da listagem de publicações

## 14.1 Papel da listagem no fluxo

A listagem funciona como hub de exploração editorial.

Ela deve responder:

* quais temas existem;
* o que vale abrir;
* como continuar sem esforço excessivo.

## 14.2 Saídas principais da listagem

* detalhe de publicação;
* home;
* eventual contato, se houver CTA contextual;
* eventual filtro/refinamento, quando amadurecer.

## 14.3 Risco principal da listagem

Se a listagem não escaneia bem, o visitante não entra no aprofundamento.
Ele abandona antes de ler.

---

## 15. Fluxo principal a partir do detalhe da publicação

## 15.1 Papel do detalhe no fluxo

O detalhe da publicação é simultaneamente:

* destino de leitura;
* prova de autoridade;
* ponte para continuidade da navegação.

## 15.2 Saídas principais do detalhe

* publicações relacionadas;
* retorno à listagem;
* páginas institucionais;
* contato.

## 15.3 Regra importante

A publicação individual não deve ser terminal muda.
Ela deve redistribuir o visitante para o próximo passo adequado.

---

## 16. Fluxo principal a partir das páginas institucionais

## 16.1 Papel das páginas institucionais

Essas páginas reduzem hesitação e fortalecem confiança.

Elas não existem apenas para “completar menu”, mas para:

* contextualizar;
* posicionar;
* responder perguntas de legitimidade;
* preparar a aproximação.

## 16.2 Saídas principais das páginas institucionais

* listagem de publicações;
* contato;
* eventualmente home.

## 16.3 Risco principal

Se forem genéricas demais, quebram o ritmo da navegação e funcionam como desvio morto.

---

## 17. Caminhos secundários

Além do fluxo principal, o site deve reconhecer caminhos secundários legítimos.

## 17.1 Caminho de retorno

Exemplos:

* detalhe → listagem
* páginas institucionais → home
* contato → retorno ao site

Função:

* evitar aprisionamento;
* permitir reconsideração.

## 17.2 Caminho de aprofundamento em cadeia

Exemplo:

* detalhe → relacionados → outro detalhe → outra leitura

Função:

* aumentar permanência e densidade de exploração.

## 17.3 Caminho de confiança progressiva

Exemplo:

* publicação → sobre → atuação → contato

Função:

* suportar visitantes que precisam de mais contexto antes de agir.

---

## 18. Relação entre navegação e intenção do visitante

O fluxo de navegação pública precisa respeitar a intenção de entrada do visitante.

## 18.1 Visitante orientado por busca

Tende a entrar por conteúdo.
Precisa de ponte para o restante do site.

## 18.2 Visitante orientado por reconhecimento

Tende a entrar pela home ou página institucional.
Precisa de navegação clara para aprofundar.

## 18.3 Visitante orientado por ação

Tende a procurar logo contato ou atuação.
Precisa de caminho curto e sem rodeios.

## 18.4 Regra central

Boa navegação pública não força o mesmo percurso para todos.
Ela oferece percursos coerentes para intenções diferentes.

---

## 19. Relação entre navegação e SEO

A navegação pública é parte da estratégia de SEO.

## 19.1 Por quê

Porque a estrutura de links internos influencia:

* descoberta de páginas;
* distribuição de autoridade interna;
* permanência;
* profundidade de navegação;
* compreensão semântica do site.

## 19.2 Implicações práticas

* a home deve apontar para páginas e conteúdos relevantes;
* a listagem deve apontar para detalhes;
* o detalhe deve apontar para relacionados e páginas institucionais;
* as páginas institucionais devem apontar para conteúdo e contato.

## 19.3 Regra importante

SEO técnico sem boa navegação interna produz descoberta parcial e experiência fraca.

---

## 20. Relação entre navegação e arquitetura da informação

A navegação pública é a manifestação operacional da arquitetura da informação.

Em termos práticos:

* a arquitetura da informação diz **o que existe e por quê**;
* a navegação diz **como o usuário se move por isso**.

Se a arquitetura de informação estiver boa, mas a navegação estiver fraca, o valor do projeto não se revela ao visitante.

---

## 21. Diagrama complementar — loops e saídas

```mermaid id="030-loops-saidas"
flowchart LR
    H[Home] --> L[Listagem]
    L --> D[Detalhe]
    D --> R[Relacionados]
    R --> D2[Outro detalhe]
    D2 --> L
    D --> S[Sobre / Atuacao]
    S --> C[Contato]
    D --> C
    H --> C
    L --> X[Saida]
    D --> X
    H --> X
```

---

## 22. Leitura do diagrama complementar

Esse diagrama mostra duas forças simultâneas da navegação pública:

* **loops úteis**, que mantêm o visitante dentro do ecossistema;
* **saídas inevitáveis**, que precisam ser tratadas com inteligência.

A meta do projeto não é eliminar toda saída, mas:

* reduzir saídas por desorientação;
* aumentar saídas por conversão;
* aumentar loops de aprofundamento.

---

## 23. Pontos de atrito do fluxo de navegação pública

O fluxo pode falhar em alguns pontos específicos.

## 23.1 Atrito de entrada

O visitante entra e não entende rapidamente:

* o que é o site;
* onde clicar;
* por que continuar.

## 23.2 Atrito de distribuição

A home não distribui bem.
A listagem não orienta bem.
O detalhe não aponta bem para o próximo passo.

## 23.3 Atrito de loop quebrado

O visitante lê uma publicação, mas não encontra:

* relacionados;
* caminho para o acervo;
* caminho para o projeto;
* caminho para contato.

## 23.4 Atrito de excesso de caminhos

Muitas saídas concorrentes podem enfraquecer a decisão.
Navegação pública boa não é excesso de links; é hierarquia de caminhos.

## 23.5 Atrito de confiança

A navegação leva o visitante a páginas, mas elas não sustentam confiança suficiente para avançar.

---

## 24. Elementos que fortalecem o fluxo de navegação

A navegação pública melhora quando o sistema oferece:

* menu principal claro;
* home bem distribuída;
* cards editoriais escaneáveis;
* detalhe de publicação com continuidade;
* links para relacionados;
* páginas institucionais com função clara;
* CTAs contextuais e não invasivos;
* caminhos curtos para contato;
* retorno fácil à listagem e à home.

---

## 25. Regras macro de integridade do fluxo público

## 25.1 RI-FNP-01

Toda página pública relevante deve levar a pelo menos um próximo passo útil.

## 25.2 RI-FNP-02

A home deve funcionar como distribuidora principal do fluxo institucional e editorial.

## 25.3 RI-FNP-03

A listagem de publicações deve levar naturalmente ao detalhe.

## 25.4 RI-FNP-04

O detalhe da publicação deve redistribuir a navegação para relacionados, páginas institucionais e contato.

## 25.5 RI-FNP-05

Páginas institucionais devem reforçar confiança e apontar para conteúdo ou contato.

## 25.6 RI-FNP-06

A navegação pública deve permitir loops de aprofundamento sem aprisionar o usuário.

## 25.7 RI-FNP-07

Saídas por desorientação devem ser reduzidas por hierarquia clara de navegação.

## 25.8 RI-FNP-08

SEO, conteúdo e links internos devem operar articuladamente dentro do fluxo público.

---

## 26. Decisões arquiteturais implícitas neste documento

Este documento fixa, em nível macro, as seguintes decisões:

1. a navegação pública é multiponto, não centrada apenas na home;
2. home, listagem, detalhe e páginas institucionais formam o núcleo do fluxo;
3. a publicação individual é um nó de redistribuição, não apenas um fim;
4. a arquitetura pública precisa suportar loops de exploração;
5. contato é saída qualificada, não link aleatório;
6. o fluxo navegacional é parte do valor do site, não detalhe cosmético;
7. o projeto admite páginas soberanas ainda não totalmente implementadas, desde que coerentes com a arquitetura.

---

## 27. Riscos que este documento evita

### 27.1 Páginas-becco

Evita páginas que não apontam para continuidade.

### 27.2 Navegação confusa

Evita excesso de caminhos sem hierarquia.

### 27.3 Detalhe editorial isolado

Evita que a publicação individual retenha leitura, mas não distribua o visitante.

### 27.4 Home sem função real

Evita que a home seja apenas vitrine sem capacidade de orientar.

### 27.5 Conversão brusca

Evita contato aparecendo sem amadurecimento anterior.

### 27.6 SEO desconectado da experiência

Evita indexação que traz tráfego sem continuidade interna.

---

## 28. Critérios de aceite deste documento

Este documento será considerado aceito quando:

* representar claramente o fluxo de navegação pública;
* distinguir caminhos principais, secundários, loops e saídas;
* explicar a função de home, listagem, detalhe, páginas institucionais e contato;
* alinhar o fluxo à arquitetura da informação, jornadas, conteúdo/SEO e frontend real;
* servir como base para refinamento de menus, links internos, CTAs e continuidade de navegação.

---

## 29. Conclusão executiva

A navegação pública do projeto William Albarello precisa funcionar como um sistema de fluxo, não como uma coleção de páginas desconectadas.

Esse fluxo, quando corretamente desenhado, faz com que o visitante:

* entre por múltiplas portas;
* se oriente rapidamente;
* aprofunde por conteúdo e páginas institucionais;
* circule por loops úteis de exploração;
* encontre caminhos claros para contato;
* saia por conversão ou por término natural, e não por desorientação.

O frontend real já comprova parte desse desenho, e a arquitetura soberana do projeto amplia esse mapa de forma coerente.

Este documento fixa essa lógica e prepara o terreno para o próximo aprofundamento do bloco: o fluxo de aproximação, contato e conversão.

---

