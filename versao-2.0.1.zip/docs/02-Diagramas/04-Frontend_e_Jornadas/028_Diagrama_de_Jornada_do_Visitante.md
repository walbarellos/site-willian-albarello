
# 028_Diagrama_de_Jornada_do_Visitante

## 1. Identificação do documento

- **Projeto:** William Albarello
- **Diretório:** `02-Diagramas`
- **Caminho oficial:** `/home/user/Documents/Softwares/Willian Albarello/William Albarello/02-Diagramas/04-Frontend_e_Jornadas/028_Diagrama_de_Jornada_do_Visitante.md`
- **Natureza do documento:** Diagrama e contrato lógico da jornada do visitante público
- **Função sistêmica:** Explicar a experiência do visitante na superfície pública do sistema, cobrindo pontos de entrada, navegação, leitura, percepção de autoridade, aproximação e conversão
- **Posição na trilha:** Quarto documento do bloco `04-Frontend_e_Jornadas`
- **Dependências principais:** `004_Requisitos_Funcionais_e_Nao_Funcionais.md`, `008_Regras_de_Negocio.md`, `009_Personas_Perfis_e_Usuarios.md`, `010_Jornadas_do_Usuario_e_Fluxos_Principais.md`, `012_Estrategia_de_Conteudo_SEO_e_Publicacao.md`, `017_UI_UX_Arquitetura_da_Informacao.md` e eventuais prints/wireframes do frontend público

---

## 2. Objetivo

Este documento existe para formalizar a **jornada do visitante público** no projeto William Albarello.

Se os documentos anteriores deste bloco já fixaram:

- a arquitetura macro do frontend;
- o mapa de componentes da UI;
- a árvore de rotas e páginas;

este arquivo responde a outra pergunta essencial:

> como o visitante chega, o que ele percebe, por onde navega, como aprofunda confiança e em que pontos decide se aproxima ou abandona a experiência?

Seu objetivo é explicitar:

- os principais pontos de entrada do visitante;
- o caminho entre descoberta, leitura e aproximação;
- os momentos de entendimento, confiança e decisão;
- os pontos de atrito da jornada;
- os elementos que sustentam conversão sem ruptura de experiência;
- a coerência entre arquitetura da informação, conteúdo, SEO e UI/UX.

Este documento não fecha:

- copy final de cada CTA;
- mapa de heatmaps ou analytics detalhado;
- teste A/B de páginas;
- microinterações específicas de cada bloco;
- fluxos internos do painel administrativo.

Seu foco é a **jornada pública do visitante**, do primeiro contato à manifestação de interesse.

---

## 3. Fontes de referência

Este documento deriva principalmente das seguintes bases do projeto:

- `01-Waterfall/01-Obrigatorios/004_Requisitos_Funcionais_e_Nao_Funcionais.md`
- `01-Waterfall/01-Obrigatorios/008_Regras_de_Negocio.md`
- `01-Waterfall/01-Obrigatorios/009_Personas_Perfis_e_Usuarios.md`
- `01-Waterfall/01-Obrigatorios/010_Jornadas_do_Usuario_e_Fluxos_Principais.md`
- `01-Waterfall/01-Obrigatorios/012_Estrategia_de_Conteudo_SEO_e_Publicacao.md`
- `01-Waterfall/01-Obrigatorios/017_UI_UX_Arquitetura_da_Informacao.md`

Também dialoga diretamente com:

- `025_Diagrama_de_Arquitetura_do_Frontend.md`
- `026_Diagrama_de_Componentes_da_UI.md`
- `027_Diagrama_de_Rotas_e_Paginas.md`
- frontend público real do monorepo
- eventuais prints, wireframes e evidências visuais do site

---

## 4. Premissas e limites

## 4.1 Premissas adotadas

Para este documento, adotam-se as seguintes premissas:

- o visitante da área pública chega sem autenticação;
- a jornada pública do projeto é orientada por:
  - descoberta;
  - leitura;
  - construção de confiança;
  - aproximação;
- a homepage pública funciona como ponto de entrada dominante, mas não único;
- publicações individuais também funcionam como entradas importantes via busca, compartilhamento e indexação;
- o visitante não quer “estudar o sistema”; ele quer entender rapidamente:
  - quem é o profissional/projeto;
  - o que ele faz;
  - se aquilo é relevante para sua necessidade;
  - como entrar em contato;
- a estratégia do projeto depende fortemente de conteúdo/SEO e autoridade;
- o frontend real já comprova rotas públicas mínimas:
  - `/`
  - `/publicacoes`
  - `/publicacoes/[slug]`

## 4.2 Limites deste documento

Este arquivo não define:

- funil comercial completo pós-contato;
- automação de CRM;
- playbook de atendimento interno;
- mapa de remarketing;
- métricas finais por canal;
- versão final de cada seção institucional.

Seu papel é fixar a **jornada de experiência pública**.

## 4.3 Regra de prudência arquitetural

Há uma diferença importante entre:

- a **jornada soberana desejada do visitante**; e
- o **estado atual da implementação**, ainda parcial.

Por isso, este documento:

- reconhece o que já está materializado no frontend;
- não trata o bootstrap atual como jornada completa;
- também não reduz a jornada correta ao que já está codificado.

---

## 5. Tese central da jornada do visitante

A tese deste documento é a seguinte:

> a jornada do visitante no projeto William Albarello deve conduzir, com baixa fricção, da descoberta inicial à percepção de autoridade, da percepção de autoridade à leitura aprofundada, e da leitura aprofundada à aproximação qualificada.

Isso significa que a experiência pública não deve ser tratada como simples sequência de páginas.

Ela deve operar como percurso intencional:

1. **entrada**
2. **orientação**
3. **reconhecimento de valor**
4. **aprofundamento**
5. **confiança**
6. **ação**

Se uma dessas camadas falhar, a jornada perde força.

---

## 6. Quem é o visitante desta jornada

Com base nos documentos de personas, o visitante público deve ser lido como um perfil de entrada que pode variar em maturidade, mas compartilha algumas características:

- chega com interesse, dúvida, necessidade ou curiosidade;
- ainda não conhece plenamente o projeto;
- precisa de sinais rápidos de legitimidade;
- tende a decidir rapidamente se continua ou abandona;
- pode entrar:
  - pela home;
  - por uma publicação;
  - por indicação;
  - por mecanismo de busca;
  - por compartilhamento direto.

Este visitante não é, no primeiro momento, um operador técnico do sistema.  
Ele é um **observador potencialmente convertível**.

---

## 7. Objetivos do visitante

A jornada pública precisa responder a objetivos concretos do visitante.

## 7.1 Objetivos primários

- entender o que é o projeto/profissional;
- descobrir se aquilo é relevante para sua necessidade;
- consumir conteúdo útil ou persuasivo;
- avaliar se há autoridade e coerência;
- encontrar caminho claro de contato.

## 7.2 Objetivos secundários

- explorar mais conteúdos relacionados;
- entender áreas de atuação;
- obter prova indireta de qualidade;
- reduzir incerteza antes de uma aproximação.

---

## 8. Pontos de entrada da jornada

A jornada do visitante não começa em um único lugar.  
Ela precisa reconhecer múltiplas portas de entrada.

## 8.1 Entrada pela home

**Rota:** `/`

É a entrada institucional dominante.

Vantagens:
- melhor contexto;
- melhor narrativa;
- mais controle de direcionamento.

Risco:
- se a home for vaga, o visitante não entende o valor rápido o suficiente.

## 8.2 Entrada por publicação

**Rota:** `/publicacoes/[slug]`

É a entrada editorial dominante.

Vantagens:
- alto poder de descoberta orgânica;
- entrada por intenção específica;
- favorece autoridade temática.

Risco:
- se o detalhe da publicação não contextualizar o restante do projeto, o visitante consome o texto e sai.

## 8.3 Entrada por listagem de publicações

**Rota:** `/publicacoes`

É uma entrada intermediária.

Vantagens:
- oferece exploração rápida do acervo;
- ajuda visitantes que já sabem que querem “ler mais”.

Risco:
- se a listagem for fria, pouco escaneável ou mal hierarquizada, ela vira página de abandono.

## 8.4 Entrada por páginas institucionais futuras

**Rotas soberanas esperadas:**
- `/sobre`
- `/atuacao`
- `/contato`

Essas páginas funcionam como entradas de confiança e intenção.

---

## 9. Macroetapas da jornada do visitante

A jornada pública pode ser lida em seis macroetapas.

## 9.1 Descoberta

O visitante toma contato inicial com o projeto.

Fontes típicas:
- busca;
- compartilhamento;
- indicação;
- navegação direta;
- acesso por conteúdo.

## 9.2 Orientação

O visitante tenta responder rapidamente:
- onde estou?
- o que este site oferece?
- isso é para mim?

## 9.3 Reconhecimento de valor

O visitante identifica:
- clareza de proposta;
- relevância do conteúdo;
- coerência entre forma e substância.

## 9.4 Aprofundamento

O visitante:
- lê publicações;
- explora páginas institucionais;
- navega entre conteúdos relacionados;
- entende melhor o posicionamento.

## 9.5 Confiança

O visitante começa a sentir:
- legitimidade;
- coerência;
- segurança de aproximação;
- valor percebido suficiente para avançar.

## 9.6 Conversão / aproximação

O visitante decide:
- entrar em contato;
- seguir navegando com intenção mais forte;
- guardar o projeto para retorno posterior.

---

## 10. Diagrama principal — jornada do visitante

```mermaid
flowchart TD
    E[Entrada do visitante] --> FONTE{Fonte de entrada}

    FONTE --> HOME[Home /]
    FONTE --> LISTA[/publicacoes]
    FONTE --> DETALHE[/publicacoes/[slug]]
    FONTE --> INST[Pagina institucional futura]

    HOME --> ORIENTA[Entende proposta e identidade]
    LISTA --> EXPLORA[Explora acervo]
    DETALHE --> LEITURA[Leitura de conteudo]
    INST --> CONFIANCA1[Percebe posicionamento]

    ORIENTA --> DECISAO1{Encontrou relevancia?}
    EXPLORA --> DECISAO2{Encontrou tema de interesse?}
    LEITURA --> DECISAO3{Conteudo gerou valor?}
    CONFIANCA1 --> DECISAO4{Confianca suficiente?}

    DECISAO1 -->|Sim| APROF[Explora paginas e publicacoes]
    DECISAO1 -->|Nao| SAIDA1[Abandono]
    DECISAO2 -->|Sim| DETALHE2[Abre publicacao]
    DECISAO2 -->|Nao| SAIDA2[Abandono]
    DECISAO3 -->|Sim| REL[Explora relacionados / sobre / contato]
    DECISAO3 -->|Nao| SAIDA3[Abandono]
    DECISAO4 -->|Sim| CONTATO1[Busca aproximacao]
    DECISAO4 -->|Nao| EXPLORA2[Continua explorando]

    APROF --> CONFIANCA2[Construcao de confianca]
    DETALHE2 --> LEITURA2[Leitura aprofundada]
    REL --> CONFIANCA2
    EXPLORA2 --> CONFIANCA2

    LEITURA2 --> CONFIANCA2
    CONFIANCA2 --> DECISAO5{Pronto para agir?}

    DECISAO5 -->|Sim| CTA[CTA / contato / manifestacao de interesse]
    DECISAO5 -->|Nao| RETORNO[Guardar para retorno futuro ou continuar leitura]

    CTA --> CONVERSAO[Conversao publica]
````

---

## 11. Leitura executiva do diagrama

O diagrama mostra que a jornada pública não é linear de forma rígida, mas possui lógica clara.

O visitante:

1. entra por alguma porta;
2. tenta se orientar;
3. decide se há relevância;
4. aprofunda leitura e percepção;
5. constrói confiança;
6. escolhe entre:

   * agir;
   * continuar explorando;
   * abandonar.

Isso confirma que o sistema público precisa funcionar bem em **múltiplas entradas** e não apenas na home.

---

## 12. Jornada pela home

## 12.1 Papel da home

A home é a principal página de orientação da jornada.

Ela deve responder rapidamente:

* quem é William Albarello;
* qual é a proposta/atuação;
* por que vale a atenção do visitante;
* por onde seguir.

## 12.2 O que o visitante procura na home

* clareza inicial;
* hierarquia visual;
* sinal de autoridade;
* indicação de próximos passos;
* CTA sem agressividade confusa.

## 12.3 O que a home deve fazer bem

* contextualizar;
* posicionar;
* distribuir navegação;
* apontar para conteúdo;
* apontar para contato.

## 12.4 Principais saídas da home

* páginas institucionais;
* listagem de publicações;
* contato;
* CTAs contextuais.

---

## 13. Jornada pela listagem de publicações

## 13.1 Papel da listagem

A listagem funciona como biblioteca navegável do projeto.

Ela deve permitir:

* exploração rápida;
* leitura de títulos e resumos;
* escolha de uma peça editorial relevante;
* percepção de densidade e consistência do acervo.

## 13.2 O que o visitante procura na listagem

* temas de interesse;
* títulos claros;
* resumos úteis;
* sinais de atualização e organização;
* baixa fricção para abrir uma publicação.

## 13.3 Riscos da listagem

* cards sem hierarquia;
* excesso de ruído;
* resumos ruins;
* ausência de contexto;
* dificuldade para decidir “qual abrir”.

---

## 14. Jornada pela publicação individual

## 14.1 Papel da página de detalhe

A publicação individual é o coração da autoridade editorial do projeto.

Ela deve sustentar:

* leitura confortável;
* escaneabilidade;
* compreensão do tema;
* aprofundamento;
* ponte para próximos passos.

## 14.2 O que o visitante procura no detalhe

* texto de valor real;
* clareza de tema;
* sensação de consistência;
* continuidade de navegação;
* possibilidade de explorar mais.

## 14.3 Elementos que fortalecem a jornada no detalhe

* título forte;
* resumo claro;
* corpo legível;
* metadata coerente;
* conteúdos relacionados;
* CTA contextual;
* retorno fácil para listagem ou áreas institucionais.

## 14.4 Principal risco do detalhe

O visitante pode ler um bom texto e sair do site sem perceber que há:

* mais conteúdo;
* uma proposta maior;
* um caminho de contato.

Por isso, a publicação precisa ser também ponte, não apenas destino.

---

## 15. Jornada pelas páginas institucionais

## 15.1 Papel das páginas institucionais

Elas existem para transformar atenção em confiança.

Páginas como:

* `/sobre`
* `/atuacao`
* equivalentes institucionais

devem responder perguntas como:

* quem é este profissional/projeto?
* por que devo confiar?
* em que frentes ele atua?
* como isso se conecta à minha necessidade?

## 15.2 Quando o visitante chega nelas

* diretamente, por navegação da home;
* depois de ler conteúdo;
* depois de perceber relevância mas antes de entrar em contato.

## 15.3 O que elas fazem na jornada

Elas reduzem hesitação.

---

## 16. Momento de conversão / aproximação

## 16.1 O que é conversão neste contexto

Na camada pública, conversão não deve ser lida apenas como “venda fechada”.

Ela significa, no mínimo:

* manifestação de interesse;
* contato qualificado;
* início de aproximação.

## 16.2 Canais esperados de conversão

Conforme a evolução do projeto, a conversão pública pode ocorrer por:

* formulário de contato;
* botão de aproximação;
* canal externo integrado;
* CTA contextual em páginas-chave.

## 16.3 Regra da conversão

A conversão deve parecer **próximo passo natural**, não salto abrupto.

---

## 17. Pontos de atrito da jornada

A jornada do visitante pode falhar por diversos motivos.
Os principais atritos esperados são estes.

## 17.1 Atrito de entendimento

O visitante não entende rapidamente:

* o que é o projeto;
* o que ele oferece;
* por que aquilo importa.

## 17.2 Atrito de hierarquia

A interface não deixa claro:

* onde clicar;
* o que ler;
* por onde continuar.

## 17.3 Atrito de confiança

O visitante não percebe sinais suficientes de:

* coerência;
* autoridade;
* profissionalismo;
* consistência.

## 17.4 Atrito de leitura

O conteúdo:

* cansa;
* confunde;
* não escaneia bem;
* não entrega valor rápido o suficiente.

## 17.5 Atrito de conversão

O visitante até se interessa, mas:

* não vê CTA claro;
* não entende o próximo passo;
* não confia o suficiente para agir.

## 17.6 Atrito técnico

* carregamento ruim;
* rotas quebradas;
* página vazia;
* detalhe sem contexto;
* links sem continuidade.

---

## 18. Elementos que reduzem atrito

A jornada pública melhora quando o sistema oferece:

* proposta clara logo na entrada;
* navegação simples;
* páginas institucionais bem amarradas;
* acervo editorial escaneável;
* leitura confortável;
* CTA contextual e não invasivo;
* consistência visual;
* semântica de SEO correta;
* continuidade entre páginas.

---

## 19. Jornada ideal resumida

A jornada ideal do visitante pode ser resumida assim:

1. **entra** por home, publicação ou listagem;
2. **entende rapidamente** onde está;
3. **percebe relevância**;
4. **aprofunda** por conteúdo ou páginas institucionais;
5. **constrói confiança**;
6. **encontra caminho claro de aproximação**;
7. **converte** ou guarda boa memória para retorno.

---

## 20. Diagrama complementar — jornada resumida por intenção

```mermaid
flowchart LR
    D[Descoberta] --> O[Orientacao]
    O --> V[Valor percebido]
    V --> A[Aprofundamento]
    A --> C[Confianca]
    C --> X[Acao / conversao]
```

---

## 21. Leitura do diagrama complementar

Esse diagrama resume a lógica essencial da experiência pública:

* sem **orientação**, a descoberta se perde;
* sem **valor percebido**, a navegação esfria;
* sem **aprofundamento**, a confiança não amadurece;
* sem **confiança**, a conversão não acontece.

---

## 22. Relação com SEO e conteúdo

A jornada do visitante está profundamente ligada à estratégia de conteúdo/SEO do projeto.

## 22.1 SEO como porta de entrada

Boa parte dos visitantes tende a entrar por conteúdo.

Isso significa que o detalhe da publicação precisa cumprir papel duplo:

* responder à busca/intenção que trouxe o visitante;
* apresentar o restante do ecossistema do projeto.

## 22.2 Conteúdo como construção de confiança

Conteúdo não é apenas tráfego.
Ele é mecanismo de legitimidade.

## 22.3 Regra importante

Conteúdo sem ponte institucional gera leitura isolada.
Institucional sem conteúdo gera autoridade fraca.
A jornada precisa dos dois.

---

## 23. Relação com UI/UX e arquitetura da informação

A jornada do visitante depende diretamente de:

* arquitetura de informação clara;
* componentes bem hierarquizados;
* navegação compreensível;
* páginas com semântica explícita;
* continuidade entre home, listagem, detalhe e contato.

Ou seja:
a jornada não é uma camada “por cima” da UI.
Ela emerge da UI corretamente desenhada.

---

## 24. Sinais de sucesso da jornada

Mesmo sem fechar aqui uma camada completa de analytics, a jornada pode ser considerada saudável quando:

* o visitante encontra rapidamente caminhos de navegação;
* a home distribui bem o fluxo;
* a listagem leva ao detalhe com naturalidade;
* a publicação individual retém atenção;
* há progressão para páginas institucionais ou contato;
* o CTA não parece deslocado;
* o abandono precoce diminui nas entradas principais.

---

## 25. Regras macro de integridade da jornada do visitante

## 25.1 RI-JV-01

Toda entrada pública relevante deve permitir orientação rápida.

## 25.2 RI-JV-02

A home deve funcionar como distribuidora clara da navegação pública.

## 25.3 RI-JV-03

A listagem editorial deve facilitar decisão de leitura, não gerar sobrecarga.

## 25.4 RI-JV-04

A publicação individual deve combinar valor de leitura com ponte para continuidade da jornada.

## 25.5 RI-JV-05

A conversão pública deve aparecer como próximo passo natural.

## 25.6 RI-JV-06

A experiência pública deve reduzir atritos de entendimento, confiança e continuidade.

## 25.7 RI-JV-07

SEO, conteúdo e UI devem operar de forma articulada na construção da jornada.

## 25.8 RI-JV-08

Páginas institucionais devem atuar como reforço de confiança, não como conteúdo genérico sem função.

---

## 26. Decisões arquiteturais implícitas neste documento

Este documento fixa, em nível macro, as seguintes decisões:

1. a jornada pública começa em múltiplas entradas;
2. home e conteúdo são portas principais complementares;
3. a publicação individual tem papel central na construção de autoridade;
4. páginas institucionais existem para reduzir hesitação e aprofundar confiança;
5. CTA e contato devem encerrar a jornada como continuação natural;
6. a experiência pública deve ser lida como percurso de valor, não como coleção de páginas;
7. atritos de entendimento e confiança são tão críticos quanto atritos técnicos.

---

## 27. Riscos que este documento evita

### 27.1 Site bonito, mas sem percurso

Evita que o visitante veja páginas isoladas sem lógica de avanço.

### 27.2 Conteúdo que não converte confiança

Evita que a publicação funcione apenas como texto solto.

### 27.3 Home vaga

Evita entrada sem clareza de proposta.

### 27.4 CTA deslocado

Evita conversão abrupta, precoce ou descontextualizada.

### 27.5 Arquitetura da informação desconectada da jornada

Evita desenhar navegação sem pensar no comportamento real do visitante.

### 27.6 Falta de contexto nas entradas orgânicas

Evita que o visitante entre por uma publicação e nunca perceba a proposta maior do projeto.

---

## 28. Critérios de aceite deste documento

Este documento será considerado aceito quando:

* representar claramente a jornada do visitante público;
* explicitar pontos de entrada, navegação, leitura, confiança e conversão;
* identificar atritos relevantes;
* dialogar com personas, conteúdo, SEO, UI/UX e arquitetura da informação;
* servir como base para decisões de páginas, CTAs, blocos e continuidade de navegação.

---

## 29. Conclusão executiva

O visitante público do projeto William Albarello não deve atravessar o site como quem percorre páginas sem relação.

Ele deve viver uma jornada.

Essa jornada, quando corretamente desenhada, começa na descoberta, passa por orientação, valor percebido, aprofundamento e confiança, e termina em aproximação qualificada.

A home, a listagem de publicações, o detalhe editorial e as páginas institucionais são peças complementares desse percurso.

Este documento fixa essa lógica.

Ele transforma a noção abstrata de “experiência do visitante” em um mapa operacional claro, capaz de orientar UI, conteúdo, SEO, CTAs e evolução do frontend público.

---

