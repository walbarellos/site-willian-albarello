
# 001_Convencao_de_Diagramas

## 1. Identificação do documento

- **Projeto:** William Albarello
- **Diretório:** `02-Diagramas`
- **Caminho oficial:** `/home/user/Documents/Softwares/Willian Albarello/William Albarello/02-Diagramas/00-Indice_Mestre/001_Convencao_de_Diagramas.md`
- **Natureza do documento:** Norma mestra de padronização diagramática
- **Função sistêmica:** Definir padrões visuais, semânticos e técnicos para todos os diagramas do Diretório 02
- **Documento relacionado imediatamente anterior:** `000_Indice_Mestre_dos_Diagramas.md`
- **Documento relacionado imediatamente posterior:** `002_Guia_de_Leitura_e_Sequenciamento.md`

---

## 2. Finalidade deste documento

Este documento formaliza a convenção oficial de diagramas do projeto William Albarello. Sua função é estabilizar o modo como os diagramas do Diretório `02-Diagramas` devem ser construídos, nomeados, organizados, lidos, mantidos e atualizados.

Ele existe para impedir cinco problemas clássicos:

1. diagramas visualmente bonitos, porém semanticamente frágeis;
2. diagramas inconsistentes entre si;
3. diagramas que contradizem o Waterfall;
4. diagramas com granularidade errada para sua função;
5. diagramas sem utilidade operacional real.

Esta convenção deve ser lida como **norma mestra do Diretório 02**. Sempre que houver dúvida sobre sintaxe, nomenclatura, granularidade, legenda, representação de atores, fronteiras, sistemas externos, banco, autenticação, jornadas, estados, SEO, deploy e rastreabilidade, este documento deve ser consultado antes da geração ou revisão de qualquer arquivo diagramático.

---

## 3. Escopo da convenção

Esta convenção se aplica a todos os arquivos do Diretório:

`/home/user/Documents/Softwares/Willian Albarello/William Albarello/02-Diagramas`

Inclui, portanto, os blocos:

- `00-Indice_Mestre`
- `01-Arquitetura_e_Contexto`
- `02-Backend_e_API`
- `03-Dados_e_Persistencia`
- `04-Frontend_e_Jornadas`
- `05-Infra_Deploy_e_Operacao`
- `06-Seguranca_e_Controle_de_Acesso`
- `07-SEO_CMS_e_Publicacao`
- `08-Rastreabilidade_e_Apoio`

Não se aplica ao Diretório `01-Waterfall` como forma obrigatória, mas todo diagrama do Diretório 02 deve ser subordinado semanticamente ao conteúdo consolidado no Waterfall.

---

## 4. Fontes normativas prioritárias

Os diagramas do Diretório 02 devem respeitar, prioritariamente, os seguintes documentos do Diretório 01:

- `014_Arquitetura_Tecnica.md`
- `015_Seguranca_Autenticacao_e_Autorizacao.md`
- `016_API_Contract_Mestre.md`
- `017_UI_UX_Arquitetura_da_Informacao.md`
- `023_Matriz_de_Rastreabilidade.md`
- `024_Registro_de_Decisoes_Arquiteturais.md`

Documentos complementares frequentemente vinculados:

- `005_Escopo_MVP_e_Fora_de_Escopo.md`
- `006_Requisitos_Funcionais.md`
- `007_Requisitos_Nao_Funcionais.md`
- `008_Arquitetura_da_Informacao.md`
- `009_Jornada_do_Usuario_e_Fluxos_Principais.md`
- `010_Wireframes_e_Estrutura_de_Paginas.md`
- `012_Estrategia_de_Conteudo_e_SEO.md`
- `013_Modelo_de_Dados_e_CMS.md`
- `018_Plano_de_Testes_Homologacao_e_Qualidade.md`
- `021_Criterios_de_Aceite_Gerais.md`
- `022_Plano_de_Implantacao_Rollback_e_Suporte.md`

### Regra mestra de precedência

Se houver conflito entre:
- um diagrama do Diretório 02, e
- um documento consolidado do Diretório 01,

prevalece o Diretório 01, até que a decisão seja formalmente revisada.

---

## 5. Princípios obrigatórios de construção

Todo diagrama do Diretório 02 deve obedecer simultaneamente aos seguintes princípios:

### 5.1 Coerência
O diagrama deve ser coerente com o escopo, requisitos, arquitetura, segurança, UI/UX, modelo de dados, SEO, deploy e rastreabilidade do projeto.

### 5.2 Utilidade real
O diagrama deve resolver uma necessidade concreta:
- explicar;
- orientar implementação;
- reduzir ambiguidade;
- apoiar análise;
- sustentar auditoria;
- facilitar manutenção;
- preservar continuidade.

### 5.3 Clareza
O diagrama deve ser facilmente legível, mesmo por alguém que não participou da sua construção.

### 5.4 Suficiência
O diagrama deve ter detalhe suficiente para cumprir sua função, sem cair em verborragia visual.

### 5.5 Não invenção
É proibido inventar:
- sistemas externos não comprovados;
- integrações não definidas;
- fluxos não respaldados;
- entidades de dados sem base;
- permissões sem regra;
- infraestrutura fantasiosa.

Na ausência de confirmação, usar:
- hipótese mínima;
- linguagem conservadora;
- explicitação de premissa.

### 5.6 Rastreabilidade
Todo diagrama deve poder ser relacionado a:
- um ou mais documentos do Waterfall;
- um ou mais objetivos do projeto;
- um ou mais requisitos;
- uma função explícita no sistema.

---

## 6. Padrão técnico obrigatório

A linguagem diagramática oficial do Diretório 02 é **Mermaid**, inserida em arquivos `.md`.

### 6.1 Formato obrigatório
Todo diagrama deve ser incluído em bloco:

```mermaid
...
````

### 6.2 Tipos Mermaid preferenciais

Os tipos padrão do projeto são:

* `flowchart`
* `sequenceDiagram`
* `stateDiagram-v2`
* `erDiagram`

Também podem ser usados, quando fizer sentido e sem conflitar com a clareza:

* `journey`
* `classDiagram` apenas se absolutamente necessário
* `graph` como variação compatível do `flowchart`

### 6.3 Escolha correta por finalidade

#### Usar `flowchart` para:

* contexto do sistema;
* visão geral da solução;
* containers;
* componentes macro;
* fronteiras;
* módulos backend;
* componentes da API;
* jornadas;
* fluxos editoriais;
* infraestrutura;
* segurança macro;
* SEO;
* rastreabilidade.

#### Usar `sequenceDiagram` para:

* login;
* autenticação;
* publicação de conteúdo;
* edição de postagem;
* consulta pública;
* fluxo de requisições;
* criação/renovação/encerramento de sessão.

#### Usar `stateDiagram-v2` para:

* estados de postagem;
* estados de sessão;
* estados de publicação;
* estados de processamento, se necessário.

#### Usar `erDiagram` para:

* entidade-relacionamento;
* modelo de dados do conteúdo;
* modelo de dados de usuários/papéis.

### 6.4 Restrições técnicas

Evitar:

* sintaxes pouco estáveis ou dependentes de renderizações específicas;
* excesso de subgraphs aninhados desnecessariamente;
* labels excessivamente longos dentro dos nós;
* hacks visuais que tornem o código Mermaid ilegível;
* duplicação visual que deveria ser resolvida por um diagrama separado.

---

## 7. Padrão estrutural obrigatório de cada arquivo diagramático

Todo arquivo diagramático do Diretório 02 deve, preferencialmente, seguir a seguinte estrutura textual:

````md
# Título do arquivo

## 1. Objetivo

## 2. Fontes de referência no Waterfall

## 3. Premissas e limites

## 4. Diagrama principal

```mermaid
...
````

## 5. Regras de leitura do diagrama

## 6. Observações de consistência

## 7. Impactos, dependências e vínculos

## 8. Relação com outros diagramas

````

### 7.1 Seções mínimas obrigatórias
Nenhum arquivo deve sair sem, no mínimo:
- objetivo;
- diagrama principal;
- regras de leitura;
- observações de consistência;
- relação com o Waterfall.

### 7.2 Seções opcionais
Dependendo do caso, pode haver:
- legenda;
- matriz de apoio;
- exemplos de fluxo;
- premissas;
- restrições;
- riscos de interpretação.

---

## 8. Convenção de nomenclatura

### 8.1 Nomenclatura dos arquivos
O padrão oficial é:

- três dígitos iniciais;
- nome descritivo completo;
- palavras separadas por underscore;
- extensão `.md`.

Exemplo correto:

`014_Diagrama_de_Sequencia_Login.md`

### 8.2 Nomenclatura dos diretórios
O padrão oficial dos diretórios é:

- dois dígitos iniciais;
- tema do bloco;
- palavras separadas por underscore ou hífen, mantendo consistência com a estrutura real já criada.

### 8.3 Nomenclatura interna nos diagramas
Dentro dos diagramas Mermaid:

- IDs técnicos dos nós: curtos, estáveis, sem espaços;
- labels visíveis: legíveis em português e semanticamente claros.

Exemplo recomendado:

```mermaid
flowchart LR
    visitante["Visitante"]
    site_publico["Site Público"]
    painel_admin["Painel Administrativo"]
````

### 8.4 Regra de IDs internos

Os IDs internos devem:

* evitar espaços;
* evitar acentos;
* evitar caracteres especiais desnecessários;
* ser semanticamente estáveis.

Exemplo recomendado:

* `site_publico`
* `painel_admin`
* `api_backend`
* `db_principal`
* `buscador_google`

Exemplo a evitar:

* `x1`
* `nodo3`
* `coisa`
* `backendNovoMesmo`

---

## 9. Nível de abstração e granularidade

A granularidade do diagrama deve ser adequada ao seu bloco e função.

### 9.1 Bloco 01 — Arquitetura e Contexto

Granularidade:

* macro;
* sistêmica;
* explicativa;
* sem detalhamento interno excessivo.

Não deve conter:

* campos de banco;
* validações específicas de rota;
* fluxo detalhado de middleware;
* detalhes de tela muito finos.

### 9.2 Bloco 02 — Backend e API

Granularidade:

* média a média-alta;
* focada em módulos, responsabilidades e fluxos de interação;
* detalhamento suficiente para orientar implementação e leitura técnica.

Não deve:

* virar pseudocódigo;
* mapear linha a linha do backend;
* colapsar tudo num único diagrama ilegível.

### 9.3 Bloco 03 — Dados e Persistência

Granularidade:

* estrutural;
* semântica;
* voltada a entidades, relacionamentos, estados e versionamento.

Deve evitar:

* detalhe de coluna irrelevante se o objetivo for macro;
* confusão entre ER macro e estrutura física completa do banco, salvo quando isso for o objetivo.

### 9.4 Bloco 04 — Frontend e Jornadas

Granularidade:

* funcional;
* orientada à experiência e navegação;
* focada em páginas, componentes, fluxos e papéis.

### 9.5 Bloco 05 — Infra, Deploy e Operação

Granularidade:

* topológica;
* operacional;
* realista.

Não deve inventar ambientes ou serviços inexistentes.

### 9.6 Bloco 06 — Segurança e Controle de Acesso

Granularidade:

* lógica;
* de fluxo;
* de responsabilidade;
* de controle.

### 9.7 Bloco 07 — SEO, CMS e Publicação

Granularidade:

* editorial;
* estrutural;
* orientada a indexação, metadata e publicação.

### 9.8 Bloco 08 — Rastreabilidade e Apoio

Granularidade:

* matricial;
* de cobertura;
* de governança.

---

## 10. Convenção semântica dos elementos

### 10.1 Atores humanos

Atores humanos devem ser representados com labels claras, como:

* `Visitante`
* `Administrador`
* `Editor`
* `Usuário autenticado`

Regra:

* não usar nomes vagos;
* não multiplicar perfis sem necessidade;
* se houver distinção relevante entre papéis, ela deve refletir o Waterfall.

### 10.2 Sistemas internos

Sistemas internos são elementos pertencentes ao projeto:

* site público;
* painel administrativo;
* backend/API;
* camada de autenticação interna;
* persistência própria.

### 10.3 Sistemas externos

Sistemas externos devem ser representados explicitamente como externos:

* provedores de deploy;
* motores de busca;
* DNS;
* serviços terceiros;
* integrações públicas.

Regra:
todo sistema externo deve ser claramente distinguível dos componentes internos.

### 10.4 Banco de dados / persistência

Toda representação de banco deve deixar claro:

* se é armazenamento principal;
* se é componente interno;
* se é base editorial/CMS;
* se é sessão, cache ou persistência primária, quando isso for relevante.

### 10.5 Fluxos

Todo fluxo deve explicitar:

* direção;
* sentido;
* objetivo do vínculo;
* natureza do trânsito quando relevante.

Exemplo:

* autentica;
* consulta;
* publica;
* persiste;
* indexa;
* renderiza;
* atualiza;
* registra.

Evitar setas sem significado.

### 10.6 Fronteiras

Fronteiras devem ser usadas para:

* delimitar o sistema;
* separar frontend de backend;
* separar interno de externo;
* separar ambiente público de administrativo;
* separar serviços próprios de terceiros.

---

## 11. Convenção visual

### 11.1 Regra geral

A semântica vem antes da estética.

As escolhas visuais devem servir à leitura, não à ornamentação.

### 11.2 Classes visuais lógicas

Sempre que possível, usar classes semânticas estáveis em Mermaid, mesmo que o renderizador varie.

Classes lógicas recomendadas:

* `actor`
* `frontend`
* `backend`
* `database`
* `external`
* `auth`
* `seo`
* `infra`
* `decision`
* `warning`
* `admin`

### 11.3 Significado lógico das classes

#### `actor`

Representa pessoa ou papel humano.

#### `frontend`

Representa interface pública ou administrativa.

#### `backend`

Representa API, regras de negócio, serviços internos.

#### `database`

Representa persistência, banco, armazenamento principal.

#### `external`

Representa serviço ou sistema terceiro.

#### `auth`

Representa autenticação, autorização, sessão ou identidade.

#### `seo`

Representa mecanismos de indexação, sitemap, metadata, buscadores.

#### `infra`

Representa deploy, pipeline, DNS, ambiente operacional.

#### `decision`

Representa pontos condicionais importantes.

#### `warning`

Representa riscos, falhas, restrições ou pontos críticos.

#### `admin`

Representa recursos específicos do painel interno.

### 11.4 Exemplo de base visual Mermaid

```mermaid
flowchart LR
    visitante["Visitante"]
    site_publico["Site Público"]
    api_backend["API / Backend"]
    db_principal["Banco Principal"]
    google["Mecanismo de Busca"]

    visitante -->|navega| site_publico
    site_publico -->|consulta| api_backend
    api_backend -->|persiste/consulta| db_principal
    google -->|indexa| site_publico

    classDef actor fill:#f5f5f5,stroke:#333,stroke-width:1px;
    classDef frontend fill:#e8f0fe,stroke:#1a73e8,stroke-width:1px;
    classDef backend fill:#e6f4ea,stroke:#137333,stroke-width:1px;
    classDef database fill:#fef7e0,stroke:#b06000,stroke-width:1px;
    classDef external fill:#fce8e6,stroke:#c5221f,stroke-width:1px;

    class visitante actor
    class site_publico frontend
    class api_backend backend
    class db_principal database
    class google external
```

### 11.5 Observação importante sobre cores

As cores são **lógicas e auxiliares**, não contratuais. O que é obrigatório é:

* consistência semântica;
* distinção entre categorias;
* legibilidade.

Se um renderizador não preservar cor, a estrutura ainda deve continuar compreensível.

---

## 12. Convenções por tipo de diagrama

## 12.1 Diagramas de contexto e visão geral

Devem:

* mostrar atores;
* mostrar o sistema;
* mostrar sistemas externos;
* mostrar relações principais;
* evitar detalhe interno excessivo.

Devem evitar:

* detalhamento de endpoint;
* classes/tabelas;
* detalhes de autenticação linha a linha.

---

## 12.2 Diagramas C4

Quando o objetivo for equivalente a C4, adotar os princípios abaixo em Mermaid, mesmo sem biblioteca C4 formal:

### Nível 1 — Contexto

Mostrar:

* pessoas;
* sistema principal;
* sistemas externos;
* relações.

### Nível 2 — Containers

Mostrar:

* frontend público;
* painel administrativo;
* backend/API;
* banco;
* serviços auxiliares;
* infraestrutura relevante.

Não confundir container com componente pequeno.

---

## 12.3 Diagramas de componentes

Devem mostrar:

* blocos internos relevantes;
* dependências;
* contratos;
* fronteiras.

Não devem:

* virar class diagram escondido;
* representar detalhes sem ganho analítico.

---

## 12.4 Diagramas de sequência

Devem seguir esta convenção:

* participantes nomeados de forma clara;
* sequência temporal natural de cima para baixo;
* mensagens curtas e semânticas;
* uso de blocos condicionais apenas quando necessário.

Exemplo:

```mermaid
sequenceDiagram
    participant Admin as Administrador
    participant UI as Painel
    participant API as API
    participant DB as Banco

    Admin->>UI: envia credenciais
    UI->>API: POST /login
    API->>DB: valida usuário
    DB-->>API: dados do usuário
    API-->>UI: sessão/token válido
    UI-->>Admin: acesso liberado
```

Regra:
sempre que possível, o diagrama de sequência deve explicitar sucesso e falha, ao menos textualmente nas observações.

---

## 12.5 Diagramas de estados

Devem usar `stateDiagram-v2`.

Devem:

* representar estados reais;
* mostrar transições válidas;
* evitar estados sem respaldo;
* explicitar estado inicial e, quando aplicável, estado terminal.

Exemplo:

```mermaid
stateDiagram-v2
    [*] --> Rascunho
    Rascunho --> EmRevisao
    EmRevisao --> Agendado
    EmRevisao --> Publicado
    Agendado --> Publicado
    Publicado --> Arquivado
    Arquivado --> [*]
```

---

## 12.6 Diagramas ER

Devem usar `erDiagram`.

Devem:

* representar entidades relevantes;
* descrever cardinalidades;
* manter nomes claros;
* evitar transformar o diagrama em dump técnico ilegível.

Exemplo:

```mermaid
erDiagram
    USUARIO ||--o{ POSTAGEM : cria
    POSTAGEM }o--o{ TAG : possui
    POSTAGEM ||--o| SEO_METADATA : contem
```

Regra:
se o diagrama for macro, não listar todos os atributos; se for detalhado, listar apenas atributos relevantes ao objetivo.

---

## 12.7 Diagramas de jornada

Quando a necessidade for experiência do usuário ou trilha operacional, podem ser usados:

* `flowchart`
* `journey`

Preferir `flowchart` se a clareza do projeto ficar maior e mais estável.

---

## 12.8 Diagramas de SEO, publicação e editorial

Devem deixar claro:

* origem do conteúdo;
* fluxo de criação/edição/publicação;
* metadata;
* canonicals;
* sitemap;
* descoberta e indexação.

Evitar representar SEO como abstração genérica sem ponto operacional real.

---

## 12.9 Diagramas de deploy e infraestrutura

Devem deixar claro:

* onde o frontend roda;
* onde o backend roda;
* como o domínio aponta;
* quais serviços externos suportam a solução;
* fluxos de publicação, build e entrega, se aplicável.

Nunca inventar:

* ambientes inexistentes;
* clusters não usados;
* pipelines não implementadas ou não aprovadas documentalmente.

---

## 13. Convenção para representação de autenticação, autorização e sessão

### 13.1 Autenticação

Representar separadamente:

* entrada de credenciais;
* validação;
* emissão de sessão/token;
* retorno;
* falhas.

### 13.2 Autorização

Representar:

* perfil;
* recurso;
* decisão de acesso;
* efeito da decisão.

### 13.3 Sessão

Representar:

* criação;
* persistência;
* renovação, se existir;
* expiração;
* encerramento;
* invalidação por logout ou falha, se aplicável.

### 13.4 Regra de clareza

Não misturar, no mesmo diagrama, autenticação, autorização e sessão em detalhe excessivo se isso prejudicar leitura. Separar em diagramas distintos quando necessário.

---

## 14. Convenção para representação de fronteiras

Sempre que possível, usar `subgraph` para fronteiras importantes.

Exemplo:

```mermaid
flowchart LR
    subgraph Sistema["Sistema William Albarello"]
        site["Site Público"]
        painel["Painel Administrativo"]
        api["API / Backend"]
        db["Banco Principal"]
    end

    visitante["Visitante"]
    google["Buscador"]
    vercel["Vercel"]
```

### Fronteiras mais comuns

* sistema interno;
* ambiente público;
* ambiente administrativo;
* serviços externos;
* infraestrutura;
* camadas de aplicação.

### Regra

Fronteira não é decoração. Ela deve comunicar responsabilidade, posse ou limite de atuação.

---

## 15. Convenção para legenda e explicações

### 15.1 Quando legenda é obrigatória

A legenda é obrigatória quando houver:

* várias categorias visuais;
* múltiplos tipos de atores;
* distinção entre interno e externo;
* semântica de setas não óbvia;
* estados ou fluxos complexos.

### 15.2 Forma da legenda

A legenda pode ser:

* textual em seção própria;
* implícita por convenção estável;
* complementar ao diagrama.

### 15.3 Regra

Nenhum diagrama importante deve depender de interpretação subjetiva do leitor.

---

## 16. Convenção de rastreabilidade

Todo diagrama deve explicitar sua ligação com o Waterfall.

### 16.1 Forma mínima de rastreabilidade

Cada documento diagramático deve conter seção como:

* **Documentos-fonte no Waterfall**
* **Requisitos relacionados**
* **Diagramas relacionados**
* **Dependências impactadas**

### 16.2 Forma ideal

Além da seção textual, a rastreabilidade global deve ser consolidada em:

* `046_Matriz_de_Correlacao_Waterfall_x_Diagramas.md`
* `047_Mapa_de_Rastreabilidade_RF_x_Diagramas.md`

### 16.3 Regra

Se um diagrama não puder ser rastreado, sua utilidade ou legitimidade deve ser questionada.

---

## 17. Convenção para premissas e limites

Sempre que um diagrama depender de hipótese, isso deve ser declarado.

### 17.1 Premissas permitidas

São permitidas apenas:

* premissas mínimas;
* premissas coerentes com o Waterfall;
* premissas úteis para completar entendimento;
* premissas explicitamente marcadas.

### 17.2 Premissas proibidas

São proibidas:

* premissas que expandem escopo sem autorização;
* premissas que criam funcionalidades novas;
* premissas que contradizem o projeto;
* premissas vendidas como fato.

### 17.3 Seção recomendada

Todo arquivo que depender de hipótese deve conter:

* **Premissas adotadas**
* **Limites do diagrama**
* **Pontos que dependem de confirmação**

---

## 18. Convenção de manutenção e atualização

### 18.1 Gatilhos de revisão

Revisar diagramas quando houver:

* mudança de escopo;
* mudança de tecnologia;
* mudança de autenticação;
* mudança de rotas ou páginas;
* mudança de estrutura de dados;
* mudança de deploy;
* mudança editorial/SEO;
* nova decisão arquitetural;
* correção de inconsistência.

### 18.2 Processo recomendado

1. localizar documentos do Waterfall impactados;
2. revisar o diagrama-alvo;
3. revisar diagramas correlatos;
4. revisar rastreabilidade;
5. atualizar checklist;
6. atualizar handoff, se necessário.

### 18.3 Regra de integridade

É proibido alterar um diagrama nuclear sem revisar seu contexto ao menos no bloco correspondente e nos vínculos de rastreabilidade.

---

## 19. Padrões proibidos

Os seguintes padrões são proibidos no Diretório 02:

* diagramas sem fonte documental;
* diagrama “genérico de internet” adaptado superficialmente;
* excesso de detalhe em diagrama macro;
* falta de detalhe em diagrama operacional;
* nomenclatura inconsistente;
* labels ambíguas;
* mistura arbitrária de português e inglês;
* representação de infra inexistente;
* setas sem semântica;
* diagrama sem seção explicativa mínima;
* uso de Mermaid quebrado ou não renderizável sem motivo técnico.

---

## 20. Checklist mínimo de conformidade de um diagrama

Antes de considerar qualquer arquivo diagramático pronto, verificar:

* o objetivo está claro?
* o diagrama corresponde ao nome do arquivo?
* a granularidade está correta?
* o diagrama é coerente com o Waterfall?
* há nomenclatura consistente?
* há distinção entre interno e externo?
* as setas têm sentido claro?
* os atores estão bem representados?
* a semântica visual está estável?
* as premissas estão explícitas, se existirem?
* há explicação de leitura?
* a rastreabilidade está indicada?
* o diagrama ajuda de fato na compreensão do sistema?

---

## 21. Exemplo de template padrão recomendado

````md
# 00X_Nome_do_Arquivo

## 1. Objetivo

## 2. Fontes de referência no Waterfall

## 3. Premissas e limites

## 4. Diagrama principal

```mermaid
flowchart LR
    ...
````

## 5. Legenda e regras de leitura

## 6. Observações de consistência

## 7. Relação com outros diagramas

## 8. Impactos de manutenção

```

---

## 22. Regra mestra final do Diretório 02

Os diagramas do projeto William Albarello devem ser:

- tecnicamente corretos;
- semanticamente estáveis;
- rastreáveis;
- legíveis;
- úteis;
- coerentes com a documentação;
- realistas;
- sustentáveis ao longo da continuidade do projeto.

O objetivo do Diretório 02 não é ornamentar o projeto, mas torná-lo mais compreensível, implementável, auditável e preservável.

---

## 23. Conclusão executiva

Esta convenção estabelece o idioma estrutural do Diretório `02-Diagramas`. A partir dela, todo arquivo diagramático do projeto deve seguir um padrão comum de:

- linguagem técnica;
- estilo de representação;
- nomenclatura;
- granularidade;
- explicação;
- vínculo com o Waterfall;
- manutenção;
- rastreabilidade.

Em termos práticos:

- o índice mestre organiza;
- esta convenção estabiliza;
- o guia de leitura sequencia;
- os diagramas específicos materializam.

Sem esta convenção, o Diretório 02 corre risco de fragmentação. Com ela, o repositório passa a operar como camada visual disciplinada do projeto.


