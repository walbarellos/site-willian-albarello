
# 045_Diagrama_de_Canonicals_Sitemap_e_Metadata

## 1. Identificação do documento

- **Projeto:** William Albarello
- **Diretório:** `02-Diagramas`
- **Caminho oficial:** `/home/user/Documents/Softwares/Willian Albarello/William Albarello/02-Diagramas/07-SEO_CMS_e_Publicacao/045_Diagrama_de_Canonicals_Sitemap_e_Metadata.md`
- **Natureza do documento:** Diagrama e contrato lógico da camada técnica de SEO estrutural
- **Função sistêmica:** Detalhar a lógica de canonicals, sitemap, metadados, Open Graph e sinais técnicos relacionados à indexação do projeto
- **Posição no bloco:** Quarto e último documento do bloco `07-SEO_CMS_e_Publicacao`
- **Dependências principais:** `012_Modulos_Dominios_e_Limites_do_Software.md`, `014_Integracoes_e_Sistemas_Externos.md`, `017_UI_UX_Arquitetura_da_Informacao.md`, `021_Criterios_de_Aceite_Gerais.md`, `034_Diagrama_de_DNS_Dominio_e_Subdominios.md`, `042_Diagrama_de_Fluxo_Editorial.md`, `043_Diagrama_de_Indexacao_e_SEO.md`, `044_Diagrama_de_Geracao_e_Publicacao_de_Posts.md`
- **Status:** ATIVO
- **Versão:** v1.0
- **Autoridade:** Alta

---

## 2. Objetivo

Este documento existe para formalizar, de modo claro e soberano, **como o projeto William Albarello organiza sua camada técnica de SEO estrutural**.

Ele responde, com precisão, às seguintes perguntas:

1. como as URLs canônicas devem ser definidas;
2. como `sitemap.xml` deve refletir a superfície pública do projeto;
3. como os metadados por tipo de página devem ser organizados;
4. como Open Graph deve acompanhar a camada pública;
5. como `metadataBase`, rotas públicas e domínio principal se conectam;
6. como a publicação editorial influencia canonical, sitemap e metadata;
7. quais elementos já estão comprovados no frontend real;
8. o que ainda é direção soberana acima do runtime atual.

Este documento trata canonicals, sitemap e metadata como **infraestrutura semântica do site**, e não como acabamento cosmético.

---

## 3. Fontes reais utilizadas

Este documento foi construído com base em artefatos efetivamente encontrados no acervo técnico do projeto.

### 3.1 Documentos soberanos do projeto principal
- `01-Waterfall/01-Obrigatorios/012_Modulos_Dominios_e_Limites_do_Software.md`
- `01-Waterfall/01-Obrigatorios/014_Integracoes_e_Sistemas_Externos.md`
- `01-Waterfall/01-Obrigatorios/017_UI_UX_Arquitetura_da_Informacao.md`
- `01-Waterfall/01-Obrigatorios/021_Criterios_de_Aceite_Gerais.md`
- `01-Waterfall/01-Obrigatorios/024_Registro_de_Decisoes_Arquiteturais.md`

### 3.2 Documentação complementar real do monorepo
- `Waterfall/DOC-06-mapa-de-paginas-e-jornadas.md`
- `Waterfall/DOC-10-arquitetura-tecnica.md`
- `Waterfall/DOC-15-seo-tecnico.md`
- `Waterfall/DOC-16-estrategia-editorial-e-governanca.md`
- `Waterfall/DOC-19-plano-de-testes-e-criterios-de-aceite.md`
- `Waterfall/DOC-24-go-live-checklist-e-handover-final.md`

### 3.3 Frontend real e rotas efetivamente encontradas
- `apps/web/app/layout.tsx`
- `apps/web/app/robots.ts`
- `apps/web/app/sitemap.ts`
- `apps/web/app/page.tsx`
- `apps/web/app/publicacoes/page.tsx`
- `apps/web/app/publicacoes/[slug]/page.tsx`
- `apps/web/next.config.mjs`

### 3.4 Contratos e diagramas correlatos
- `APIs/API-06-openapi-public.yaml`
- `Diagrama/DGM-03-arquitetura-seo.mmd`
- `042_Diagrama_de_Fluxo_Editorial.md`
- `043_Diagrama_de_Indexacao_e_SEO.md`
- `044_Diagrama_de_Geracao_e_Publicacao_de_Posts.md`

---

## 4. Regra de honestidade técnica deste documento

Este ponto é obrigatório.

O acervo **comprova diretamente** que o projeto já possui:

- domínio principal soberano: `https://willianalbarello.com.br`
- `metadataBase` real no frontend
- `robots.ts` real
- `sitemap.ts` real
- rotas públicas reais para:
  - `/`
  - `/publicacoes`
  - `/publicacoes/[slug]`
- modelo editorial com campos de SEO, como:
  - `meta_title`
  - `meta_description`
  - `canonical_url`
  - `og_title`
  - `og_description`
  - `og_image_url`
  - `schema_type`
- política soberana de:
  - canonical obrigatório
  - sitemap público
  - bloqueio de `/painel`
  - Open Graph coerente
  - indexação apenas da superfície pública elegível

O acervo **não comprova diretamente**, no runtime atual:

- metadata dinâmica final e completa já implementada em todas as páginas públicas;
- JSON-LD plenamente materializado por tipo de conteúdo;
- integração end-to-end já finalizada entre CMS real, API pública e metadata por `slug`;
- política final de redirects em mudança de slug já implementada;
- captura real de OG/social preview em produção;
- atualização dinâmica comprovada de sitemap baseada em massa real de posts publicados.

Além disso, o acervo mostra uma diferença importante entre:

### 4.1 Camada soberana de SEO
Mais madura, com governança editorial e semântica já bem definida.

### 4.2 Camada runtime atual
Já bem iniciada no frontend, mas ainda não plenamente fechada em todos os comportamentos dinâmicos.

Este documento, portanto, trabalha com duas camadas:

- **camada soberana de SEO estrutural**, que representa o desenho correto;
- **camada técnica atual**, que representa o que já está materializado de forma mais concreta.

Essa distinção precisa permanecer explícita.

---

## 5. Tese central da camada técnica de SEO estrutural

A tese central deste documento é a seguinte:

> no projeto William Albarello, canonical, sitemap e metadata devem operar como um sistema coerente de identidade pública, de modo que cada URL pública tenha uma versão soberana clara, um conjunto mínimo de sinais semânticos e uma relação consistente com a descoberta pelos buscadores.

Em linguagem simples:

- cada página pública precisa saber “quem é”;
- cada página pública precisa saber “qual URL a representa”;
- o sitemap precisa dizer “quais URLs públicas importam”;
- o `robots` precisa dizer “o que rastrear e o que ignorar”;
- o Open Graph precisa dizer “como essa página se apresenta quando compartilhada”.

---

## 6. Princípios soberanos da camada SEO estrutural

A lógica de canonicals, sitemap e metadata do projeto deve obedecer aos seguintes princípios:

1. **uma URL pública soberana por conteúdo**
2. **metadata coerente com a intenção da página**
3. **sitemap fiel à superfície pública real**
4. **robots coerente com as fronteiras públicas e internas**
5. **Open Graph alinhado à identidade do conteúdo**
6. **domínio principal como base semântica única**
7. **SEO técnico nasce da arquitetura de rotas**
8. **conteúdo publicado determina elegibilidade de indexação**
9. **canonical e slug devem andar juntos**
10. **metadata e conteúdo real não podem se contradizer**

---

## 7. Componentes da camada técnica de SEO

A camada técnica de SEO do projeto é composta por cinco blocos principais:

### 7.1 Host canônico
- `https://willianalbarello.com.br`

### 7.2 Rotas públicas elegíveis
- `/`
- `/publicacoes`
- `/publicacoes/[slug]`

### 7.3 Artefatos técnicos de descoberta
- `/robots.txt`
- `/sitemap.xml`

### 7.4 Metadados por página
- `title`
- `description`
- `metadataBase`
- canonical
- Open Graph
- schema type quando aplicável

### 7.5 Governança editorial
- status publicado
- slug único
- taxonomia coerente
- metadados mínimos
- elegibilidade à camada pública

---

## 8. Diagrama principal da camada técnica de SEO

```mermaid
flowchart TB

    subgraph DOMINIO["Host soberano"]
        H[https://willianalbarello.com.br]
    end

    subgraph ROTAS["Rotas publicas"]
        R1[/]
        R2[/publicacoes]
        R3[/publicacoes/[slug]]
    end

    subgraph SINAIS["Sinais tecnicos"]
        M1[Metadata]
        M2[Canonical]
        M3[Open Graph]
        M4[Sitemap]
        M5[Robots]
    end

    subgraph DESCOBERTA["Descoberta e indexacao"]
        B1[Crawler]
        B2[Interpretacao]
        B3[Indexacao]
    end

    H --> R1
    H --> R2
    H --> R3

    R1 --> M1
    R1 --> M2
    R1 --> M3

    R2 --> M1
    R2 --> M2
    R2 --> M3

    R3 --> M1
    R3 --> M2
    R3 --> M3

    H --> M4
    H --> M5

    M1 --> B1
    M2 --> B1
    M3 --> B1
    M4 --> B1
    M5 --> B1

    B1 --> B2
    B2 --> B3
````

---

## 9. Leitura correta do diagrama principal

## 9.1 O domínio principal é a raiz semântica

Toda a camada pública nasce do host soberano, e não de subdomínios dispersos ou caminhos improvisados.

## 9.2 Cada rota pública precisa de identidade própria

A home, a listagem e o detalhe por `slug` não compartilham a mesma intenção semântica.
Cada uma precisa de metadata e canonical apropriadas.

## 9.3 Os sinais técnicos trabalham em conjunto

Canonical, Open Graph, sitemap, robots e metadata não são peças independentes.
Eles compõem a mesma narrativa técnica da página.

## 9.4 O buscador interpreta sinais combinados

O crawler não lê apenas um campo.
Ele combina:

* URL
* HTML
* title
* description
* canonical
* sitemap
* robots
* conteúdo real

---

## 10. Domínio principal e `metadataBase`

O acervo comprova que o frontend já possui `metadataBase` associado ao domínio principal.

## 10.1 Função do `metadataBase`

Ele fornece a raiz absoluta para:

* canonicals
* Open Graph URLs
* construção coerente de metadata
* normalização de caminhos públicos

## 10.2 Regra soberana

Toda URL pública do projeto deve ser compreendida como derivada do domínio principal:

* `https://willianalbarello.com.br/`
* `https://willianalbarello.com.br/publicacoes`
* `https://willianalbarello.com.br/publicacoes/[slug]`

## 10.3 Consequência

A camada técnica não deve produzir sinais semânticos apontando para:

* hosts secundários sem legitimidade;
* subdomínios administrativos;
* caminhos internos;
* ambientes de preview como se fossem produção.

---

## 11. Lógica de canonicals

Canonical é a declaração da URL soberana de cada página indexável.

## 11.1 Função do canonical

* reduzir ambiguidade;
* consolidar autoridade em uma única URL;
* evitar dispersão de sinais;
* alinhar a rota pública à intenção editorial.

## 11.2 Regra soberana

Toda página pública relevante deve ter canonical coerente com:

* o domínio principal;
* a rota pública correta;
* o slug final, quando houver;
* a versão definitiva da URL.

## 11.3 Canonical por tipo de página

### Home

Canonical:

* `https://willianalbarello.com.br/`

### Listagem de publicações

Canonical:

* `https://willianalbarello.com.br/publicacoes`

### Detalhe de publicação

Canonical:

* `https://willianalbarello.com.br/publicacoes/[slug]`

---

## 12. Diagrama de lógica de canonical

```mermaid id="r8x2me"
flowchart LR

    HOST[metadataBase / host soberano]
    TIPO[Tipo de pagina]
    SLUG[Slug quando aplicavel]
    URL[URL canonica final]

    HOST --> URL
    TIPO --> URL
    SLUG --> URL
```

---

## 13. Regras específicas de canonical por página

## 13.1 Home

A home deve sempre apontar para a raiz soberana do domínio.

### Regra

Não pode haver canonical da home apontando para:

* URL com parâmetros desnecessários;
* ambiente alternativo;
* rota interna.

---

## 13.2 Página de listagem `/publicacoes`

A listagem deve ter canonical próprio, distinto da home e distinto do detalhe.

### Regra

A listagem é um hub público próprio e deve ser tratada como entidade indexável independente.

---

## 13.3 Página de detalhe `/publicacoes/[slug]`

É a unidade canônica de conteúdo editorial individual.

### Regra

O canonical do detalhe deve refletir:

* o slug final válido;
* o host principal;
* o caminho público definitivo.

### Consequência

Mudar `slug` sem política coerente de canonical e transição enfraquece a estabilidade semântica da peça.

---

## 14. Casos de conflito de canonical

O projeto precisa reconhecer situações em que a canonicidade pode ser prejudicada.

## 14.1 Slug duplicado

Dois conteúdos disputando a mesma identidade pública.

## 14.2 Mudança de slug sem transição coerente

A nova URL existe, mas a antiga pode continuar circulando sem política clara.

## 14.3 Página pública com canonical genérico

Exemplo:

* detalhe usando canonical de listagem;
* listagem usando canonical da home.

## 14.4 Ambiente de preview emitindo sinais como se fosse produção

Isso contradiz a arquitetura de domínio e indexação.

### Regra soberana

Ambientes que não são produção não devem ser tratados como fonte semântica soberana.

---

## 15. Sitemap

O sitemap é o mapa formal da superfície pública do projeto.

## 15.1 Evidência real

O frontend já possui `apps/web/app/sitemap.ts`.

## 15.2 Função do sitemap

* enumerar URLs públicas relevantes;
* reforçar a arquitetura pública;
* ajudar a descoberta de conteúdo elegível;
* reduzir opacidade do acervo para crawlers.

## 15.3 Regra soberana

O sitemap deve incluir apenas:

* páginas públicas legítimas;
* URLs canônicas;
* conteúdo editorial elegível.

---

## 16. Diagrama de composição do sitemap

```mermaid id="0x6lrc"
flowchart TD

    HOME[Home publica]
    LISTA[Listagem de publicacoes]
    DETALHES[Detalhes de posts publicados]
    MAP[sitemap.xml]

    HOME --> MAP
    LISTA --> MAP
    DETALHES --> MAP
```

---

## 17. Regras de inclusão no sitemap

## 17.1 Devem entrar no sitemap

* `/`
* `/publicacoes`
* `/publicacoes/[slug]` de conteúdo publicado e elegível

## 17.2 Não devem entrar no sitemap

* `/painel`
* `/painel/*`
* rotas internas
* conteúdo não publicado
* estados editoriais internos
* URLs de preview
* URLs inconsistentes ou temporárias

## 17.3 Regra crítica

Sitemap não é inventário técnico completo do projeto.
É inventário **da superfície pública relevante**.

---

## 18. Relação entre fluxo editorial e sitemap

A arquitetura editorial e o sitemap precisam permanecer coerentes.

## 18.1 Conteúdo antes da publicação

* `draft`
* `review`
* `ready_to_publish`

Esses estados não pertencem ao sitemap público.

## 18.2 Conteúdo publicado

Ao atingir elegibilidade pública, o conteúdo passa a poder integrar:

* listagem pública
* detalhe público
* descoberta via sitemap

## 18.3 Conteúdo arquivado

Ao sair da superfície pública ativa, o conteúdo deve ser reavaliado quanto à permanência ou não no mapa de descoberta.

---

## 19. Robots

O `robots.txt` é a política declarativa de rastreamento do projeto.

## 19.1 Evidência real

O frontend já possui `apps/web/app/robots.ts`.

## 19.2 Função

* orientar crawlers;
* reforçar fronteiras públicas;
* bloquear superfícies internas;
* apontar para o sitemap.

## 19.3 Regra soberana já consolidada

`/painel` e seus desdobramentos não devem ser tratados como área rastreável pública.

---

## 20. Diagrama de `robots` e controle de fronteira

```mermaid id="d3j9hv"
flowchart LR

    ROB[robots.txt] --> ALLOW[Permitir rastreamento da superficie publica]
    ROB --> BLOCK[Bloquear /painel e superficie interna]
    ROB --> MAP[Referenciar sitemap.xml]
```

---

## 21. Metadata por tipo de página

A metadata não deve ser monolítica.
Ela precisa variar conforme a natureza da página.

## 21.1 Home

Deve comunicar:

* identidade institucional;
* proposta pública principal;
* autoridade do domínio.

### Campos mínimos

* `title`
* `description`
* canonical da raiz
* Open Graph institucional

---

## 21.2 Listagem de publicações

Deve comunicar:

* que a página é hub editorial;
* que agrega publicações;
* que leva ao aprofundamento por detalhe.

### Campos mínimos

* `title` coerente com o hub editorial
* `description` de listagem
* canonical de `/publicacoes`
* Open Graph coerente com hub de conteúdo

---

## 21.3 Detalhe de publicação

Deve comunicar:

* título da publicação;
* resumo/descritivo;
* URL canônica do conteúdo;
* sinais sociais coerentes;
* tipo semântico editorial.

### Campos mínimos

* `title` editorial
* `description` editorial
* canonical do detalhe
* Open Graph da publicação
* imagem OG quando houver
* schema type coerente

---

## 22. Diagrama de metadata por tipo de página

```mermaid id="q4u2fk"
flowchart TB

    subgraph HOME["Home"]
        H1[title institucional]
        H2[description institucional]
        H3[canonical raiz]
        H4[OG institucional]
    end

    subgraph LISTA["Listagem de publicacoes"]
        L1[title de hub editorial]
        L2[description de listagem]
        L3[canonical /publicacoes]
        L4[OG de hub]
    end

    subgraph DETALHE["Detalhe de post"]
        D1[title editorial]
        D2[description editorial]
        D3[canonical /publicacoes/[slug]]
        D4[OG editorial]
        D5[schema Article quando aplicavel]
    end
```

---

## 23. Open Graph

Open Graph é parte da camada de apresentação semântica, especialmente em compartilhamento.

## 23.1 Função

* melhorar representação em compartilhamento;
* reduzir ambiguidade visual;
* alinhar a narrativa do conteúdo em contextos externos.

## 23.2 Campos reconhecidos no modelo editorial

* `og_title`
* `og_description`
* `og_image_url`

## 23.3 Regra soberana

Open Graph deve:

* ser coerente com title/description/canonical;
* respeitar a identidade da peça;
* não contradizer o conteúdo real;
* não apontar para imagens ou rotas inconsistentes.

---

## 24. Metadata e modelo de dados editorial

O modelo de dados do projeto já mostra que metadata não é decorativa.

## 24.1 Campos editoriais diretamente ligados à camada SEO

* `slug`
* `meta_title`
* `meta_description`
* `canonical_url`
* `og_title`
* `og_description`
* `og_image_url`
* `schema_type`
* `reading_time_minutes`

## 24.2 Consequência arquitetural

O CMS editorial não gerencia apenas texto.
Ele gerencia também a identidade semântica pública do conteúdo.

---

## 25. Relação entre metadata e UI/UX

A camada técnica de SEO precisa respeitar a arquitetura de informação e a UX do projeto.

## 25.1 Home

É ponto de entrada institucional e precisa comunicar isso também na metadata.

## 25.2 Listagem editorial

É hub público e precisa refletir esse papel na descrição semântica.

## 25.3 Detalhe editorial

É ativo individual e precisa carregar sua própria identidade.

## 25.4 Regra de coerência

A metadata não deve prometer algo diferente do que a UI pública efetivamente entrega.

---

## 26. Relação entre metadata e API pública

A API pública e a camada frontend precisam permanecer coerentes.

## 26.1 A API pública fornece o conteúdo

Ela entrega:

* título
* resumo
* slug
* outros campos editoriais elegíveis

## 26.2 O frontend público organiza a camada semântica

Ele deve transformar isso em:

* title HTML
* description
* canonical
* Open Graph
* schema quando aplicável

## 26.3 Conclusão

A API fornece a matéria-prima editorial; o frontend organiza a expressão semântica pública.

---

## 27. Relação entre camada SEO estrutural e indexação

Este documento aprofunda tecnicamente o que o `043` apresentou em visão mais macro.

## 27.1 O `043` mostrou

* descoberta
* superfícies públicas
* rastreamento
* fronteiras públicas e internas

## 27.2 O `045` detalha

* como cada página se identifica;
* como o host canônico organiza URLs;
* como sitemap e robots participam;
* como metadata e OG reforçam a leitura do conteúdo.

---

## 28. Casos de erro e degradação da camada técnica

A camada técnica de SEO também pode falhar de modo estrutural.

## 28.1 Canonical incorreto

* detalhe apontando para lista;
* lista apontando para home;
* produção apontando para preview.

## 28.2 Sitemap incoerente

* incluindo área interna;
* omitindo área pública central;
* incluindo conteúdo não publicado.

## 28.3 Metadata vazia ou genérica

* todas as páginas com a mesma descrição;
* detalhe editorial sem identidade própria;
* title desalinhado do conteúdo real.

## 28.4 Open Graph inconsistente

* imagem ausente ou errada;
* título social divergente da peça;
* descrição incoerente.

## 28.5 Consequência

Isso degrada:

* compreensão semântica;
* descoberta;
* compartilhamento;
* autoridade do domínio;
* coerência editorial.

---

## 29. Testes mínimos da camada de canonicals, sitemap e metadata

A camada técnica precisa entrar nos critérios de aceite.

## 29.1 Casos mínimos P0

1. `metadataBase` aponta para o domínio principal.
2. home possui canonical da raiz.
3. `/publicacoes` possui canonical próprio.
4. `/publicacoes/[slug]` possui canonical coerente com o slug.
5. `robots.txt` é acessível.
6. `robots.txt` bloqueia `/painel`.
7. `sitemap.xml` é acessível.
8. sitemap não inclui área administrativa.
9. metadata de listagem não é igual à metadata da home.
10. metadata de detalhe editorial é coerente com a publicação.

## 29.2 Casos mínimos P1

1. Open Graph de detalhe acompanha a peça.
2. conteúdo publicado aparece de forma consistente no sitemap.
3. conteúdo não publicado não gera URL pública indexável.
4. mudanças editoriais mantêm canonical coerente.
5. schema editorial é aplicado quando a implementação estiver madura.

---

## 30. Estado real materializado hoje

Este bloco é decisivo para honestidade operacional.

## 30.1 Já comprovado no acervo

* `metadataBase` real no frontend;
* `robots.ts` real;
* `sitemap.ts` real;
* domínio principal soberano;
* rotas públicas reais e claras;
* modelo editorial com campos de SEO;
* bloqueio arquitetural de `/painel`;
* política documental clara de canonical, sitemap, metadata e OG.

## 30.2 Ainda não comprovado como implementação completa

* metadata dinâmica plenamente fechada por `slug` em toda a experiência pública;
* schema JSON-LD completo em produção;
* tratamento final de mudança de slug com política técnica completa;
* sincronização integral entre conteúdo publicado real e sitemap dinâmico;
* todas as peças públicas entregando OG final e consistente em runtime.

## 30.3 Leitura correta

A camada técnica de SEO estrutural está **bem desenhada, parcialmente implementada e claramente governada**, mas ainda precisa alcançar execução completa em alguns pontos dinâmicos.

---

## 31. Riscos do estágio atual

## 31.1 Risco de ter infraestrutura técnica parcial sem semântica completa

Ter `robots.ts` e `sitemap.ts` não basta se a metadata das páginas ainda estiver incompleta ou genérica.

### Mitigação

* fechar metadata por tipo de página;
* amarrar canonical ao runtime real;
* validar por rota e por conteúdo.

## 31.2 Risco de divergência entre modelo editorial e expressão semântica

Se o CMS guarda `meta_title`, `canonical_url` e OG, mas o frontend não usa isso corretamente, a arquitetura fica cindida.

### Mitigação

* tornar a camada pública consumidora plena da semântica editorial;
* testar end-to-end por publicação.

## 31.3 Risco de sitemap e canonical perderem coerência com estado editorial

Conteúdo arquivado ou não publicado não pode continuar com sinais públicos indevidos.

### Mitigação

* atrelar elegibilidade pública à governança editorial;
* revisar sitemap e metadata conforme o estado do conteúdo.

## 31.4 Risco de preview/ambiente não produtivo emitir sinais errados

Isso enfraquece a soberania do domínio principal.

### Mitigação

* preservar produção como fonte semântica canônica;
* impedir que ambientes transitórios se apresentem como definitivos.

---

## 32. Decisões arquiteturais firmadas por este documento

1. O domínio principal é a raiz canônica de toda a camada pública.
2. Cada rota pública relevante deve possuir canonical próprio e coerente.
3. `sitemap.xml` deve refletir apenas a superfície pública legítima.
4. `robots.txt` deve proteger a fronteira entre público e interno.
5. Metadata deve variar por tipo de página.
6. Open Graph é parte da camada semântica pública, não acessório opcional.
7. O modelo editorial já contém os campos necessários para alimentar a camada técnica de SEO.
8. A camada pública deve consumir esses sinais de forma coerente.
9. Conteúdo não publicado não deve produzir sinais públicos soberanos.
10. A arquitetura de canonicals, sitemap e metadata está mais madura do que parte do runtime dinâmico atual, e isso deve permanecer explícito.

---

## 33. O que este documento resolve

Este documento resolve:

* a lógica estrutural de canonical por página;
* a função arquitetural de `sitemap.xml` e `robots.txt`;
* a organização de metadata por tipo de página;
* a relação entre Open Graph, canonical e conteúdo;
* a ligação entre modelo editorial, frontend público e descoberta;
* a base técnica de aceite da camada SEO estrutural.

---

## 34. O que este documento ainda não resolve

Este documento ainda não resolve, em detalhe fino:

* engine final de metadata dinâmica por publicação;
* política técnica detalhada de redirect em troca de slug;
* implementação final de JSON-LD por tipo de peça;
* estratégias avançadas de paginação, hubs taxonômicos e rich results;
* integração formal com ferramentas externas de monitoramento de indexação.

Esses pontos pertencem à implementação posterior e a eventuais blocos complementares de operação/monitoramento.

---

## 35. Critérios de aceite do documento

Este documento será considerado aceito quando cumprir simultaneamente os seguintes critérios:

1. explicar com clareza a lógica de canonicals, sitemap e metadata;
2. distinguir honestamente estado atual e direção soberana;
3. contemplar host canônico, rotas reais e sinais técnicos de descoberta;
4. manter coerência com frontend real, mapa de rotas e arquitetura editorial;
5. servir como fechamento sólido do bloco `07-SEO_CMS_e_Publicacao`.

---

## 36. Conclusão arquitetural

O projeto William Albarello já possui uma camada técnica de SEO estrutural muito bem concebida:

* o host soberano está claro;
* as rotas públicas principais estão definidas;
* `metadataBase`, `robots.ts` e `sitemap.ts` já existem;
* o modelo editorial já guarda os campos semânticos necessários;
* a política de canonical e de bloqueio do painel já está amadurecida.

A leitura correta do momento atual é esta:

* o projeto já sabe **qual URL representa cada coisa**;
* já sabe **o que deve ou não entrar no mapa da descoberta**;
* já sabe **que metadata é parte do conteúdo público**;
* e já começou a materializar isso no frontend real.

Em linguagem simples:

> a espinha dorsal técnica do SEO estrutural já está desenhada com bastante clareza; o próximo trabalho é completar a execução dinâmica fina para que cada publicação pública expresse exatamente a identidade semântica que o projeto já decidiu adotar.

---

## 37. Fechamento do bloco 07

Com este documento, o bloco `07-SEO_CMS_e_Publicacao` fica logicamente fechado com a seguinte sequência:

* `042_Diagrama_de_Fluxo_Editorial.md`
* `043_Diagrama_de_Indexacao_e_SEO.md`
* `044_Diagrama_de_Geracao_e_Publicacao_de_Posts.md`
* `045_Diagrama_de_Canonicals_Sitemap_e_Metadata.md`

---

