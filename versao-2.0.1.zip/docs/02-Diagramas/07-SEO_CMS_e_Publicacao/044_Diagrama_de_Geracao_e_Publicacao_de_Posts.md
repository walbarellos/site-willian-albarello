
# 044_Diagrama_de_Geracao_e_Publicacao_de_Posts

## 1. Identificação do documento

- **Projeto:** William Albarello
- **Diretório:** `02-Diagramas`
- **Caminho oficial:** `/home/user/Documents/Softwares/Willian Albarello/William Albarello/02-Diagramas/07-SEO_CMS_e_Publicacao/044_Diagrama_de_Geracao_e_Publicacao_de_Posts.md`
- **Natureza do documento:** Diagrama e contrato lógico do pipeline operacional de geração e publicação de posts
- **Função sistêmica:** Explicar como posts/publicações são criados, validados, persistidos, promovidos de estado editorial e tornados visíveis na superfície pública
- **Posição no bloco:** Terceiro documento do bloco `07-SEO_CMS_e_Publicacao`
- **Dependências principais:** `012_Modulos_Dominios_e_Limites_do_Software.md`, `013_Modelo_de_Dados_Conceitual.md`, `016_API_Contract_Mestre.md`, `017_UI_UX_Arquitetura_da_Informacao.md`, `018_Plano_de_Testes_Homologacao_e_Qualidade.md`, `042_Diagrama_de_Fluxo_Editorial.md`, `043_Diagrama_de_Indexacao_e_SEO.md`
- **Status:** ATIVO
- **Versão:** v1.0
- **Autoridade:** Alta

---

## 2. Objetivo

Este documento existe para formalizar, de modo claro e operacional, **como o projeto William Albarello gera, valida, persiste e publica posts/publicações**.

Ele responde, com precisão, às seguintes perguntas:

1. quem participa do pipeline de geração/publicação;
2. quais etapas existem entre criação e visibilidade pública;
3. quais validações precisam ocorrer em cada fase;
4. como o backend persiste e promove estado editorial;
5. quando um post passa a ser elegível para API pública;
6. como a UI administrativa e a superfície pública se conectam;
7. quais diferenças existem entre o fluxo soberano e o runtime atual;
8. quais riscos e critérios de bloqueio precisam ser respeitados.

Este documento trata publicação como **pipeline operacional governado**, e não como simples persistência de formulário.

---

## 3. Regra terminológica deste documento

Neste projeto, o termo do arquivo é **“posts”**, mas o acervo técnico e contratual também usa com frequência:

- **publicações**
- **conteúdo editorial**
- **artigos/posts institucionais**

Para evitar ruído conceitual, este documento adota a seguinte equivalência:

> **post = publicação editorial pública do CMS**

Ou seja, neste contexto:
- criar post = criar publicação;
- publicar post = tornar a publicação visível na camada pública;
- atualizar post = editar publicação já existente.

---

## 4. Fontes reais utilizadas

Este documento foi construído com base em artefatos efetivamente encontrados no acervo técnico do projeto.

### 4.1 Documentos soberanos do projeto principal
- `01-Waterfall/01-Obrigatorios/012_Modulos_Dominios_e_Limites_do_Software.md`
- `01-Waterfall/01-Obrigatorios/013_Modelo_de_Dados_Conceitual.md`
- `01-Waterfall/01-Obrigatorios/016_API_Contract_Mestre.md`
- `01-Waterfall/01-Obrigatorios/017_UI_UX_Arquitetura_da_Informacao.md`
- `01-Waterfall/01-Obrigatorios/018_Plano_de_Testes_Homologacao_e_Qualidade.md`
- `01-Waterfall/01-Obrigatorios/021_Criterios_de_Aceite_Gerais.md`
- `01-Waterfall/01-Obrigatorios/024_Registro_de_Decisoes_Arquiteturais.md`

### 4.2 Documentação complementar real do monorepo
- `Waterfall/DOC-06-mapa-de-paginas-e-jornadas.md`
- `Waterfall/DOC-11-modelo-de-dados.md`
- `Waterfall/DOC-12-especificacao-de-apis-e-contratos.md`
- `Waterfall/DOC-15-seo-tecnico.md`
- `Waterfall/DOC-16-estrategia-editorial-e-governanca.md`
- `Waterfall/DOC-19-plano-de-testes-e-criterios-de-aceite.md`
- `Waterfall/DOC-22-operacao-runbooks-e-rotina-de-publicacao.md`

### 4.3 Contratos e diagramas reais
- `APIs/API-07-openapi-admin.yaml`
- `APIs/API-06-openapi-public.yaml`
- `Diagrama/DGM-04-fluxo-publicacao-editorial.mmd`
- `Diagrama/DGM-06-sequencia-publicacao-end-to-end.mmd`

### 4.4 Frontend/backend reais relacionados
- `apps/api/src/routes/auth.ts`
- `apps/web/app/publicacoes/page.tsx`
- `apps/web/app/publicacoes/[slug]/page.tsx`

---

## 5. Regra de honestidade técnica deste documento

Este ponto é obrigatório.

O acervo **comprova diretamente** que o projeto já possui:

- painel administrativo pensado para criação e edição de publicações;
- contrato administrativo com rotas para:
  - listar publicações;
  - criar publicação;
  - ler publicação;
  - atualizar publicação;
  - alterar status;
- contrato público com rotas para:
  - listar publicações públicas;
  - ler publicação por `slug`;
  - ler relacionados;
- modelo de dados com campos editoriais e SEO;
- frontend público com rotas reais de listagem e detalhe de publicações;
- estratégia editorial soberana com ciclo de estados e gates de publicação;
- distinção entre camada administrativa e camada pública;
- necessidade de slug único, taxonomia, metadata e auditoria.

O acervo **também comprova uma tensão importante**:

### 5.1 Camada soberana editorial
Reconhece fluxo mais rico:
- `draft`
- `review`
- `ready_to_publish`
- `published`
- `archived`

### 5.2 Camada contratual/runtime atual
Em alguns pontos ainda está mais simplificada:
- status contratual mais estreito em certos artefatos;
- frontend público ainda parcialmente em scaffold;
- UI administrativa editorial ainda não plenamente materializada no código atual.

### 5.3 Conclusão correta
Este documento trabalha com duas camadas:

- **pipeline soberano de publicação**, que representa o fluxo correto do projeto;
- **pipeline técnico atualmente mais comprovado**, que representa o que já está mais próximo do runtime.

Essa distinção precisa permanecer explícita.

---

## 6. Tese central do pipeline de posts

A tese central deste documento é a seguinte:

> no projeto William Albarello, um post deve percorrer um pipeline controlado de criação, validação, persistência, transição de estado e exposição pública, de modo que a camada pública só consuma conteúdo que já tenha passado por critérios editoriais, estruturais e SEO mínimos.

Em linguagem simples:

- o autor não escreve diretamente “na internet”;
- primeiro o conteúdo nasce no CMS;
- depois o sistema valida;
- depois persiste;
- depois governa o estado;
- só então entrega ao site público.

---

## 7. Princípios soberanos do pipeline operacional de posts

O pipeline de geração e publicação deve obedecer aos seguintes princípios:

1. **criação começa em ambiente interno**
2. **persistência não equivale a publicação**
3. **estado editorial governa visibilidade**
4. **validação antecede promoção de estado**
5. **SEO e taxonomia fazem parte do pipeline**
6. **slug e identidade pública precisam ser estáveis**
7. **publicação precisa deixar rastro**
8. **superfície pública não deve consumir conteúdo inelegível**
9. **atualização deve preservar governança**
10. **arquivamento é parte formal do pipeline**

---

## 8. Atores do pipeline

O pipeline de posts envolve múltiplos atores.

## 8.1 Ator humano editorial
### Editor / Operador de Conteúdo
Responsável por:
- criar rascunhos;
- editar;
- enriquecer conteúdo;
- organizar taxonomia;
- preparar publicação.

### Administrador Principal
Responsável por:
- revisar ou supervisionar;
- publicar;
- arquivar;
- governar mudanças mais sensíveis;
- consultar auditoria.

---

## 8.2 Atores sistêmicos
### Painel administrativo
Interface de entrada, edição e transição editorial.

### API administrativa
Responsável por:
- autenticar;
- autorizar;
- validar payload;
- persistir;
- mudar status;
- auditar ações.

### Banco de dados
Responsável por:
- armazenar o estado do post;
- armazenar metadados;
- sustentar integridade editorial.

### API pública
Responsável por:
- expor somente posts elegíveis;
- listar conteúdo publicado;
- entregar detalhe por `slug`.

### Frontend público
Responsável por:
- consumir a API pública;
- apresentar posts publicados;
- expor sinais de SEO e descoberta.

---

## 9. Macrovisão do pipeline de geração e publicação

O pipeline correto pode ser entendido como cinco macrofases:

1. **criação**
2. **enriquecimento**
3. **validação e governança**
4. **publicação**
5. **visibilidade pública**

Além disso, existem duas macrofases pós-publicação:

6. **atualização**
7. **arquivamento**

---

## 10. Diagrama principal do pipeline de geração e publicação

```mermaid
flowchart TD

    subgraph INTERNO["Camada interna / CMS"]
        A1[Editor/Admin]
        A2[Painel Admin]
        A3[API Admin]
        A4[(Banco)]
    end

    subgraph GOVERNANCA["Governança editorial"]
        G1[Draft]
        G2[Review]
        G3[Ready To Publish]
        G4[Published]
        G5[Archived]
    end

    subgraph PUBLICO["Camada pública"]
        P1[API Publica]
        P2[Listagem /publicacoes]
        P3[Detalhe /publicacoes/[slug]]
    end

    A1 --> A2
    A2 --> A3
    A3 --> A4

    A4 --> G1
    G1 --> G2
    G2 --> G3
    G3 --> G4
    G4 --> P1
    P1 --> P2
    P1 --> P3
    G4 --> G5
````

---

## 11. Leitura correta do diagrama principal

## 11.1 O post nasce na camada interna

O autor ou operador nunca cria diretamente na superfície pública.
Ele cria dentro do painel administrativo.

## 11.2 A API administrativa é o guardião do pipeline

O painel não grava livremente.
Ele depende da API para:

* validar;
* autorizar;
* persistir;
* mudar status.

## 11.3 O banco conserva o estado editorial

O post existe no banco com:

* campos de conteúdo;
* campos de SEO;
* taxonomia;
* status;
* timestamps;
* rastros operacionais.

## 11.4 A visibilidade pública depende do estado

Só quando o conteúdo atinge `published` ele se torna elegível à camada pública.

## 11.5 A API pública faz a ponte para o site

O frontend público não deveria consultar rascunhos ou estados internos.
Ele deve receber apenas o recorte elegível.

---

## 12. Fase 1 — Criação do post

A criação é a entrada do conteúdo no pipeline.

## 12.1 Ação humana inicial

O operador/admin:

* acessa a área de publicações;
* escolhe criar nova publicação;
* preenche campos iniciais;
* salva.

## 12.2 Campos base mínimos da fase de criação

Com base no modelo e contrato, a criação gira em torno de:

* `title`
* `slug`
* `summary`
* `content`
* `status`
* `categoryId`
* `tagIds`

### Campos SEO associados

* `meta_title`
* `meta_description`
* `canonical_url`
* `og_title`
* `og_description`
* `og_image_url`

## 12.3 Regra correta

Na criação, o sistema pode aceitar incompletude razoável para rascunho.
Mas isso não autoriza publicação.

---

## 13. Fase 2 — Validação inicial

Todo post precisa passar por validação já na entrada.

## 13.1 Validações mínimas da criação

* payload bem formado;
* autenticação válida;
* permissão compatível com a ação;
* título não vazio;
* slug formalmente válido;
* coerência mínima do objeto enviado.

## 13.2 Validações de conflito

A arquitetura já reconhece a necessidade de:

* slug único;
* tratamento de conflito por `409`.

## 13.3 Regra soberana

Persistir conteúdo mal formado ou estruturalmente inconsistente enfraquece todo o pipeline posterior.

---

## 14. Diagrama de criação e persistência inicial

```mermaid id="w8r1jb"
sequenceDiagram
    autonumber
    actor E as Editor/Admin
    participant UI as Painel
    participant API as API Admin
    participant DB as Banco

    E->>UI: preencher formulario do post
    UI->>API: POST /admin/publications
    API->>API: validar sessao + permissao + payload
    API->>API: verificar conflitos de slug
    API->>DB: persistir publicacao inicial
    DB-->>API: publicacao salva
    API-->>UI: 201 + snapshot do post
```

---

## 15. Fase 3 — Enriquecimento do post

Depois de criado, o post entra em amadurecimento editorial.

## 15.1 O que se enriquece

* corpo do conteúdo;
* resumo;
* taxonomia;
* metadados SEO;
* coerência entre título e slug;
* legibilidade editorial.

## 15.2 Regra correta

O post não é apenas texto.
Ele é composto por:

* conteúdo;
* enquadramento temático;
* identidade pública;
* sinais técnicos de descoberta.

## 15.3 Consequência

A qualidade do enriquecimento define o quão apto o post estará para virar ativo público de verdade.

---

## 16. Fase 4 — Governança de estado

A governança de estado é o coração do pipeline.

## 16.1 Fluxo soberano reconhecido

* `draft`
* `review`
* `ready_to_publish`
* `published`
* `archived`

## 16.2 Papel do estado

O estado responde:

* em que estágio editorial o post está;
* se ele pode ser editado livremente;
* se precisa de revisão;
* se está pronto para publicação;
* se já está público;
* se foi retirado do fluxo.

## 16.3 Honestidade técnica

O runtime atual ainda não comprova integralmente todos esses estados em todos os artefatos, mas essa continua sendo a máquina soberana correta do projeto.

---

## 17. Diagrama de estados editoriais do post

```mermaid id="a3k7fx"
stateDiagram-v2
    [*] --> Draft
    Draft --> Review
    Review --> ReadyToPublish
    ReadyToPublish --> Published
    Published --> Archived
    Published --> Draft: reabertura controlada quando aplicavel
    Published --> Review: atualizacao com nova revisao quando aplicavel
```

---

## 18. Fase 5 — Validação de publicabilidade

Antes de publicar, o post precisa provar que está pronto.

## 18.1 Critérios mínimos soberanos

Com base na estratégia editorial e SEO, a publicação deve exigir:

1. título coerente;
2. slug final único;
3. resumo minimamente útil;
4. conteúdo consistente;
5. categoria válida;
6. tags adequadas;
7. metadados SEO mínimos;
8. canonical coerente;
9. papel/permissão adequada para publicar;
10. trilha de auditoria da ação.

## 18.2 Regra crítica

Persistir um post não significa que ele esteja publicável.
Publicar é ato distinto, governado e mais sensível.

---

## 19. Fase 6 — Publicação do post

A publicação é a promoção do post da camada interna para a camada pública.

## 19.1 O que acontece na publicação

Quando o post é publicado, o sistema deve:

* alterar o estado para `published`;
* definir `published_at` quando aplicável;
* persistir a mudança;
* registrar auditoria;
* tornar o item elegível à API pública;
* permitir leitura na superfície pública;
* refletir a identidade canônica e SEO do conteúdo.

## 19.2 Quem deve publicar

Conforme a governança do projeto:

* `admin` possui autoridade plena;
* `editor` pode participar do fluxo, mas a publicação final permanece governada.

---

## 20. Diagrama de publicação do post

```mermaid id="0o9yvd"
sequenceDiagram
    autonumber
    actor A as Admin
    participant UI as Painel
    participant API as API Admin
    participant DB as Banco
    participant AUD as Auditoria

    A->>UI: solicitar publicacao
    UI->>API: PATCH /admin/publications/{id}/status
    API->>API: validar sessao + role + checklist editorial + SEO
    API->>DB: atualizar status=published e published_at
    API->>AUD: registrar PUBLICATION_PUBLISHED
    DB-->>API: persistido
    API-->>UI: 200 publicado
```

---

## 21. Fase 7 — Visibilidade pública

Depois de publicado, o post entra na camada pública.

## 21.1 Efeito público esperado

O post passa a poder aparecer em:

* `/publicacoes`
* `/publicacoes/[slug]`
* listas relacionadas
* sitemap
* descoberta por buscadores

## 21.2 Regra soberana

A superfície pública só deve consumir conteúdo elegível e publicado.

## 21.3 Papel da API pública

A API pública deve filtrar e entregar apenas o conteúdo que pode ser visto pelo visitante final.

---

## 22. Diagrama de passagem para visibilidade pública

```mermaid id="2mwh1s"
flowchart LR

    PUB[Post em status published] --> API[API Publica]
    API --> LISTA[/publicacoes]
    API --> DETALHE[/publicacoes/[slug]]
    LISTA --> USER[Visitante]
    DETALHE --> USER
```

---

## 23. Relação entre geração/publicação e frontend público

O frontend público é consumidor, não origem do post.

## 23.1 Fluxo correto

1. painel cria/edita;
2. API admin governa;
3. banco persiste;
4. API pública seleciona;
5. frontend público apresenta.

## 23.2 Benefício desse desenho

* separação entre interno e público;
* controle de visibilidade;
* governança de estado;
* suporte a SEO e rastreabilidade.

---

## 24. Relação entre pipeline de posts e SEO

O pipeline de posts e o SEO são inseparáveis.

## 24.1 Antes da publicação

O post precisa de:

* slug;
* metadata;
* canonical;
* taxonomia;
* coerência editorial.

## 24.2 Depois da publicação

O post precisa:

* ser elegível à descoberta;
* poder entrar em sitemap;
* carregar identidade pública coerente;
* não disputar canonicidade com URLs ruins.

## 24.3 Regra de ouro

Post público sem SEO mínimo é pipeline incompleto.

---

## 25. Relação entre pipeline de posts e taxonomia

Taxonomia é parte do pipeline, não adorno.

## 25.1 Categoria

Define o agrupamento mais estrutural do post.

## 25.2 Tags

Refinam a semântica e a descoberta.

## 25.3 Consequência operacional

Post mal taxonomizado:

* enfraquece navegação;
* piora clusterização;
* dificulta descoberta;
* degrada coerência do acervo.

---

## 26. Relação entre pipeline de posts e permissões

O pipeline precisa respeitar autoridade de cada papel.

## 26.1 Editor

Pode:

* criar;
* editar;
* preparar;
* revisar;
* organizar parte do fluxo editorial.

## 26.2 Admin

Pode:

* tudo que o editor pode;
* publicar;
* arquivar;
* supervisionar;
* consultar auditoria.

## 26.3 Regra soberana

Ação de maior impacto exige autoridade maior.

---

## 27. Relação entre pipeline de posts e auditoria

Cada etapa crítica do pipeline deve deixar rastro.

## 27.1 Eventos mínimos auditáveis

* `PUBLICATION_CREATED`
* `PUBLICATION_UPDATED`
* `PUBLICATION_STATUS_CHANGED`
* `PUBLICATION_PUBLISHED`
* `PUBLICATION_ARCHIVED`
* `SEO_METADATA_UPDATED`
* `CATEGORY_LINKED`
* `TAG_LINKED`

## 27.2 Valor operacional

Esses eventos ajudam a responder:

* quem criou;
* quem alterou;
* quem publicou;
* qual status mudou;
* em qual entidade;
* em que momento.

---

## 28. Fase 8 — Atualização do post publicado

Publicação não encerra a vida do post.

## 28.1 Quando atualizar

* correção de conteúdo;
* melhoria editorial;
* refresh SEO;
* atualização factual;
* revisão de contexto.

## 28.2 Fluxo correto

O post já publicado pode:

* ser editado;
* voltar a uma fase de revisão lógica;
* reaparecer publicamente atualizado.

## 28.3 Honestidade técnica

No contrato atual, isso pode ainda parecer uma edição do item `published`, sem máquina de estados rica explicitada.
Mas, soberanamente, o projeto já reconhece a lógica de revisão e republicação.

---

## 29. Fase 9 — Arquivamento do post

O pipeline termina formalmente com arquivamento quando necessário.

## 29.1 Quando arquivar

* conteúdo obsoleto;
* conteúdo substituído;
* retirada estratégica;
* necessidade de sair da descoberta ativa.

## 29.2 O que o arquivamento deve causar

* alteração de estado;
* remoção da elegibilidade pública;
* rastreabilidade da ação;
* eventual ajuste de descoberta e SEO, conforme estratégia.

## 29.3 Regra importante

Arquivar é ação editorial e operacional relevante, não simples exclusão impulsiva.

---

## 30. Diagrama completo de pipeline operacional

```mermaid id="l5t8qv"
flowchart TD

    C[Criar post] --> V1{Payload valido?}
    V1 -->|Nao| ERR1[Rejeitar criacao]
    V1 -->|Sim| D[Salvar draft]

    D --> E[Enriquecer conteudo + taxonomia + SEO]
    E --> V2{Pronto para revisao?}
    V2 -->|Nao| E
    V2 -->|Sim| R[Review]

    R --> V3{Aprovado editorialmente?}
    V3 -->|Nao| E
    V3 -->|Sim| RTP[Ready To Publish]

    RTP --> V4{Role adequada + checklist final?}
    V4 -->|Nao| BLOCK[Bloquear publicacao]
    V4 -->|Sim| P[Published]

    P --> PUBAPI[API Publica]
    PUBAPI --> SITE[Visibilidade publica]

    P --> U{Precisa atualizar?}
    U -->|Sim| E
    U -->|Nao| ARC{Precisa arquivar?}
    ARC -->|Sim| A[Archived]
    ARC -->|Nao| SITE
```

---

## 31. Casos de erro e bloqueio do pipeline

Um pipeline maduro precisa saber dizer “não”.

## 31.1 Casos mínimos de bloqueio

* sessão inválida;
* role insuficiente;
* payload inválido;
* slug duplicado;
* post inexistente;
* categoria ausente na publicação;
* metadados mínimos ausentes;
* tentativa de promoção de estado inconsistente;
* conflito de publicação.

## 31.2 Respostas esperadas

A arquitetura já reconhece respostas como:

* `401`
* `403`
* `409`
* `422`

---

## 32. Testes mínimos do pipeline de posts

O pipeline precisa entrar nos testes obrigatórios.

## 32.1 Casos mínimos P0

1. criar post válido.
2. rejeitar criação inválida.
3. editar rascunho.
4. bloquear publicação sem requisitos mínimos.
5. publicar com requisitos mínimos válidos.
6. tornar post publicado visível na API pública.
7. listar post publicado na superfície pública.
8. acessar detalhe público por `slug`.
9. arquivar post e retirá-lo da elegibilidade ativa.
10. registrar auditoria de criação/publicação/arquivamento.

## 32.2 Casos mínimos P1

1. atualizar post publicado com governança.
2. manter canonical coerente após atualização.
3. bloquear editor sem autoridade final quando necessário.
4. garantir consistência entre estado interno e exposição pública.

---

## 33. Estado real materializado hoje

Este bloco é decisivo para honestidade operacional.

## 33.1 Já comprovado no acervo

* contrato admin para CRUD editorial e mudança de status;
* contrato público para listagem e detalhe de conteúdo publicado;
* modelo de dados com campos editoriais e SEO;
* páginas públicas reais para listagem e detalhe;
* estratégia editorial madura;
* sequência end-to-end documentada;
* governança de papéis e auditoria.

## 33.2 Ainda não comprovado como implementação completa

* UI administrativa final do CMS no código atual;
* máquina de estados editorial soberana plenamente refletida no runtime;
* validações completas de publicabilidade já fechadas no backend real;
* integração final do detalhe público com conteúdo real em produção;
* automação completa pós-publicação em sitemap/relacionados.

## 33.3 Leitura correta

O pipeline operacional de posts está **muito bem desenhado documentalmente**, com parte contratual já madura, mas ainda em fase de consolidação prática no runtime.

---

## 34. Riscos do estágio atual

## 34.1 Risco de CRUD sem pipeline real

Ter CRUD de publicação sem governança editorial forte empobrece o produto.

### Mitigação

* manter estados e gates explícitos;
* não reduzir publicação a “campo status solto”.

## 34.2 Risco de conteúdo persistido virar conteúdo público cedo demais

Isso rompe a separação entre interno e público.

### Mitigação

* API pública filtra elegibilidade;
* publicação exige checklist;
* superfície pública não consome estados internos.

## 34.3 Risco de contrato e runtime divergirem da governança soberana

Já existe essa tensão em parte do acervo.

### Mitigação

* alinhar estado editorial do modelo/contrato com o fluxo soberano;
* testar transições críticas;
* manter documentação e runtime convergentes.

## 34.4 Risco de SEO ser acoplado tarde demais

Isso enfraquece a publicação pública.

### Mitigação

* manter metadata e canonical dentro do pipeline;
* não tratar SEO como “ajuste posterior”.

---

## 35. Decisões arquiteturais firmadas por este documento

1. Post e publicação editorial são equivalentes funcionais neste projeto.
2. O pipeline começa no painel e termina na camada pública.
3. Persistência não equivale a visibilidade pública.
4. O estado editorial governa a exposição pública.
5. Publicação exige checklist editorial, taxonômico e SEO.
6. A API administrativa é o guardião da criação, edição e promoção de estado.
7. A API pública só deve expor conteúdo elegível.
8. Atualização e arquivamento são fases formais do pipeline.
9. Auditoria é obrigatória nas ações críticas do pipeline.
10. O desenho soberano do pipeline está mais rico do que parte do runtime atual, e isso deve permanecer explícito até a convergência final.

---

## 36. O que este documento resolve

Este documento resolve:

* a visão operacional do pipeline de posts;
* os atores e camadas envolvidas;
* a relação entre criação, persistência, estado e visibilidade;
* a integração entre CMS, API admin, banco, API pública e frontend;
* a base de validação, publicação, atualização e arquivamento;
* a conexão do pipeline com SEO, permissões e auditoria.

---

## 37. O que este documento ainda não resolve

Este documento ainda não resolve, em detalhe fino:

* UI final do editor/admin de conteúdo;
* modelagem física fechada da máquina de estados no banco;
* regras finas de preview editorial;
* estratégia de versionamento histórico do conteúdo;
* redirecionamento fino em mudança de slug;
* automação integral pós-publicação no runtime.

Esses pontos pertencem ao próximo documento do bloco e à implementação técnica progressiva.

---

## 38. Critérios de aceite do documento

Este documento será considerado aceito quando cumprir simultaneamente os seguintes critérios:

1. representar corretamente atores, validações, persistência, estado, publicação e visibilidade;
2. distinguir honestamente o estado soberano e o estado técnico atual;
3. mostrar a separação entre camada interna e camada pública;
4. manter coerência com conteúdo/SEO, CMS, API e UI/UX;
5. servir como base sólida para a continuação do bloco 07.

---

## 39. Conclusão arquitetural

O projeto William Albarello já possui um pipeline de posts conceitualmente robusto:

* o conteúdo nasce dentro do CMS;
* é validado e amadurecido;
* passa por governança de estado;
* só se torna público quando elegível;
* pode ser atualizado e arquivado com controle.

A leitura correta do momento atual é esta:

* a lógica do pipeline já está clara;
* a arquitetura já sabe quem cria, quem governa e quem publica;
* a separação entre interno e público está bem desenhada;
* o runtime ainda precisa alcançar toda a riqueza desse desenho em alguns pontos.

Em linguagem simples:

> o projeto já desenhou bem a esteira de vida dos posts; agora precisa continuar transformando essa esteira documental em execução técnica integral e coerente.

---

