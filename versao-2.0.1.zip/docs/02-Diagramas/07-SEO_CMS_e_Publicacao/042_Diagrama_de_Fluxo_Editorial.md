
# 042_Diagrama_de_Fluxo_Editorial

## 1. Identificação do documento

- **Projeto:** William Albarello
- **Diretório:** `02-Diagramas`
- **Caminho oficial:** `/home/user/Documents/Softwares/Willian Albarello/William Albarello/02-Diagramas/07-SEO_CMS_e_Publicacao/042_Diagrama_de_Fluxo_Editorial.md`
- **Natureza do documento:** Diagrama e contrato lógico do ciclo editorial
- **Função sistêmica:** Mostrar o fluxo editorial do conteúdo, desde criação até revisão, preparação para publicação, publicação, atualização, indexação pública e arquivamento
- **Posição no bloco:** Primeiro documento do bloco `07-SEO_CMS_e_Publicacao`
- **Dependências principais:** `012_Modulos_Dominios_e_Limites_do_Software.md`, `013_Modelo_de_Dados_Conceitual.md`, `017_UI_UX_Arquitetura_da_Informacao.md`, `018_Plano_de_Testes_Homologacao_e_Qualidade.md`, `038_Diagrama_de_Seguranca_da_Aplicacao.md`, `039_Diagrama_de_Fluxo_de_Sessao.md`, `040_Diagrama_de_Permissoes_por_Perfil.md`, `041_Diagrama_de_Auditoria_e_Rastreabilidade.md`
- **Status:** ATIVO
- **Versão:** v1.0
- **Autoridade:** Alta

---

## 2. Objetivo

Este documento existe para formalizar, de modo claro e soberano, **como o conteúdo editorial do projeto William Albarello nasce, é preparado, validado, publicado, mantido e eventualmente arquivado**.

Ele responde às seguintes perguntas:

1. como uma publicação entra no sistema;
2. quais estados editoriais existem;
3. quais validações precisam ocorrer antes da publicação;
4. como conteúdo, taxonomia e SEO se conectam;
5. como a publicação chega à superfície pública;
6. como funciona atualização de conteúdo já publicado;
7. quando e como um conteúdo deve ser arquivado;
8. o que já está materializado no contrato, no modelo e no código real;
9. o que ainda é governança soberana acima do runtime atual.

Este documento trata fluxo editorial como **processo de governança de conteúdo**, e não apenas como CRUD de textos.

---

## 3. Fontes reais utilizadas

Este documento foi construído com base em artefatos efetivamente encontrados no acervo técnico do projeto.

### 3.1 Documentos soberanos do projeto principal
- `01-Waterfall/01-Obrigatorios/012_Modulos_Dominios_e_Limites_do_Software.md`
- `01-Waterfall/01-Obrigatorios/013_Modelo_de_Dados_Conceitual.md`
- `01-Waterfall/01-Obrigatorios/017_UI_UX_Arquitetura_da_Informacao.md`
- `01-Waterfall/01-Obrigatorios/018_Plano_de_Testes_Homologacao_e_Qualidade.md`
- `01-Waterfall/01-Obrigatorios/021_Criterios_de_Aceite_Gerais.md`
- `01-Waterfall/01-Obrigatorios/023_Matriz_de_Rastreabilidade.md`
- `01-Waterfall/01-Obrigatorios/024_Registro_de_Decisoes_Arquiteturais.md`

### 3.2 Documentação complementar real do monorepo
- `Waterfall/DOC-06-mapa-de-paginas-e-jornadas.md`
- `Waterfall/DOC-11-modelo-de-dados.md`
- `Waterfall/DOC-15-seo-tecnico.md`
- `Waterfall/DOC-16-estrategia-editorial-e-governanca.md`
- `Waterfall/DOC-19-plano-de-testes-e-criterios-de-aceite.md`
- `Waterfall/DOC-22-operacao-runbooks-e-rotina-de-publicacao.md`

### 3.3 Diagramas e contratos reais
- `Diagrama/DGM-04-fluxo-publicacao-editorial.mmd`
- `Diagrama/DGM-06-sequencia-publicacao-end-to-end.mmd`
- `APIs/API-07-openapi-admin.yaml`
- `APIs/API-06-openapi-public.yaml`

### 3.4 Código real relacionado
- `apps/web/app/publicacoes/page.tsx`
- `apps/web/app/publicacoes/[slug]/page.tsx`

---

## 4. Regra de honestidade técnica deste documento

Este ponto é obrigatório.

O acervo **comprova diretamente** que o projeto já possui:

- um módulo editorial real e central;
- páginas públicas para:
  - listagem de publicações;
  - detalhe de publicação por `slug`;
- rotas administrativas contratuais para:
  - listar publicações;
  - criar publicação;
  - editar publicação;
  - alterar status;
  - gerir categorias;
  - gerir tags;
  - consultar auditoria;
- campos editoriais e SEO no modelo de dados, como:
  - `title`
  - `slug`
  - `summary`
  - `content`
  - `category_id`
  - `tagIds`
  - `meta_title`
  - `meta_description`
  - `canonical_url`
  - `og_title`
  - `og_description`
  - `og_image_url`
  - `schema_type`
  - `reading_time_minutes`
- governança editorial explícita com estados:
  - `draft`
  - `review`
  - `ready_to_publish`
  - `published`
  - `archived`
- regras de publicabilidade ligadas a:
  - slug único;
  - taxonomia correta;
  - metadados SEO mínimos;
  - canonical válido;
  - revisão técnica/editorial;
  - trilha de auditoria.

O acervo **também comprova uma divergência importante**:

### 4.1 Governança editorial soberana
Os documentos `DOC-16` e `DGM-04` reconhecem um fluxo editorial mais rico:
- `draft`
- `review`
- `ready_to_publish`
- `published`
- `archived`

### 4.2 Estado atual do contrato/modelo técnico
O contrato administrativo e o modelo de dados ainda aparecem mais estreitos em alguns pontos:
- `PATCH /admin/publications/{id}/status` com enum comprovado: `draft`, `published`, `archived`
- `DOC-11-modelo-de-dados.md` com restrição explícita de status: `draft`, `published`, `archived`

### 4.3 Conclusão correta
O fluxo editorial soberano do projeto é **mais maduro do que a materialização técnica atual**.

Este documento, portanto, trabalha com duas camadas:

- **camada soberana editorial**, que representa o desenho correto do ciclo;
- **camada runtime atual**, que representa o que já está mais explicitamente implementado ou contratado.

Essa diferença precisa permanecer visível.

---

## 5. Tese central do fluxo editorial

A tese central deste documento é a seguinte:

> no projeto William Albarello, conteúdo não deve ser tratado como texto solto a ser publicado por impulso, mas como ativo editorial governado por ciclo, critérios de qualidade, validações SEO, rastreabilidade e transições explícitas de estado.

Em linguagem simples:

- primeiro se cria;
- depois se estrutura;
- depois se revisa;
- depois se prepara para publicar;
- só então se publica;
- depois se mantém, atualiza ou arquiva.

Publicar, neste projeto, é **ato editorial governado**, e não simples “salvar e tornar visível”.

---

## 6. Princípios soberanos do ciclo editorial

O fluxo editorial do projeto deve obedecer aos seguintes princípios:

1. **conteúdo nasce em rascunho**
2. **publicação exige critérios mínimos**
3. **SEO não é pós-efeito, é parte do fluxo**
4. **taxonomia faz parte da governança editorial**
5. **status editorial deve ser explícito**
6. **publicação e arquivamento precisam deixar rastro**
7. **conteúdo publicado pode ser atualizado sem perder controle**
8. **conteúdo desatualizado deve poder sair de circulação com governança**
9. **a superfície pública só deve consumir conteúdo elegível**
10. **o fluxo editorial deve ser testável, auditável e operacionalmente legível**

---

## 7. Estados editoriais do projeto

A governança editorial soberana do projeto reconhece os seguintes estados:

### 7.1 `draft`
Estado de criação e trabalho inicial.

### 7.2 `review`
Estado de revisão técnica/editorial.

### 7.3 `ready_to_publish`
Estado de conteúdo pronto, aguardando publicação final.

### 7.4 `published`
Estado de conteúdo público e elegível para descoberta.

### 7.5 `archived`
Estado de conteúdo retirado do fluxo ativo de descoberta/publicação.

---

## 8. Diagrama principal do fluxo editorial soberano

```mermaid
flowchart TD

    D[Draft] --> R[Review]
    R --> RTP[Ready To Publish]
    RTP --> P[Published]
    P --> U[Updated]
    U --> P
    P --> A[Archived]

    subgraph VALIDACOES["Validações obrigatórias"]
        V1[Titulo + slug unico]
        V2[Categoria + tags]
        V3[SEO minimo\nmeta + canonical + OG]
        V4[Auditoria da acao]
        V5[Conteudo e resumo consistentes]
        V6[Checklist editorial final]
    end

    D --> V1
    R --> V2
    RTP --> V3
    RTP --> V5
    RTP --> V6
    P --> V4
    A --> V4
````

---

## 9. Leitura correta do diagrama principal

## 9.1 `draft`

É o ponto de entrada normal do conteúdo.

Nele, o editor:

* cria a peça;
* define título;
* inicia slug;
* escreve resumo e conteúdo;
* começa taxonomia;
* preenche ou planeja SEO.

## 9.2 `review`

É o ponto em que a peça deixa de ser apenas rascunho pessoal e entra em governança.

Nele, o sistema e/ou a operação validam:

* coerência textual;
* consistência técnica;
* taxonomia;
* estrutura mínima do conteúdo.

## 9.3 `ready_to_publish`

É o estado em que o conteúdo já deveria estar apto à publicação, faltando apenas o ato final de liberação.

Nele, o projeto espera:

* SEO preenchido;
* canonical válido;
* categoria e tags corretas;
* slug final;
* integridade de revisão;
* checklist editorial final.

## 9.4 `published`

É o estado em que o conteúdo passa a:

* aparecer na API pública;
* integrar a listagem pública;
* responder por URL própria;
* participar de descoberta, interlinking, sitemap e leitura pública.

## 9.5 `updated`

Não é necessariamente um status persistido no contrato atual, mas é um **momento lógico do ciclo**:

* conteúdo publicado é alterado;
* passa por ajuste;
* volta ao estado público com nova versão editorial coerente.

## 9.6 `archived`

É o estado em que a peça sai do acervo ativo de descoberta, normalmente por:

* desatualização;
* desalinhamento estratégico;
* substituição editorial;
* necessidade de retirada organizada.

---

## 10. Diagrama runtime simplificado atualmente comprovado

Como o contrato atual ainda está mais estreito, a leitura mínima hoje comprovada também pode ser representada assim:

```mermaid id="3w6fka"
flowchart LR

    D1[Draft] --> P1[Published]
    P1 --> A1[Archived]
    P1 --> U1[Update via edicao]
    U1 --> P1
```

### Interpretação correta

Esse diagrama não substitui o soberano.
Ele apenas mostra que o contrato e o modelo atuais ainda estão mais próximos de um ciclo simplificado.

---

## 11. Fase 1 — Criação do conteúdo

A criação começa no painel administrativo.

## 11.1 Fluxo de entrada

1. operador/admin abre a lista de publicações;
2. escolhe criar nova publicação;
3. preenche campos básicos;
4. salva como rascunho.

## 11.2 Campos mínimos relevantes de criação

Com base no modelo e no contrato, a criação editorial gira em torno de:

* `title`
* `slug`
* `summary`
* `content`
* `categoryId`
* `tagIds`
* `status`

### Campos SEO relacionados

* `meta_title`
* `meta_description`
* `canonical_url`
* `og_title`
* `og_description`
* `og_image_url`

## 11.3 Regra correta

O sistema pode permitir rascunho incompleto, mas não publicação incompleta.

---

## 12. Fase 2 — Enriquecimento editorial

Depois do rascunho, a peça precisa ganhar completude.

## 12.1 Elementos que devem amadurecer

* corpo do conteúdo;
* resumo;
* coerência entre título e slug;
* categoria;
* tags;
* metadados SEO;
* elegibilidade semântica de publicação.

## 12.2 Regras já comprovadas pela documentação

A governança editorial real já fixa que:

* tags não devem duplicar categoria;
* taxonomia deve ser coerente;
* publicação exige metadados mínimos;
* slug único é obrigatório;
* canonical correto é obrigatório.

---

## 13. Fase 3 — Revisão

A revisão não é enfeite.
Ela existe para impedir ruído, erro e publicação fraca.

## 13.1 O que se revisa

* qualidade do texto;
* coerência técnica;
* adequação ao posicionamento editorial;
* clareza do resumo;
* slug final;
* taxonomia;
* metadados;
* prontidão de indexação.

## 13.2 Papéis soberanos reconhecidos pela estratégia editorial

A documentação complementar já reconhece funções como:

* owner editorial;
* editor técnico;
* revisor SEO;
* publicador.

### Honestidade técnica

Esses papéis estão documentalmente claros, mas ainda não aparecem todos como roles plenas no runtime atual.

---

## 14. Fase 4 — Preparação para publicação

O estado `ready_to_publish` representa a peça pronta para ir ao ar com governança.

## 14.1 Critérios mínimos soberanos de publicabilidade

Com base em `DOC-15` e `DOC-16`, uma publicação só deve ir para `published` quando tiver:

1. objetivo editorial claro;
2. conteúdo revisado;
3. slug único;
4. categoria definida;
5. tags adequadas;
6. metadados SEO mínimos;
7. canonical válido;
8. revisão final de linguagem;
9. rastreabilidade da ação de publicação.

## 14.2 Regra crítica

Publicar sem esse pacote mínimo contradiz diretamente a estratégia editorial e SEO do projeto.

---

## 15. Fase 5 — Publicação

A publicação é o ponto em que o conteúdo cruza da camada administrativa para a camada pública.

## 15.1 Efeito arquitetural da publicação

Quando uma peça entra em `published`, ela deve passar a:

* ser elegível na listagem pública;
* responder por URL pública por `slug`;
* integrar descoberta e navegação;
* poder participar de relacionados;
* integrar sitemap quando aplicável;
* carregar seus metadados públicos.

## 15.2 Regra de dados

No modelo real:

* `published_at` se torna obrigatório quando `status = published`;
* categoria deixa de ser opcional para publicação;
* slug precisa estar válido e único.

---

## 16. Diagrama de sequência editorial end-to-end

```mermaid
sequenceDiagram
    autonumber
    actor Admin as Admin/Editor
    participant Panel as Painel Admin (Next.js)
    participant API as Admin API
    participant DB as PostgreSQL
    participant Site as Site Publico
    participant PublicAPI as Public API

    Admin->>Panel: Criar ou editar rascunho
    Panel->>API: POST/PUT /v1/admin/publications
    API->>API: Validar sessao + CSRF + permissao
    API->>API: Validar payload editorial
    API->>DB: Upsert publication (draft/review/ready)
    DB-->>API: persistido
    API-->>Panel: 200/201 + snapshot

    Admin->>Panel: Publicar
    Panel->>API: PATCH/POST de status editorial
    API->>API: Validar regras de negocio + SEO + taxonomia + slug
    API->>DB: Atualizar status=published e published_at
    API->>DB: Registrar audit log
    DB-->>API: committed
    API-->>Panel: 200 publicado

    Site->>PublicAPI: GET /v1/public/publications
    PublicAPI->>DB: Buscar apenas status elegivel
    DB-->>PublicAPI: rows
    PublicAPI-->>Site: 200 listagem publica
```

---

## 17. Relação entre fluxo editorial e API pública

O frontend público não deveria consumir qualquer conteúdo bruto.

## 17.1 Regra correta

A API pública deve expor apenas conteúdo elegível à superfície pública.

## 17.2 Evidência real

O fluxo técnico complementar já registra a ideia de:

* painel grava/publica;
* API pública consulta o banco;
* site público lista/detalha conteúdo publicado.

## 17.3 Conclusão

Existe uma fronteira clara entre:

* conteúdo em trabalho interno;
* conteúdo disponível para descoberta pública.

---

## 18. Relação entre fluxo editorial e SEO

O bloco editorial e o bloco SEO são inseparáveis.

## 18.1 O que a estratégia de SEO já impõe

* slug único;
* canonical válido;
* metadata mínima;
* sitemap atualizado em publicação/arquivamento;
* `Article` como tipo de schema para publicações;
* prevenção de duplicidade editorial.

## 18.2 Consequência

O fluxo editorial precisa incorporar SEO antes da publicação, não depois.

## 18.3 Regra de ouro

Conteúdo editorialmente pronto, mas SEO-incompleto, **não está pronto de verdade**.

---

## 19. Relação entre fluxo editorial e taxonomia

Taxonomia não é decoração.
Ela organiza descoberta, clusterização e leitura pública.

## 19.1 Regras já fixadas no acervo

* categoria representa agrupamento mais estrutural;
* tags representam subtópicos;
* tags não devem duplicar categoria;
* categoria deve estar definida quando a peça for publicada.

## 19.2 Consequência editorial

Uma peça sem taxonomia adequada:

* fica mal descoberta;
* enfraquece SEO;
* piora navegação pública;
* reduz coerência do acervo.

---

## 20. Fase 6 — Atualização de conteúdo publicado

Conteúdo publicado não deve ser tratado como estático para sempre.

## 20.1 Quando atualizar

* revisão evergreen;
* mudança técnica relevante;
* melhoria de clareza;
* correção factual;
* reforço de SEO ou interlinking;
* atualização de posicionamento.

## 20.2 Leitura correta do ciclo

O conteúdo publicado pode:

* ser editado;
* passar por revisão;
* retornar ao estado público atualizado.

## 20.3 Honestidade técnica

O contrato atual não modela explicitamente `updated` como status formal.
Aqui, `updated` é **momento lógico do fluxo**, não necessariamente valor persistido do campo `status`.

---

## 21. Fase 7 — Arquivamento

Arquivar não é “deletar no susto”.

## 21.1 Quando arquivar

Com base na estratégia editorial real:

* conteúdo desatualizado sem plano de revisão;
* conteúdo que não adere mais ao posicionamento;
* peça substituída por nova versão;
* material que deve sair do fluxo ativo de descoberta.

## 21.2 O que arquivamento exige

* decisão governada;
* rastro de auditoria;
* avaliação de impacto em SEO;
* decisão sobre canonical/redirect, quando aplicável;
* retirada coerente da descoberta ativa.

## 21.3 Regra importante

Arquivamento é ato editorial e operacional relevante, e deve ser tratado como tal.

---

## 22. Diagrama de publicação, atualização e arquivamento

```mermaid id="9q6jdu"
flowchart TD

    P[Published] --> Q{Mudanca necessaria?}
    Q -->|Nao| KEEP[Permanece publico]
    Q -->|Sim| EDIT[Editar / revisar]
    EDIT --> REPUB[Republicar versao atualizada]
    REPUB --> P

    P --> ARCQ{Conteudo desatualizado ou fora de estrategia?}
    ARCQ -->|Nao| KEEP
    ARCQ -->|Sim| ARCH[Arquivar]
```

---

## 23. Eventos auditáveis do fluxo editorial

O fluxo editorial precisa deixar rastros fortes.

## 23.1 Eventos mínimos

* `PUBLICATION_CREATED`
* `PUBLICATION_UPDATED`
* `PUBLICATION_STATUS_CHANGED`
* `PUBLICATION_PUBLISHED`
* `PUBLICATION_ARCHIVED`
* `CATEGORY_LINKED`
* `TAG_LINKED`
* `SEO_METADATA_UPDATED`

## 23.2 Valor desses eventos

Eles ajudam a responder:

* quem criou;
* quem alterou;
* quem publicou;
* quando publicou;
* qual status mudou;
* qual entidade foi afetada;
* com qual contexto operacional.

---

## 24. Tela e jornada administrativa relacionadas

A arquitetura de UI/UX já reconhece um fluxo administrativo editorial claro.

## 24.1 Superfícies relevantes

* `/painel/publicacoes`
* `/painel/publicacoes/novo`
* `/painel/publicacoes/[id]`
* `/painel/publicacoes/[id]/editar`
* `/painel/categorias`
* `/painel/tags`
* `/painel/auditoria`

## 24.2 Operações críticas já reconhecidas na UI/UX

* localizar publicação;
* criar nova;
* salvar rascunho;
* editar;
* revisar;
* publicar;
* consultar auditoria.

## 24.3 Regra de UX

O fluxo editorial deve ser legível, com:

* status claros;
* bloqueios explícitos;
* mensagens previsíveis;
* transições de estado compreensíveis.

---

## 25. Casos de erro e bloqueio editorial

Um fluxo editorial maduro também prevê recusas corretas.

## 25.1 Casos mínimos de bloqueio

* slug duplicado;
* payload inválido;
* sessão inválida;
* role insuficiente;
* SEO mínimo ausente;
* categoria ausente na tentativa de publicar;
* estado inconsistente;
* conflito de publicação.

## 25.2 Evidência técnica real

O diagrama complementar já reconhece respostas como:

* `409` para conflito de slug;
* `422` para payload inválido;
* `401` para sessão inválida.

---

## 26. Relação entre fluxo editorial e testes

O fluxo editorial está no coração do plano de testes.

## 26.1 Casos mínimos já exigidos documentalmente

* criação de publicação;
* edição de publicação;
* mudança de status;
* persistência correta;
* taxonomia funcional;
* listagem pública;
* detalhe público;
* auditoria mínima;
* SEO funcional;
* coerência de slugs e URLs.

## 26.2 Massa mínima de homologação

O próprio plano de testes exige:

* ao menos 3 publicações públicas;
* categorias mínimas;
* tags mínimas;
* conteúdo em múltiplos estados;
* logs básicos de auditoria.

---

## 27. Diagrama de fluxo editorial com gates de qualidade

```mermaid id="x0c2wa"
flowchart LR

    C[Conteudo criado] --> D[Draft]
    D --> G1{Campos base preenchidos?}
    G1 -->|Nao| D
    G1 -->|Sim| R[Review]

    R --> G2{Taxonomia correta?}
    G2 -->|Nao| R
    G2 -->|Sim| RTP[Ready To Publish]

    RTP --> G3{SEO minimo + canonical + checklist final?}
    G3 -->|Nao| RTP
    G3 -->|Sim| P[Published]

    P --> G4{Precisa atualizar?}
    G4 -->|Sim| U[Updated]
    U --> R
    G4 -->|Nao| G5{Precisa arquivar?}
    G5 -->|Sim| A[Archived]
```

---

## 28. Estado real materializado hoje

Este bloco é decisivo para honestidade operacional.

## 28.1 Já comprovado no acervo

* módulo editorial é central no produto;
* existem páginas públicas para listagem e detalhe;
* existe contrato admin para criar, editar e alterar status;
* existem categorias, tags e audit logs no desenho real;
* o modelo de dados já contempla publicações com campos SEO;
* existe estratégia editorial explícita com critérios de publicabilidade;
* existe diagrama específico de fluxo editorial;
* existe sequência end-to-end entre painel, API, banco e site público.

## 28.2 Ainda não comprovado como implementação completa

* painel administrativo editorial completo em UI real;
* estados `review` e `ready_to_publish` plenamente implementados no contrato/runtime atual;
* workflow editorial completo automatizado no backend;
* atualização automática comprovada de sitemap no código atual;
* related content já materializado plenamente na UI pública;
* toda a governança de revisão materializada como engine de estado fechada.

## 28.3 Leitura correta

A arquitetura editorial está **muito madura documentalmente** e **parcialmente contratada/estruturada tecnicamente**, mas o runtime ainda precisa alcançar toda a riqueza do fluxo soberano.

---

## 29. Riscos do estágio atual

## 29.1 Risco de contrato simplificado demais frente à governança editorial

Hoje existe tensão entre:

* fluxo soberano rico;
* contrato/runtime ainda mais estreito.

### Mitigação

* alinhar campo `status` e transições ao fluxo editorial real;
* não achatar `review` e `ready_to_publish` por conveniência permanente.

## 29.2 Risco de publicar sem checklist mínimo

Sem gates editoriais claros, a qualidade pública degrada.

### Mitigação

* bloquear publicação sem taxonomia e SEO mínimos;
* auditar publicação e arquivamento;
* usar staging e homologação.

## 29.3 Risco de taxonomia frouxa

Sem controle, categorias e tags perdem valor.

### Mitigação

* governança taxonômica;
* revisão de redundâncias;
* relação clara entre cluster, categoria e tag.

## 29.4 Risco de SEO ser tratado como pós-processamento

Isso contradiz frontalmente a estratégia técnica do projeto.

### Mitigação

* SEO entra antes de `published`;
* canonical, slug e metadados são parte do fluxo;
* atualização e arquivamento devem considerar descoberta pública.

---

## 30. Decisões arquiteturais firmadas por este documento

1. O conteúdo do projeto segue ciclo editorial governado.
2. `draft`, `review`, `ready_to_publish`, `published` e `archived` são os estados soberanos do fluxo.
3. O contrato/runtime atual ainda está mais simples do que a governança desejada.
4. Publicação exige slug, taxonomia, SEO mínimo e checklist editorial.
5. A superfície pública só deve servir conteúdo elegível à publicação.
6. Atualização de conteúdo publicado é parte normal do ciclo.
7. Arquivamento é ação editorial relevante e rastreável.
8. Taxonomia e SEO são partes do fluxo editorial, não anexos periféricos.
9. Auditoria é obrigatória em publicação, mudança de status e arquivamento.
10. O fluxo editorial precisa ser refletido em testes, UI, API e modelo de dados sem contradição.

---

## 31. O que este documento resolve

Este documento resolve:

* a visão macro do fluxo editorial;
* os estados editoriais soberanos;
* a diferença entre ciclo soberano e runtime atual;
* a relação entre criação, revisão, publicação, atualização e arquivamento;
* a conexão entre fluxo editorial, taxonomia, SEO, API pública e auditoria;
* a base para testes e endurecimento do CMS editorial.

---

## 32. O que este documento ainda não resolve

Este documento ainda não resolve, em detalhe fino:

* máquina de estados implementada em código;
* UX detalhada do editor de conteúdo;
* política final de revisões/versionamento de conteúdo;
* automação concreta de sitemap e related content no runtime;
* detalhes finos de preview editorial;
* estratégia de redirect em troca de slug já implementada end-to-end.

Esses pontos pertencem aos próximos documentos do bloco e à implementação técnica progressiva.

---

## 33. Critérios de aceite do documento

Este documento será considerado aceito quando cumprir simultaneamente os seguintes critérios:

1. representar corretamente o ciclo editorial de ponta a ponta;
2. distinguir honestamente governança soberana e estado técnico atual;
3. mostrar criação, revisão, publicação, atualização e arquivamento;
4. integrar fluxo editorial com SEO, taxonomia, CMS e API pública;
5. servir como base sólida para os documentos seguintes do bloco 07.

---

## 34. Conclusão arquitetural

O projeto William Albarello já possui uma visão editorial madura e estruturalmente correta:

* conteúdo nasce como rascunho;
* passa por governança;
* só publica com critérios mínimos;
* entra na superfície pública com integridade editorial e SEO;
* pode ser revisto e atualizado;
* pode ser arquivado com controle.

A leitura correta do momento atual é esta:

* o desenho editorial do projeto já está claro;
* ele é mais sofisticado do que o contrato/runtime atual em alguns pontos;
* e isso não é problema, desde que essa diferença seja reconhecida e corrigida progressivamente.

Em linguagem simples:

> o projeto já sabe como o conteúdo deve viver; agora precisa terminar de fazer o runtime obedecer plenamente a essa vida editorial desenhada.

---

