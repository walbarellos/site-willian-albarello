
# 003_Diagrama_de_Contexto_do_Sistema

## 1. Identificação do documento

- **Projeto:** William Albarello
- **Diretório:** `02-Diagramas`
- **Caminho oficial:** `/home/user/Documents/Softwares/Willian Albarello/William Albarello/02-Diagramas/01-Arquitetura_e_Contexto/003_Diagrama_de_Contexto_do_Sistema.md`
- **Natureza do documento:** Diagrama de contexto do sistema
- **Função sistêmica:** Representar o sistema no nível mais alto, evidenciando atores externos, solução principal, serviços de apoio, integrações comprovadas e limites de responsabilidade
- **Posição na sequência:** Primeiro diagrama estrutural do Bloco 01
- **Dependência imediata:** `000_Indice_Mestre_dos_Diagramas.md`, `001_Convencao_de_Diagramas.md`, `002_Guia_de_Leitura_e_Sequenciamento.md`

---

## 2. Objetivo

Este documento apresenta o **diagrama de contexto do sistema** do projeto William Albarello no seu nível mais alto de abstração.

Seu objetivo é permitir que qualquer leitor compreenda, sem mergulhar ainda em containers, módulos, endpoints, entidades ou telas internas:

- quem interage com o sistema;
- qual é o núcleo da solução;
- quais componentes macro pertencem ao sistema;
- quais serviços externos orbitam a solução;
- quais limites separam o sistema de seu ecossistema;
- como o projeto se posiciona como site institucional com capacidade editorial, painel interno e backend próprio.

Este documento não detalha implementação interna fina. Sua função é **situar o sistema no mundo**.

---

## 3. Fontes de referência no Waterfall

Este diagrama deve ser lido como derivado, principalmente, dos seguintes documentos do Diretório `01-Waterfall`:

- `001_Visao_Geral_do_Projeto.md`
- `002_Problema_Oportunidade_e_Tese_Central.md`
- `003_Objetivos_de_Negocio_e_de_Produto.md`
- `004_Publico_Alvo_e_Personas.md`
- `005_Escopo_MVP_e_Fora_de_Escopo.md`
- `014_Arquitetura_Tecnica.md`
- `016_API_Contract_Mestre.md`
- `017_UI_UX_Arquitetura_da_Informacao.md`

Documentos complementares com influência indireta:

- `008_Arquitetura_da_Informacao.md`
- `009_Jornada_do_Usuario_e_Fluxos_Principais.md`
- `012_Estrategia_de_Conteudo_e_SEO.md`
- `013_Modelo_de_Dados_e_CMS.md`
- `015_Seguranca_Autenticacao_e_Autorizacao.md`
- `022_Plano_de_Implantacao_Rollback_e_Suporte.md`
- `024_Registro_de_Decisoes_Arquiteturais.md`

---

## 4. Premissas e limites

### 4.1 Premissas adotadas

Para fins deste diagrama de contexto, são assumidas como válidas as seguintes premissas documentais:

- o projeto William Albarello é um **site institucional pessoal/profissional** orientado à construção de autoridade;
- a solução possui **camada pública** e **camada administrativa/painel interno**;
- existe ou existirá uma **API/backend** para sustentar autenticação, gestão de conteúdo e operações internas;
- existe ou existirá uma **camada de persistência/CMS/banco** coerente com a solução;
- a estratégia de hospedagem considera **frontend em Vercel** e **backend em Render**, conforme direcionamento já associado ao projeto;
- o sistema precisa dialogar com **motores de busca** por causa do requisito de indexação e SEO forte.

### 4.2 Limites deste diagrama

Este documento **não** detalha:

- arquitetura interna de módulos;
- componentes internos da API;
- fluxos de autenticação passo a passo;
- entidades do banco de dados;
- rotas, telas ou journeys detalhadas;
- pipelines de CI/CD;
- políticas de backup, observabilidade ou auditoria em detalhe.

Esses aspectos serão tratados em diagramas posteriores do Diretório 02.

### 4.3 Regra de prudência

Este diagrama mostra **somente elementos que fazem sentido dentro do contexto já estabelecido** pelos documentos-base do projeto. Não há inclusão de integrações não comprovadas ou de serviços acessórios não estabilizados.

---

## 5. Diagrama principal

```mermaid
flowchart LR

    visitante["Visitante / Leitor"]
    admin["Administrador / Autor"]

    buscadores["Motores de Busca"]
    vercel["Vercel"]
    render["Render"]

    subgraph sistema["Sistema William Albarello"]
        site["Site Institucional Público"]
        painel["Painel Interno / Área Administrativa"]
        api["Backend / API"]
        dados["Banco de Dados / CMS / Persistência"]
    end

    visitante -->|acessa, navega, consome conteúdo| site
    admin -->|autentica e administra conteúdo| painel

    site -->|consulta dados públicos| api
    painel -->|operações administrativas| api
    api -->|lê e grava dados| dados

    buscadores -->|descobrem e indexam| site

    vercel -->|hospeda camada web pública e/ou frontend| site
    vercel -. suporte de publicação .-> painel

    render -->|hospeda backend e serviços de aplicação| api

    classDef actor fill:#f5f5f5,stroke:#333,stroke-width:1px;
    classDef frontend fill:#e8f0fe,stroke:#1a73e8,stroke-width:1px;
    classDef backend fill:#e6f4ea,stroke:#137333,stroke-width:1px;
    classDef database fill:#fff4d6,stroke:#b06000,stroke-width:1px;
    classDef external fill:#fde8e8,stroke:#b42318,stroke-width:1px;

    class visitante,admin actor
    class site,painel frontend
    class api backend
    class dados database
    class buscadores,vercel,render external
````

---

## 6. Leitura do diagrama

## 6.1 Visão macro

O diagrama mostra que o projeto William Albarello pode ser entendido, em contexto, como uma solução composta por quatro blocos internos principais:

* **Site Institucional Público**
* **Painel Interno / Área Administrativa**
* **Backend / API**
* **Banco de Dados / CMS / Persistência**

Ao redor desse núcleo aparecem:

* os **atores humanos** que usam o sistema;
* os **motores de busca**, relevantes para a descoberta e indexação do conteúdo;
* os **serviços de deploy/hospedagem**, que sustentam a operação técnica da solução.

## 6.2 Atores externos

### Visitante / Leitor

É o usuário que acessa a face pública da solução. Seu interesse principal é:

* conhecer a autoridade profissional de William Albarello;
* navegar por páginas institucionais;
* consumir conteúdos/publicações;
* encontrar sinais de confiança, competência técnica e posicionamento profissional.

### Administrador / Autor

É o operador da camada interna do sistema. Seu papel é:

* autenticar-se;
* acessar o painel;
* criar, editar e publicar conteúdo;
* administrar elementos institucionais do site;
* operar a camada editorial e administrativa.

## 6.3 Núcleo interno do sistema

### Site Institucional Público

É a camada pública visível da solução. Seu papel é:

* apresentar William Albarello como autoridade profissional;
* publicar páginas institucionais;
* expor conteúdos e publicações;
* servir como ponto principal de indexação, descoberta e navegação pública.

### Painel Interno / Área Administrativa

É a camada privada utilizada pelo administrador. Seu papel é:

* centralizar autenticação administrativa;
* permitir operação editorial;
* sustentar gestão de conteúdo e demais ações internas compatíveis com o escopo do projeto.

### Backend / API

É a camada intermediária e lógica da solução. Seu papel é:

* receber requisições do site e do painel;
* aplicar regras de negócio;
* controlar autenticação e autorização, quando aplicável;
* mediar acesso à persistência;
* sustentar operações do domínio.

### Banco de Dados / CMS / Persistência

É a camada de armazenamento do sistema. Seu papel é:

* persistir conteúdo;
* registrar usuários e/ou credenciais;
* guardar dados estruturais e operacionais;
* sustentar a camada editorial/CMS.

## 6.4 Serviços externos e contexto operacional

### Motores de Busca

Representam o ecossistema de indexação. Sua presença no diagrama é obrigatória porque o projeto possui orientação explícita para SEO forte e descoberta orgânica.

### Vercel

Representa a camada de hospedagem/publicação da face web do projeto, em especial da camada pública e, conforme a configuração final adotada, do frontend associado ao site e/ou à interface administrativa.

### Render

Representa a camada de hospedagem da aplicação backend/API, coerente com a estratégia documental já associada ao projeto.

---

## 7. Fronteiras e limites de responsabilidade

## 7.1 O que está dentro da fronteira do sistema

Estão dentro do sistema:

* site institucional público;
* painel interno;
* backend/API;
* persistência/CMS/banco.

Esses elementos compõem a solução propriamente dita.

## 7.2 O que está fora da fronteira do sistema

Estão fora da fronteira:

* visitantes/leitores;
* administrador como ator humano;
* motores de busca;
* plataformas de deploy/hospedagem.

Esses elementos interagem com o sistema, mas não são parte lógica do produto em si.

## 7.3 Limite importante

Vercel e Render são representados como **serviços de infraestrutura de apoio**, e não como partes funcionais do domínio da aplicação.

---

## 8. Interpretação arquitetural do contexto

Este diagrama deixa claro que o projeto não é apenas uma página estática simples. Ele aponta para uma solução com:

* face pública institucional;
* capacidade de administração interna;
* backend com lógica aplicada;
* persistência compatível com conteúdo e operação;
* preocupação explícita com SEO e descoberta;
* infraestrutura distribuída entre camada de frontend/publicação e camada de backend.

Em termos de leitura arquitetural, isso posiciona o projeto como uma solução **institucional-digital com operação editorial e controle administrativo**, e não apenas como presença estática de portfólio.

---

## 9. Regras de leitura e interpretação

### 9.1 Regra de abstração

Este diagrama deve ser lido no nível **mais alto** da solução. Ele não responde “como cada parte foi implementada”, e sim “quais partes existem e como se relacionam”.

### 9.2 Regra de não detalhamento

Se o leitor quiser saber:

* como a autenticação funciona;
* como a API está dividida;
* como os dados se relacionam;
* como as páginas navegam;
* como o SEO técnico opera;
* como o deploy ocorre em detalhe;

ele deve seguir para os diagramas posteriores do Diretório 02.

### 9.3 Regra de precedência

Se qualquer detalhe específico aqui parecer conflitar com documentos posteriores mais especializados, deve-se lembrar que este é um diagrama de contexto macro. O refinamento virá nos documentos seguintes, sem invalidar a visão geral.

---

## 10. Observações de consistência

### 10.1 Coerência com o Waterfall

Este diagrama é coerente com a ideia central do projeto enquanto site profissional com forte posicionamento institucional, capacidade de publicação, área administrativa e sustentação técnica moderna.

### 10.2 Coerência com a sequência do Diretório 02

Este documento prepara o terreno para os próximos artefatos:

* `004_Diagrama_de_Visao_Geral_da_Solucao.md`
* `005_Diagrama_C4_Nivel_1_Contexto.md`
* `006_Diagrama_C4_Nivel_2_Containers.md`

### 10.3 Coerência com arquitetura futura

Este diagrama não fecha decisões finas de tecnologia além do nível contextual já assumido documentalmente. Seu papel é apenas estabilizar:

* atores;
* sistema;
* serviços externos;
* relações centrais;
* fronteiras macro.

---

## 11. Relação com outros diagramas

## 11.1 Diagramas que vêm depois deste

Este diagrama serve de base para:

* `004_Diagrama_de_Visao_Geral_da_Solucao.md`
* `005_Diagrama_C4_Nivel_1_Contexto.md`
* `006_Diagrama_C4_Nivel_2_Containers.md`
* `008_Diagrama_de_Fronteiras_do_Sistema.md`

## 11.2 Diagramas impactados indiretamente

Seu entendimento também influencia:

* bloco `02-Backend_e_API`
* bloco `04-Frontend_e_Jornadas`
* bloco `05-Infra_Deploy_e_Operacao`
* bloco `07-SEO_CMS_e_Publicacao`

## 11.3 Papel no encadeamento

Sem este arquivo, o leitor tende a entrar em detalhes técnicos sem saber exatamente qual é o ecossistema em que o sistema está inserido.

---

## 12. Vínculo com o problema e com os objetivos do projeto

O problema central do projeto não é apenas “ter um site”, mas construir uma presença digital sólida, profissional, administrável e capaz de sustentar autoridade, indexação e publicação estruturada.

Este diagrama apoia diretamente esses objetivos porque mostra, de forma sintética, que a solução:

* separa a face pública da face administrativa;
* possui sustentação lógica via backend/API;
* possui persistência para conteúdo e operação;
* conversa com o ecossistema de busca;
* se apoia em infraestrutura coerente com a proposta do projeto.

---

## 13. Critérios de aceite deste diagrama

Este diagrama será considerado correto se:

* representar claramente os atores externos principais;
* representar claramente o sistema principal;
* mostrar as fronteiras entre interno e externo;
* mostrar site público, painel, backend/API e persistência;
* mostrar buscadores e serviços de deploy compatíveis com o projeto;
* não inventar integrações sem base;
* permanecer legível e coerente com o Waterfall.

---

## 14. Conclusão executiva

O diagrama de contexto do sistema fixa a moldura externa do projeto William Albarello.

Ele demonstra que a solução deve ser entendida como:

* um **site institucional público** voltado à construção de autoridade;
* uma **camada administrativa interna** para operação e gestão;
* uma **camada backend/API** que sustenta lógica e integração interna;
* uma **camada de persistência/CMS** que guarda dados e conteúdo;
* uma solução conectada ao ecossistema de **SEO/indexação** e apoiada por **serviços de deploy/hospedagem**.

Este documento inaugura o Bloco 01 do Diretório 02 e deve ser lido como a base contextual sobre a qual os próximos diagramas irão aprofundar a solução.


