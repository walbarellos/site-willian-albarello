
# 007_Diagrama_de_Componentes_Macro

## 1. Identificação do documento

- **Projeto:** William Albarello
- **Diretório:** `02-Diagramas`
- **Caminho oficial:** `/home/user/Documents/Softwares/Willian Albarello/William Albarello/02-Diagramas/01-Arquitetura_e_Contexto/007_Diagrama_de_Componentes_Macro.md`
- **Natureza do documento:** Diagrama macro de componentes da solução
- **Função sistêmica:** Decompor a solução em componentes internos principais, evidenciando responsabilidades, interfaces e dependências sem descer ao nível de classes, tabelas ou implementação fina
- **Posição no bloco:** Quinto documento do bloco `01-Arquitetura_e_Contexto`
- **Dependência imediata:** `006_Diagrama_C4_Nivel_2_Containers.md`

---

## 2. Objetivo

Este documento existe para apresentar a solução William Albarello em um nível intermediário entre:

- a visão macro de contexto e containers; e
- o detalhamento posterior de backend, API, dados, jornadas e segurança.

Seu objetivo é mostrar **quais são os componentes internos principais da solução**, quais papéis cada um cumpre e como eles se relacionam entre si em termos de dependência e responsabilidade.

Se o documento `006_Diagrama_C4_Nivel_2_Containers.md` respondeu:

**“quais containers compõem o sistema?”**

este documento responde:

**“quais componentes macro existem dentro da solução e como eles se articulam?”**

Este arquivo deve permitir que o leitor compreenda, com clareza:

- os grandes componentes internos do sistema;
- quais interfaces cada componente serve;
- quais dependências estruturais existem entre eles;
- como conteúdo, autenticação, publicação, navegação e administração se conectam;
- como a solução se mantém coerente sem ainda entrar em componentes de baixo nível.

---

## 3. Fontes de referência no Waterfall

Este documento deriva principalmente dos seguintes arquivos do Diretório `01-Waterfall`:

- `014_Arquitetura_Tecnica.md`
- `016_API_Contract_Mestre.md`
- `017_UI_UX_Arquitetura_da_Informacao.md`
- `023_Matriz_de_Rastreabilidade.md`

Fontes complementares úteis para interpretação:

- `001_Visao_Geral_do_Projeto.md`
- `005_Escopo_MVP_e_Fora_de_Escopo.md`
- `006_Requisitos_Funcionais.md`
- `008_Arquitetura_da_Informacao.md`
- `009_Jornada_do_Usuario_e_Fluxos_Principais.md`
- `010_Wireframes_e_Estrutura_de_Paginas.md`
- `012_Estrategia_de_Conteudo_e_SEO.md`
- `013_Modelo_de_Dados_e_CMS.md`
- `015_Seguranca_Autenticacao_e_Autorizacao.md`
- `022_Plano_de_Implantacao_Rollback_e_Suporte.md`
- `024_Registro_de_Decisoes_Arquiteturais.md`

---

## 4. Premissas e limites

## 4.1 Premissas adotadas

Para fins deste diagrama de componentes macro, adotam-se as seguintes premissas conservadoras:

- a solução possui separação entre experiência pública e operação administrativa;
- existe uma camada de backend/API centralizando regras de negócio e integração com persistência;
- o projeto possui responsabilidade editorial e de publicação de conteúdo;
- SEO não é um detalhe periférico, mas uma capacidade estrutural ligada ao domínio de publicação;
- autenticação, autorização e sessão são responsabilidades relevantes e recorrentes;
- a solução possui um núcleo de persistência/CMS que sustenta conteúdo, dados administrativos e organização do domínio;
- a arquitetura deve ser legível tanto para análise documental quanto para posterior implementação.

## 4.2 Limites deste documento

Este documento não detalha:

- controllers, services, repositories ou módulos específicos de backend;
- entidades, relacionamentos ou atributos de banco;
- endpoints, verbos HTTP ou contratos específicos de rota;
- estados de conteúdo ou sessão;
- componentes visuais finos da interface;
- infraestrutura de deploy em profundidade;
- auditoria, logs ou pipelines detalhadas.

Esses aspectos serão tratados em documentos específicos posteriores.

## 4.3 Regra de abstração

Neste arquivo, “componente macro” deve ser entendido como:

- bloco funcional relevante;
- responsabilidade estável da solução;
- peça arquitetural reconhecível;
- unidade suficientemente grande para orientar entendimento, implementação e rastreabilidade.

Logo, este diagrama **não** representa classes, arquivos ou tabelas. Ele representa **capabilidades grandes e coerentes**.

---

## 5. Posição deste documento na sequência metodológica

Este documento ocupa uma posição crítica no encadeamento do Bloco 01.

### 5.1 O que veio antes
Os documentos anteriores estabeleceram:

- o contexto do sistema;
- a visão geral da solução;
- o sistema no ecossistema em linguagem C4 Nível 1;
- a decomposição em containers no C4 Nível 2.

### 5.2 O que este documento faz
Agora, este arquivo desce um nível e mostra os **grandes componentes internos** da solução, ainda em linguagem macro, porém com mais utilidade para:

- entendimento de fronteiras funcionais;
- identificação de dependências internas;
- preparação do detalhamento dos blocos seguintes.

### 5.3 O que virá depois
Os documentos seguintes usarão esta decomposição como base para:

- fronteiras do sistema;
- módulos do backend;
- componentes da API;
- modelo de dados;
- jornadas e fluxos;
- publicação, SEO e segurança.

---

## 6. Diagrama principal — Componentes Macro da Solução

```mermaid
flowchart LR

    subgraph experiencia["Camada de Experiência"]
        pagina_publica["Componente Macro: Páginas Públicas"]
        navegacao_publica["Componente Macro: Navegação Pública e Estrutura de Rotas"]
        painel_admin["Componente Macro: Painel Administrativo"]
    end

    subgraph aplicacao["Camada de Aplicação"]
        gateway_app["Componente Macro: Orquestração da Aplicação / API"]
        auth_access["Componente Macro: Autenticação, Autorização e Sessão"]
        gestao_conteudo["Componente Macro: Gestão de Conteúdo"]
        publicacao_seo["Componente Macro: Publicação, SEO e Metadata"]
    end

    subgraph dados["Camada de Dados"]
        cms_persistencia["Componente Macro: CMS / Persistência Principal"]
    end

    subgraph apoio["Camada de Apoio Externo"]
        buscadores["Componente Externo: Motores de Busca"]
        hospedagem_web["Componente Externo: Hospedagem Web / Frontend"]
        hospedagem_app["Componente Externo: Hospedagem Aplicacional / Backend"]
    end

    pagina_publica -->|usa rotas e navegação| navegacao_publica
    navegacao_publica -->|consome conteúdo publicado| publicacao_seo
    pagina_publica -->|consulta dados públicos via aplicação| gateway_app

    painel_admin -->|solicita acesso protegido| auth_access
    painel_admin -->|executa operações administrativas| gateway_app

    auth_access -->|autoriza uso interno| gateway_app
    gateway_app -->|coordena gestão editorial| gestao_conteudo
    gateway_app -->|consulta e grava dados| cms_persistencia
    gestao_conteudo -->|persiste conteúdo e metadados| cms_persistencia
    gestao_conteudo -->|aciona publicação| publicacao_seo
    publicacao_seo -->|estrutura páginas, slugs e metadados| pagina_publica
    cms_persistencia -->|fornece conteúdo estruturado| publicacao_seo

    buscadores -->|rastreiam páginas públicas| pagina_publica
    hospedagem_web -->|publica interface web| pagina_publica
    hospedagem_web -. suporta interface protegida .-> painel_admin
    hospedagem_app -->|executa aplicação| gateway_app
    hospedagem_app -. executa políticas de acesso .-> auth_access
    hospedagem_app -. executa regras editoriais .-> publicacao_seo

    classDef frontend fill:#e8f0fe,stroke:#1a73e8,stroke-width:1px;
    classDef backend fill:#e6f4ea,stroke:#137333,stroke-width:1px;
    classDef database fill:#fff4d6,stroke:#b06000,stroke-width:1px;
    classDef seo fill:#f3e8ff,stroke:#7e22ce,stroke-width:1px;
    classDef external fill:#fde8e8,stroke:#b42318,stroke-width:1px;

    class pagina_publica,navegacao_publica,painel_admin frontend
    class gateway_app,auth_access,gestao_conteudo backend
    class cms_persistencia database
    class publicacao_seo seo
    class buscadores,hospedagem_web,hospedagem_app external
````

---

## 7. Legenda e regras de leitura

## 7.1 Tipos de componente

Neste diagrama, os elementos devem ser lidos assim:

* **Componente Macro**: bloco funcional interno importante, com responsabilidade estável e papel claro na solução;
* **Componente Externo**: elemento fora da fronteira do sistema, mas com interação operacional relevante;
* **Camada**: agrupamento lógico de componentes segundo sua função predominante.

## 7.2 Sentido das setas

As setas representam:

* dependência funcional;
* consumo de capacidade;
* relação de coordenação;
* fluxo de informação em nível macro;
* apoio operacional relevante.

Elas **não** representam, necessariamente:

* protocolo técnico;
* chamada HTTP literal;
* ordem temporal exata;
* implementação concreta linha a linha.

## 7.3 Regra de interpretação

Este documento deve ser lido como um mapa de responsabilidades e dependências. Seu objetivo não é provar como o código já está implementado, mas mostrar como a solução deve ser compreendida em termos arquiteturais.

---

## 8. Explicação dos componentes macro

## 8.1 Componente Macro: Páginas Públicas

### Função

Representa a face pública da solução.

### Responsabilidades principais

* exibir a presença institucional de William Albarello;
* disponibilizar páginas públicas e conteúdo publicado;
* sustentar leitura, navegação e consumo de informação;
* servir como camada visível para visitantes e motores de busca.

### Observação

Este componente não é sinônimo de “frontend inteiro”. Ele é o subconjunto do frontend orientado à exposição pública do site.

---

## 8.2 Componente Macro: Navegação Pública e Estrutura de Rotas

### Função

Organiza a forma como o visitante percorre a solução pública.

### Responsabilidades principais

* estruturar caminhos de navegação;
* organizar rotas públicas;
* suportar coerência entre páginas;
* servir de base para leitura, descoberta e experiência.

### Observação

Ele aparece destacado porque navegação e estrutura de rotas são parte relevante da arquitetura da informação e têm impacto direto em UX, SEO e percepção institucional.

---

## 8.3 Componente Macro: Painel Administrativo

### Função

Representa a face interna operável da solução.

### Responsabilidades principais

* oferecer interface administrativa;
* permitir operação editorial e institucional;
* sustentar ações de gestão protegidas;
* servir como ponto de controle interno do sistema.

### Observação

Este componente não inclui a lógica de autenticação em si, apenas a interface e experiência administrativa.

---

## 8.4 Componente Macro: Orquestração da Aplicação / API

### Função

É o componente central de coordenação da solução.

### Responsabilidades principais

* receber demandas da camada pública e da camada administrativa;
* aplicar regras de negócio;
* coordenar o acesso à persistência;
* acionar rotinas de gestão e publicação;
* funcionar como eixo central da aplicação.

### Observação

Este componente resume a camada de backend/API em sua função mais importante: **orquestrar o sistema**.

---

## 8.5 Componente Macro: Autenticação, Autorização e Sessão

### Função

Representa a responsabilidade de controle de acesso da solução.

### Responsabilidades principais

* validar credenciais;
* estabelecer identidade administrativa;
* proteger a área interna;
* controlar sessão;
* autorizar ou negar operações conforme políticas do sistema.

### Observação

Este componente permanece visível em nível macro porque acesso protegido é um requisito estrutural do projeto.

---

## 8.6 Componente Macro: Gestão de Conteúdo

### Função

Representa a responsabilidade de administração editorial e manipulação de conteúdo.

### Responsabilidades principais

* criar, editar e organizar conteúdo;
* manter dados editoriais;
* intermediar ações administrativas relacionadas à publicação;
* garantir coerência entre conteúdo administrado e persistência.

### Observação

Este componente funciona como ponte natural entre painel administrativo, API e persistência.

---

## 8.7 Componente Macro: Publicação, SEO e Metadata

### Função

Representa a responsabilidade de transformar conteúdo persistido em conteúdo publicável, indexável e institucionalmente bem exposto.

### Responsabilidades principais

* estruturar publicação;
* gerar ou organizar slugs;
* sustentar metadados;
* articular sitemap, canonicals e sinais de SEO;
* preparar conteúdo para exposição pública e rastreamento.

### Observação

Esse componente foi mantido explícito porque o projeto não trata SEO como detalhe lateral. Ele é parte do valor da solução.

---

## 8.8 Componente Macro: CMS / Persistência Principal

### Função

Representa a base de dados e armazenamento estruturado da solução.

### Responsabilidades principais

* persistir conteúdo;
* armazenar dados administrativos;
* servir de base ao CMS;
* manter informações necessárias ao funcionamento da solução.

### Observação

Neste nível, o componente é tratado como persistência principal, sem abrir entidades, coleções, tabelas ou relacionamentos.

---

## 8.9 Componentes Externos de Apoio

### Motores de Busca

Representam o ecossistema de descoberta e indexação.

### Hospedagem Web / Frontend

Representa a plataforma externa que sustenta a camada de interface web.

### Hospedagem Aplicacional / Backend

Representa a plataforma externa que sustenta a camada de aplicação.

### Observação

Esses elementos aparecem no diagrama porque afetam o comportamento operacional da solução, embora estejam fora da fronteira do sistema.

---

## 9. Explicação das dependências principais

## 9.1 Páginas Públicas → Navegação Pública e Estrutura de Rotas

A camada pública depende de estrutura de navegação para ser coerente, navegável e inteligível.

## 9.2 Navegação Pública e Estrutura de Rotas → Publicação, SEO e Metadata

A navegação pública se articula com a forma como conteúdo, URLs e sinais de indexação são expostos.

## 9.3 Páginas Públicas → Orquestração da Aplicação / API

Mesmo em experiência pública, a solução depende da aplicação para obter conteúdo, dados ou organização dinâmica relevante.

## 9.4 Painel Administrativo → Autenticação, Autorização e Sessão

Toda operação interna precisa ser antecedida e protegida por controle de acesso.

## 9.5 Painel Administrativo → Orquestração da Aplicação / API

O painel não opera diretamente na persistência. Ele depende da aplicação como mediadora central.

## 9.6 Autenticação, Autorização e Sessão → Orquestração da Aplicação / API

O acesso permitido abre caminho para operações válidas sobre a camada central da aplicação.

## 9.7 Orquestração da Aplicação / API → Gestão de Conteúdo

A aplicação coordena as operações editoriais e administrativas em alto nível.

## 9.8 Orquestração da Aplicação / API → CMS / Persistência Principal

O backend centraliza leitura e escrita na persistência.

## 9.9 Gestão de Conteúdo → CMS / Persistência Principal

A administração editorial depende da gravação estruturada dos dados.

## 9.10 Gestão de Conteúdo → Publicação, SEO e Metadata

O conteúdo administrado precisa passar por uma camada que o torne publicável e indexável.

## 9.11 CMS / Persistência Principal → Publicação, SEO e Metadata

A publicação depende do conteúdo e dos metadados persistidos.

## 9.12 Publicação, SEO e Metadata → Páginas Públicas

O conteúdo publicado e tecnicamente estruturado é refletido na camada pública do site.

---

## 10. Componentes, interfaces e fronteiras

## 10.1 Interfaces principais implícitas

O diagrama sugere as seguintes interfaces arquiteturais principais:

* interface pública de navegação e leitura;
* interface administrativa protegida;
* interface de aplicação/APIs internas e públicas;
* interface de persistência;
* interface editorial/SEO;
* interface com plataformas externas de hospedagem e indexação.

## 10.2 Fronteiras internas da solução

Este documento evidencia três grandes fronteiras internas:

* **experiência**
* **aplicação**
* **dados**

Essa divisão ajuda a evitar confusões como:

* frontend operando diretamente banco;
* SEO dissolvido no frontend sem responsabilidade própria;
* painel administrativo confundido com backend;
* autenticação tratada como detalhe invisível.

## 10.3 Fronteira externa

A fronteira externa separa o sistema propriamente dito de:

* buscadores;
* serviços de hospedagem;
* ambiente operacional de suporte.

---

## 11. Relação deste documento com o C4 Nível 2

Este documento não substitui o `006_Diagrama_C4_Nivel_2_Containers.md`. Ele o complementa.

### 11.1 Diferença principal

* o **C4 Nível 2** mostrou os containers como grandes unidades do sistema;
* este documento mostra os **componentes macro** que ajudam a compreender a lógica interna da solução em um nível mais analítico.

### 11.2 Em termos práticos

* `006` responde: **quais containers compõem o sistema?**
* `007` responde: **quais grandes componentes fazem a solução funcionar por dentro?**

---

## 12. Relação com a API, UI/UX e rastreabilidade

## 12.1 Relação com o contrato de API

O componente **Orquestração da Aplicação / API** e suas dependências ajudam a localizar onde o contrato de API se torna relevante dentro da solução.

## 12.2 Relação com UI/UX

Os componentes **Páginas Públicas**, **Navegação Pública e Estrutura de Rotas** e **Painel Administrativo** mostram como a camada de experiência se estrutura antes do detalhamento das jornadas e rotas.

## 12.3 Relação com rastreabilidade

A presença explícita dos componentes grandes facilita, posteriormente, a correlação entre:

* requisitos;
* decisões arquiteturais;
* diagramas;
* partes reais da solução.

---

## 13. Observações de consistência

## 13.1 Coerência com o Waterfall

Este diagrama é coerente com a documentação técnica, com o contrato de API, com a arquitetura de informação e com a necessidade de rastreabilidade.

## 13.2 Coerência com a proposta do projeto

A solução continua sendo apresentada como:

* site institucional;
* plataforma publicável;
* sistema administrável;
* arquitetura com forte preocupação com autoridade, conteúdo e SEO.

## 13.3 Coerência metodológica

O nível de detalhe está acima do C4 Nível 2, mas ainda abaixo do detalhamento de módulos, rotas, entidades e fluxos específicos, o que é exatamente a finalidade deste documento.

---

## 14. Impactos e dependências para documentos seguintes

Este documento prepara terreno para:

* `008_Diagrama_de_Fronteiras_do_Sistema.md`
* `009_Diagrama_de_Modulos_do_Backend.md`
* `010_Diagrama_de_Componentes_da_API.md`
* `013_Diagrama_de_Casos_de_Uso_do_Painel_Interno.md`
* `019_Diagrama_ER_Entidade_Relacionamento.md`
* `025_Diagrama_de_Arquitetura_do_Frontend.md`
* `042_Diagrama_de_Fluxo_Editorial.md`

Se este documento mudar estruturalmente, devem ser revisitados, no mínimo:

* `006_Diagrama_C4_Nivel_2_Containers.md`
* `008_Diagrama_de_Fronteiras_do_Sistema.md`
* bloco 02;
* bloco 04;
* bloco 07.

---

## 15. Critérios de aceite deste documento

Este documento será considerado adequado se:

* mapear os grandes componentes internos da solução sem detalhamento excessivo;
* distinguir experiência, aplicação e dados;
* explicitar componentes de autenticação, gestão de conteúdo e publicação/SEO;
* mostrar o backend como orquestrador central;
* mostrar a persistência como base do domínio editorial e administrativo;
* representar dependências macro claras e coerentes;
* permanecer útil para leitura, implementação futura e rastreabilidade.

---

## 16. Conclusão executiva

O diagrama de componentes macro do projeto William Albarello demonstra que a solução pode ser compreendida, internamente, como a articulação entre:

* uma camada pública de apresentação institucional;
* uma camada administrativa protegida;
* um núcleo de aplicação que orquestra regras e operações;
* uma camada de autenticação e autorização;
* uma capacidade de gestão de conteúdo;
* uma capacidade editorial/SEO de publicação;
* uma base de persistência estruturada.

Esse desenho reforça que o sistema não é apenas “site + backend + banco”, mas uma arquitetura com responsabilidades suficientemente distintas para justificar sua decomposição em componentes macro legíveis.

Este documento fecha a transição entre a visão de containers e o aprofundamento posterior em fronteiras, backend, API, dados, frontend e fluxos.

---

