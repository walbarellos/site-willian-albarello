
# 005_Diagrama_C4_Nivel_1_Contexto

## 1. Identificação do documento

- **Projeto:** William Albarello
- **Diretório:** `02-Diagramas`
- **Caminho oficial:** `/home/user/Documents/Softwares/Willian Albarello/William Albarello/02-Diagramas/01-Arquitetura_e_Contexto/005_Diagrama_C4_Nivel_1_Contexto.md`
- **Natureza do documento:** Diagrama C4 — Nível 1 (Contexto)
- **Função sistêmica:** Formalizar, em linguagem compatível com C4, o contexto do sistema, destacando pessoas, sistema principal e sistemas externos relevantes
- **Posição no bloco:** Terceiro documento do bloco `01-Arquitetura_e_Contexto`
- **Dependência imediata:** `003_Diagrama_de_Contexto_do_Sistema.md` e `004_Diagrama_de_Visao_Geral_da_Solucao.md`

---

## 2. Objetivo

Este documento formaliza o **Context Diagram** do projeto William Albarello segundo a lógica do modelo C4, adaptado para representação em Mermaid e em português.

Seu objetivo é mostrar, com disciplina arquitetural e sem excesso de detalhe interno:

- quem usa o sistema;
- qual é o sistema principal;
- quais sistemas externos interagem com ele;
- quais relações centrais existem entre usuários, sistema e ecossistema técnico;
- qual é a posição do sistema dentro do ambiente operacional real do projeto.

Diferentemente do diagrama de visão geral da solução, este documento não enfatiza os macroblocos internos do sistema. Aqui, o foco está na pergunta:

**“Quem interage com o sistema William Albarello e com quais sistemas externos ele se relaciona?”**

---

## 3. Fontes de referência no Waterfall

Este documento deriva principalmente dos seguintes arquivos do Diretório `01-Waterfall`:

- `001_Visao_Geral_do_Projeto.md`
- `005_Escopo_MVP_e_Fora_de_Escopo.md`
- `014_Arquitetura_Tecnica.md`
- `015_Seguranca_Autenticacao_e_Autorizacao.md`
- `016_API_Contract_Mestre.md`
- `022_Plano_de_Implantacao_Rollback_e_Suporte.md`

Fontes complementares úteis para leitura contextual:

- `003_Objetivos_de_Negocio_e_de_Produto.md`
- `004_Publico_Alvo_e_Personas.md`
- `008_Arquitetura_da_Informacao.md`
- `012_Estrategia_de_Conteudo_e_SEO.md`
- `017_UI_UX_Arquitetura_da_Informacao.md`
- `024_Registro_de_Decisoes_Arquiteturais.md`

---

## 4. Premissas e limites

## 4.1 Premissas adotadas

Para fins deste diagrama C4 Nível 1, consideram-se válidas as seguintes premissas documentais:

- o projeto William Albarello é um sistema digital com face pública institucional e operação administrativa interna;
- o sistema possui capacidade de publicação e gestão de conteúdo;
- o projeto depende de indexação por mecanismos de busca;
- a arquitetura prevê backend/API e camada de persistência, mas esses elementos não serão detalhados internamente neste nível C4;
- a estratégia de operação considera plataformas externas de deploy/hospedagem coerentes com a linha Vercel + Render;
- o administrador do sistema é um ator humano distinto do visitante/leitor.

## 4.2 Limites deste documento

Este documento **não** detalha:

- containers internos;
- módulos da API;
- fluxos de autenticação passo a passo;
- modelo de dados;
- jornadas detalhadas;
- arquitetura de páginas;
- deploy em nível operacional fino.

Esses temas aparecerão nos documentos posteriores do Diretório 02.

## 4.3 Regra de abstração

No nível C4 Context, o sistema principal deve aparecer como **uma unidade coerente**, e não como coleção de componentes internos. Portanto, este documento intencionalmente “esconde” detalhes internos para privilegiar:

- posicionamento;
- fronteira;
- usuários;
- integrações externas;
- ecossistema.

---

## 5. Conceito C4 adotado neste documento

Este arquivo usa o raciocínio do **C4 Model — Nível 1 (Contexto)**, adaptado às convenções do projeto.

No C4 Nível 1, o objetivo é apresentar:

- **Pessoas**: quem usa ou interage com o sistema;
- **Sistema principal**: o produto em foco;
- **Sistemas externos**: serviços ou plataformas externas com as quais o sistema se relaciona;
- **Relações**: como essas interações acontecem em nível alto.

### 5.1 O que este diagrama deve responder

Ao final da leitura, este documento deve permitir responder:

- quem usa o sistema William Albarello?
- quem administra o sistema?
- de quais sistemas externos ele depende?
- como ele se posiciona no ecossistema técnico e público?
- quais relações externas são centrais para sua existência?

### 5.2 O que este diagrama não deve tentar responder

Este documento não deve responder:

- como os dados fluem internamente entre componentes;
- como o login funciona em sequência;
- como o conteúdo é versionado;
- como as rotas são organizadas;
- como a infraestrutura é detalhada por ambiente.

---

## 6. Diagrama principal — C4 Nível 1 (Contexto)

```mermaid
flowchart LR

    visitante["Pessoa: Visitante / Leitor
Consome conteúdo, navega e conhece a autoridade profissional"]
    admin["Pessoa: Administrador / Autor
Gerencia conteúdo, opera o painel e mantém o sistema"]

    sistema["Sistema: William Albarello
Site institucional com capacidade de administração, publicação de conteúdo e presença digital orientada à autoridade"]

    buscadores["Sistema Externo: Motores de Busca
Descobrem, rastreiam e indexam o conteúdo público"]
    vercel["Sistema Externo: Vercel
Hospedagem/publicação da camada web e frontend"]
    render["Sistema Externo: Render
Hospedagem/publicação da camada backend e aplicação"]

    visitante -->|acessa e consome conteúdo público| sistema
    admin -->|administra e mantém o sistema| sistema
    buscadores -->|rastreiam e indexam páginas públicas| sistema
    sistema -->|publica frontend e interface web| vercel
    sistema -->|publica backend e serviços de aplicação| render

    classDef person fill:#f5f5f5,stroke:#333,stroke-width:1px;
    classDef internal fill:#e8f0fe,stroke:#1a73e8,stroke-width:1px;
    classDef external fill:#fde8e8,stroke:#b42318,stroke-width:1px;

    class visitante,admin person
    class sistema internal
    class buscadores,vercel,render external
````

---

## 7. Legenda e convenções de leitura

## 7.1 Tipos de elemento

Neste diagrama, os elementos são lidos assim:

* **Pessoa**: ator humano que interage com o sistema;
* **Sistema**: produto principal em foco;
* **Sistema Externo**: plataforma ou serviço fora da fronteira lógica do produto, mas relevante para sua operação, descoberta ou entrega.

## 7.2 Sentido das relações

As setas indicam relação funcional em nível alto, e não chamadas técnicas detalhadas.

Exemplos:

* **“acessa e consome conteúdo público”** indica interação do visitante com a face pública do sistema;
* **“administra e mantém o sistema”** indica operação administrativa;
* **“rastreiam e indexam páginas públicas”** indica relação entre buscadores e o conteúdo exposto pelo sistema;
* **“publica frontend e interface web”** e **“publica backend e serviços de aplicação”** indicam dependência do sistema em relação às plataformas de hospedagem e entrega.

## 7.3 Regra de interpretação

As relações devem ser lidas como:

* relação de uso;
* relação de dependência operacional;
* relação de descoberta/indexação;
* relação de sustentação técnica.

Elas **não** devem ser interpretadas como arquitetura interna ou fluxo detalhado de implementação.

---

## 8. Explicação dos elementos do diagrama

## 8.1 Pessoa: Visitante / Leitor

É o ator externo que acessa a camada pública do sistema. Sua função no ecossistema é:

* visitar o site institucional;
* ler conteúdos;
* navegar pelas páginas públicas;
* formar percepção de autoridade, credibilidade e posicionamento profissional.

Esse ator representa o público externo real do projeto.

## 8.2 Pessoa: Administrador / Autor

É o ator humano responsável por operar o sistema internamente. Sua função inclui:

* autenticar-se;
* acessar a camada administrativa;
* produzir, editar e publicar conteúdo;
* manter o sistema institucional atualizado;
* operar a presença digital de forma controlada.

Ele é tratado como pessoa externa à arquitetura porque, em C4 Nível 1, o foco é mostrar **quem usa o sistema**, e não quem faz parte dele.

## 8.3 Sistema: William Albarello

É o sistema principal em foco neste documento.

Em nível de contexto, ele é compreendido como:

* um site institucional;
* uma presença digital profissional;
* uma solução com capacidade administrativa;
* uma estrutura de conteúdo publicável;
* uma plataforma com preocupação explícita com indexação e autoridade digital.

Neste nível, todos os componentes internos do sistema ficam condensados em um único bloco.

## 8.4 Sistema Externo: Motores de Busca

Representa o ecossistema de descoberta e indexação. Sua presença é essencial porque:

* o projeto exige SEO forte;
* a visibilidade orgânica depende de indexação;
* a camada pública do sistema precisa ser descoberta, rastreada e compreendida por buscadores.

## 8.5 Sistema Externo: Vercel

Representa a plataforma externa associada à publicação da camada web/front-end do projeto.

Sua inclusão no contexto é coerente porque:

* sustenta a entrega pública do sistema;
* pertence ao ambiente operacional;
* não faz parte do domínio do produto, mas influencia diretamente sua existência em produção.

## 8.6 Sistema Externo: Render

Representa a plataforma externa associada à publicação da camada de backend/aplicação.

Sua presença no diagrama é importante porque:

* o backend é parte funcional do sistema;
* sua hospedagem está fora da fronteira do produto;
* ela compõe o ecossistema técnico real da solução.

---

## 9. Fronteira do sistema

## 9.1 O que está dentro da fronteira

No nível C4 Context, apenas o bloco:

* **Sistema: William Albarello**

é considerado o sistema em foco.

Ou seja, tudo o que compõe:

* site público,
* painel interno,
* backend,
* autenticação,
* CMS,
* publicação,

fica implicitamente contido nesse sistema, sem detalhamento.

## 9.2 O que está fora da fronteira

Estão fora da fronteira do sistema:

* Visitante / Leitor
* Administrador / Autor
* Motores de Busca
* Vercel
* Render

Esses elementos interagem com o sistema, mas não pertencem ao seu domínio interno.

## 9.3 Importância dessa fronteira

A fronteira é essencial porque impede erro metodológico comum:
confundir componentes do sistema com atores ou plataformas externas.

No C4 Nível 1, a regra é simples:

* **pessoas e sistemas externos orbitam o sistema principal**;
* o sistema principal fica no centro da representação.

---

## 10. Posição do sistema no ecossistema do projeto

Este diagrama revela que o sistema William Albarello ocupa uma posição intermediária entre:

* o **público externo**, que acessa e consome a presença institucional;
* a **operação interna**, conduzida pelo administrador;
* o **ecossistema de descoberta**, representado pelos motores de busca;
* o **ecossistema de operação técnica**, representado pelas plataformas de deploy/hospedagem.

Essa posição é importante porque demonstra que o sistema não é apenas uma página estática, mas um produto com:

* consumo externo;
* operação interna;
* presença pública indexável;
* sustentação técnica em plataformas externas.

---

## 11. Critérios de leitura arquitetural

Este diagrama deve ser lido observando três perguntas centrais.

## 11.1 Quem usa o sistema?

Resposta:

* Visitante / Leitor
* Administrador / Autor

## 11.2 Quais sistemas externos interagem com ele?

Resposta:

* Motores de Busca
* Vercel
* Render

## 11.3 Qual é o papel do sistema nesse ecossistema?

Resposta:
Ser a plataforma central que:

* apresenta autoridade institucional;
* publica conteúdo;
* permite gestão administrativa;
* expõe páginas públicas;
* depende de infraestrutura externa para existir em produção;
* depende de buscadores para maximizar descoberta orgânica.

---

## 12. Relação deste documento com os diagramas anteriores

## 12.1 Relação com `003_Diagrama_de_Contexto_do_Sistema.md`

O `003` já apresentou contexto em linguagem livre e estrutural do projeto.

O `005` faz algo diferente:

* formaliza esse mesmo contexto em **lógica C4**;
* simplifica o sistema para um único bloco central;
* reforça o raciocínio de pessoa → sistema → sistemas externos.

## 12.2 Relação com `004_Diagrama_de_Visao_Geral_da_Solucao.md`

O `004` abriu a solução em macroblocos internos:

* frontend público,
* painel,
* backend,
* persistência,
* SEO,
* autenticação,
* operação.

O `005`, por sua vez, abstrai tudo isso novamente em um único sistema central, porque esse é o comportamento correto para C4 Nível 1.

Em resumo:

* `004` mostra **a solução em macro por dentro**;
* `005` mostra **o sistema como unidade no ecossistema**.

---

## 13. Relação deste documento com os próximos diagramas

Este documento prepara terreno diretamente para:

* `006_Diagrama_C4_Nivel_2_Containers.md`
* `007_Diagrama_de_Componentes_Macro.md`
* `008_Diagrama_de_Fronteiras_do_Sistema.md`

### 13.1 Papel no encadeamento

A lógica correta é:

1. primeiro entender o sistema como um bloco central no mundo (`005`);
2. depois abrir esse bloco em containers (`006`);
3. depois observar componentes macro (`007`);
4. depois consolidar fronteiras e limites (`008`).

---

## 14. Observações de consistência

## 14.1 Coerência com escopo

O diagrama permanece dentro do escopo macro do projeto. Não inclui integrações não comprovadas, serviços supérfluos ou sistemas externos sem função clara.

## 14.2 Coerência com arquitetura

A representação é compatível com a visão de site institucional administrável, com backend, publicação de conteúdo e SEO forte.

## 14.3 Coerência com segurança

A figura do administrador, separada do visitante, prepara terreno para distinções posteriores entre autenticação, autorização e controle de acesso.

## 14.4 Coerência com implantação

A presença de Vercel e Render é coerente com o plano de implantação e com a necessidade de explicitar o ecossistema técnico externo do projeto.

---

## 15. Critérios de aceite deste documento

Este diagrama será considerado adequado se:

* representar claramente as pessoas que usam o sistema;
* representar claramente o sistema principal como unidade central;
* representar apenas sistemas externos relevantes e comprovados;
* mostrar a relação entre sistema, usuários, buscadores e plataformas de operação;
* manter o nível de abstração correto de C4 Nível 1;
* não abrir componentes internos do sistema;
* permanecer coerente com os documentos-base do Waterfall.

---

## 16. Conclusão executiva

O C4 Nível 1 do projeto William Albarello posiciona o sistema como uma plataforma central de presença institucional e operação editorial, utilizada por dois perfis humanos principais:

* o visitante/leitor, que consome conteúdo e percebe autoridade;
* o administrador/autor, que opera e mantém o sistema.

Ao redor desse núcleo, destacam-se dois grupos de sistemas externos:

* os **motores de busca**, que sustentam a descoberta orgânica;
* as **plataformas de deploy/hospedagem**, que sustentam a operação técnica.

Este documento é importante porque estabiliza, em linguagem arquitetural disciplinada, o lugar do sistema no ecossistema real do projeto. Ele deve ser lido como o elo entre a visão contextual ampla e a abertura técnica em containers que virá no documento seguinte.


