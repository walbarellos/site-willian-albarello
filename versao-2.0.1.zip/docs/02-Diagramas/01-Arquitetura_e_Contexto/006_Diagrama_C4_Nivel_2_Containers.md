
# 006_Diagrama_C4_Nivel_2_Containers

## 1. Identificação do documento

- **Projeto:** William Albarello
- **Diretório:** `02-Diagramas`
- **Caminho oficial:** `/home/user/Documents/Softwares/Willian Albarello/William Albarello/02-Diagramas/01-Arquitetura_e_Contexto/006_Diagrama_C4_Nivel_2_Containers.md`
- **Natureza do documento:** Diagrama C4 — Nível 2 (Containers)
- **Função sistêmica:** Abrir o sistema William Albarello em seus containers principais, mostrando responsabilidades, fronteiras, comunicações e sustentação operacional
- **Posição no bloco:** Quarto documento do bloco `01-Arquitetura_e_Contexto`
- **Dependência imediata:** `005_Diagrama_C4_Nivel_1_Contexto.md`

---

## 2. Objetivo

Este documento formaliza o **C4 Nível 2 — Containers** do projeto William Albarello.

Seu objetivo é mostrar, com maior precisão arquitetural do que o diagrama de contexto, como o sistema principal se decompõe em grandes unidades executáveis, persistentes ou logicamente separáveis, preservando ainda o nível macro e sem entrar em detalhes de componentes internos, classes, tabelas ou endpoints.

Em outras palavras:

- o `005_Diagrama_C4_Nivel_1_Contexto.md` mostrou o sistema como um bloco único dentro do ecossistema;
- este documento mostra **quais containers relevantes compõem esse bloco**.

Este arquivo deve permitir responder:

- quais são os containers principais da solução;
- qual o papel de cada container;
- como os containers se comunicam;
- quais containers são públicos, privados, internos ou auxiliares;
- quais plataformas externas sustentam a operação;
- como o sistema se organiza em nível de runtime e responsabilidade.

---

## 3. Fontes de referência no Waterfall

Este documento deriva principalmente dos seguintes arquivos do Diretório `01-Waterfall`:

- `013_Modelo_de_Dados_e_CMS.md`
- `014_Arquitetura_Tecnica.md`
- `015_Seguranca_Autenticacao_e_Autorizacao.md`
- `016_API_Contract_Mestre.md`
- `017_UI_UX_Arquitetura_da_Informacao.md`
- `022_Plano_de_Implantacao_Rollback_e_Suporte.md`

Documentos complementares úteis para interpretação:

- `001_Visao_Geral_do_Projeto.md`
- `005_Escopo_MVP_e_Fora_de_Escopo.md`
- `006_Requisitos_Funcionais.md`
- `007_Requisitos_Nao_Funcionais.md`
- `008_Arquitetura_da_Informacao.md`
- `012_Estrategia_de_Conteudo_e_SEO.md`
- `018_Plano_de_Testes_Homologacao_e_Qualidade.md`
- `024_Registro_de_Decisoes_Arquiteturais.md`

---

## 4. Premissas e limites

## 4.1 Premissas adotadas

Para fins deste diagrama C4 Nível 2, são adotadas as seguintes premissas conservadoras:

- a solução possui **container web público** para a experiência institucional;
- a solução possui **container administrativo** para a operação interna;
- existe um **container backend/API** que centraliza regras de negócio e integração com persistência;
- existe uma **camada de persistência/CMS** como container de dados principal;
- autenticação/autorização é uma responsabilidade relevante o suficiente para ser destacada;
- publicação editorial/SEO estrutural também é responsabilidade relevante o suficiente para ser destacada;
- a estratégia operacional considera **frontend/interface em Vercel** e **backend/aplicação em Render**, conforme o histórico documental já associado ao projeto.

## 4.2 Limites deste documento

Este documento não detalha:

- módulos internos do backend;
- controllers, services ou repositories;
- endpoints específicos;
- entidades de banco em detalhe;
- estados do conteúdo;
- componentes visuais internos do frontend;
- pipelines de CI/CD;
- observabilidade e logs em profundidade.

Esses temas serão aprofundados em documentos posteriores.

## 4.3 Nota importante sobre “containers” auxiliares

Neste documento, **Autenticação/Autorização/Sessão** e **Publicação/SEO Estrutural** são representados como **containers lógicos relevantes**.

Isso não significa, necessariamente, que já estejam fisicamente separados em deploys independentes. Significa que, no nível arquitetural, eles possuem responsabilidade suficientemente distinta para merecer visualização própria.

Essa escolha evita dois erros:

- esconder responsabilidades críticas dentro de um bloco genérico de backend;
- fingir que toda a solução se resume a frontend + backend + banco, apagando capacidades transversais que são essenciais ao projeto.

---

## 5. Conceito C4 adotado neste documento

No modelo C4, o **Nível 2 — Containers** responde à pergunta:

**“Quais são os containers que compõem o sistema e como eles colaboram?”**

No contexto deste projeto, container deve ser entendido como:

- aplicação web;
- interface administrativa;
- serviço de aplicação;
- serviço lógico auxiliar relevante;
- banco de dados / armazenamento principal;
- unidade de runtime ou responsabilidade arquitetural macro.

Este documento não entra em componentes internos. Ele permanece no nível:

- **container**
- **responsabilidade**
- **comunicação**
- **fronteira**
- **tecnologia inferível**
- **hospedagem**

---

## 6. Diagrama principal — C4 Nível 2 (Containers)

```mermaid
flowchart LR

    visitante["Pessoa: Visitante / Leitor"]
    admin["Pessoa: Administrador / Autor"]

    buscadores["Sistema Externo: Motores de Busca"]
    vercel["Sistema Externo: Vercel"]
    render["Sistema Externo: Render"]

    subgraph sistema["Sistema William Albarello"]
        subgraph web["Zona Web / Experiência"]
            frontend_publico["Container: Frontend Público
Responsável por páginas institucionais, leitura de conteúdo, navegação e exposição pública"]
            painel_admin["Container: Painel Administrativo
Responsável por operação interna, gestão de conteúdo e interface protegida"]
        end

        subgraph aplicacao["Zona de Aplicação"]
            auth["Container Lógico: Autenticação / Autorização / Sessão
Responsável por login, validação de acesso e proteção da área interna"]
            api["Container: Backend / API / Regras de Negócio
Responsável por operações administrativas, entrega de dados públicos e orquestração da solução"]
            editorial["Container Lógico: Publicação / SEO Estrutural
Responsável por slugs, metadata, sitemap, canonicals e disponibilização editorial"]
        end

        subgraph dados["Zona de Dados"]
            cms["Container: Banco / CMS / Persistência
Responsável por conteúdo, dados administrativos e armazenamento estruturado"]
        end
    end

    visitante -->|acessa| frontend_publico
    admin -->|opera| painel_admin

    painel_admin -->|solicita login e validação| auth
    auth -->|autoriza operações internas| api

    frontend_publico -->|consulta dados e conteúdo público| api
    painel_admin -->|executa operações administrativas| api

    api -->|lê e grava dados| cms
    api -->|aciona regras de publicação| editorial
    cms -->|fornece conteúdo estruturado| editorial

    editorial -->|expõe conteúdo publicado e metadados| frontend_publico
    buscadores -->|rastreiam e indexam páginas públicas| frontend_publico

    vercel -->|hospeda / publica| frontend_publico
    vercel -. hospeda / publica .-> painel_admin

    render -->|hospeda / publica| api
    render -. hospeda / executa .-> auth
    render -. hospeda / executa .-> editorial

    classDef person fill:#f5f5f5,stroke:#333,stroke-width:1px;
    classDef frontend fill:#e8f0fe,stroke:#1a73e8,stroke-width:1px;
    classDef backend fill:#e6f4ea,stroke:#137333,stroke-width:1px;
    classDef database fill:#fff4d6,stroke:#b06000,stroke-width:1px;
    classDef seo fill:#f3e8ff,stroke:#7e22ce,stroke-width:1px;
    classDef external fill:#fde8e8,stroke:#b42318,stroke-width:1px;

    class visitante,admin person
    class frontend_publico,painel_admin frontend
    class auth,api backend
    class cms database
    class editorial seo
    class buscadores,vercel,render external
````

---

## 7. Legenda e regras de leitura

## 7.1 Tipos de elemento

Neste diagrama, os elementos devem ser lidos assim:

* **Pessoa**: ator humano que usa o sistema;
* **Container**: aplicação, serviço ou armazenamento com responsabilidade própria;
* **Container Lógico**: capacidade arquitetural de primeira classe, representada separadamente por relevância operacional;
* **Sistema Externo**: plataforma ou serviço fora da fronteira do produto, mas essencial ao seu funcionamento ou descoberta.

## 7.2 Leitura das zonas internas

A solução foi organizada em três zonas lógicas:

* **Zona Web / Experiência**
* **Zona de Aplicação**
* **Zona de Dados**

Essa divisão foi adotada para tornar evidente a separação entre:

* interface pública/privada;
* lógica de negócio e controle de acesso;
* persistência e base de conteúdo.

## 7.3 Regra de interpretação

Este diagrama deve ser lido como uma fotografia arquitetural macro do sistema em nível de containers.

Ele **não** afirma, obrigatoriamente, que cada container lógico já é um deploy independente. Ele afirma que cada responsabilidade é grande o suficiente para ser reconhecida no desenho da solução.

---

## 8. Explicação dos containers

## 8.1 Container: Frontend Público

### Função

É a aplicação/interface responsável pela face pública do projeto.

### Responsabilidades principais

* apresentar William Albarello institucionalmente;
* expor páginas públicas;
* exibir conteúdos publicados;
* sustentar navegação e leitura;
* servir de alvo para indexação por motores de busca.

### Tecnologia inferível pelos anexos

Tecnologia web moderna de frontend/publicação, compatível com deploy em Vercel, renderização pública e organização de páginas, rotas e conteúdo.

### Natureza

Container de experiência pública.

---

## 8.2 Container: Painel Administrativo

### Função

É a aplicação/interface responsável pela operação interna da solução.

### Responsabilidades principais

* permitir acesso administrativo;
* oferecer interface de gestão;
* viabilizar criação, edição e manutenção de conteúdo;
* orquestrar uso da camada administrativa do sistema.

### Tecnologia inferível pelos anexos

Aplicação/interface web administrativa, possivelmente compartilhando base tecnológica com a camada pública, mas separada aqui por responsabilidade, segurança e uso.

### Natureza

Container de experiência interna.

---

## 8.3 Container Lógico: Autenticação / Autorização / Sessão

### Função

Representa a responsabilidade arquitetural de controle de acesso da solução.

### Responsabilidades principais

* validar credenciais;
* controlar sessão;
* proteger o painel;
* autorizar operações administrativas;
* reduzir exposição indevida da camada interna.

### Tecnologia inferível pelos anexos

Capacidade integrada ao backend ou destacável como módulo/serviço lógico, envolvendo autenticação, autorização e gestão de sessão compatíveis com o contrato de segurança do projeto.

### Natureza

Container lógico de segurança.

### Observação importante

Ele pode ser implementado:

* como módulo interno do backend;
* como camada dedicada de autenticação;
* como serviço lógico fortemente separado no design.

Neste documento, ele é mantido explícito porque sua função é crítica para a solução.

---

## 8.4 Container: Backend / API / Regras de Negócio

### Função

É o núcleo lógico e operacional da solução.

### Responsabilidades principais

* receber chamadas do frontend público;
* receber chamadas do painel administrativo;
* aplicar regras de negócio;
* intermediar autenticação e autorização;
* consultar e persistir dados;
* coordenar publicação e exposição pública de conteúdo.

### Tecnologia inferível pelos anexos

Serviço HTTP/API com camada de regras de negócio, compatível com deploy em Render e com integração à camada de persistência.

### Natureza

Container de aplicação principal.

---

## 8.5 Container Lógico: Publicação / SEO Estrutural

### Função

Representa a capacidade de transformar conteúdo persistido em conteúdo exposto publicamente com estrutura técnica adequada para descoberta e indexação.

### Responsabilidades principais

* organizar publicação editorial;
* sustentar slugs e URLs públicas;
* estruturar metadados;
* sustentar sitemap e canonicals;
* reforçar prontidão para indexação.

### Tecnologia inferível pelos anexos

Capacidade implementável como módulo do backend, rotina editorial, camada de geração de metadados ou serviço lógico associado à exposição pública.

### Natureza

Container lógico editorial/técnico.

### Observação importante

Sua separação aqui não implica obrigatoriamente processo isolado em produção. Implica apenas que SEO/publicação não é uma nota de rodapé do sistema, mas uma capacidade arquitetural relevante.

---

## 8.6 Container: Banco / CMS / Persistência

### Função

É o repositório principal de dados e conteúdo do sistema.

### Responsabilidades principais

* armazenar dados estruturados;
* armazenar conteúdo editorial;
* sustentar informações administrativas;
* registrar estados e informações operacionais relevantes;
* servir como base do CMS e da camada de conteúdo.

### Tecnologia inferível pelos anexos

Persistência principal do sistema, compatível com backend próprio e com gestão estruturada de conteúdo.

### Natureza

Container de dados.

---

## 9. Explicação das relações entre containers

## 9.1 Visitante → Frontend Público

O visitante interage apenas com a face pública do sistema. Ele não dialoga diretamente com containers internos.

## 9.2 Administrador → Painel Administrativo

O administrador utiliza a interface interna protegida, e não opera diretamente backend ou persistência.

## 9.3 Painel Administrativo → Autenticação / Autorização / Sessão

Toda entrada na área administrativa deve atravessar a camada de controle de acesso. Isso representa a separação correta entre interface interna e política de acesso.

## 9.4 Frontend Público → Backend / API

A camada pública consulta o backend para obter ou materializar dados e conteúdo públicos.

## 9.5 Painel Administrativo → Backend / API

A camada administrativa realiza operações internas por meio da API, preservando a centralidade do backend como orquestrador.

## 9.6 Backend / API → Banco / CMS / Persistência

O backend é o mediador da leitura e gravação de dados. Isso protege a arquitetura contra acoplamento indevido entre interface e persistência.

## 9.7 Backend / API → Publicação / SEO Estrutural

A API aciona ou coordena regras editoriais e técnicas ligadas à publicação.

## 9.8 Banco / CMS / Persistência → Publicação / SEO Estrutural

A publicação depende do conteúdo e dos dados persistidos para gerar exposição pública coerente.

## 9.9 Publicação / SEO Estrutural → Frontend Público

A face pública recebe conteúdo já apto à exibição, navegação e indexação.

## 9.10 Motores de Busca → Frontend Público

Os buscadores interagem com a camada pública, e não com a camada administrativa ou diretamente com o backend.

## 9.11 Vercel e Render

As plataformas externas sustentam, em nível macro:

* **Vercel**: camada web/interface;
* **Render**: camada de aplicação/backend.

---

## 10. Tecnologias inferíveis e prudência arquitetural

## 10.1 O que pode ser inferido com segurança

Pelos documentos-base do projeto e pela linha já estabelecida, é razoável inferir:

* uma camada web publicada em Vercel;
* uma camada de backend publicada em Render;
* uma solução com site público e área administrativa;
* um backend/API com autenticação e persistência;
* um mecanismo editorial/SEO estrutural relevante para a proposta do projeto.

## 10.2 O que não deve ser afirmado sem código ou confirmação explícita

Sem evidência direta de código ou configuração, este documento evita cravar como fato:

* framework exato do frontend;
* linguagem exata do backend;
* banco de dados específico;
* serviço de sessão específico;
* existência física separada de cada container lógico.

## 10.3 Regra adotada aqui

Onde a documentação aponta fortemente para a necessidade arquitetural, o container é representado.

Onde a implementação específica ainda não está confirmada, usa-se formulação conservadora como:

* “container lógico”;
* “capacidade arquitetural”;
* “tecnologia inferível”;
* “compatível com”.

---

## 11. Fronteiras do sistema

## 11.1 O que está dentro da fronteira do sistema

Estão dentro do sistema William Albarello, neste nível de leitura:

* Frontend Público
* Painel Administrativo
* Autenticação / Autorização / Sessão
* Backend / API / Regras de Negócio
* Publicação / SEO Estrutural
* Banco / CMS / Persistência

## 11.2 O que está fora da fronteira do sistema

Estão fora do sistema:

* Visitante / Leitor
* Administrador / Autor
* Motores de Busca
* Vercel
* Render

## 11.3 Interpretação da fronteira

Essa fronteira significa:

* o produto possui responsabilidades próprias bem definidas;
* plataformas de hospedagem pertencem ao ecossistema externo;
* usuários não fazem parte da arquitetura interna;
* o sistema não deve ser confundido com o ambiente que o hospeda.

---

## 12. Relação com os diagramas anteriores

## 12.1 Relação com o `005_Diagrama_C4_Nivel_1_Contexto.md`

O `005` apresentou o sistema como unidade única no ecossistema.

O `006` abre esse bloco e mostra:

* quais containers relevantes compõem a solução;
* como eles se comunicam;
* como a aplicação se separa em interface, aplicação, publicação e dados.

## 12.2 Relação com o `004_Diagrama_de_Visao_Geral_da_Solucao.md`

O `004` mostrou a macroarquitetura por blocos.

O `006` formaliza essa visão em linguagem C4 Nível 2, com foco em containers e relações mais disciplinadas.

Em resumo:

* `004` é visão macro estrutural;
* `006` é decomposição arquitetural em containers.

---

## 13. Relação com os próximos diagramas

Este documento prepara diretamente a leitura de:

* `007_Diagrama_de_Componentes_Macro.md`
* `008_Diagrama_de_Fronteiras_do_Sistema.md`
* `009_Diagrama_de_Modulos_do_Backend.md`
* `010_Diagrama_de_Componentes_da_API.md`

### Papel no encadeamento

A progressão correta é:

1. contexto do sistema;
2. sistema como unidade no ecossistema;
3. sistema aberto em containers;
4. containers detalhados em componentes e blocos especializados.

---

## 14. Observações de consistência

## 14.1 Coerência com escopo

O diagrama permanece aderente ao escopo do projeto e não introduz complexidade extravagante.

## 14.2 Coerência com segurança

A autenticação/autorização aparece como responsabilidade de primeira classe, coerente com a existência de painel interno e área protegida.

## 14.3 Coerência com conteúdo e SEO

A camada de publicação/SEO aparece como container lógico relevante, coerente com a exigência de forte presença editorial/indexável.

## 14.4 Coerência com operação

A sustentação em plataformas externas permanece visível, sem confundir deploy com domínio do sistema.

## 14.5 Coerência metodológica com C4

O nível de abstração está adequado a C4 Nível 2:

* já não é o sistema como caixa única;
* ainda não são componentes finos.

---

## 15. Critérios de aceite deste documento

Este documento será considerado adequado se:

* mostrar containers principais reais ou logicamente necessários;
* distinguir claramente experiência pública e administrativa;
* explicitar backend/API como núcleo de aplicação;
* explicitar persistência/CMS como base de dados;
* representar autenticação/autorização como responsabilidade relevante;
* representar publicação/SEO como capacidade arquitetural relevante;
* mostrar plataformas externas de hospedagem coerentes com o projeto;
* manter prudência quanto a tecnologias não confirmadas;
* permanecer legível, coerente e útil para evolução do projeto.

---

## 16. Conclusão executiva

O C4 Nível 2 do projeto William Albarello demonstra que a solução não deve ser pensada como um site monolítico indiferenciado, mas como um conjunto organizado de containers com responsabilidades distintas:

* uma **camada pública** para presença institucional e leitura;
* uma **camada administrativa** para operação interna;
* uma **camada de autenticação e autorização** para controle de acesso;
* uma **camada backend/API** para regras de negócio e orquestração;
* uma **camada de persistência/CMS** para dados e conteúdo;
* uma **camada editorial/SEO** para publicação e exposição estruturada;
* uma sustentação operacional em **plataformas externas de hospedagem**.

Este documento estabiliza a decomposição macro do sistema em containers e prepara a descida para níveis mais detalhados da arquitetura.


