
# 008_Diagrama_de_Fronteiras_do_Sistema

## 1. Identificação do documento

- **Projeto:** William Albarello
- **Diretório:** `02-Diagramas`
- **Caminho oficial:** `/home/user/Documents/Softwares/Willian Albarello/William Albarello/02-Diagramas/01-Arquitetura_e_Contexto/008_Diagrama_de_Fronteiras_do_Sistema.md`
- **Natureza do documento:** Diagrama de fronteiras do sistema
- **Função sistêmica:** Delimitar com clareza o que pertence ao sistema, o que pertence ao ambiente externo, quais serviços são terceiros, quais dependências existem e onde começam e terminam as responsabilidades do projeto
- **Posição no bloco:** Sexto documento do bloco `01-Arquitetura_e_Contexto`
- **Dependência imediata:** `003_Diagrama_de_Contexto_do_Sistema.md`, `004_Diagrama_de_Visao_Geral_da_Solucao.md`, `005_Diagrama_C4_Nivel_1_Contexto.md`, `006_Diagrama_C4_Nivel_2_Containers.md` e `007_Diagrama_de_Componentes_Macro.md`

---

## 2. Objetivo

Este documento existe para deixar inequívoco, em nível arquitetural, **o que está dentro do sistema William Albarello e o que está fora dele**.

Seu objetivo não é apenas desenhar caixas, mas responder com precisão às perguntas abaixo:

- o que é responsabilidade direta do sistema?
- o que é responsabilidade de plataformas terceiras?
- quais atores usam o sistema, mas não fazem parte dele?
- quais dependências externas influenciam a operação?
- até onde vai a obrigação técnica do projeto e onde começa a obrigação de serviços terceiros?
- quais capacidades devem ser tratadas como internas, mesmo que dependam de infraestrutura externa?

Este documento é importante porque evita confusões muito comuns, como:

- confundir o sistema com a hospedagem;
- tratar o buscador como parte do produto;
- supor que um serviço terceiro substitui responsabilidade arquitetural interna;
- atribuir ao frontend responsabilidades de persistência direta;
- misturar usuário, sistema e plataforma como se fossem a mesma coisa.

---

## 3. Fontes de referência no Waterfall

Este documento deriva principalmente dos seguintes arquivos do Diretório `01-Waterfall`:

- `005_Escopo_MVP_e_Fora_de_Escopo.md`
- `014_Arquitetura_Tecnica.md`
- `015_Seguranca_Autenticacao_e_Autorizacao.md`
- `016_API_Contract_Mestre.md`
- `021_Criterios_de_Aceite_Gerais.md`
- `024_Registro_de_Decisoes_Arquiteturais.md`

Documentos complementares relevantes:

- `001_Visao_Geral_do_Projeto.md`
- `003_Objetivos_de_Negocio_e_de_Produto.md`
- `006_Requisitos_Funcionais.md`
- `007_Requisitos_Nao_Funcionais.md`
- `008_Arquitetura_da_Informacao.md`
- `012_Estrategia_de_Conteudo_e_SEO.md`
- `013_Modelo_de_Dados_e_CMS.md`
- `017_UI_UX_Arquitetura_da_Informacao.md`
- `022_Plano_de_Implantacao_Rollback_e_Suporte.md`
- `023_Matriz_de_Rastreabilidade.md`

---

## 4. Premissas e limites

## 4.1 Premissas adotadas

Para fins deste documento, assumem-se como válidas as seguintes premissas arquiteturais e documentais:

- o projeto William Albarello é uma solução institucional com camada pública e camada administrativa;
- o sistema possui backend/API próprio como centro de regras e integração;
- o sistema possui persistência própria para conteúdo e dados estruturados;
- autenticação, autorização e sessão são capacidades internas do sistema, ainda que sua execução dependa da camada aplicacional;
- publicação editorial e SEO estrutural são capacidades internas do sistema;
- Vercel e Render devem ser tratados como **plataformas terceiras de execução/hospedagem**, e não como parte do domínio funcional da solução;
- motores de busca devem ser tratados como **sistemas externos consumidores da superfície pública**, e não como parte do sistema.

## 4.2 Limites deste documento

Este arquivo não detalha:

- endpoints específicos;
- classes, serviços ou módulos internos;
- entidades e relacionamentos do banco;
- sequências passo a passo de login/publicação;
- estrutura fina de deploy/CI/CD;
- política de logs e observabilidade em profundidade.

Seu foco é **fronteira, responsabilidade e dependência**.

## 4.3 Regra mestra de leitura

Sempre que houver dúvida, a regra correta é:

- **capacidade do produto** = dentro da fronteira;
- **ator humano** = fora da fronteira;
- **serviço terceiro que executa ou hospeda** = fora da fronteira;
- **sistema que consome ou indexa a superfície pública** = fora da fronteira.

---

## 5. Diagrama principal — Fronteiras do Sistema

```mermaid
flowchart LR

    visitante["Ator Externo: Visitante / Leitor"]
    admin["Ator Externo: Administrador / Autor"]

    buscadores["Sistema Externo: Motores de Busca"]
    hospedagem_web["Serviço Terceiro: Hospedagem Web / Frontend (ex.: Vercel)"]
    hospedagem_app["Serviço Terceiro: Hospedagem Aplicacional / Backend (ex.: Render)"]

    subgraph fronteira["Fronteira do Sistema William Albarello"]
        subgraph experiencia["Responsabilidades Internas — Experiência"]
            site_publico["Site Público / Páginas Institucionais"]
            painel_admin["Painel Administrativo / Área Interna"]
            navegacao["Navegação, Rotas e Estrutura Pública"]
        end

        subgraph aplicacao["Responsabilidades Internas — Aplicação"]
            auth["Autenticação / Autorização / Sessão"]
            api["Backend / API / Orquestração"]
            gestao["Gestão de Conteúdo"]
            publicacao["Publicação / SEO / Metadata"]
        end

        subgraph dados["Responsabilidades Internas — Dados"]
            persistencia["CMS / Persistência Principal"]
        end
    end

    visitante -->|consome conteúdo e navega| site_publico
    admin -->|opera o sistema| painel_admin

    site_publico -->|usa estrutura de navegação| navegacao
    painel_admin -->|exige acesso controlado| auth
    painel_admin -->|aciona operações internas| api

    site_publico -->|obtém conteúdo e dados públicos| api
    auth -->|libera ou bloqueia acesso| api
    api -->|coordena gestão editorial| gestao
    api -->|lê e grava dados| persistencia
    gestao -->|atualiza conteúdo| persistencia
    gestao -->|aciona fluxo de publicação| publicacao
    persistencia -->|fornece conteúdo estruturado| publicacao
    publicacao -->|estrutura páginas, slugs e metadados| site_publico
    publicacao -->|alimenta experiência pública| navegacao

    buscadores -->|rastreiam e indexam| site_publico
    hospedagem_web -->|executa / publica interface web| site_publico
    hospedagem_web -. sustenta .-> painel_admin
    hospedagem_app -->|executa aplicação| api
    hospedagem_app -. sustenta .-> auth
    hospedagem_app -. sustenta .-> gestao
    hospedagem_app -. sustenta .-> publicacao

    classDef actor fill:#f5f5f5,stroke:#333,stroke-width:1px;
    classDef internal_front fill:#e8f0fe,stroke:#1a73e8,stroke-width:1px;
    classDef internal_app fill:#e6f4ea,stroke:#137333,stroke-width:1px;
    classDef internal_data fill:#fff4d6,stroke:#b06000,stroke-width:1px;
    classDef thirdparty fill:#fde8e8,stroke:#b42318,stroke-width:1px;

    class visitante,admin actor
    class site_publico,painel_admin,navegacao internal_front
    class auth,api,gestao,publicacao internal_app
    class persistencia internal_data
    class buscadores,hospedagem_web,hospedagem_app thirdparty
````

---

## 6. Legenda e regras de leitura

## 6.1 O que significa “fronteira do sistema”

A fronteira do sistema é a linha conceitual que separa:

* o que **pertence ao produto**;
* do que **interage com o produto**;
* e do que **sustenta tecnicamente o produto sem fazer parte de sua lógica interna**.

Neste documento, tudo que está dentro do subgraph `Fronteira do Sistema William Albarello` pertence ao sistema.

Tudo que está fora desse subgraph é externo ao sistema.

## 6.2 Tipos de elemento

Os elementos do diagrama devem ser lidos assim:

* **Ator Externo**: pessoa que usa o sistema, mas não compõe sua arquitetura;
* **Sistema Externo**: sistema de fora que interage com a face pública do produto;
* **Serviço Terceiro**: plataforma externa de hospedagem, execução ou suporte técnico;
* **Responsabilidade Interna**: capacidade, módulo macro ou parte pertencente ao sistema.

## 6.3 Regra de interpretação

Uma seta neste diagrama indica:

* uso;
* dependência;
* sustentação;
* relacionamento funcional;
* responsabilidade de serviço.

Ela não representa necessariamente:

* chamada HTTP específica;
* ordem temporal exata;
* detalhe de código;
* topologia física final.

---

## 7. O que está dentro da fronteira do sistema

## 7.1 Camada de Experiência

Estão dentro da fronteira, como responsabilidades internas de experiência:

* **Site Público / Páginas Institucionais**
* **Painel Administrativo / Área Interna**
* **Navegação, Rotas e Estrutura Pública**

### Motivo

Esses elementos fazem parte do comportamento e da entrega funcional do produto. Eles não são acessórios externos; são partes constitutivas da solução.

## 7.2 Camada de Aplicação

Estão dentro da fronteira, como responsabilidades internas de aplicação:

* **Autenticação / Autorização / Sessão**
* **Backend / API / Orquestração**
* **Gestão de Conteúdo**
* **Publicação / SEO / Metadata**

### Motivo

Essas capacidades representam lógica do produto, regras do domínio, proteção de acesso, manipulação de conteúdo e estruturação da presença pública. Portanto, pertencem ao sistema, mesmo quando executadas sobre infraestrutura externa.

## 7.3 Camada de Dados

Está dentro da fronteira:

* **CMS / Persistência Principal**

### Motivo

Persistência é parte central do produto. O banco ou CMS não é um ator externo; ele é um repositório do próprio sistema.

---

## 8. O que está fora da fronteira do sistema

## 8.1 Atores humanos externos

Estão fora da fronteira:

* **Visitante / Leitor**
* **Administrador / Autor**

### Motivo

Esses elementos usam o sistema, mas não pertencem à sua estrutura interna.

O administrador pode ter permissões elevadas, mas continua sendo um ator externo ao produto, não um componente do sistema.

## 8.2 Sistemas externos

Está fora da fronteira:

* **Motores de Busca**

### Motivo

Motores de busca consomem a camada pública e influenciam a visibilidade do projeto, mas não pertencem ao sistema.

## 8.3 Serviços terceiros

Estão fora da fronteira:

* **Hospedagem Web / Frontend**
* **Hospedagem Aplicacional / Backend**

### Motivo

Plataformas de hospedagem e execução são terceiras. Elas sustentam o sistema, mas não fazem parte do domínio do produto.

---

## 9. Responsabilidades internas do sistema

## 9.1 Responsabilidades de experiência

### Site Público / Páginas Institucionais

Responsável por:

* apresentar William Albarello;
* expor conteúdo público;
* sustentar leitura e percepção institucional;
* servir como superfície de descoberta pública.

### Painel Administrativo / Área Interna

Responsável por:

* oferecer interface interna de operação;
* permitir administração e manutenção do conteúdo;
* centralizar a experiência de gestão protegida.

### Navegação, Rotas e Estrutura Pública

Responsável por:

* organizar caminhos de leitura;
* sustentar arquitetura de informação pública;
* articular páginas, rotas e experiência institucional.

## 9.2 Responsabilidades de aplicação

### Autenticação / Autorização / Sessão

Responsável por:

* validar identidade;
* controlar acesso;
* manter sessão;
* impor restrições administrativas.

### Backend / API / Orquestração

Responsável por:

* receber demandas das camadas de interface;
* aplicar regras do sistema;
* mediar acesso à persistência;
* coordenar as capacidades internas.

### Gestão de Conteúdo

Responsável por:

* criar, editar, manter e organizar conteúdo;
* sustentar o lado administrativo editorial;
* articular operação interna e persistência.

### Publicação / SEO / Metadata

Responsável por:

* transformar conteúdo em material publicável;
* estruturar slugs, metadata, sitemap e sinais de indexação;
* alimentar a camada pública com material já preparado.

## 9.3 Responsabilidades de dados

### CMS / Persistência Principal

Responsável por:

* armazenar conteúdo;
* manter dados administrativos;
* preservar dados estruturais do sistema;
* servir de base ao domínio editorial e institucional.

---

## 10. Responsabilidades externas e limites de obrigação

## 10.1 Visitante / Leitor

O visitante tem responsabilidade de uso, não de operação.

O sistema é responsável por atender adequadamente a navegação pública, mas não controla o comportamento do visitante.

## 10.2 Administrador / Autor

O administrador utiliza o sistema e opera suas capacidades internas, mas não se confunde com a arquitetura do produto.

O sistema é responsável por oferecer mecanismos adequados de operação, segurança e controle.

## 10.3 Motores de Busca

Os buscadores são externos. O sistema pode:

* expor páginas adequadamente;
* estruturar SEO técnico;
* oferecer conteúdo indexável.

Mas o sistema **não controla** a política interna de indexação dos buscadores.

## 10.4 Hospedagem Web / Frontend

A plataforma de hospedagem web é responsável por:

* servir a aplicação web publicada;
* manter seu ambiente de execução;
* aplicar suas próprias regras de disponibilidade e infraestrutura.

O sistema é responsável por:

* entregar um frontend coerente e publicável;
* não quebrar sua própria aplicação;
* configurar adequadamente sua camada pública.

## 10.5 Hospedagem Aplicacional / Backend

A plataforma aplicacional é responsável por:

* executar a aplicação backend;
* manter sua infraestrutura como serviço;
* prover o ambiente de runtime.

O sistema continua responsável por:

* coerência da aplicação;
* segurança lógica do backend;
* organização correta da solução;
* proteção funcional e consistência dos dados.

---

## 11. Pontos de dependência externos

O diagrama evidencia três pontos de dependência externos principais.

## 11.1 Dependência de descoberta pública

O sistema depende do ecossistema de motores de busca para ampliar sua visibilidade orgânica.

### Consequência

SEO e publicação estruturada são responsabilidades internas justamente porque existe essa dependência externa.

## 11.2 Dependência de publicação da camada web

O sistema depende de serviço terceiro para hospedar/publicar sua interface pública e possivelmente a camada administrativa web.

### Consequência

A arquitetura deve prever separação entre produto e plataforma, evitando acoplamento conceitual indevido.

## 11.3 Dependência de execução da camada aplicacional

O sistema depende de serviço terceiro para executar backend, autenticação e lógicas administrativas/editoriais.

### Consequência

O sistema precisa ser desenhado com clareza suficiente para não confundir responsabilidade do software com responsabilidade da plataforma.

---

## 12. Limites de responsabilidade do projeto

## 12.1 O que é responsabilidade direta do projeto

É responsabilidade direta do projeto William Albarello:

* experiência pública;
* experiência administrativa;
* controle de acesso;
* regras de negócio;
* gestão de conteúdo;
* publicação e SEO estrutural;
* persistência e integridade funcional;
* coerência arquitetural da solução.

## 12.2 O que não é responsabilidade direta do projeto

Não é responsabilidade direta do projeto:

* algoritmo interno dos buscadores;
* disponibilidade estrutural das plataformas terceiras em si;
* política interna de provedores de hospedagem;
* operação interna do serviço terceiro enquanto infraestrutura como serviço.

## 12.3 O que é responsabilidade compartilhada

Há responsabilidades compartilhadas em temas como:

* disponibilidade percebida em produção;
* entrega correta da camada web;
* execução estável da aplicação;
* configuração segura do ambiente;
* aderência entre arquitetura do produto e limitações da plataforma.

---

## 13. Fronteiras internas relevantes

Além da grande fronteira do sistema, o diagrama também evidencia fronteiras internas importantes.

## 13.1 Fronteira entre experiência pública e operação interna

A camada pública e o painel administrativo coexistem, mas possuem responsabilidades distintas.

### Importância

Evita confundir:

* navegação pública com operação protegida;
* visitante com administrador;
* conteúdo público com interface de gestão.

## 13.2 Fronteira entre interface e aplicação

Nem o site público nem o painel administrativo devem ser tratados como origem autônoma de regra de negócio.

### Importância

A lógica principal continua centralizada na camada aplicacional.

## 13.3 Fronteira entre aplicação e dados

A persistência não deve ser acessada diretamente pela interface.

### Importância

Protege integridade arquitetural e mantém mediação da aplicação.

## 13.4 Fronteira entre domínio interno e plataforma externa

O sistema é o produto. A hospedagem é suporte operacional.

### Importância

Evita a ilusão de que trocar a plataforma equivale a trocar o sistema.

---

## 14. Relação deste documento com os anteriores

## 14.1 Relação com `003_Diagrama_de_Contexto_do_Sistema.md`

O `003` mostrou o sistema no nível mais alto.

O `008` refina essa visão explicitando onde termina a fronteira do produto.

## 14.2 Relação com `004_Diagrama_de_Visao_Geral_da_Solucao.md`

O `004` mostrou macroblocos da solução.

O `008` usa esse entendimento para separar o que é interno do que é externo.

## 14.3 Relação com `005_Diagrama_C4_Nivel_1_Contexto.md`

O `005` mostrou o sistema como bloco no ecossistema.

O `008` materializa esse raciocínio em termos de responsabilidade e limite.

## 14.4 Relação com `006_Diagrama_C4_Nivel_2_Containers.md`

O `006` abriu o sistema em containers.

O `008` usa essa abertura para dizer, de forma mais governativa:

* quais containers pertencem ao sistema;
* quais são terceiros;
* quais são apenas atores externos.

## 14.5 Relação com `007_Diagrama_de_Componentes_Macro.md`

O `007` mostrou componentes internos principais.

O `008` informa, com maior rigor, quais desses componentes estão sob responsabilidade direta do sistema e quais dependem de elementos externos.

---

## 15. Relação com os documentos seguintes

Este documento é base direta para a leitura e geração de:

* `009_Diagrama_de_Modulos_do_Backend.md`
* `010_Diagrama_de_Componentes_da_API.md`
* `011_Diagrama_de_Fluxo_de_Autenticacao.md`
* `012_Diagrama_de_Autorizacao_e_Papeis.md`
* `032_Diagrama_de_Deploy_Vercel_Render.md`
* `033_Diagrama_de_Infraestrutura_Geral.md`
* `038_Diagrama_de_Seguranca_da_Aplicacao.md`
* `041_Diagrama_de_Auditoria_e_Rastreabilidade.md`

### Motivo

Todos esses documentos dependem da resposta à pergunta:

**“isto está dentro ou fora da responsabilidade do sistema?”**

---

## 16. Observações de consistência

## 16.1 Coerência com escopo

O documento permanece dentro do escopo do projeto e não adiciona sistemas externos não comprovados.

## 16.2 Coerência com arquitetura

A separação entre experiência, aplicação, dados e serviços externos mantém coerência com a arquitetura técnica do projeto.

## 16.3 Coerência com segurança

A autenticação permanece claramente dentro da responsabilidade do sistema, enquanto o ambiente que a executa permanece fora.

## 16.4 Coerência com critérios de aceite

A fronteira ajuda diretamente na validação de aceite porque define com clareza o que o projeto precisa de fato entregar e sustentar.

## 16.5 Coerência com ADR

A lógica de fronteiras preserva a disciplina de decisões arquiteturais, especialmente no que diz respeito a:

* responsabilidade do sistema;
* uso de serviços terceiros;
* separação entre produto e plataforma;
* presença de capacidades internas relevantes.

---

## 17. Critérios de aceite deste documento

Este documento será considerado adequado se:

* deixar inequívoco o que está dentro da fronteira do sistema;
* deixar inequívoco o que está fora da fronteira;
* distinguir atores, sistemas externos e serviços terceiros;
* representar responsabilidades internas de forma coerente;
* explicitar pontos de dependência externa;
* mostrar limites reais de responsabilidade do projeto;
* permanecer consistente com escopo, arquitetura, segurança, API, critérios de aceite e ADR.

---

## 18. Conclusão executiva

O diagrama de fronteiras do sistema William Albarello demonstra que o produto deve ser entendido como um núcleo arquitetural próprio, composto por:

* experiência pública;
* experiência administrativa;
* autenticação e controle de acesso;
* backend/orquestração;
* gestão de conteúdo;
* publicação e SEO estrutural;
* persistência principal.

Fora dessa fronteira ficam:

* os usuários humanos;
* os motores de busca;
* as plataformas terceiras de hospedagem e execução.

Essa distinção é decisiva porque protege o projeto contra erros de entendimento sobre escopo, responsabilidade e dependência.

Em termos práticos:

* o produto é responsável por sua lógica, conteúdo, acesso e exposição pública;
* os terceiros são responsáveis por sustentar o ambiente em que o produto roda;
* os usuários usam o sistema, mas não o compõem;
* os buscadores consomem a superfície pública, mas não pertencem à arquitetura interna.

Este documento fecha o bloco de fundação arquitetural e prepara a entrada no detalhamento do backend e da API.

---


