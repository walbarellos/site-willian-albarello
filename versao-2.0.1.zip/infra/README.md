# Infraestrutura Operacional — `personal-site`

## Objetivo

A pasta `infra/` concentra os artefatos operacionais do projeto para:

1. preparar ambiente por contexto (`dev`, `staging`, `production`);
2. orientar deploy de `web`, `admin` e `api`;
3. padronizar validação mínima antes de release;
4. reduzir improviso em operação e rollback.

Este diretório complementa os contratos já consolidados em `APIs/`, `QA/`, `Scaffold/` e `Waterfall/`.

## Escopo desta camada

Inclui:

- matriz e exemplos de variáveis de ambiente;
- runbooks por plataforma (Vercel/Render);
- scripts operacionais (`dev-up`, `smoke`, `release-check`);
- documentação objetiva de operação e rollback.

Não inclui:

- lógica de negócio de aplicação;
- contratos de API (ficam em `APIs/`);
- documentação funcional de telas (fica em `UI_UX/`).

## Estrutura esperada

Durante este ciclo, a estrutura soberana de `infra/` será:

- `infra/README.md`
- `infra/env/`
- `infra/vercel/`
- `infra/render/`
- `infra/scripts/`
- `infra/ops/`
- `infra/ci/` (apoio para integração com workflows)

Subpastas só devem ser materializadas com arquivos reais. Evitar diretórios vazios.

## Relação com cada aplicação

- `apps/web` (Vercel): frontend público (`next build`, `next start` em produção gerenciada).
- `apps/admin` (Vercel): painel administrativo com requisitos de sessão/autenticação.
- `apps/api` (Render): serviço HTTP Fastify com `health/ready` e contratos admin/public.

## Ordem de uso (operacional)

1. validar env e exemplos em `infra/env/`;
2. revisar runbooks de plataforma em `infra/vercel/` e `infra/render/`;
3. subir ambiente local com `infra/scripts/dev-up.sh`;
4. executar smoke com `infra/scripts/smoke.sh`;
5. executar gate pré-release com `infra/scripts/release-check.sh`;
6. seguir `infra/ops/OPERACAO-E-ROLLBACK.md` para publicação e contingência.

## Fontes soberanas de decisão

- `README.md`
- `apps/api/README.md`
- `apps/web/README.md`
- `apps/admin/README.md`
- `QA/QA-01-checklist-de-homologacao-funcional.md`
- `QA/QA-02-matriz-de-gates-ci-e-deploy-readiness.md`
- `Scaffold/SCF-04-bootstrap-de-qualidade-local-e-ci.md`
- `Waterfall/DOC-10-arquitetura-tecnica.md`
- `Waterfall/DOC-14-seguranca-p0.md`
- `Waterfall/DOC-21-observabilidade-logs-e-incidentes.md`
- `Diagrama/DGM-05-deploy-vercel-render.mmd`

## Convenções de governança

1. não versionar segredos reais;
2. versionar apenas exemplos e templates seguros;
3. scripts devem ser explícitos, sem automação obscura;
4. toda mudança operacional relevante deve refletir em runbook e QA;
5. qualquer ajuste de deploy deve preservar aderência ao estado real do código.

## Critério de pronto desta camada

A camada `infra/` é considerada operacional quando:

1. ambientes estão mapeados e exemplificados;
2. deploy de `web/admin/api` está documentado por plataforma;
3. scripts de subida/smoke/release-check estão executáveis;
4. existe runbook de operação e rollback coerente com os workflows.
