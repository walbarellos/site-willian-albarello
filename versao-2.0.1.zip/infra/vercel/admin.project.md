# Runbook Vercel — Admin (`apps/admin`)

## Objetivo

Documento operacional de deploy do painel administrativo na Vercel, aderente ao estado atual do monorepo `personal-site`.

## Escopo

Aplicação:

- `apps/admin`

Função:

- autenticação administrativa;
- leitura de sessão server-side;
- listagem e edição editorial.

## Pré-condições

Antes de publicar:

1. `pnpm install --frozen-lockfile`
2. `pnpm build:admin`
3. `pnpm typecheck:admin`
4. `pnpm verify:hardening` (gate agregado recomendado)

Referência:

- `QA/QA-02-matriz-de-gates-ci-e-deploy-readiness.md`

## Configuração do projeto na Vercel

### Root Directory

- `apps/admin`

### Framework Preset

- `Next.js`

### Build Command

- `pnpm build`  
  (internamente: `next build --webpack`)

### Install Command

- `pnpm install --frozen-lockfile`

### Output Directory

- padrão do Next.js (não sobrescrever)

## Variáveis de ambiente (admin)

Obrigatórias para produção:

- `NEXT_PUBLIC_ADMIN_URL`  
  Exemplo: `https://admin.seudominio.com`

- `NEXT_PUBLIC_API_URL`  
  Exemplo: `https://api.seudominio.com`

Opcional (fallback de resolução no client admin):

- `ADMIN_API_URL`
- `API_URL`

Regra prática:

1. definir sempre `NEXT_PUBLIC_ADMIN_URL` e `NEXT_PUBLIC_API_URL`;
2. usar `ADMIN_API_URL`/`API_URL` apenas para necessidades específicas.

## Domínio e DNS

1. anexar domínio administrativo no projeto Vercel;
2. validar HTTPS antes de uso operacional;
3. confirmar que a API aceita a origem do admin em `CORS_ORIGINS`.

## Cautelas de autenticação e sessão

O admin depende de leitura server-side de sessão (`apps/admin/src/lib/session.ts`) e fluxo seguro de `next` (`apps/admin/src/lib/routes.ts`).

Pontos críticos:

1. login deve redirecionar apenas para rotas permitidas;
2. `/` do admin deve redirecionar corretamente para login ou área protegida;
3. cookies de sessão devem trafegar corretamente entre admin e API em HTTPS;
4. divergência de domínio/API/CORS pode quebrar sessão mesmo com build verde.

## Smoke checks pós-deploy

Executar após release:

1. abrir `GET /` (admin) e validar redirect esperado;
2. abrir `GET /painel/login` e validar render da tela;
3. executar login válido;
4. validar redirect para `/painel/publicacoes`;
5. abrir uma edição em `/painel/publicacoes/[id]/editar`;
6. validar que chamadas para API retornam sem erro de origem/sessão.

Referência de checklist:

- `QA/QA-01-checklist-de-homologacao-funcional.md`

## Falhas comuns e diagnóstico rápido

### 1) Login falha com erro de sessão/forbidden

Possíveis causas:

- API URL incorreta no admin;
- domínio admin ausente em `CORS_ORIGINS`;
- incompatibilidade de ambiente HTTP/HTTPS.

Ação:

1. revisar env do projeto Vercel e API;
2. revisar `CORS_ORIGINS` na API;
3. redeploy após ajuste.

### 2) Redirect pós-login incorreto

Possível causa:

- parâmetro `next` inválido/não permitido.

Ação:

1. validar regras em `apps/admin/src/lib/routes.ts`;
2. reproduzir com `next` limpo e com rota permitida.

### 3) Build verde, runtime quebrado

Possível causa:

- env incompleta no projeto Vercel.

Ação:

1. conferir `NEXT_PUBLIC_ADMIN_URL` e `NEXT_PUBLIC_API_URL`;
2. repetir smoke checks após novo deploy.

## Rollback (procedimento curto)

1. identificar último deployment saudável no histórico da Vercel;
2. promover redeploy desse commit/deployment;
3. executar smoke checks de login/listagem/edição;
4. registrar incidente para correção da release regressiva.

## Referências soberanas

- `apps/admin/package.json`
- `apps/admin/README.md`
- `apps/admin/src/lib/session.ts`
- `apps/admin/src/lib/routes.ts`
- `Diagrama/DGM-05-deploy-vercel-render.mmd`
- `QA/QA-02-matriz-de-gates-ci-e-deploy-readiness.md`
