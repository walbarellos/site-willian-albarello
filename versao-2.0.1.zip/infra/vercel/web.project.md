# Runbook Vercel — Web Público (`apps/web`)

## Objetivo

Documento operacional do deploy do frontend público na Vercel, aderente ao estado atual do monorepo `personal-site`.

## Escopo

Aplicação:

- `apps/web`

Função:

- servir a camada pública (`/`, `/publicacoes`, `/publicacoes/[slug]`)
- consumir API pública via variáveis de ambiente

## Pré-condições

Antes de publicar:

1. `pnpm install --frozen-lockfile`
2. `pnpm build:web`
3. `pnpm typecheck:web`
4. `pnpm verify:hardening` (gate agregado recomendado)

Referência de gates:

- `QA/QA-02-matriz-de-gates-ci-e-deploy-readiness.md`

## Configuração do projeto na Vercel

### Root Directory

- `apps/web`

### Framework Preset

- `Next.js`

### Build Command

- `pnpm build`

### Install Command

- `pnpm install --frozen-lockfile`

### Output Directory

- padrão do Next.js (não sobrescrever)

## Variáveis de ambiente (web)

Obrigatórias para produção:

- `NEXT_PUBLIC_SITE_URL`  
  Exemplo: `https://www.seudominio.com`

- `NEXT_PUBLIC_API_URL`  
  Exemplo: `https://api.seudominio.com`

Opcional (fallback de resolução no código):

- `PUBLIC_API_URL`
- `API_URL`

Regra prática:

1. preencher sempre `NEXT_PUBLIC_SITE_URL` e `NEXT_PUBLIC_API_URL`;
2. manter `PUBLIC_API_URL`/`API_URL` apenas se houver necessidade operacional específica.

## Domínio e DNS

Para domínio customizado:

1. anexar domínio público no projeto Vercel;
2. apontar DNS conforme instruções da Vercel;
3. validar HTTPS ativo antes de liberar tráfego.

## Smoke checks pós-deploy

Executar após cada release:

1. `GET /` responde `200`
2. `GET /publicacoes` responde `200`
3. abrir um slug válido em `/publicacoes/[slug]`
4. validar geração de metadata/canonical
5. validar consumo da API pública (sem erro de base URL)

Checklist mínimo de referência:

- `QA/QA-01-checklist-de-homologacao-funcional.md`

## Falhas comuns e diagnóstico rápido

### 1) Página pública sem dados

Possível causa:

- `NEXT_PUBLIC_API_URL` ausente ou incorreta.

Ação:

1. revisar env do projeto Vercel;
2. redeploy após correção.

### 2) Canonical/metadata incorretos

Possível causa:

- `NEXT_PUBLIC_SITE_URL` incorreta.

Ação:

1. ajustar env;
2. publicar novamente e validar `view-source`.

### 3) Erro de build

Possível causa:

- divergência de lockfile ou regressão TypeScript.

Ação:

1. reproduzir local com `pnpm build:web` e `pnpm typecheck:web`;
2. corrigir antes de novo deploy.

## Rollback (procedimento curto)

1. identificar último deployment saudável no histórico da Vercel;
2. promover redeploy desse commit/deployment;
3. executar smoke checks mínimos;
4. abrir incidente interno para correção definitiva da versão regressiva.

## Referências soberanas

- `apps/web/package.json`
- `apps/web/README.md`
- `Diagrama/DGM-05-deploy-vercel-render.mmd`
- `QA/QA-02-matriz-de-gates-ci-e-deploy-readiness.md`
