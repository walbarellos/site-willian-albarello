# CI Operacional — `infra/ci`

## Objetivo
A pasta `infra/ci` centraliza a governanca operacional de CI do `personal-site`.

Ela existe para:
1. mapear o que cada workflow valida;
2. alinhar execucao local com execucao de pipeline;
3. padronizar resposta a falhas de gate;
4. registrar evidencias minimas para congelamento de versao.

## Escopo desta pasta
Inclui documentos operacionais de CI:
- matriz de pipelines e gates;
- mapa local x CI;
- checklists de bootstrap/release;
- playbook de falha de pipeline;
- criterios de ownership e retencao de artefatos.

Nao inclui:
- implementacao dos workflows (fica em `.github/workflows`);
- scripts de execucao (fica em `infra/scripts`);
- contratos funcionais/telas (fica em `QA`, `APIs`, `UI_UX`).

## Fontes soberanas
1. `.github/workflows/scaffold-bootstrap.yml`
2. `.github/workflows/api-contract.yml`
3. `.github/workflows/api-docs.yml`
4. `.github/workflows/api-breaking-change.yml`
5. `.github/workflows/deploy-readiness.yml`
6. `infra/scripts/dev-up.sh`
7. `infra/scripts/smoke.sh`
8. `infra/scripts/release-check.sh`
9. `QA/QA-01-checklist-de-homologacao-funcional.md`
10. `QA/QA-02-matriz-de-gates-ci-e-deploy-readiness.md`

## Relacao com os gates
A CI operacional desta camada protege, no minimo:
- instalacao deterministica;
- testes agregados (`pnpm test:ci`);
- hardening agregado (`pnpm verify:hardening`);
- guardas contratuais OpenAPI;
- gate de readiness pre-release.

A decisao de release deve respeitar os gates bloqueantes definidos em `QA/QA-02`.

## Ordem pratica de uso
1. executar validacao local (`pnpm test:ci`, `pnpm verify:hardening`);
2. executar `infra/scripts/release-check.sh`;
3. consultar os workflows em `.github/workflows`;
4. em falha, seguir o playbook de pipeline desta pasta;
5. registrar evidencias e atualizar relatorio da versao.

## Criterio de pronto desta camada
`infra/ci` esta pronta quando:
1. os documentos desta pasta refletirem o estado real dos workflows;
2. houver mapeamento claro local x pipeline;
3. houver checklist objetivo de evidencia para release;
4. houver orientacao operacional para investigacao de falhas.

## Regra de manutencao
Qualquer mudanca em:
- workflow,
- gate bloqueante,
- script de validacao,
- criterio de release,

deve atualizar os documentos correspondentes em `infra/ci` no mesmo ciclo.
