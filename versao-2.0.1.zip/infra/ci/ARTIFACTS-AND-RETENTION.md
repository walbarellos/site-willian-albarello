# Artifacts and Retention — `personal-site`

## Objetivo
Definir politica soberana de artefatos por ciclo para auditoria, continuidade e rastreabilidade operacional.

## Principios
1. preservar o que prova estado real da versao;
2. evitar acumulo de lixo operacional sem valor de auditoria;
3. manter rastreabilidade entre codigo, relatorio e evidencias.

## Artefatos obrigatorios por ciclo
Cada ciclo fechado deve preservar no minimo:
1. ZIP da versao (ex.: `versao-1.6.zip`);
2. relatorio final da versao (ex.: `RELATORIO-FINAL-V1.6.md`);
3. evidencia de validacoes tecnicas:
   - `pnpm test:ci`
   - `pnpm verify:hardening`
   - `bash infra/scripts/smoke.sh` (quando aplicavel)
4. referencia ao checklist de release preenchido (`infra/ci/RELEASE-EVIDENCE-CHECKLIST.md`).

## Artefatos recomendados
1. links/status dos workflows relevantes (`scaffold`, `api-contract`, `api-docs`, `api-breaking-change`, `deploy-readiness`);
2. registro de incidente/falha quando houve correcao durante o ciclo;
3. handoff de continuidade para o proximo ciclo.

## Retencao minima

| Tipo de artefato | Retencao minima | Regra |
|---|---|---|
| ZIP de versao | manter ultimas 3 versoes | preservar no repositorio local para auditoria imediata |
| Relatorio final | manter historico completo do projeto | nunca descartar relatorio de versao fechada |
| Evidencias de comandos locais | manter ate fechamento de 2 ciclos seguintes | pode consolidar no relatorio quando estavel |
| Evidencias de workflow (links/status) | manter no relatorio da versao | nao precisa duplicar logs completos no repo |
| Logs temporarios de debug | descarte apos resolucao e consolidacao no relatorio | nao sao artefatos soberanos |

## O que pode ser descartado
1. caches de build (`.next`, `dist`, `coverage`) nao vinculados a evidencia formal;
2. logs temporarios de depuracao sem valor de auditoria;
3. arquivos transitorios sem referencia em relatorio/checklist.

## O que nao pode ser descartado
1. `versao-*.zip` dentro da janela de retencao minima;
2. `RELATORIO-FINAL-*.md`;
3. documentos soberanos atualizados em `infra/`, `infra/ci`, `QA`, `Waterfall`, `UI_UX`;
4. evidencias que sustentam decisao de `LIBERAR` ou `BLOQUEAR` release.

## Responsabilidade operacional
No fechamento de cada ciclo:
1. validar checklist de release;
2. gerar ZIP e relatorio final;
3. registrar estado dos gates/workflows;
4. aplicar descarte apenas no que for explicitamente transitório.

## Registro da rodada
Data:
Versao:
Executor:

Resumo:
1. Artefatos gerados:
2. Artefatos preservados:
3. Artefatos descartados:
4. Justificativa de descarte:
