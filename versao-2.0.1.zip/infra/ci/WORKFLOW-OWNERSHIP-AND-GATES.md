# Workflow Ownership and Gates — `personal-site`

## Objetivo
Definir ownership operacional dos workflows e o papel de cada gate na decisao de release.

## Fonte de verdade
1. `.github/workflows/scaffold-bootstrap.yml`
2. `.github/workflows/api-contract.yml`
3. `.github/workflows/api-docs.yml`
4. `.github/workflows/api-breaking-change.yml`
5. `.github/workflows/deploy-readiness.yml`
6. `QA/QA-02-matriz-de-gates-ci-e-deploy-readiness.md`
7. `infra/scripts/release-check.sh`

## Ownership por workflow

| Workflow | Ownership primario | Responsabilidade principal |
|---|---|---|
| `scaffold-bootstrap.yml` | Engenharia de Plataforma/Monorepo | garantir bootstrap tecnico e hardening minimo |
| `api-contract.yml` | Engenharia de API/Contratos | preservar presenca/estrutura basica dos contratos OpenAPI |
| `api-docs.yml` | Engenharia de API + Documentacao tecnica | manter consistencia documental minima de OpenAPI e referencias |
| `api-breaking-change.yml` | Engenharia de API/Arquitetura | bloquear remocoes de superficie contratual em PR |
| `deploy-readiness.yml` | Ownership de release do ciclo | consolidar gate agregado de readiness pre-release |

## Gates bloqueantes para release
Falha em qualquer item abaixo BLOQUEIA release:
1. install deterministico (`pnpm install --frozen-lockfile`)
2. `pnpm test:ci`
3. `pnpm verify:hardening`
4. guardas OpenAPI (`api-contract`, `api-docs`, `api-breaking-change`)
5. `deploy-readiness.yml` verde
6. checklist de evidencia de release preenchido

## Gates de alerta (nao bloqueantes por si so)
Sao alertas operacionais, mas podem escalar para bloqueio se evidenciarem risco real:
1. divergencia documental nao critica sem impacto contratual imediato;
2. ausencia temporaria de evidencia complementar quando os gates tecnicos estao verdes;
3. observacoes de melhoria que nao alteram contrato/runtime.

## Regra de escalonamento
Um alerta vira bloqueante quando:
1. impacta contrato OpenAPI ou surface API;
2. impacta autenticacao/sessao/admin/web em fluxo critico;
3. impede reproducao de checks locais/CI;
4. gera inconsistencias entre relatorio e estado fisico do repositorio.

## Politica de decisao de release
1. release so pode seguir com todos os gates bloqueantes verdes;
2. se houver duvida de classificacao (alerta x bloqueio), prevalece bloqueio;
3. toda excecao precisa de registro formal no relatorio da versao.

## Responsabilidade de atualizacao
Qualquer mudanca em workflow, gate ou script de release exige atualizacao sincronizada em:
1. `infra/ci/CI-MATRIX.md`
2. `infra/ci/LOCAL-TO-CI-MAP.md`
3. `infra/ci/RELEASE-EVIDENCE-CHECKLIST.md`
4. este documento (`WORKFLOW-OWNERSHIP-AND-GATES.md`)

## Registro da rodada
Data:
Executor:
Versao alvo:

Resumo:
1. Workflows verdes:
2. Gates bloqueantes pendentes:
3. Alertas ativos:
4. Decisao final:
