# Local to CI Map — `personal-site`

## Objetivo
Mapear, de forma auditavel, a equivalencia entre validacoes locais e validacoes de pipeline, reduzindo divergencia entre "passa local" e "quebra no CI".

## Fonte de verdade
1. `package.json`
2. `infra/scripts/smoke.sh`
3. `infra/scripts/release-check.sh`
4. `.github/workflows/scaffold-bootstrap.yml`
5. `.github/workflows/api-contract.yml`
6. `.github/workflows/api-docs.yml`
7. `.github/workflows/api-breaking-change.yml`
8. `.github/workflows/deploy-readiness.yml`
9. `QA/QA-02-matriz-de-gates-ci-e-deploy-readiness.md`

## Mapa de equivalencia

| Validacao local | Comando local | Workflow equivalente | Gate(s) relacionado(s) | Resultado esperado |
|---|---|---|---|---|
| Instalacao deterministica | `pnpm install --frozen-lockfile` | `scaffold-bootstrap.yml`, `deploy-readiness.yml`, `api-contract.yml` | G-01 | instalacao sem erro |
| Hardening agregado | `pnpm verify:hardening` | `scaffold-bootstrap.yml`, `deploy-readiness.yml` | G-10 (e suporte G-02..G-09) | build+typecheck completos verdes |
| Testes agregados CI | `pnpm test:ci` | `deploy-readiness.yml` | G-16 (e suporte G-14,G-15) | contratos+api testes verdes |
| Contrato OpenAPI (presenca/chaves) | checagem local por `test -s` + `grep` nos arquivos `APIs/*` | `api-contract.yml` | G-11 | contrato basico valido |
| Docs OpenAPI (core/refs/readme) | checagem local por `grep` em `APIs/*` e `README.md` | `api-docs.yml` | G-12 | docs OpenAPI coerentes |
| Guarda de breaking removals | comparacao local de superficie (manual) | `api-breaking-change.yml` (`pull_request`) | G-13 | sem remocao de superficie contratual |
| Gate de pre-release completo | `bash infra/scripts/release-check.sh` | `deploy-readiness.yml` (`SKIP_SMOKE=1`) | gate agregado de release | test+hardening (e smoke no local) |
| Smoke operacional local | `bash infra/scripts/smoke.sh` | sem equivalente 1:1 (CI pula smoke por design) | suporte aos gates funcionais (G-17..G-20) | endpoints/paginas basicas respondendo |

## Diferencas intencionais local x CI
1. o `smoke.sh` e obrigatorio no local para readiness operacional;
2. no CI, `deploy-readiness.yml` usa `SKIP_SMOKE=1` para evitar dependencia de servicos em runtime local;
3. `api-breaking-change.yml` aplica diff de remocao principalmente em `pull_request`.

## Ordem recomendada de execucao local (pre-PR)
1. `pnpm install --frozen-lockfile`
2. `pnpm test:ci`
3. `pnpm verify:hardening`
4. `bash infra/scripts/smoke.sh`
5. `bash infra/scripts/release-check.sh`

## Criterio de alinhamento
Este mapa esta alinhado quando:
1. comandos locais descritos aqui existem de fato no repositorio;
2. workflows referenciados continuam executando os checks esperados;
3. qualquer mudanca de script/workflow atualiza este documento no mesmo ciclo.
