# Pipeline Failure Playbook — `personal-site`

## Objetivo
Padronizar a resposta operacional para falhas de pipeline sem improviso.

Este playbook define:
1. triagem inicial;
2. classificacao da falha;
3. ordem de investigacao;
4. criterio de bloqueio/liberacao de release.

## Entrada minima para triagem
Antes de agir, coletar:
1. workflow que falhou (`scaffold`, `api-contract`, `api-docs`, `api-breaking-change`, `deploy-readiness`);
2. etapa exata que falhou;
3. mensagem objetiva de erro;
4. commit/PR e branch;
5. se reproduz localmente.

## Classificacao de falhas

### F-01 Infra/ambiente
Exemplos:
- falha de install (`pnpm install --frozen-lockfile`)
- problema de cache/dependencia/plataforma

Acao:
1. validar lockfile e versoes de node/pnpm;
2. reproduzir install local;
3. corrigir divergencia de ambiente antes de seguir.

### F-02 Build/typecheck
Exemplos:
- erro em `pnpm verify:hardening`
- quebra em `build:*` ou `typecheck:*`

Acao:
1. rodar local: `pnpm verify:hardening`;
2. corrigir no menor escopo afetado;
3. rerodar ate verde.

### F-03 Testes
Exemplos:
- falha em `pnpm test:ci`
- testes contracts/api instaveis

Acao:
1. reproduzir local: `pnpm test:ci`;
2. diferenciar flake de regressao real;
3. corrigir e anexar evidencia de reexecucao.

### F-04 Contrato OpenAPI
Exemplos:
- falta de arquivo/chave em `api-contract.yml`
- referencias invalidas em `api-docs.yml`

Acao:
1. validar presenca de `APIs/API-06`, `APIs/API-07`, `schemas.common`, `responses.common`;
2. validar chaves e referencias exigidas;
3. ajustar contrato/docs e rerodar gate.

### F-05 Breaking change contratual
Exemplos:
- `api-breaking-change.yml` detecta remocao de `operationId`, `path+method`, `schemas` ou `responses`

Acao:
1. confirmar se a remocao foi intencional;
2. se nao foi intencional, restaurar superficie removida;
3. se foi intencional, tratar como mudanca de versao e alinhar consumidores/documentacao antes de prosseguir.

### F-06 Smoke/operacao
Exemplos:
- API `/health`/`/ready` fora de 200
- web/admin indisponiveis no smoke local

Acao:
1. validar servicos e portas (`3000/3001/3002`);
2. validar env e logs;
3. corrigir runtime (ex.: cache corrompido) e repetir smoke;
4. sem smoke verde, nao liberar release.

### F-07 Documentacao/gate documental
Exemplos:
- README/API docs desatualizados frente a contrato/workflow

Acao:
1. atualizar documento soberano correspondente;
2. remover divergencia entre repo real e documentacao operacional;
3. rerodar gate.

## Ordem soberana de investigacao
1. identificar categoria (F-01..F-07);
2. reproduzir localmente no comando equivalente;
3. corrigir no menor escopo;
4. reexecutar comando local;
5. reexecutar gate CI;
6. registrar evidencia no relatorio da versao.

## Regras de decisao
Release BLOQUEADO quando houver falha em gate bloqueante:
1. `pnpm test:ci`
2. `pnpm verify:hardening`
3. guardas de contrato/documentacao OpenAPI
4. falha funcional critica no smoke local

Release pode PROSSEGUIR apenas com todos os gates bloqueantes verdes.

## Escalonamento
Escalonar para rollback imediato se:
1. falha critica em producao apos deploy;
2. autenticacao admin quebrada de forma persistente;
3. API publica indisponivel de forma persistente.

Procedimento de rollback: seguir `infra/ops/OPERACAO-E-ROLLBACK.md`.

## Registro minimo de incidente de pipeline
Preencher por falha:
- Data/hora:
- Workflow:
- Etapa:
- Categoria (F-01..F-07):
- Causa raiz:
- Correcao aplicada:
- Evidencia local:
- Evidencia CI:
- Status final:
