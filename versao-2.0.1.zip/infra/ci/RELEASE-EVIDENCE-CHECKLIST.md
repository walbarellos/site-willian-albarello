# Release Evidence Checklist — `personal-site`

## Objetivo
Checklist soberano de evidencias minimas para congelamento de versao, evitando release com falso positivo.

## Regra de uso
1. preencher este checklist no fechamento de cada versao;
2. anexar evidencias objetivas (logs, status de workflow, relatorio da versao);
3. qualquer item bloqueante sem evidencia => release bloqueado.
4. a decisao final deve ser binaria (`LIBERAR` ou `BLOQUEAR`) e coerente com `QA-04`.

## Convencao de bloqueio
- **Bloqueante:** sem conclusao => release bloqueado.
- **Condicional:** pode seguir apenas com justificativa documentada no relatorio final.

## Bloco A — Pre-condicoes
- [x] A-01 `pnpm install --frozen-lockfile` executado sem erro.
- [x] A-02 `.env` valido no ambiente de execucao.
- [x] A-03 Servicos locais acessiveis para smoke (api/web/admin) quando aplicavel. **(BLOQUEANTE)**
- [x] A-04 `bash infra/scripts/runtime-reset.sh` executado antes da rodada final de smoke/release-check. **(BLOQUEANTE)**

Evidencias:
- A-01: dependencia instalada e workspace funcional na rodada v2.0.
- A-02: `.env` presente e utilizado para execucao local.
- A-03: consolidado em rodada final com `smoke` verde (`PASS=10 FAIL=0`) e servicos acessiveis.
- A-04: consolidado em rodada final com execucao de `runtime-reset.sh` antes de smoke/release-check.

## Bloco B — Gates tecnicos locais
- [x] B-01 `pnpm test:ci` verde.
- [x] B-02 `pnpm verify:hardening` verde.
- [x] B-03 `bash infra/scripts/release-check.sh` verde (ou `SKIP_SMOKE=1` apenas no contexto CI). **(BLOQUEANTE)**
- [x] B-04 `bash infra/scripts/smoke.sh` verde para readiness operacional local. **(BLOQUEANTE)**
- [x] B-05 Sem regressao imediata de runtime apos `release-check` (nao voltar a `500` em web/admin). **(BLOQUEANTE)**

Evidencias:
- B-01: executado na rodada v2.0 com sucesso (contracts e API verdes).
- B-02: executado na rodada v2.0 com sucesso (build/typecheck shared/api/web/admin).
- B-03: consolidado em rodada final; `release-check` concluido com sucesso apos ajuste do pre-smoke (`runtime-reset` com restart).
- B-04: consolidado em rodada final com `smoke` verde (`PASS=10 FAIL=0`).
- B-05: consolidado na rodada final sem regressao imediata de `500` apos `release-check`.

## Bloco C — Gates de workflow (CI)
- [x] C-01 `scaffold-bootstrap.yml` verde. **(BLOQUEANTE)**
- [x] C-02 `api-contract.yml` verde. **(BLOQUEANTE)**
- [x] C-03 `api-docs.yml` verde. **(BLOQUEANTE)**
- [x] C-04 `api-breaking-change.yml` verde (especialmente em PR). **(BLOQUEANTE)**
- [x] C-05 `deploy-readiness.yml` verde. **(BLOQUEANTE)**

Evidencias (coleta remota consolidada por `gh run list -R walbarellos/site-willian-albarello` em 2026-04-06):
1. C-01 Scaffold Bootstrap: `success` — run `24015983801` (sha `93427fa`) — https://github.com/walbarellos/site-willian-albarello/actions/runs/24015983801
2. C-02 API Contract: `success` — run `24015906452` (sha `a9a6e64`) — https://github.com/walbarellos/site-willian-albarello/actions/runs/24015906452
3. C-03 API Docs: `success` — run `24015983797` (sha `93427fa`) — https://github.com/walbarellos/site-willian-albarello/actions/runs/24015983797
4. C-04 API Breaking Change: `success` — run `24015983791` (sha `93427fa`) — https://github.com/walbarellos/site-willian-albarello/actions/runs/24015983791
5. C-05 Deploy Readiness: `success` — run `24015983822` (sha `93427fa`) — https://github.com/walbarellos/site-willian-albarello/actions/runs/24015983822

## Bloco D — Gates funcionais e contratuais (QA)
- [x] D-01 `QA-01` atualizado com evidencias de homologacao.
- [x] D-02 `QA-02` atualizado com status dos gates da rodada.
- [x] D-03 Itens criticos `API-*`, `AUTH-*`, `ADM-*`, `PUB-*`, `CT-*` sem FAIL aberto. **(BLOQUEANTE)**
- [x] D-04 `QA-11` atualizado com rastreabilidade completa evidencia -> gate -> decisao. **(BLOQUEANTE)**

Evidencias:
- D-01: `QA-01` atualizado com evidencias reais e sem pendencias criticas.
- D-02: `QA-02` atualizado com G-01..G-20 em VERDE.
- D-03: concluido apos fechamento de ADM-02 com evidencia de browser headless e checklist funcional em PASS.
- D-04: rastreabilidade consolidada no QA-11 com vinculo evidencia -> gate -> decisao.

## Bloco E — Documentacao e rastreabilidade da versao
- [x] E-01 Relatorio final da versao gerado e coerente com estado fisico do repo.
- [x] E-02 ZIP da versao gerado sem `node_modules` e caches de build.
- [x] E-03 Mudancas operacionais refletidas em `infra/` e `infra/ci` quando aplicavel.
- [x] E-04 Handoff de continuidade registrado para o proximo ciclo.
- [x] E-05 `QA-04` reemitido com decisao binaria coerente com este checklist (`LIBERAR` ou `BLOQUEAR`). **(BLOQUEANTE)**

Evidencias:
- E-01: `RELATORIO-FINAL-V2.0.md` atualizado com coleta remota de workflows CI.
- E-02: `versao-2.0.zip` validado sem `node_modules`, `.env` e `.codex`.
- E-03: docs de `infra/ci` e trilha de auditoria QA atualizados.
- E-04: `QA/QA-06-handoff-de-continuidade-v2.0.md` reemitido com estado final.
- E-05: `QA/QA-04-ato-final-de-liberacao-v2.0.md` reemitido com decisao binaria `LIBERAR`.

## Regra de bloqueio
Bloquear release se qualquer item bloqueante estiver pendente.

## Registro da rodada
Data: 2026-04-06
Versao alvo: 2.0
Executor: IA + operador do ciclo
Branch/commit de referencia: `93427fa` (workflows principais) + `a9a6e64` (ultimo verde de API Contract)

Resumo:
1. Itens concluidos:
- A-01..A-04
- B-01..B-05
- C-01..C-05
- D-01..D-04
- E-01..E-05
2. Itens pendentes:
- nenhum
3. Bloqueios:
- nenhum
4. Decisao final (`LIBERAR` / `BLOQUEAR`):
- LIBERAR
