# CI Bootstrap Checklist — `personal-site`

## Objetivo
Checklist soberano para preparar uma nova maquina/ambiente e reproduzir os checks de CI com o menor desvio possivel.

## Pre-requisitos do ambiente
- [ ] Node `>=20.11.0` instalado
- [ ] PNPM `10.x` instalado
- [ ] acesso ao repositorio com `pnpm-lock.yaml` atualizado
- [ ] shell com `bash` e `curl` disponiveis

## Bootstrap inicial
- [ ] Clonar repositorio na branch alvo
- [ ] Executar `pnpm install --frozen-lockfile`
- [ ] Validar que scripts de `infra/scripts` existem e sao executaveis

Comandos de verificacao:
```bash
ls -l infra/scripts/dev-up.sh infra/scripts/smoke.sh infra/scripts/release-check.sh
```

## Validacao tecnica local (ordem obrigatoria)
1. [ ] `pnpm test:ci`
2. [ ] `pnpm verify:hardening`
3. [ ] `bash infra/scripts/release-check.sh`

Observacao:
- no CI, o release-check roda com `SKIP_SMOKE=1`.
- no local, manter smoke ativo para validar readiness operacional.

## Validacao operacional local (quando aplicavel)
- [ ] Subir servicos: `bash infra/scripts/dev-up.sh`
- [ ] Confirmar portas: web `3000`, admin `3001`, api `3002`
- [ ] Rodar smoke: `bash infra/scripts/smoke.sh`
- [ ] Confirmar `PASS` sem `FAIL`

## Alinhamento com workflow
Checklist alinhado com `.github/workflows/deploy-readiness.yml`:
- [ ] install deterministico (`pnpm install --frozen-lockfile`)
- [ ] testes agregados (`pnpm test:ci`)
- [ ] hardening (`pnpm verify:hardening`)
- [ ] gate agregado (`SKIP_SMOKE=1 bash infra/scripts/release-check.sh`)

## Diagnostico rapido de falha
Se algum passo falhar:
1. classificar falha (infra/build/typecheck/test/contrato/smoke/docs)
2. reproduzir no comando local equivalente
3. corrigir no menor escopo
4. reexecutar do passo que falhou para frente
5. registrar evidencia no relatorio da versao

Referencia: `infra/ci/PIPELINE-FAILURE-PLAYBOOK.md`.

## Evidencias minimas a registrar
- [ ] comando executado
- [ ] resultado (`PASS`/`FAIL`)
- [ ] trecho objetivo de log
- [ ] data/hora e ambiente

## Registro da rodada
Data:
Ambiente:
Executor:
Versao/branch:

Resumo:
1. Passos concluidos:
2. Falhas encontradas:
3. Correcao aplicada:
4. Status final (`APROVADO`/`BLOQUEADO`):
