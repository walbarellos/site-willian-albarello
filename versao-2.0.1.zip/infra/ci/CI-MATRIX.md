# CI Matrix — Workflows, Gates e Evidencias

## Objetivo
Consolidar, em uma unica matriz, o papel operacional de cada workflow do repositorio e sua relacao com os gates de qualidade/deploy readiness.

## Fonte de verdade
1. `.github/workflows/scaffold-bootstrap.yml`
2. `.github/workflows/api-contract.yml`
3. `.github/workflows/api-docs.yml`
4. `.github/workflows/api-breaking-change.yml`
5. `.github/workflows/deploy-readiness.yml`
6. `QA/QA-02-matriz-de-gates-ci-e-deploy-readiness.md`

## Matriz operacional

| Workflow | Objetivo | Gatilho principal | Comandos/checagens centrais | Gates cobertos (QA-02) | Saida esperada |
|---|---|---|---|---|---|
| `scaffold-bootstrap.yml` | Garantir bootstrap tecnico minimo do monorepo | `push` em `main/master`, `pull_request` | `pnpm install --frozen-lockfile`; `pnpm run verify:hardening` | G-01, G-10 | install e hardening verdes |
| `api-contract.yml` | Proteger presenca/estrutura basica dos contratos OpenAPI e pacote contracts | `push/pull_request` com mudancas em `APIs/**`, `packages/contracts/**` | validacao de presenca de arquivos OpenAPI/components; `grep` de chaves; build/typecheck de `@william-albarello/contracts` | G-11 (e suporte tecnico aos contratos) | contrato basico consistente e pacote contracts compilando |
| `api-docs.yml` | Validar consistencia documental minima de OpenAPI + referencias no README | `push/pull_request` com mudancas em `APIs/**`, workflow e `README.md` | validacao de presenca; `openapi/info/paths`; refs para componentes compartilhados; mencoes no `README.md` | G-12 | documentacao contratual coerente e referenciada |
| `api-breaking-change.yml` | Bloquear remocoes de superficie contratual em PR | `pull_request` (diff contra base) e `push` de presenca | validacao de presenca; comparacao contra branch base para remocao de `operationId`, `path+method`, `schemas`, `responses` | G-13 | sem breaking removals em PR |
| `deploy-readiness.yml` | Gate agregado de readiness para release | `push/pull_request` com mudancas em apps/packages/infra/QA/workflows/config | `pnpm install --frozen-lockfile`; `pnpm test:ci`; `pnpm verify:hardening`; `SKIP_SMOKE=1 bash infra/scripts/release-check.sh` | G-01, G-10, G-16 e gate agregado de release | readiness tecnico agregado verde |

## Observacoes de auditoria
1. `deploy-readiness.yml` e o gate agregado mais proximo de congelamento de versao.
2. `api-breaking-change.yml` so executa comparacao de remocao no contexto de `pull_request`.
3. `api-contract.yml` e `api-docs.yml` cobrem contrato/docs de API, mas nao substituem testes funcionais/homologacao.
4. a declaracao de deploy readiness continua condicionada aos gates obrigatorios em `QA/QA-02`.

## Critico para release
Para liberar versao sem desvio de processo:
1. workflows verdes na PR/branch alvo;
2. `pnpm test:ci` verde local;
3. `pnpm verify:hardening` verde local;
4. evidencias registradas no relatorio da versao.
