# Environment Matrix — `personal-site`

## Objetivo

Matriz soberana de variáveis de ambiente do monorepo, estritamente aderente ao código atual.

Escopos cobertos:

- `apps/api`
- `apps/web`
- `apps/admin`
- ambientes `development`, `staging`, `production` (e observação de `test` quando aplicável)

Fontes auditadas:

- `.env.example`
- `apps/api/src/lib/env.ts`
- `apps/api/src/lib/admin-auth.ts`
- `apps/api/src/test-utils/setup-env.ts`
- `apps/web/src/lib/api/public.ts`
- `apps/admin/src/lib/api/admin.ts`
- `apps/web/app/{layout,page,publicacoes/[slug]/page,robots,sitemap}.ts`
- `apps/admin/app/layout.tsx`

## Regras de leitura

1. `Obrigatória` significa necessária para o runtime daquele ambiente.
2. `Fallback` significa valor padrão no código se a variável não existir.
3. Em produção, variáveis sensíveis devem ser segredos reais (nunca valores de exemplo).

## Matriz principal

| Variável | Apps que usam | Development | Staging | Production | Fallback / Observação |
|---|---|---|---|---|---|
| `NODE_ENV` | api | opcional | obrigatória | obrigatória | API assume `development` se ausente |
| `PORT` | api | opcional | obrigatória | obrigatória | fallback `3002` só em `development` |
| `SESSION_SECRET` | api | obrigatória (mín. 16) | obrigatória | obrigatória (mín. 32) | em `production` não pode usar default de dev |
| `DATABASE_URL` | api | obrigatória | obrigatória | obrigatória | fallback local só em `development` |
| `PUBLIC_SITE_URL` | api | obrigatória | obrigatória | obrigatória | URL absoluta `http/https` |
| `ADMIN_SITE_URL` | api | obrigatória | obrigatória | obrigatória | URL absoluta `http/https` |
| `CORS_ORIGINS` | api | opcional | obrigatória | obrigatória | em dev deriva de `PUBLIC_SITE_URL,ADMIN_SITE_URL`; fora de dev é obrigatório explícito |
| `ADMIN_BOOTSTRAP_EMAIL` | api | opcional | recomendada | obrigatória | em produção ausência derruba bootstrap (`fail-closed`) |
| `ADMIN_BOOTSTRAP_PASSWORD` | api | opcional | recomendada | obrigatória | em produção ausência derruba bootstrap (`fail-closed`) |
| `ADMIN_BOOTSTRAP_DISPLAY_NAME` | api | opcional | opcional | opcional | default `Administrador` |
| `ADMIN_BOOTSTRAP_ROLE` | api | opcional | opcional | opcional | `admin` ou `editor`; default `admin`; inválido gera erro |
| `NEXT_PUBLIC_SITE_URL` | web | recomendada | obrigatória | obrigatória | fallback local `http://localhost:3000` para metadata/canonical |
| `NEXT_PUBLIC_API_URL` | web, admin | recomendada | recomendada | recomendada | prioridade 1 para base da API em web/admin |
| `PUBLIC_API_URL` | web | opcional | opcional | opcional | prioridade 2 da API no web |
| `ADMIN_API_URL` | admin | opcional | opcional | opcional | prioridade 2 da API no admin |
| `API_URL` | web, admin | opcional | opcional | opcional | prioridade 3 em web/admin; fallback final `http://localhost:3002` |
| `NEXT_PUBLIC_ADMIN_URL` | admin | recomendada | obrigatória | obrigatória | fallback local `http://localhost:3001` para metadata/canonical admin |

## Ordem de resolução por aplicação

### Web (`apps/web`)

Base da API pública (`resolvePublicApiBaseUrl`):

1. `NEXT_PUBLIC_API_URL`
2. `PUBLIC_API_URL`
3. `API_URL`
4. fallback `http://localhost:3002`

URL pública base do site:

- `NEXT_PUBLIC_SITE_URL` (fallback local `http://localhost:3000`)

### Admin (`apps/admin`)

Base da API admin (`resolveAdminApiBaseUrl`):

1. `NEXT_PUBLIC_API_URL`
2. `ADMIN_API_URL`
3. `API_URL`
4. fallback `http://localhost:3002`

URL base do admin:

- `NEXT_PUBLIC_ADMIN_URL` (fallback local `http://localhost:3001`)

### API (`apps/api`)

Loader central:

- `apps/api/src/lib/env.ts`

Bootstrap admin:

- `apps/api/src/lib/admin-auth.ts`
- em produção, `ADMIN_BOOTSTRAP_EMAIL` e `ADMIN_BOOTSTRAP_PASSWORD` ausentes causam erro de inicialização.

## Matriz por ambiente (resumo operacional)

### Development

Mínimo recomendado:

- `NODE_ENV=development`
- `PORT`
- `SESSION_SECRET`
- `DATABASE_URL`
- `PUBLIC_SITE_URL`
- `ADMIN_SITE_URL`
- `NEXT_PUBLIC_SITE_URL`
- `NEXT_PUBLIC_ADMIN_URL`
- uma das URLs de API para web/admin (`NEXT_PUBLIC_API_URL` recomendado)

### Staging

Obrigatório:

- tudo do backend (`NODE_ENV`, `PORT`, `SESSION_SECRET`, `DATABASE_URL`, `PUBLIC_SITE_URL`, `ADMIN_SITE_URL`, `CORS_ORIGINS`)
- URLs públicas reais de staging (`NEXT_PUBLIC_SITE_URL`, `NEXT_PUBLIC_ADMIN_URL`)
- URL de API para web/admin (`NEXT_PUBLIC_API_URL` recomendado)

Recomendado:

- definir bootstrap admin explicitamente (`ADMIN_BOOTSTRAP_*`) para evitar ambiguidade.

### Production

Obrigatório:

- todas as variáveis do backend sem defaults de desenvolvimento
- `SESSION_SECRET` forte (mín. 32)
- `CORS_ORIGINS` explícito
- `ADMIN_BOOTSTRAP_EMAIL` e `ADMIN_BOOTSTRAP_PASSWORD`
- URLs canônicas reais (`NEXT_PUBLIC_SITE_URL`, `NEXT_PUBLIC_ADMIN_URL`)
- URL de API consumida por web/admin (`NEXT_PUBLIC_API_URL` recomendado)

## Ambiente de teste (observação)

`apps/api/src/test-utils/setup-env.ts` define defaults para testes da API:

- `NODE_ENV=test`
- `PORT=3002`
- `SESSION_SECRET` de teste
- `DATABASE_URL` de teste
- `PUBLIC_SITE_URL` e `ADMIN_SITE_URL` locais
- `CORS_ORIGINS` local

Esses valores são para suíte de testes, não para staging/production.

## Política de segurança para env

1. nunca versionar `.env` com segredos reais;
2. versionar apenas arquivos `*.example`;
3. separar segredos por ambiente/plataforma (Vercel/Render);
4. manter esta matriz sincronizada sempre que uma variável nova entrar no código.
