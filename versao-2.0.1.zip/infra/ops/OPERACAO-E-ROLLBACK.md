# Operação e Rollback — `personal-site`

## Objetivo

Runbook soberano para operação do projeto:

1. subir ambiente local;
2. validar estado mínimo funcional;
3. executar gate de pré-release;
4. orientar publicação;
5. executar rollback quando necessário.
6. responder a instabilidade operacional intermitente (`500`) sem falso positivo.

Este documento é operacional e aderente ao estado atual dos scripts em `infra/scripts/`.

## Pré-requisitos

1. `pnpm` disponível;
2. `.env` local válido na raiz (derivado de `.env.example`);
3. dependências instaladas:

```bash
pnpm install --frozen-lockfile
```

4. permissões de execução nos scripts:

```bash
chmod +x infra/scripts/*.sh
```

## Saneamento operacional pré-start (novo padrão)

Antes de subir o ambiente, executar saneamento:

```bash
bash infra/scripts/runtime-reset.sh
```

Uso recomendado com restart automático:

```bash
START_SERVICES=1 bash infra/scripts/runtime-reset.sh
```

Quando houver suspeita de cache local inconsistente (`web/admin`):

```bash
RESET_NEXT=1 START_SERVICES=1 bash infra/scripts/runtime-reset.sh
```

Esse script:

1. encerra processos antigos `pnpm dev:*`;
2. encerra listeners residuais nas portas `3000/3001/3002`;
3. limpa logs de `.tmp/dev-up`;
4. opcionalmente limpa `.next` de `apps/web` e `apps/admin`;
5. opcionalmente reinicia o stack completo.

## Subida local (ambiente completo)

Comando recomendado:

```bash
bash infra/scripts/dev-up.sh
```

O `dev-up` atual já executa saneamento pré-start automaticamente (`AUTO_RESET=1`).

Para desativar esse comportamento em depuração específica:

```bash
AUTO_RESET=0 bash infra/scripts/dev-up.sh
```

Para forçar limpeza de `.next` na subida:

```bash
RESET_NEXT=1 bash infra/scripts/dev-up.sh
```

Comportamento esperado:

1. sobe `api`, `web` e `admin` em paralelo;
2. URLs ativas:
   - `http://localhost:3000` (web)
   - `http://localhost:3001` (admin)
   - `http://localhost:3002` (api)
3. logs em `.tmp/dev-up/`;
4. encerramento por `Ctrl+C`.

## Validação operacional rápida (smoke)

Executar:

```bash
bash infra/scripts/smoke.sh
```

Parâmetros padrão atuais do smoke:

1. `WARMUP_SECONDS=2`
2. `RETRIES=3`
3. `RETRY_DELAY_SECONDS=1`

Exemplo com aquecimento maior:

```bash
WARMUP_SECONDS=4 RETRIES=4 RETRY_DELAY_SECONDS=1 bash infra/scripts/smoke.sh
```

Cobertura mínima:

1. API `/health`
2. API `/ready`
3. Web `/`
4. Web `/publicacoes`
5. Admin `/painel/login`

Critério:

- `FAIL=0` para considerar o ambiente utilizável.

## Gate local de pré-release

Executar:

```bash
bash infra/scripts/release-check.sh
```

Pipeline executada:

1. `pnpm test:ci`
2. `pnpm verify:hardening`
3. `infra/scripts/runtime-reset.sh` (pré-smoke, por padrão)
4. `infra/scripts/smoke.sh`

Parâmetros úteis:

```bash
USE_RUNTIME_RESET=1 RESET_NEXT=0 bash infra/scripts/release-check.sh
```

```bash
USE_RUNTIME_RESET=1 RESET_NEXT=1 WARMUP_SECONDS=4 RETRIES=4 bash infra/scripts/release-check.sh
```

Modo CI (sem smoke HTTP):

```bash
SKIP_SMOKE=1 bash infra/scripts/release-check.sh
```

## Publicação (fluxo recomendado)

1. garantir branch em estado estável;
2. executar `release-check.sh` com sucesso;
3. abrir PR com evidências dos gates;
4. validar workflows de CI;
5. publicar serviços por plataforma:
   - `apps/web` na Vercel
   - `apps/admin` na Vercel
   - `apps/api` no Render
6. executar smoke pós-deploy.

Referências:

- `infra/vercel/web.project.md`
- `infra/vercel/admin.project.md`
- `infra/render/api.service.yaml`

## Rollback (procedimento padrão)

### Quando acionar

Acionar rollback se ocorrer:

1. falha funcional crítica pós-deploy;
2. quebra de autenticação/sessão no admin;
3. indisponibilidade persistente de API pública;
4. regressão que impeça uso básico do site.

### Procedimento

1. identificar último deploy saudável (Vercel/Render);
2. promover redeploy da revisão estável;
3. executar smoke checks mínimos;
4. confirmar restauração de serviço;
5. registrar incidente e causa raiz;
6. bloquear nova publicação até correção.

## Protocolo de resposta a `500` intermitente (web/admin)

### Sintoma típico

1. `smoke` alterna entre janela verde e regressão;
2. `GET /` em `web` ou `GET /painel/login` em `admin` retorna `500` após restart parcial;
3. `test:ci` e `verify:hardening` passam, mas runtime não estabiliza.

### Procedimento obrigatório

1. executar saneamento sem restart:

```bash
bash infra/scripts/runtime-reset.sh
```

2. subir stack limpo:

```bash
bash infra/scripts/dev-up.sh
```

3. validar smoke:

```bash
bash infra/scripts/smoke.sh
```

4. executar gate final:

```bash
bash infra/scripts/release-check.sh
```

5. se houver nova regressão `500`, repetir com limpeza de cache:

```bash
RESET_NEXT=1 bash infra/scripts/dev-up.sh
```

6. se persistir, manter decisão `BLOQUEAR` e registrar em:
   - `QA/QA-08-registro-de-evidencias-de-execucao-v2.0.md`
   - `QA/QA-13-diagnostico-operacional-runtime-500-v2.0.md`

## Falhas típicas e resposta

### 1) API indisponível

Sinais:

- `/health` e `/ready` fora de `200`.

Ações:

1. revisar env no serviço da API;
2. verificar logs de boot;
3. rollback imediato se indisponibilidade persistir.

### 2) Login admin quebrado

Sinais:

- erro 401/403 contínuo após credencial válida.

Ações:

1. conferir `NEXT_PUBLIC_API_URL` no admin;
2. conferir `CORS_ORIGINS`, `ADMIN_SITE_URL` e cookies na API;
3. rollback se impedir operação editorial.

### 3) Web sem conteúdo público

Sinais:

- home/listagem sem dados por falha de integração.

Ações:

1. conferir `NEXT_PUBLIC_API_URL` e saúde da API;
2. validar endpoints públicos;
3. rollback se experiência pública ficar indisponível.

## Registro de execução (preencher por rodada)

Data:
Ambiente:
Executor:
Commit/Tag:

Resultados:

1. `dev-up`:
2. `smoke`:
3. `release-check`:
4. decisão (`seguir deploy` / `bloquear`):
5. observações:

## Referências soberanas

- `README.md`
- `apps/api/README.md`
- `apps/web/README.md`
- `apps/admin/README.md`
- `QA/QA-01-checklist-de-homologacao-funcional.md`
- `QA/QA-02-matriz-de-gates-ci-e-deploy-readiness.md`
- `infra/scripts/dev-up.sh`
- `infra/scripts/runtime-reset.sh`
- `infra/scripts/smoke.sh`
- `infra/scripts/release-check.sh`
