# QA-11 — Matriz de Rastreabilidade das Evidencias v2.0

## 1. Objetivo
Mapear, de forma direta e auditavel, a relacao entre:
1. requisito de fechamento da versao;
2. evidencia existente;
3. gate relacionado;
4. documento soberano que registra a prova;
5. status atual (concluido ou pendente).

## 2. Fontes soberanas
1. `QA/QA-01-checklist-de-homologacao-funcional.md`
2. `QA/QA-02-matriz-de-gates-ci-e-deploy-readiness.md`
3. `QA/QA-03-auditoria-consolidada-final.md`
4. `QA/QA-04-ato-final-de-liberacao-v2.0.md`
5. `QA/QA-08-registro-de-evidencias-de-execucao-v2.0.md`
6. `QA/QA-13-diagnostico-operacional-runtime-500-v2.0.md`
7. `infra/ci/RELEASE-EVIDENCE-CHECKLIST.md`
8. `RELATORIO-FINAL-V2.0.md`

## 3. Matriz de rastreabilidade

| Bloco | Item | Gate relacionado | Evidencia existente | Documento de prova | Status |
|---|---|---|---|---|---|
| Tecnico | `pnpm test:ci` | B-01 | executado com sucesso | `RELATORIO-FINAL-V2.0.md`, `QA-08` | CONCLUIDO |
| Tecnico | `pnpm verify:hardening` | B-02 | executado com sucesso | `RELATORIO-FINAL-V2.0.md`, `QA-08` | CONCLUIDO |
| Tecnico | `runtime-reset` pre-smoke | A-04 | execucao final consolidada antes de smoke/release-check | `infra/ci/RELEASE-EVIDENCE-CHECKLIST.md`, `QA-08` | CONCLUIDO |
| Documental | `04-High_Tech 20/20` | E-01 | preenchido, zero vazios | `RELATORIO-FINAL-V2.0.md`, `QA-03` | CONCLUIDO |
| Funcional API | API-01 | G-17 / D-03 | evidenciado com 200 + traceId | `QA-01`, `QA-08` | CONCLUIDO |
| Funcional API | API-02 | G-17 / D-03 | evidenciado com 200 + ready=true | `QA-01`, `QA-08` | CONCLUIDO |
| Funcional API | API-03 | G-17 / D-03 | evidenciado por teste dedicado de degradacao bloqueante (`/ready` => 503) | `QA-01`, `QA-08`, `apps/api/src/routes/health.test.ts` | CONCLUIDO |
| Funcional API | API-04 | G-17 / D-03 | evidenciado com 404 + NOT_FOUND | `QA-01`, `QA-08` | CONCLUIDO |
| Funcional Auth | AUTH-01..AUTH-06 | G-18 / D-03 | todos evidenciados em PASS | `QA-01`, `QA-08` | CONCLUIDO |
| Funcional Admin | ADM-01..ADM-05 | G-18 / D-03 | todos em PASS; `ADM-02` fechado com navegador headless (submit + redirect) | `QA-01`, `QA-08`, `QA-09` | CONCLUIDO |
| Funcional Web | PUB-01..PUB-05 | G-19 / D-03 | todos evidenciados em PASS com status HTTP objetivo | `QA-01`, `QA-08`, `QA-09` | CONCLUIDO |
| Contrato | CT-01 e CT-02 | G-20 / D-03 | evidenciados em PASS com traceId | `QA-01`, `QA-08` | CONCLUIDO |
| Gates | G-01..G-16 | G-01..G-16 | atualizados para VERDE | `QA-02` | CONCLUIDO |
| Gates | G-17..G-19 | G-17..G-19 | G-17, G-18 e G-19 em VERDE | `QA-02`, `QA-03` | CONCLUIDO |
| Checklist release | B-03/B-04/B-05 | B-03/B-04/B-05 | rodada final verde em `smoke` e `release-check` sem regressao imediata | `infra/ci/RELEASE-EVIDENCE-CHECKLIST.md`, `QA-08`, `QA-13` | CONCLUIDO |
| Checklist release | C-01..C-05 | C-01..C-05 | sem coleta de status remoto nesta rodada | `infra/ci/RELEASE-EVIDENCE-CHECKLIST.md`, `QA-05` | PENDENTE |
| Checklist release | D-04 | D-04 | rastreabilidade consolidada nesta matriz com vinculo evidencia -> gate -> decisao | `infra/ci/RELEASE-EVIDENCE-CHECKLIST.md`, `QA-11` | CONCLUIDO |
| Governanca | decisao final da rodada | E-05 | ato final reemitido com decisao binaria `BLOQUEAR` | `QA-04`, `infra/ci/RELEASE-EVIDENCE-CHECKLIST.md` | CONCLUIDO |

## 4. Leitura executiva da matriz
1. trilha tecnica principal esta fechada;
2. trilha funcional esta fechada (API/Auth/Admin/Web/CT em PASS);
3. trilha de release permanece bloqueada apenas por pendencias objetivas de workflow CI (C-01..C-05);
4. rastreabilidade final esta consolidada (`D-04`) e a decisao formal ja foi reemitida (`E-05`).

## 5. Criterio para virar status geral para LIBERAR
1. zerar todos os `PENDENTE` da matriz;
2. atualizar `QA-02` para 100% VERDE;
3. atualizar checklist de release sem bloqueios;
4. reemitir `QA-04` para `LIBERAR` quando os bloqueios remanescentes forem efetivamente zerados.

## 6. Conclusao
Esta matriz confirma que o bloqueio atual e coerente com as evidencias existentes. A liberacao final depende da execucao disciplinada das pendencias ja identificadas, sem necessidade de reabrir arquitetura ou ciclos estruturais.
