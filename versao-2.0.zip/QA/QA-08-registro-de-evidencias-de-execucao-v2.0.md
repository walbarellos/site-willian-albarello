# QA-08 — Registro de Evidencias de Execucao v2.0

## 1. Objetivo
Consolidar, em formato auditavel, os comandos efetivamente executados na rodada v2.0 para validacao tecnica e homologacao funcional parcial.

## 2. Escopo
Inclui apenas evidencias reais coletadas nesta rodada.

Nao inclui:
1. evidencias inferidas;
2. comandos nao executados;
3. status de workflow remoto sem coleta explicita.

## 3. Evidencias tecnicas gerais

## 3.0 Saneamento operacional (protocolo v2.0)
Comando de referencia da rodada final:
```bash
bash infra/scripts/runtime-reset.sh
```
Status:
1. protocolo incorporado como precondicao obrigatoria antes de `smoke` e `release-check`;
2. evidencia final consolidada: `runtime-reset` executado antes da rodada de validacao final.

## 3.1 Testes agregados
Comando executado:
```bash
pnpm test:ci
```
Resultado:
1. sucesso (exit 0);
2. contracts verdes;
3. API verde.

## 3.2 Hardening integrado
Comando executado:
```bash
pnpm verify:hardening
```
Resultado:
1. sucesso (exit 0);
2. build/typecheck de shared/api/web/admin concluido sem erro.

## 4. Evidencias HTTP coletadas (API/Contrato/Auth)

## 4.1 Health e Ready
Comandos executados:
```bash
curl -sS -D - http://127.0.0.1:3002/health
curl -sS -D - http://127.0.0.1:3002/ready
```
Resultados:
1. `/health` -> HTTP 200, `data.status=ok`, `meta.traceId=6f4179e2-64ea-45d1-ba9f-884f45c9480a`;
2. `/ready` -> HTTP 200, `data.ready=true`, `meta.traceId=ed4ebeb9-a8e3-4bf1-9c5a-9cd6689fd170`.

## 4.2 Envelope de erro padrao
Comando executado:
```bash
curl -sS -D - http://127.0.0.1:3002/rota-inexistente
```
Resultado:
1. HTTP 404;
2. `error.code=NOT_FOUND`;
3. `meta.traceId=9b5b9689-00ec-4209-b360-fcd275672407`.

## 4.3 Auth — payload invalido
Comando executado:
```bash
curl -sS -D - -H 'content-type: application/json' \
  -X POST http://127.0.0.1:3002/v1/admin/auth/login \
  -d '{"email":"x","password":"1"}'
```
Resultado:
1. HTTP 422;
2. `error.code=VALIDATION_ERROR`;
3. `meta.traceId=53750f4b-077d-4f0f-abaf-4195d83a56e8`.

## 4.4 Auth — credencial invalida
Comando executado:
```bash
curl -sS -D - -H 'content-type: application/json' \
  -X POST http://127.0.0.1:3002/v1/admin/auth/login \
  -d '{"email":"admin@local.test","password":"WrongPass123!"}'
```
Resultado:
1. HTTP 401;
2. `error.code=UNAUTHENTICATED`;
3. `meta.traceId=a07b5dd3-18fd-45ac-9823-3e8192886ccd`.

## 4.5 Auth — login valido + sessao + logout
Comandos executados:
```bash
# login com cookie jar
curl -sS -D - -c /tmp/qa01_cookie.txt -H 'content-type: application/json' \
  -X POST http://127.0.0.1:3002/v1/admin/auth/login \
  -d '{"email":"admin@local.test","password":"ChangeMe123!"}'

# sessao com cookie
curl -sS -D - -b /tmp/qa01_cookie.txt http://127.0.0.1:3002/v1/admin/auth/session

# sessao sem cookie
curl -sS -D - http://127.0.0.1:3002/v1/admin/auth/session

# logout com e sem cookie
curl -sS -D - -b /tmp/qa01_cookie.txt -X POST http://127.0.0.1:3002/v1/admin/auth/logout
curl -sS -D - -X POST http://127.0.0.1:3002/v1/admin/auth/logout
```
Resultados:
1. login valido -> HTTP 200, usuario bootstrap retornado, `traceId=a81683f6-1b3c-4778-bf5a-30c461d553c9`;
2. sessao ativa -> HTTP 200, `traceId=e5bf9ae2-b33c-41fa-b96e-43bea7933fe3`;
3. sessao ausente -> HTTP 401 `SESSION_EXPIRED`, `traceId=73669a14-899e-44a8-9d5a-bf6c980b43b1`;
4. logout com cookie -> HTTP 200, `success=true`, `traceId=563ef627-767b-4c5f-a6e3-c0d6685a5018`;
5. logout sem cookie -> HTTP 200, `success=true`, `traceId=7623ce8e-40c6-4ccb-ad26-a3be47bffa29`.

## 4.6 Contrato — query invalida em listagem publica
Comando executado:
```bash
curl -sS -D - 'http://127.0.0.1:3002/v1/public/publications?page=abc'
```
Resultado:
1. HTTP 422;
2. `error.code=VALIDATION_ERROR`;
3. `meta.traceId=30ee37a7-7960-4342-a15f-678174529823`.

## 5. Atualizacoes documentais realizadas com base nas evidencias
1. `QA-01` atualizado com PASS real para API-01..API-04 (incluindo API-03 por teste dedicado), AUTH-01..AUTH-06, ADM-01..ADM-05, PUB-01..PUB-05 e CT-01/CT-02;
2. `QA-02` atualizado com G-01..G-20 em VERDE;
3. `RELEASE-EVIDENCE-CHECKLIST` preenchido com estado real e decisao `BLOQUEAR`;
4. `QA-04` emitido com decisao formal bloqueada;
5. `QA-05` e `QA-06` criados para fechamento da continuidade.

## 5.1 Evidencias adicionais da rodada (gates locais)
Comandos executados:
```bash
bash infra/scripts/smoke.sh
bash infra/scripts/release-check.sh
```
Resultados:
1. `smoke.sh` (execucao direta inicial) -> `PASS=4 FAIL=3`, com falhas `500` em:
- `http://localhost:3000/`
- `http://localhost:3000/publicacoes`
- `http://localhost:3001/painel/login`
2. apos saneamento operacional (restart limpo), `smoke.sh` -> `PASS=10 FAIL=0`.
3. `release-check.sh` reexecutado com rede liberada:
- `test:ci` verde;
- `verify:hardening` verde;
- etapa final de smoke regressou para `PASS=4 FAIL=3` com retorno a `500` em web/admin.
4. rodada final apos ajuste do `release-check`:
- `runtime-reset` executado com restart pre-smoke;
- `smoke.sh` verde (`PASS=10 FAIL=0`);
- `release-check.sh` verde completo (`test:ci` + `verify:hardening` + smoke final verde);
- sem regressao imediata de `500` nas rotas basicas (`/`, `/publicacoes`, `/painel/login`).

## 5.2 Matriz de rastreabilidade da evidencia desta rodada
1. Evidencias funcionais consolidadas em `QA-01`.
2. Estados de gate consolidados em `QA-02`.
3. Checklist de bloqueio/liberacao consolidado em `infra/ci/RELEASE-EVIDENCE-CHECKLIST.md`.
4. Diagnostico operacional consolidado em `QA-13`.
5. Decisao formal reemitida em `QA-04` com status binario coerente.

## 5.3 Evidencia funcional complementar (rodada final)
Resumo objetivo:
1. login administrativo via API: HTTP 200 (`traceId=ebf40567-4e26-4af4-832b-cbe2f3885873`);
2. API-03 validado por teste dedicado de `health.test.ts` (cenário bloqueante `/ready` => 503);
3. ADM-03: listagem administrativa com sessão autenticada em HTTP 200;
4. ADM-04: edição `PATCH /v1/admin/publications/pub-001` em HTTP 200 (`traceId=a3ca6d87-b1fd-4864-a9da-c2fb4b0651e4`);
5. ADM-05: transição `PATCH /v1/admin/publications/pub-001/status` para `archived` em HTTP 200 (`traceId=ac872ac3-4125-4a2f-ba9e-be8d01ca8646`);
6. PUB-03: listagem com querystring em HTTP 200;
7. PUB-04: detalhe por slug válido em HTTP 200;
8. PUB-05: slug inválido retornando HTTP 404 sem crash.
9. ADM-02: validação de browser real headless (Playwright) com submit de login em `/painel/login?next=%2Fpainel%2Fpublicacoes` e URL final `http://localhost:3001/painel/publicacoes`.

## 6. Pendencias sem evidencia nesta rodada
1. coleta de status dos workflows CI (C-01..C-05).

## 6.1 Tentativa objetiva de coleta dos workflows C-01..C-05
Comandos/tentativas executadas:
```bash
gh --version && gh auth status
curl -sS https://github.com/walbarellos/personal-site/actions/workflows/scaffold-bootstrap.yml/badge.svg?branch=main
curl -sS https://github.com/walbarellos/personal-site/actions/workflows/api-contract.yml/badge.svg?branch=main
curl -sS https://github.com/walbarellos/personal-site/actions/workflows/api-docs.yml/badge.svg?branch=main
curl -sS https://github.com/walbarellos/personal-site/actions/workflows/api-breaking-change.yml/badge.svg?branch=main
curl -sS https://github.com/walbarellos/personal-site/actions/workflows/deploy-readiness.yml/badge.svg?branch=main
```

Resultado:
1. `gh` indisponivel no ambiente (`command not found`);
2. os 5 endpoints de badge retornaram `Not Found`;
3. status remoto de workflows nao pode ser atestado nesta rodada local.

Conclusao:
- `C-01..C-05` permanecem pendentes por ausencia de evidência remota coletável no ambiente atual.

## 7. Conclusao objetiva
A rodada v2.0 possui evidencia tecnica robusta, incluindo estabilizacao operacional validada na rodada final e fechamento da trilha funcional crítica. A decisao permanece `BLOQUEAR` neste momento apenas pela pendencia residual de coleta de status dos workflows CI `C-01..C-05`.
