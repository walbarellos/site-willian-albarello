# QA-01 — Checklist de Homologação Funcional

## 1. Objetivo
Este checklist transforma o estado esperado de runtime em validação operacional reproduzível para `api`, `web` e `admin` no monorepo `personal-site`.

Este documento é de execução.
Cada item deve ser marcado com evidência objetiva.

## 2. Escopo desta homologação
Abrange:
1. saúde da API (`/health`, `/ready`)
2. autenticação e sessão administrativa
3. fluxo editorial mínimo no painel
4. fluxo público de leitura (home, listagem e detalhe)
5. coerência de envelope HTTP (`meta.traceId`, erros padronizados)

Não abrange:
1. testes de carga/performance
2. pentest completo
3. validação cross-browser extensiva

## 3. Pré-condições obrigatórias
1. Dependências instaladas: `pnpm install`
2. Ambiente configurado com `.env` válido na raiz
3. API rodando em `http://localhost:3002`
4. Web rodando em `http://localhost:3000`
5. Admin rodando em `http://localhost:3001`
6. Build/typecheck verdes no mínimo para estado local de verificação

## 4. Dados mínimos para execução
1. usuário bootstrap disponível na API (`admin@local.test` / `ChangeMe123!` em ambiente local padrão)
2. pelo menos uma publicação disponível na listagem pública
3. pelo menos uma publicação disponível na listagem administrativa para edição/transição

## 5. Padrão de evidência
Para cada item executado, registrar:
1. data/hora
2. ambiente (`local`, `staging`, etc.)
3. resultado (`PASS` ou `FAIL`)
4. evidência curta (ex.: resposta HTTP, screenshot, log)
5. `traceId` quando aplicável
6. comando/passo executado para reprodução

## 6. Checklist funcional (execução)

| ID | Domínio | Cenário | Passos objetivos | Critério de aceite | Evidência | Status |
|---|---|---|---|---|---|---|
| API-01 | API | Health | `GET /health` | HTTP 200 + JSON com `data.status=ok` e `meta.traceId` | 2026-04-05 local: 200 OK, `traceId=6f4179e2-64ea-45d1-ba9f-884f45c9480a` | PASS |
| API-02 | API | Ready saudável | `GET /ready` sem dependência bloqueante falhando | HTTP 200 + `data.ready=true` + `meta.traceId` | 2026-04-05 local: 200 OK, `traceId=ed4ebeb9-a8e3-4bf1-9c5a-9cd6689fd170` | PASS |
| API-03 | API | Ready degradado bloqueante | forçar falha bloqueante de dependência e chamar `/ready` | HTTP 503 + `error.code=SERVICE_UNAVAILABLE` + `meta.traceId` | 2026-04-05 local: evidenciado em teste automatizado `apps/api/src/routes/health.test.ts` (caso `returns 503 on /ready when blocking dependency fails`) | PASS |
| API-04 | API | Envelope de erro | chamar rota inválida `GET /rota-inexistente` | HTTP 404 + `error.code=NOT_FOUND` + `meta.traceId` | 2026-04-05 local: 404, `code=NOT_FOUND`, `traceId=9b5b9689-00ec-4209-b360-fcd275672407` | PASS |
| AUTH-01 | Admin/API | Login inválido | `POST /v1/admin/auth/login` com payload inválido | HTTP 422 + `error.code=VALIDATION_ERROR` + `meta.traceId` | 2026-04-05 local: 422, `code=VALIDATION_ERROR`, `traceId=53750f4b-077d-4f0f-abaf-4195d83a56e8` | PASS |
| AUTH-02 | Admin/API | Credencial inválida | login com senha incorreta | HTTP 401 + `error.code=UNAUTHENTICATED` | 2026-04-05 local: 401, `code=UNAUTHENTICATED`, `traceId=a07b5dd3-18fd-45ac-9823-3e8192886ccd` | PASS |
| AUTH-03 | Admin/API | Login válido | login com credencial bootstrap válida | HTTP 200 + cookie de sessão + `data.user` + `meta.traceId` | 2026-04-05 local: 200, user `admin@local.test`, `traceId=a81683f6-1b3c-4778-bf5a-30c461d553c9` | PASS |
| AUTH-04 | Admin/API | Leitura de sessão ativa | `GET /v1/admin/auth/session` com cookie válido | HTTP 200 + usuário autenticado + `meta.traceId` | 2026-04-05 local: 200, sessao ativa, `traceId=e5bf9ae2-b33c-41fa-b96e-43bea7933fe3` | PASS |
| AUTH-05 | Admin/API | Sessão ausente/expirada | `GET /v1/admin/auth/session` sem cookie | HTTP 401 + `error.code=SESSION_EXPIRED` | 2026-04-05 local: 401, `code=SESSION_EXPIRED`, `traceId=73669a14-899e-44a8-9d5a-bf6c980b43b1` | PASS |
| AUTH-06 | Admin/API | Logout idempotente | `POST /v1/admin/auth/logout` com e sem cookie | HTTP 200 nos dois casos + `data.success=true` | 2026-04-05 local: 200 com/sem cookie, `traceId=563ef627-767b-4c5f-a6e3-c0d6685a5018` e `7623ce8e-40c6-4ccb-ad26-a3be47bffa29` | PASS |
| ADM-01 | Admin | Redirect de entrada | abrir `http://localhost:3001/` sem sessão | redireciona para `/painel/login` | 2026-04-05 local (runtime limpo): `GET /` retornou `307` com `location=/painel/login?next=%2Fpainel%2Fpublicacoes`; smoke verde (`ADMIN-LOGIN` 200) | PASS |
| ADM-02 | Admin | Pós-login | autenticar no login | redireciona para `/painel/publicacoes` | 2026-04-05 local: validado com browser real headless (Playwright) via submit de formulário em `/painel/login?next=%2Fpainel%2Fpublicacoes`, URL final `http://localhost:3001/painel/publicacoes` e presença de marcadores de listagem (`hasListMarkers=true`), conforme registro consolidado no QA-08 | PASS |
| ADM-03 | Admin | Listagem editorial | acessar listagem | lista carrega sem erro fatal; paginação/filtros funcionam | 2026-04-05 local: `GET /painel/publicacoes` com sessão autenticada retornou 200 e conteúdo de listagem identificado | PASS |
| ADM-04 | Admin | Edição de publicação | abrir `/painel/publicacoes/:id/editar` e salvar alteração | persistência sem erro fatal + feedback de sucesso | 2026-04-05 local: `PATCH /v1/admin/publications/pub-001` retornou 200, `status=published`, `traceId=a3ca6d87-b1fd-4864-a9da-c2fb4b0651e4` | PASS |
| ADM-05 | Admin | Transição de status | executar transição editorial válida | status atualizado sem quebra de contrato | 2026-04-05 local: `PATCH /v1/admin/publications/pub-001/status` com `archived` retornou 200, `status=archived`, `traceId=ac872ac3-4125-4a2f-ba9e-be8d01ca8646` | PASS |
| PUB-01 | Web | Home pública | abrir `http://localhost:3000/` | render sem erro fatal + bloco editorial visível | 2026-04-05 local (runtime limpo): `GET /` retornou 200 e smoke marcou `WEB-HOME` PASS | PASS |
| PUB-02 | Web | Listagem pública | abrir `/publicacoes` | listagem carrega + estados coerentes | 2026-04-05 local (runtime limpo): `GET /publicacoes` retornou 200 e smoke marcou `WEB-PUBLICACOES` PASS | PASS |
| PUB-03 | Web | Busca/filtro/página | usar querystring em `/publicacoes` (`q`, `page`, `pageSize`, etc.) | resultado coerente + paginação consistente | 2026-04-05 local: `GET /publicacoes?q=inteligencia&page=1&pageSize=1` retornou 200 com conteúdo de listagem | PASS |
| PUB-04 | Web | Detalhe por slug válido | abrir `/publicacoes/<slug-existente>` | conteúdo abre + metadata coerente | 2026-04-05 local: `GET /publicacoes/inteligencia-relacional-eixo-presenca-institucional` retornou 200 com conteúdo do artigo | PASS |
| PUB-05 | Web | Detalhe inválido | abrir `/publicacoes/<slug-invalido>` | comportamento de not found sem crash | 2026-04-05 local: `GET /publicacoes/slug-inexistente-qa-xyz` retornou 404 com tela de not found sem crash | PASS |
| CT-01 | Contrato | Erro padronizado em query inválida | chamar listagem pública com query inválida | HTTP 422 + `VALIDATION_ERROR` + `meta.traceId` | 2026-04-05 local: 422 em `/v1/public/publications?page=abc`, `code=VALIDATION_ERROR`, `traceId=30ee37a7-7960-4342-a15f-678174529823` | PASS |
| CT-02 | Contrato | Coerência de trace | validar múltiplas respostas API | todas têm `meta.traceId` e header `x-trace-id` quando aplicável | 2026-04-05 local: validado em `/health`, `/ready`, auth e erros (headers + body com `traceId`) | PASS |

## 7. Roteiro rápido de execução manual
1. iniciar API: `pnpm dev:api`
2. iniciar Web: `pnpm dev:web`
3. iniciar Admin: `pnpm dev:admin`
4. executar bloco API (API-01..API-04)
5. executar bloco Auth (AUTH-01..AUTH-06)
6. executar bloco Admin (ADM-01..ADM-05)
7. executar bloco Web público (PUB-01..PUB-05)
8. executar checagens contratuais finais (CT-01..CT-02)

## 8. Regra de aprovação
A homologação funcional deste ciclo só é aprovada quando:
1. todos os itens críticos (`API-*`, `AUTH-*`, `ADM-*`, `PUB-*`, `CT-*`) estiverem em `PASS`
2. não houver `FAIL` aberto sem plano de correção
3. cada `PASS` tiver evidência anexada
4. os cenários de erro preservarem envelope padronizado com `meta.traceId`

## 9. Registro de execução desta rodada
Data: 2026-04-05
Ambiente: local
Executor: IA + operador do ciclo
Commit/versão: v2.0 (estado local)

Resumo:
1. PASS:
- API-01, API-02, API-03, API-04
- AUTH-01, AUTH-02, AUTH-03, AUTH-04, AUTH-05, AUTH-06
- ADM-01, ADM-03, ADM-04, ADM-05
- PUB-01, PUB-02, PUB-03, PUB-04, PUB-05
- CT-01, CT-02
2. FAIL:
- nenhum aberto apos saneamento operacional da rodada
3. PENDENTE:
- nenhum
4. Próxima ação:
- manter execução de workflows CI para fechamento de `C-01..C-05`;
- atualizar checklist de release conforme coleta remota dos workflows.

## 10. Trilha objetiva para fechar pendências desta versão

### API-03 (ready degradado)
1. Fechado nesta rodada via teste automatizado dedicado da rota:
- `apps/api/src/routes/health.test.ts`
- caso `returns 503 on /ready when blocking dependency fails`.
2. Resultado:
- cenário degradado bloqueante validado com retorno `503`;
- `error.code=SERVICE_UNAVAILABLE`.

### ADM-02 até ADM-05 (painel)
1. `ADM-02`, `ADM-03`, `ADM-04` e `ADM-05` fechados com evidência objetiva.
2. Evidências desta rodada:
- pós-login (`ADM-02`): browser real headless com redirect final para `/painel/publicacoes`;
- listagem: HTTP 200 em `/painel/publicacoes`;
- edição: HTTP 200 em `PATCH /v1/admin/publications/pub-001`;
- transição: HTTP 200 + `status=archived` em `PATCH /v1/admin/publications/pub-001/status`.

### PUB-03 até PUB-05 (web público)
1. Fechados nesta rodada com evidência objetiva:
- `PUB-03`: HTTP 200 em `/publicacoes?q=inteligencia&page=1&pageSize=1`;
- `PUB-04`: HTTP 200 em slug válido;
- `PUB-05`: HTTP 404 em slug inválido, sem crash.

## 11. Critério de fechamento deste documento
Este checklist só muda para fechado quando:
1. todos os itens críticos (`API-*`, `AUTH-*`, `ADM-*`, `PUB-*`, `CT-*`) estiverem em `PASS` com evidência;
2. não houver regressão em itens já `PASS`;
3. o resumo final desta página estiver alinhado com `QA-02` e `infra/ci/RELEASE-EVIDENCE-CHECKLIST.md`.
