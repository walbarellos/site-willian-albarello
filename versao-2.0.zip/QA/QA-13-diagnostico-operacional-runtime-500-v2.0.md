# QA-13 — Diagnostico Operacional de Runtime 500 v2.0

## 1. Objetivo
Registrar evidencia tecnica objetiva sobre os erros `500` observados em `web/admin` na rodada v2.0 e separar causa operacional de causa de codigo.

## 2. Contexto do incidente
Durante a rodada de QA:
1. `GET http://127.0.0.1:3000/` -> `500`;
2. `GET http://127.0.0.1:3000/publicacoes` -> `500`;
3. `GET http://127.0.0.1:3001/painel/login` -> `500`.

Esses resultados foram usados corretamente para bloquear liberacao sem ressalvas no estado da rodada.

## 3. Reproducao controlada adicional
Foi executada validacao isolada com novas instancias de debug:
1. web: `pnpm --filter @william-albarello/web exec next dev -p 3100`
2. admin: `pnpm --filter @william-albarello/admin exec next dev -p 3101`
3. chamadas de verificacao:
- `curl http://127.0.0.1:3100/`
- `curl http://127.0.0.1:3100/publicacoes`
- `curl http://127.0.0.1:3101/painel/login`

Resultado:
1. todas as rotas retornaram `200`;
2. conteudo HTML completo renderizado;
3. sem erro fatal de runtime nessas instancias limpas.

## 4. Leitura tecnica
A diferenca entre:
1. `3000/3001` (erro `500`) e
2. `3100/3101` (resposta `200`)

indica **forte evidencia de causa operacional local** (processos stale, estado antigo em memoria, processo de start inconsistente), e nao prova imediata de regressao estrutural no codigo atual.

## 5. Impacto na decisao de release
1. O bloqueio vigente permanece correto enquanto houver alternancia entre estado verde e retorno a `500`.
2. Este diagnostico reduz risco de retrabalho em refatoracao desnecessaria de codigo.
3. A proxima acao obrigatoria e estabilizar o runtime entre `smoke` e `release-check`.

## 6. Protocolo de saneamento recomendado
1. encerrar processos atuais de `web/admin/api` da sessao anterior;
2. reiniciar stack em ambiente limpo:
- `pnpm dev:api`
- `pnpm dev:web`
- `pnpm dev:admin`
3. reexecutar:
- `bash infra/scripts/smoke.sh`
- `bash infra/scripts/release-check.sh`
4. atualizar `QA-01`, `QA-02` e `infra/ci/RELEASE-EVIDENCE-CHECKLIST.md` conforme nova rodada.
5. repetir o ciclo ate obter consistencia sem regressao imediata no passo de `release-check`.

## 7. Criterio de confirmacao
Considerar incidente operacional resolvido quando:
1. `3000/3001/3002` responderem de forma consistente sem `500`;
2. `smoke.sh` fechar em `PASS=10 FAIL=0`;
3. `release-check.sh` concluir sem regressao para `500` em `/`, `/publicacoes` e `/painel/login`;
4. item pendente de QA funcional (`ADM-02`) executado com evidencia.
4. itens pendentes de QA funcional remanescentes serem executados com evidencia (`ADM-02`).

## 8. Conclusao
No estado atual, o incidente operacional de `500` em `web/admin` foi resolvido na rodada final de estabilizacao: `runtime-reset` executado, `smoke` verde e `release-check` verde sem regressao imediata nas rotas basicas. A liberacao geral da versao segue bloqueada apenas por pendencias funcionais/evidenciais remanescentes fora deste incidente operacional.

## 9. Status operacional do incidente (fechamento)
Classificacao obrigatoria para este documento:
1. `RESOLVIDO` = nao reproduz mais, com consistencia entre `smoke` e `release-check`;
2. `MITIGADO` = reduzido, mas ainda com risco de regressao;
3. `REPRODUZIVEL` = ainda reproduz em condicoes controladas.

Status atual desta versao:
- **RESOLVIDO (operacional)**.

Justificativa:
1. `runtime-reset` foi executado antes da rodada final;
2. `smoke.sh` fechou em `PASS=10 FAIL=0`;
3. `release-check.sh` concluiu verde com smoke final verde;
4. nao houve regressao imediata de `500` nas rotas basicas apos a rodada final.

## 10. Evidencia minima para mudar o status para RESOLVIDO
Para trocar de `MITIGADO` para `RESOLVIDO`, exigir:
1. execucao documentada de `runtime-reset.sh` na rodada final;
2. `smoke.sh` verde (`PASS=10 FAIL=0`) apos subida limpa;
3. `release-check.sh` verde sem regressao posterior de `500` em web/admin;
4. repeticao de verificacao HTTP minima:
   - `GET /` (web) = 200
   - `GET /publicacoes` (web) = 200
   - `GET /painel/login` (admin) = 200
5. atualizacao cruzada de:
   - `QA-08` (registro de evidencias),
   - `QA-11` (rastreabilidade),
   - `infra/ci/RELEASE-EVIDENCE-CHECKLIST.md` (bloqueios),
   - `QA-04` (ato formal).

## 11. Regra de decisao vinculada
Enquanto este documento estiver em `MITIGADO` ou `REPRODUZIVEL`:
1. manter estado de release como `BLOQUEAR`;
2. nao emitir `LIBERAR` no `QA-04`.

Com status `RESOLVIDO`, a decisao de release ainda depende do fechamento das pendencias funcionais e evidenciais restantes (`ADM-02` e `C-01..C-05`).
