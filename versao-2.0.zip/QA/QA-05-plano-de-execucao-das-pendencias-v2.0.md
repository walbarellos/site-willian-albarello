# QA-05 — Plano de Execucao das Pendencias v2.0

## 1. Objetivo
Definir a execucao operacional, em ordem fixa, para eliminar as pendencias bloqueantes da v2.0 e permitir reemissao do ato final com decisao `LIBERAR`.

## 2. Base de referencia
1. `QA/QA-01-checklist-de-homologacao-funcional.md`
2. `QA/QA-02-matriz-de-gates-ci-e-deploy-readiness.md`
3. `QA/QA-04-ato-final-de-liberacao-v2.0.md`
4. `infra/ci/RELEASE-EVIDENCE-CHECKLIST.md`
5. `QA/QA-08-registro-de-evidencias-de-execucao-v2.0.md`
6. `QA/QA-11-matriz-de-rastreabilidade-das-evidencias-v2.0.md`
7. `QA/QA-13-diagnostico-operacional-runtime-500-v2.0.md`

## 3. Pendencias bloqueantes atuais
1. `C-01..C-05` pendentes (coleta de status dos workflows CI da rodada)

## 4. Regra de execucao
1. executar em blocos, sem pular ordem;
2. registrar evidencia objetiva por item (status, traceId, log/screenshot quando aplicavel);
3. atualizar imediatamente QA-01 e QA-02 ao fim de cada bloco;
4. nao converter item para PASS sem evidencia real.

## 5. Sequencia operacional

## Bloco A — Preparacao de ambiente
1. executar `bash infra/scripts/runtime-reset.sh`;
2. subir API (`3002`), Web (`3000`) e Admin (`3001`) com `bash infra/scripts/dev-up.sh`;
3. validar disponibilidade das tres aplicacoes;
4. registrar A-03 e A-04 no checklist de release.

Criterio de saida do bloco:
- A-03 e A-04 marcados como concluidos com evidencia.
- sem erro `500` nas rotas basicas (`/`, `/publicacoes`, `/painel/login`).

## Bloco B — Estabilizacao operacional web/admin
1. identificar condicao que reabre `500` apos `release-check`;
2. aplicar ajuste operacional/codigo necessario para eliminar regressao;
3. validar manualmente as tres rotas basicas afetadas;
4. registrar evidencia tecnica (comando/log/resultado).

Criterio de saida do bloco:
- rotas basicas de web/admin respondendo `200`;
- `smoke` verde apos restart limpo;
- `release-check` sem regressao imediata para `500` nas rotas basicas;
- B-05 marcado como concluido.

## Bloco C — API-03 (ready degradado)
1. **Concluido** na rodada atual via teste dedicado:
- `apps/api/src/routes/health.test.ts`
- caso `returns 503 on /ready when blocking dependency fails`.

Criterio de saida do bloco:
- `API-03` em PASS com evidencia registrada.

## Bloco D — Fluxo ADM (ADM-01..ADM-05)
1. **concluido**: validar pos-login para listagem (`ADM-02`) em browser real;
2. **concluido**: listagem editorial (`ADM-03`);
3. **concluido**: edicao e persistencia (`ADM-04`);
4. **concluido**: transicao de status editorial (`ADM-05`).

Criterio de saida do bloco:
- ADM-02..ADM-05 em PASS com evidencias.

## Bloco E — Fluxo PUB (PUB-01..PUB-05)
1. **Concluido**: busca/filtro/pagina (`PUB-03`);
2. **Concluido**: detalhe por slug valido (`PUB-04`);
3. **Concluido**: detalhe por slug invalido/not found (`PUB-05`).

Criterio de saida do bloco:
- PUB-03..PUB-05 em PASS com evidencias.

## Bloco F — Checklist de release local
1. executar `bash infra/scripts/release-check.sh` (B-03);
2. executar `bash infra/scripts/smoke.sh` (B-04);
3. registrar evidencias no checklist.

Criterio de saida do bloco:
- B-03 e B-04 em PASS com estabilidade comprovada (sem regressao para `500` entre as execucoes).

## Bloco G — Evidencia de workflows CI
1. coletar status dos workflows:
- `scaffold-bootstrap.yml`
- `api-contract.yml`
- `api-docs.yml`
- `api-breaking-change.yml`
- `deploy-readiness.yml`
2. registrar C-01..C-05 no checklist.

Criterio de saida do bloco:
- C-01..C-05 em PASS com referencia de status.

## Bloco H — Fechamento documental
1. atualizar QA-01 com todos os itens criticos em PASS;
2. atualizar QA-02 para G-01..G-20 em VERDE;
3. atualizar QA-08 com evidencias finais da rodada;
4. atualizar QA-11 sem pendencias de rastreabilidade (`D-04`);
5. atualizar QA-13 para status `RESOLVIDO`;
6. atualizar `RELEASE-EVIDENCE-CHECKLIST` sem pendencias bloqueantes;
7. reemitir `QA-04` com decisao final (`E-05`).

Criterio de saida do bloco:
- decisao final `LIBERAR` documentada.

## 6. Matriz de evidencia minima por item
1. API/Contrato: status HTTP + body + `traceId`;
2. Admin/Web: screenshot ou log de navegacao + resultado esperado;
3. Gates locais: saida do comando com status 0;
4. Gates CI: status do workflow e timestamp da rodada.

## 7. Criterio final de sucesso
Plano concluido quando:
1. QA-01 sem pendencias em itens criticos;
2. QA-02 com 100% dos gates obrigatorios em VERDE;
3. checklist de release sem item bloqueante pendente;
4. QA-04 reemitido com `DECISAO: LIBERAR`.
5. `infra/scripts/smoke.sh` com `PASS=10 FAIL=0`;
6. QA-13 classificado como `RESOLVIDO`.

Estado desta rodada:
1. itens 4, 5 e 6 ja atendidos;
2. itens 1, 2 e 3 dependem apenas de coletar `C-01..C-05`.

## 8. Responsabilidade de execucao
Executor primario: IA + operador do ciclo.

Regra de auditoria:
- qualquer divergia entre documento e estado fisico invalida o fechamento e exige retorno para correcao.
