# Release Evidence Checklist — `personal-site`

## Objetivo
Checklist soberano de evidencias minimas para congelamento de versao, evitando release com falso positivo.

## Regra de uso
1. preencher este checklist no fechamento de cada versao;
2. anexar evidencias objetivas (logs, status de workflow, relatorio da versao);
3. qualquer item bloqueante sem evidencia => release bloqueado.
4. a decisao final deve ser binaria (`LIBERAR` ou `BLOQUEAR`) e coerente com `QA-04`.

## Convencao de bloqueio
- **Bloqueante:** sem conclusao => release bloqueado.
- **Condicional:** pode seguir apenas com justificativa documentada no relatorio final.

## Bloco A — Pre-condicoes
- [x] A-01 `pnpm install --frozen-lockfile` executado sem erro.
- [x] A-02 `.env` valido no ambiente de execucao.
- [x] A-03 Servicos locais acessiveis para smoke (api/web/admin) quando aplicavel. **(BLOQUEANTE)**
- [x] A-04 `bash infra/scripts/runtime-reset.sh` executado antes da rodada final de smoke/release-check. **(BLOQUEANTE)**

Evidencias:
- A-01: dependencia instalada e workspace funcional na rodada v2.0.
- A-02: `.env` presente e utilizado para execucao local.
- A-03: consolidado em rodada final com `smoke` verde (`PASS=10 FAIL=0`) e servicos acessiveis.
- A-04: consolidado em rodada final com execucao de `runtime-reset.sh` antes de smoke/release-check.

## Bloco B — Gates tecnicos locais
- [x] B-01 `pnpm test:ci` verde.
- [x] B-02 `pnpm verify:hardening` verde.
- [x] B-03 `bash infra/scripts/release-check.sh` verde (ou `SKIP_SMOKE=1` apenas no contexto CI). **(BLOQUEANTE)**
- [x] B-04 `bash infra/scripts/smoke.sh` verde para readiness operacional local. **(BLOQUEANTE)**
- [x] B-05 Sem regressao imediata de runtime apos `release-check` (nao voltar a `500` em web/admin). **(BLOQUEANTE)**

Evidencias:
- B-01: executado na rodada v2.0 com sucesso (contracts e API verdes).
- B-02: executado na rodada v2.0 com sucesso (build/typecheck shared/api/web/admin).
- B-03: consolidado em rodada final; `release-check` concluido com sucesso apos ajuste do pre-smoke (`runtime-reset` com restart).
- B-04: consolidado em rodada final com `smoke` verde (`PASS=10 FAIL=0`).
- B-05: consolidado na rodada final sem regressao imediata de `500` apos `release-check`.

## Bloco C — Gates de workflow (CI)
- [ ] C-01 `scaffold-bootstrap.yml` verde. **(BLOQUEANTE)**
- [ ] C-02 `api-contract.yml` verde. **(BLOQUEANTE)**
- [ ] C-03 `api-docs.yml` verde. **(BLOQUEANTE)**
- [ ] C-04 `api-breaking-change.yml` verde (especialmente em PR). **(BLOQUEANTE)**
- [ ] C-05 `deploy-readiness.yml` verde. **(BLOQUEANTE)**

Evidencias:
- Workflows existem e estao versionados no repositorio.
- Tentativas de coleta nesta rodada:
  1. consulta via conector GitHub para endpoints de actions/runs indisponivel no formato suportado;
  2. `gh` CLI nao disponivel no ambiente (`command not found`);
  3. consulta por badges de workflow (`https://github.com/walbarellos/personal-site/actions/workflows/<workflow>/badge.svg`) retornou `Not Found` para os 5 workflows.
- Status online da rodada permanece nao coletado nesta execucao local.

## Bloco D — Gates funcionais e contratuais (QA)
- [x] D-01 `QA-01` atualizado com evidencias de homologacao.
- [x] D-02 `QA-02` atualizado com status dos gates da rodada.
- [x] D-03 Itens criticos `API-*`, `AUTH-*`, `ADM-*`, `PUB-*`, `CT-*` sem FAIL aberto. **(BLOQUEANTE)**
- [x] D-04 `QA-11` atualizado com rastreabilidade completa evidencia -> gate -> decisao. **(BLOQUEANTE)**

Evidencias:
- D-01: atualizado com evidencias reais de PASS parcial e reabertura de falha por instabilidade operacional.
- D-02: atualizado na rodada com G-01..G-20 em VERDE; bloqueio atual deslocado apenas para C-01..C-05.
- D-03: concluido apos fechamento de ADM-02 com evidencia de browser headless (Playwright) e QA-01 sem pendencias criticas.
- D-04: rastreabilidade consolidada no QA-11 com vinculo evidencia -> gate -> decisao.

## Bloco E — Documentacao e rastreabilidade da versao
- [x] E-01 Relatorio final da versao gerado e coerente com estado fisico do repo.
- [x] E-02 ZIP da versao gerado sem `node_modules` e caches de build.
- [x] E-03 Mudancas operacionais refletidas em `infra/` e `infra/ci` quando aplicavel.
- [x] E-04 Handoff de continuidade registrado para o proximo ciclo.
- [x] E-05 `QA-04` reemitido com decisao binaria coerente com este checklist (`LIBERAR` ou `BLOQUEAR`). **(BLOQUEANTE)**

Evidencias:
- E-01: `RELATORIO-FINAL-V2.0.md`.
- E-02: `versao-2.0.zip` validado sem `node_modules`, `.env` e `.codex`.
- E-03: docs de `infra/ci` e auditoria consolidada atualizados.
- E-04: `QA/QA-03-auditoria-consolidada-final.md` gerado.
- E-05: `QA/QA-04-ato-final-de-liberacao-v2.0.md` reemitido com decisao binaria `BLOQUEAR`.

## Regra de bloqueio
Bloquear release se qualquer item bloqueante estiver pendente:
1. C-01..C-05

## Registro da rodada
Data: 2026-04-05
Versao alvo: 2.0
Executor: IA + operador do ciclo
Branch/commit: estado local de trabalho

Resumo:
1. Itens concluidos:
- A-01, A-02
- A-03, A-04
- B-01, B-02, B-03, B-04, B-05
- D-01, D-02, D-03, D-04
- E-01, E-02, E-03, E-04, E-05
2. Itens pendentes:
- C-01..C-05
3. Bloqueios:
- ausencia de status online de workflows C-01..C-05 nesta rodada local
4. Decisao final (`LIBERAR` / `BLOQUEAR`):
- BLOQUEAR (ate fechamento dos pendentes bloqueantes)
